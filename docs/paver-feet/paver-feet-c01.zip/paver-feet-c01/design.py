"""C01 — 3 inch square TPU paver corner foot. Dimensions in mm."""
import numpy as np

REVISION='C01'
BASE_WIDTH=76.2
SEAT_Z=15.0
STOP_Z=2.0
PAVER_Z=38.0  # height added below slab, 1.496 in
PLATFORM_TOP=PAVER_Z-SEAT_Z
PAD_HALF=24.0
PAD_CHAMFER=6.0
RIM_IN=33.5
RIM_OUT=36.0
RIB_WIDTH=7.2
RIB_HEIGHT=8.8
SWEEP_DEG=12.0
LIP_HEIGHT=0.0  # operator requested a flat pad, no locating lips
PAVER_CORNER=-BASE_WIDTH/2  # entire foot fits beneath paver
PAVER_SIDE_REFERENCE=398.78  # Lowe's reference product: 15.7 in actual
PAVER_THICKNESS_REFERENCE=45.0  # operator estimate, not a fit requirement
PAVER_MASS=36*.45359237
PRINTER_MASS=12.95
NOMINAL_MASS=PAVER_MASS+PRINTER_MASS
MAX_MASS=35.0
MIN_MODULUS=5.0  # assumed design low end, not a material guarantee
REF_MODULUS=9.8
CORNER_FACTOR=1.3
SAG_DRIFT=1.5
RETAINED_GAP=3.0
COMPRESSION_ALLOWANCE=.8  # unmodeled pad/base compression and fit reserve
ECCENTRICITY=2.0  # illustrative local load offset toward paver interior

def pad_outline():
    a=PAD_HALF;c=PAD_CHAMFER
    return [(-a+c,-a),(a-c,-a),(a,-a+c),(a,a-c),(a-c,a),(-a+c,a),(-a,a-c),(-a,-a+c)]

def centerline(index,segments=64,sweep=None):
    t=np.linspace(0,1,segments+1)
    r=PAD_HALF+(RIM_IN-PAD_HALF)*t
    s=SWEEP_DEG if sweep is None else sweep
    angle=np.deg2rad(index*90+s*(3*t*t-2*t*t*t))
    return np.column_stack((r*np.cos(angle),r*np.sin(angle)))

def rib_outline(index):
    p=centerline(index)
    p=np.vstack((p[0]-1.5*(p[1]-p[0])/np.linalg.norm(p[1]-p[0]),p,
                 p[-1]+1.2*(p[-1]-p[-2])/np.linalg.norm(p[-1]-p[-2])))
    t=np.gradient(p,axis=0);t/=np.linalg.norm(t,axis=1)[:,None]
    n=np.column_stack((-t[:,1],t[:,0]))
    return np.vstack((p+RIB_WIDTH/2*n,(p-RIB_WIDTH/2*n)[::-1]))
