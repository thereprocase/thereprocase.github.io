"""P01 isolation review. Linear frame/surrogate models, not an acoustic prediction.

Run beside design.py and analyze.py. Output is in review-output/.
All ball stiffnesses, damping ratios, creep multipliers and mass distributions
below are explicitly hypothetical sensitivity inputs, not measured properties.
"""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.linalg import eigh
from analyze import rib_stiffness, solve
import design as d

OUT=Path('review-output'); OUT.mkdir(exist_ok=True)

def skew(v):
    x,y,z=v
    return np.array([[0,-z,y],[z,0,-x],[-y,x,0]])

def frame_end(points,b,h,E=9.8,nu=.49):
    """6x6 inner-end stiffness, outer end fixed, interior DOFs condensed."""
    n=len(points); K=np.zeros((6*n,6*n)); G=E/(2*(1+nu)); A=b*h
    a,c=max(b,h),min(b,h)
    J=a*c**3*(1/3-.21*c/a*(1-c**4/(12*a**4)))
    for i,(p,q) in enumerate(zip(points[:-1],points[1:])):
        L=np.linalg.norm(q-p); x,y=(q-p)/L
        R=np.array([[x,y,0],[-y,x,0],[0,0,1]])
        T=np.kron(np.eye(4),R); k=np.zeros((12,12))
        for ids,coefficient in [([0,6],E*A/L),([3,9],G*J/L)]:
            k[np.ix_(ids,ids)]=coefficient*np.array([[1,-1],[-1,1]])
        for ids,I,sign in [([1,5,7,11],h*b**3/12,1),([2,4,8,10],b*h**3/12,-1)]:
            phi=12*E*I/((5/6)*G*A*L**2); s=sign
            B=E*I/(L**3*(1+phi))*np.array([
                [12,s*6*L,-12,s*6*L],
                [s*6*L,(4+phi)*L*L,-s*6*L,(2-phi)*L*L],
                [-12,-s*6*L,12,-s*6*L],
                [s*6*L,(2-phi)*L*L,-s*6*L,(4+phi)*L*L]])
            k[np.ix_(ids,ids)]=B
        ix=np.arange(6*i,6*i+12);K[np.ix_(ix,ix)]+=T.T@k@T
    free=np.arange(6,6*n-6)
    return K[:6,:6]-K[:6,free]@np.linalg.solve(K[np.ix_(free,free)],K[free,:6])

def path(angle,sweep,n=24):
    t=np.linspace(0,1,n+1);r=d.CUP_R+(d.RIM_IN-d.CUP_R)*t
    a=np.deg2rad(angle+sweep*(3*t*t-2*t*t*t))
    return np.column_stack((r*np.cos(a),r*np.sin(a)))

def foot_matrix(width=4,height=10,sweeps=(18,26,34),n=24):
    # Reference point is the ball center; frames lie at the rib mid-height.
    ball_lever=d.CUP_FLOOR+d.BALL_D/2-height/2
    K=np.zeros((6,6))
    ends={s:frame_end(path(0,s,n),width,height) for s in set(sweeps)}
    for i in range(6):
        p=path(i*60,sweeps[i%len(sweeps)],n)
        B=np.eye(6);B[:3,3:]=-skew([*p[0],-ball_lever])
        c,s=np.cos(i*np.pi/3),np.sin(i*np.pi/3)
        R=np.array([[c,-s,0],[s,c,0],[0,0,1]]);Q=np.kron(np.eye(2),R)
        K+=B.T@Q@ends[sweeps[i%len(sweeps)]]@Q.T@B
    K=(K+K.T)/2
    # Ball approximated as transmitting forces but no moments.
    trans=K[:3,:3]-K[:3,3:]@np.linalg.solve(K[3:,3:],K[3:,:3])
    return K,(trans+trans.T)/2

def transmissibility(f,fn,zeta):
    r=np.asarray(f)/fn
    return np.sqrt((1+(2*zeta*r)**2)/((1-r*r)**2+(2*zeta*r)**2))

def series(K,kxy,kz):
    return np.linalg.inv(np.linalg.inv(K)+np.diag([1/kxy,1/kxy,1/kz]))

def printer_modes(Kfoot,mass=12.95,rotate_feet=False):
    # Exploratory geometry: 320 mm square foot spacing, COM 230 mm above supports.
    a=.160;h=.230;body_w=.389;body_d=.389;body_h=.458
    K=np.zeros((6,6))
    for i,(x,y) in enumerate([(-a,-a),(a,-a),(a,a),(-a,a)]):
        angle=i*np.pi/2 if rotate_feet else 0
        c,s=np.cos(angle),np.sin(angle);R=np.array([[c,-s,0],[s,c,0],[0,0,1]])
        B=np.column_stack((np.eye(3),-skew([x,y,-h])))
        K+=B.T@(R@Kfoot@R.T*1000)@B
    # Initial upward support forces introduce a destabilizing gravity stiffness.
    K[3,3]-=mass*9.80665*h;K[4,4]-=mass*9.80665*h
    inertia=mass/12*np.array([body_d**2+body_h**2,body_w**2+body_h**2,body_w**2+body_d**2])
    M=np.diag([mass,mass,mass,*inertia])
    values,vectors=eigh(K,M)
    return dict(frequencies_Hz=(np.sqrt(np.maximum(values,0))/(2*np.pi)).tolist(),
                unstable=bool(np.any(values<=0)),gravity_stiffness_included=True)

def candidate_sweep():
    results=[]
    # Analyze only 3 unique ribs; opposite copies have the same vertical stiffness.
    for sw in [(18,26,34),(18,18,18),(26,26,26),(34,34,34)]:
        for b in [3.,3.5,4.,4.5,5.]:
            for h in np.arange(6,12.01,.5):
                rs=[rib_stiffness(path(0,s,20),b,float(h),9.8) for s in sw]
                k=2*sum(r['k'] for r in rs)
                worst=20*9.80665/4*1.3/(k*7.4/9.8)
                nominal=12.95*9.80665/4/k
                for seat in [14.,18.,24.]:
                    for creep in [1.,1.5,2.]:
                        clearance=seat-5-worst*creep
                        results.append(dict(sweeps=list(sw),width_mm=b,height_mm=float(h),seat_mm=seat,
                            tpu_height_mm=seat+d.CUP_H,ball_top_mm=seat+d.CUP_FLOOR+d.BALL_D,
                            k_N_mm=k,nominal_sag_mm=nominal,
                            fn_Hz=float(np.sqrt(4*k*1000/12.95)/(2*np.pi)),
                            worst_initial_sag_mm=worst,assumed_creep_factor=creep,
                            residual_clearance_mm=clearance,passes_clearance=bool(clearance>=3),
                            nominal_max_bending_strain=nominal*max(r['bending_strain_per_mm'] for r in rs)))
    return results

def main():
    # Independent 3D implementation reproduces the existing out-of-plane solver.
    K,trans=foot_matrix(n=40)
    kv,_=solve(40)
    assert abs(K[2,2]/kv-1)<1e-8
    assert np.all(np.linalg.eigvalsh(K)>0)
    K2,t2=foot_matrix(n=80)
    convergence=float(np.linalg.norm(t2-trans)/np.linalg.norm(t2))
    assert convergence<.005
    # Check exact axial, in-plane and out-of-plane straight cantilever solutions.
    p=np.column_stack((np.linspace(0,30,25),np.zeros(25)))
    compliance=np.linalg.inv(frame_end(p,4,10))
    E=9.8;G=E/(2*1.49);A=40
    expected=[30/(E*A),30**3/(3*E*(10*4**3/12))+30/((5/6)*G*A),
              30**3/(3*E*(4*10**3/12))+30/((5/6)*G*A)]
    assert np.max(abs(np.diag(compliance)[:3]/expected-1))<1e-8
    eigxy=np.linalg.eigvalsh(trans[:2,:2]);_,equal=foot_matrix(sweeps=(26,26,26),n=40)
    sweep=candidate_sweep()
    winners=[]
    for seat in [14.,18.,24.]:
        for creep in [1.,1.5,2.]:
            feasible=[c for c in sweep if c['seat_mm']==seat and c['assumed_creep_factor']==creep and c['passes_clearance']]
            if feasible:
                winners.append(min(feasible,key=lambda c:c['k_N_mm']))
    fn=np.sqrt(4*kv*1000/12.95)/(2*np.pi)
    force_cases=[]
    for z in [.05,.15,.30]:
        for f in [5.,10.,15.,20.,30.,50.,80.]:
            T=float(transmissibility(f,fn,z))
            force_cases.append(dict(f_Hz=f,zeta_assumed=z,T_force=T,force_ratio_dB=float(20*np.log10(T))))
    balls=[];modes=[]
    for kz in [5.,20.,100.]:
        keff=1/(1/kv+1/kz)
        new_fn=np.sqrt(4*keff*1000/12.95)/(2*np.pi)
        ball_fn=np.sqrt(4*kz*1000/12.95)/(2*np.pi)
        balls.append(dict(assumed_ball_kz_N_mm=kz,ball_only_fn_Hz=float(ball_fn),combined_fn_Hz=float(new_fn),
            frequency_reduction_percent=float(100*(1-new_fn/ball_fn)),combined_k_N_mm=keff))
        for kxy in [1.,5.,20.]:
            k=series(trans,kxy,kz)
            modes.append(dict(ball_kz_assumed=kz,ball_kxy_assumed=kxy,
                              all_same_orientation=printer_modes(k),alternating_90deg=printer_modes(k,rotate_feet=True)))
    report=dict(revision='P01-review-01',baseline_k_N_mm=kv,
        frame_K_ball_center_units_N_mm_rad=K.tolist(),moment_free_translation_K_N_mm=trans.tolist(),
        horizontal_principal_k_N_mm=eigxy.tolist(),horizontal_anisotropy_ratio=float(eigxy[-1]/eigxy[0]),
        equal26_translation_K_N_mm=equal.tolist(),convergence_relative=convergence,
        baseline_fn_Hz=float(fn),baseline_isolation_crossover_Hz=float(fn*np.sqrt(2)),
        force_transmission=force_cases,ball_series_sensitivity=balls,
        hypothetical_rigid_body_modes=modes,sweep_count=len(sweep),candidates=sweep,
        grid_minimum_stiffness_candidates=winners,
        assumptions=dict(mass_kg=12.95,modulus_MPa=9.8,corner_spacing_mm=320,com_above_support_mm=230,
            body_envelope_mm=[389,389,458],mass_distribution='uniform rectangular body, hypothetical',
            damping_ratios=[.05,.15,.30],ball_stiffness='hypothetical; no squash ball measurements',
            creep='multipliers are clearance stress tests, not a material creep law',
            optimization='minimize vertical linear stiffness subject to static clearance; no acoustic spectrum objective'))
    (OUT/'review.json').write_text(json.dumps(report,indent=2))
    plots(report)
    summary={k:v for k,v in report.items() if k not in ['candidates','frame_K_ball_center_units_N_mm_rad','force_transmission','hypothetical_rigid_body_modes']}
    print(json.dumps(summary,indent=2))

def plots(report):
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':160})
    f=np.geomspace(1,100,500);fn=report['baseline_fn_Hz']
    fig,ax=plt.subplots(figsize=(9,5))
    for z,color in zip([.05,.15,.30],['#0000a8','#008e9c','#b87900']):
        ax.semilogx(f,20*np.log10(transmissibility(f,fn,z)),label=f'Assumed damping ratio ζ = {z:.2f}',color=color)
    ax.axhline(0,color='#666',lw=1);ax.axvline(fn,color='#666',ls=':',label=f'P01 foot-only fₙ = {fn:.1f} Hz')
    ax.set(xlabel='Excitation frequency (Hz)',ylabel='Transmitted force / applied force (dB)',
        title='P01: predicted force transmission, not microphone sound reduction',ylim=(-42,25))
    ax.legend(fontsize=9);ax.grid(alpha=.2);fig.text(.12,.015,'12.95 kg · E = 9.8 MPa · rigid single-mass surrogate · excludes ball and table dynamics',fontsize=9)
    fig.tight_layout(rect=[0,.04,1,1]);fig.savefig(OUT/'transmission.png');plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,5))
    for kz,color in zip([5.,20.,100.],['#0000a8','#008e9c','#b87900']):
        kb=report['baseline_k_N_mm']; combined=1/(1/kb+1/kz)
        fball=np.sqrt(4*kz*1000/12.95)/(2*np.pi);fcombined=np.sqrt(4*combined*1000/12.95)/(2*np.pi)
        ax.semilogx(f,20*np.log10(transmissibility(f,fcombined,.15)),color=color,label=f'Ball + foot, ball k = {kz:g} N/mm')
        ax.semilogx(f,20*np.log10(transmissibility(f,fball,.15)),color=color,ls='--',alpha=.55)
    ax.axhline(0,color='#666',lw=1);ax.set(xlabel='Excitation frequency (Hz)',ylabel='Force transmission (dB)',
        title='Sensitivity to unknown ball stiffness',ylim=(-50,22));ax.legend(fontsize=9);ax.grid(alpha=.2)
    fig.text(.12,.015,'Dashed: hypothetical balls alone. Solid: balls + P01. Same ζ = 0.15 assumed for all cases.',fontsize=9)
    fig.tight_layout(rect=[0,.04,1,1]);fig.savefig(OUT/'ball-sensitivity.png');plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,5))
    subset=[c for c in report['candidates'] if c['width_mm']==4 and c['sweeps']==[18,26,34] and c['assumed_creep_factor']==1.5]
    for seat,color in zip([14.,18.,24.],['#0000a8','#008e9c','#b87900']):
        a=[c for c in subset if c['seat_mm']==seat]
        ax.plot([c['height_mm'] for c in a],[c['residual_clearance_mm'] for c in a],color=color,
            label=f'TPU height {seat+d.CUP_H:.1f} mm / ball top {seat+42:g} mm')
    ax.axhline(3,color='#666',ls='--',label='Provisional 3 mm clearance target');ax.axhline(0,color='#a22',lw=1)
    ax.set(xlabel='Rib depth (mm)',ylabel='Remaining stop clearance (mm)',title='Height buys travel; softness consumes it',ylim=(-15,18));ax.legend(fontsize=9);ax.grid(alpha=.2)
    fig.text(.12,.015,'Stress test: 20 kg · 30% corner overload · E = 7.4 MPa · 1.5× assumed sag drift (not a creep prediction)',fontsize=8)
    fig.tight_layout(rect=[0,.04,1,1]);fig.savefig(OUT/'clearance.png');plt.close(fig)

if __name__=='__main__':main()
