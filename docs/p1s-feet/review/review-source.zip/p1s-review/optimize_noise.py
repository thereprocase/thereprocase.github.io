"""P02 constrained geometry + uncertain-property force-transmission sweep.

The objective is a declared surrogate: worst-case 30–100 Hz integrated force
power ratio, with equal uncorrelated forcing power in X/Y/Z. It is NOT a measured
printer spectrum, a microphone dB score, or a claim of a universal optimum.
"""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from noise_review import path,foot_matrix,printer_modes,series
from analyze import rib_stiffness

OUT=Path('review-output');OUT.mkdir(exist_ok=True)
E_LOW=7.4
E_REF=9.8
MASS_MAX=20.
CORNER_FACTOR=1.3
DRIFT=1.5
TRAVEL=12.
RESERVE=3.
K_MIN=MASS_MAX*9.80665/4*CORNER_FACTOR*E_REF/E_LOW*DRIFT/(TRAVEL-RESERVE)

def force_transfer(f,kfoot,kball,mass=12.95,lossfoot=.3,lossball=.3,moving_mass=.020):
    """Two-mass chain, per foot: printer/4 -> ball -> cup -> foot -> ground.

    Stiffness N/mm input; masses kg; complex stiffness loss factors, not viscous
    damping ratios. Moving mass approximates the cup plus part of the ribs.
    """
    w=2*np.pi*np.asarray(f)
    a=np.asarray(kball)*1000*(1+1j*np.asarray(lossball))
    b=np.asarray(kfoot)*1000*(1+1j*np.asarray(lossfoot))
    m=mass/4
    determinant=(a-m*w*w)*(a+b-moving_mass*w*w)-a*a
    return np.abs(a*b/determinant)

def uncertainty_arrays():
    # kb applies horizontally/vertically through separate arrays.
    rows=[]
    for mass in [12.95,20.]:
        for E in [7.4,9.8,15.,26.]:
            for dynamic_ratio in [1.,1.5,2.]:
                for ball_z,ball_xy in [(z,xy) for z in [5.,20.,100.] for xy in [1.,5.,20.]]:
                    for loss_f in [.1,.3,.6]:
                        for loss_b in [.1,.3,.6]:
                            rows.append([mass,E,dynamic_ratio,ball_z,ball_xy,loss_f,loss_b])
    return np.array(rows)

def spectral_score(K,params,f):
    # Sixfold geometry has uncoupled equal horizontal principal stiffnesses.
    mass,E,dyn,bz,bxy,lf,lb=params.T
    k=np.array([*np.linalg.eigvalsh(K[:2,:2]),K[2,2]])
    ball=np.column_stack([bxy,bxy,bz])
    kfoot=k[None,:,None]*E[:,None,None]/E_REF*dyn[:,None,None]
    w=2*np.pi*f[None,None,:]
    a=ball[:,:,None]*1000*(1+1j*lb[:,None,None]);b=kfoot*1000*(1+1j*lf[:,None,None])
    det=(a-mass[:,None,None]/4*w*w)*(a+b-.020*w*w)-a*a
    T2=abs(a*b/det)**2
    power=np.trapezoid(T2.mean(axis=1),f,axis=1)/(f[-1]-f[0])
    worst=int(np.argmax(power))
    return float(power[worst]),worst

def main():
    params=uncertainty_arrays();freq_band=np.linspace(30,100,141)
    all_rows=[];feasible=[]
    # 0.2 mm layer-compatible rib depths; 0.4 mm width increments.
    for sweep in range(18,41,2):
        for width in np.arange(2.8,5.21,.4):
            width=round(float(width),1)
            first=None
            for height in np.arange(6,14.01,.2):
                height=round(float(height),1)
                rib=rib_stiffness(path(0,sweep,24),width,height,E_REF)
                k=6*rib['k']
                row=dict(sweep_deg=sweep,width_mm=width,height_mm=height,kz_N_mm=k,
                    passes_clearance=bool(k>=K_MIN),nominal_bending_strain=31.749/k*rib['bending_strain_per_mm'])
                all_rows.append(row)
                # Avoid selecting a mathematical boundary that disappears when
                # the curved centerline is refined. This is numerical headroom,
                # not a print-tolerance or material safety factor.
                if first is None and k>=K_MIN*1.015:first=row.copy()
            # Deeper ribs at same sweep/width are stiffer; retain first feasible.
            if first:
                _,K=foot_matrix(width=width,height=first['height_mm'],sweeps=(sweep,)*3,n=64)
                if K[2,2]<K_MIN*1.01:continue
                score,worst=spectral_score(K,params,freq_band)
                first.update(kz_N_mm=float(K[2,2]),kxy_N_mm=float(K[0,0]),
                    worst_band_power_ratio=score,worst_band_force_dB=float(10*np.log10(score)),
                    worst_case_parameters=params[worst].tolist(),K_N_mm=K.tolist())
                feasible.append(first)
    feasible.sort(key=lambda c:c['worst_band_power_ratio'])
    winner=feasible[0]
    _,K0=foot_matrix(n=40)
    _,K1=foot_matrix(width=winner['width_mm'],height=winner['height_mm'],sweeps=(winner['sweep_deg'],)*3,n=80)
    assert K1[2,2]>=K_MIN
    refined_score,worst=spectral_score(K1,params,freq_band)
    baseline_score,_=spectral_score(K0,params,freq_band)
    sagrows=[]
    for E in [5.,7.4,9.8,15.,26.]:
        for mass in [12.95,20.]:
            for extra in [1.,1.3]:
                sag=mass*9.80665/4*extra/(K1[2,2]*E/E_REF)
                sagrows.append(dict(E_MPa=E,mass_kg=mass,corner_factor=extra,sag_mm=float(sag),
                    clearance_initial_mm=float(TRAVEL-sag),clearance_at_1_5_sag_mm=float(TRAVEL-1.5*sag),
                    clearance_at_2_sag_mm=float(TRAVEL-2*sag)))
    # Sweep entire illustrated spectrum for envelopes, including amplification.
    f=np.geomspace(.5,200,1000)
    envelopes={}
    for label,K in [('P01',K0),('P02',K1)]:
        mass,E,dyn,bz,bxy,lf,lb=params.T
        arr=force_transfer(f[None,:],K[2,2]*E[:,None]/E_REF*dyn[:,None],bz[:,None],
            mass[:,None],lf[:,None],lb[:,None])
        envelopes[label]=dict(min=arr.min(axis=0),max=arr.max(axis=0))
    # Isolated confirmation of the massless-cup series reduction, including loss.
    fs=np.geomspace(1,100,100);kb=20000*(1+.3j);kf=14000*(1+.3j);ks=kb*kf/(kb+kf)
    exact=abs(ks/(ks-12.95/4*(2*np.pi*fs)**2))
    assert np.max(abs(force_transfer(fs,14,20,moving_mass=0)/exact-1))<1e-10
    assert abs(float(force_transfer(0,14,20))-1)<1e-12
    ball_comparison=[]
    for b in [5.,20.,100.]:
        for hz in [5.,10.,20.,30.,50.,100.]:
            val=float(force_transfer(hz,K1[2,2],b))
            kb=b*1000*(1+.3j);ball_alone=abs(kb/(kb-12.95/4*(2*np.pi*hz)**2))
            kf=K1[2,2]*1000*(1+.3j)
            foot_alone=abs(kf/(kf-(12.95/4+.020)*(2*np.pi*hz)**2))
            ball_comparison.append(dict(ball_k_N_mm=b,f_Hz=hz,with_foot_T=val,ball_only_T=float(ball_alone),
                change_force_dB=float(20*np.log10(val/ball_alone)),foot_only_T=float(foot_alone),
                ball_added_to_foot_change_dB=float(20*np.log10(val/foot_alone))))
    modes=[]
    for bz,bxy in [(5.,1.),(20.,5.),(100.,20.)]:
        modes.append(dict(ball_z=bz,ball_xy=bxy,P01=printer_modes(series(K0,bxy,bz)),
                          P02=printer_modes(series(K1,bxy,bz))))
    report=dict(revision='P02',objective=__doc__,required_reference_k_N_mm=K_MIN,
        nominal_geometry_count=len(all_rows),spectrally_compared_candidates=len(feasible),
        uncertainty_cases=len(params),frequency_sweep_Hz=[.5,200],scoring_band_Hz=[30,100],
        minimum_modulus_design_MPa=E_LOW,extra_soft_test_MPa=5,
        gap_mm=TRAVEL,retained_clearance_target_mm=RESERVE,assumed_sag_drift_factor=DRIFT,
        winner=winner,top_candidates=feasible[:12],all_grid_candidates=all_rows,
        P01_K_N_mm=K0.tolist(),P02_K_N_mm=K1.tolist(),
        score_P01_force_power=baseline_score,score_P02_force_power=refined_score,
        score_change_dB=float(10*np.log10(refined_score/baseline_score)),
        clearance_cases=sagrows,ball_comparison=ball_comparison,rigid_body_mode_scenarios=modes,
        uncertainty_parameter_columns=['mass_kg','E_static_MPa','dynamic_static_ratio','ball_kz_N_mm','ball_kxy_N_mm','foot_loss_factor','ball_loss_factor'],
        uncertainty_parameters=params.tolist(),
        qualification='Conditional optimum within this grid and surrogate objective only. No acoustic or physical validation.')
    (OUT/'optimization.json').write_text(json.dumps(report,indent=2))
    plot(report,f,envelopes,K1)
    print(json.dumps({k:v for k,v in report.items() if k not in ['all_grid_candidates','uncertainty_parameters','clearance_cases','ball_comparison']},indent=2))

def plot(report,f,envelopes,K1):
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':160})
    fig,ax=plt.subplots(figsize=(10,5.5))
    e=envelopes['P02'];ax.fill_between(f,20*np.log10(e['min']),20*np.log10(e['max']),color='#008e9c',alpha=.18,label='P02 property-sweep envelope')
    ax.semilogx(f,20*np.log10(e['max']),color='#008e9c',label='P02 worst at each frequency')
    ax.semilogx(f,20*np.log10(envelopes['P01']['max']),color='#0000a8',ls='--',label='P01 worst at each frequency')
    ax.axhline(0,color='#666',lw=1);ax.axvspan(30,100,color='#b87900',alpha=.08,label='Declared comparison band')
    ax.set(xlabel='Frequency (Hz)',ylabel='Transmitted / applied force (dB)',title='Uncertainty dominates: no all-frequency reduction',ylim=(-65,28),xlim=(.5,200));ax.grid(alpha=.2);ax.legend(fontsize=9)
    fig.text(.1,.01,f"Two-mass linear surrogate · {report['uncertainty_cases']} parameter cases · material laws and table modes unknown",fontsize=9)
    fig.tight_layout(rect=[0,.035,1,1]);fig.savefig(OUT/'p02-envelope.png');plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(13,4.5),sharey=True)
    for ax,kb in zip(axes,[5,20,100]):
        k=kb*1000*(1+.3j);alone=abs(k/(k-12.95/4*(2*np.pi*f)**2))
        withfoot=force_transfer(f,K1[2,2],kb)
        kf=K1[2,2]*1000*(1+.3j);footonly=abs(kf/(kf-(12.95/4+.020)*(2*np.pi*f)**2))
        ax.semilogx(f,20*np.log10(alone),color='#666',ls='--',label='Ball alone')
        ax.semilogx(f,20*np.log10(withfoot),color='#008e9c',label='Ball + P02')
        ax.semilogx(f,20*np.log10(footonly),color='#b87900',ls=':',label='TPU foot alone')
        ax.axhline(0,color='#999',lw=1);ax.set(title=f'Assumed ball k = {kb} N/mm',xlabel='Frequency (Hz)',ylim=(-65,22),xlim=(.5,200));ax.grid(alpha=.2)
    axes[0].set_ylabel('Force transmission (dB)');axes[-1].legend(fontsize=9)
    fig.suptitle('Does the ball help? Compliance lowers resonance, but moves the amplification region.')
    fig.text(.08,.01,'12.95 kg · foot E = 9.8 MPa · both assumed loss factors = 0.30 · moving cup mass = 20 g/foot · no measured ball properties',fontsize=9)
    fig.tight_layout(rect=[0,.045,1,.93]);fig.savefig(OUT/'does-ball-help.png');plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,5))
    mod=np.linspace(5,26,200);k=K1[2,2]*mod/E_REF;force=20*9.80665/4*1.3
    for drift,color in [(1,'#008e9c'),(1.5,'#0000a8'),(2,'#b87900')]:
        ax.plot(mod,TRAVEL-force/k*drift,color=color,label=f'{drift:g}× initial sag')
    ax.axhline(3,color='#666',ls='--',label='3 mm retained-clearance target');ax.axhline(0,color='#a22');ax.axvline(7.4,color='#666',ls=':')
    ax.set(xlabel='Assumed effective static modulus (MPa)',ylabel='Cup-to-stop clearance (mm)',title='P02 clearance at 20 kg and 30% corner overload',ylim=(-8,12));ax.grid(alpha=.2);ax.legend(fontsize=9)
    fig.text(.12,.015,'12 mm initial travel · 7.4 MPa provisional design low end · 5 MPa upset test · sag drift factors are not creep predictions',fontsize=8)
    fig.tight_layout(rect=[0,.04,1,1]);fig.savefig(OUT/'p02-clearance.png');plt.close(fig)

if __name__=='__main__':main()
