# Reproduce the isolation review

Python 3.14 was used. Install requirements.txt in a virtual environment, then:

    python noise_review.py
    python optimize_noise.py

The bundled design.py and analyze.py are the unchanged P01 baseline. P02 is
selected explicitly by optimize_noise.py; CAD source is in the separate P02 CAD
bundle. OPENBLAS_NUM_THREADS=1 can reduce overhead for the small matrix solves.
The outputs reproduce the saved JSON and plots in review-output/. See the
published report and P02 README for assumptions and limitations.
