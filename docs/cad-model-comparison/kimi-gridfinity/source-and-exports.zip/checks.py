#!/usr/bin/env python
"""Measured verification of the exported parts.

Run:  python checks.py
Reads out/stl/*.stl + assembly.json, writes out/checks.json and prints a summary.

Checks are functional, not just existence: interface clearances (bin/baseplate,
bin/bin stacking), profile stations vs the Gridfinity spec, finger-access
geometry, label groove presence/depth, capacity vs real fastener dimensions.
"""
import json
import math
import os
import struct
import sys

import numpy as np
import trimesh
from trimesh.proximity import ProximityQuery
from trimesh.ray import ray_triangle

ROOT = os.path.dirname(os.path.abspath(__file__))
STL = os.path.join(ROOT, "out", "stl")

results = {}

def report(name, **kv):
    results[name] = kv
    print(f"[check] {name}: {kv}")

# ---------------------------------------------------------------- mesh utils
def load(name):
    return trimesh.load_mesh(os.path.join(STL, name + ".stl"), process=True)

def section_segments(mesh, z):
    """Line segments where the plane z=const cuts the mesh (3D endpoints)."""
    tri = mesh.triangles
    dz = tri[:, :, 2] - z
    all_pts, all_tid = [], []
    for e0, e1 in ((0, 1), (1, 2), (2, 0)):
        a, b = tri[:, e0], tri[:, e1]
        da, db = dz[:, e0], dz[:, e1]
        mask = (da < 0) != (db < 0)
        idx = np.nonzero(mask)[0]
        if len(idx) == 0:
            continue
        t = (-da[idx]) / (db[idx] - da[idx])
        all_pts.append(a[idx] + t[:, None] * (b[idx] - a[idx]))
        all_tid.append(idx)
    if not all_pts:
        return []
    pts = np.vstack(all_pts)
    tid = np.concatenate(all_tid)
    order = np.argsort(tid, kind="stable")
    pts, tid = pts[order], tid[order]
    segs, i = [], 0
    while i < len(tid):
        j = i
        while j < len(tid) and tid[j] == tid[i]:
            j += 1
        if j - i >= 2:
            segs.append((pts[i], pts[i + 1]))
        i = j
    return segs

def crossings_at_y(segs, y0=0.0):
    """X positions where section segments cross the line y=y0."""
    xs = []
    for p, q in segs:
        y1, y2 = p[1], q[1]
        if (y1 < y0) != (y2 < y0):
            t = (y0 - y1) / (y2 - y1)
            xs.append(p[0] + t * (q[0] - p[0]))
    return np.sort(np.array(xs))

def outer_inner_widths(mesh, z):
    xs = crossings_at_y(section_segments(mesh, z))
    if len(xs) < 4:
        return None, None
    return float(xs[-1] - xs[0]), float(xs[-2] - xs[1])

def ray_up(mesh, x, y, z0):
    locs, _, _ = ray_triangle.RayMeshIntersector(mesh).intersects_location(
        np.array([[x, y, z0]]), np.array([[0, 0, 1.0]]))
    if len(locs) == 0:
        return None
    hits = locs[:, 2]
    hits = hits[hits > z0 + 1e-6]
    return float(hits.min()) if len(hits) else None

def ray_down(mesh, x, y, z0):
    locs, _, _ = ray_triangle.RayMeshIntersector(mesh).intersects_location(
        np.array([[x, y, z0]]), np.array([[0, 0, -1.0]]))
    if len(locs) == 0:
        return None
    hits = locs[:, 2]
    hits = hits[hits < z0 - 1e-6]
    return float(hits.max()) if len(hits) else None

def clearance_report(name, mesh_other, points, contact_tol=0.05):
    """Clearance of sampled points against another mesh.
    Note: signed_distance sign is unreliable for OCC-exported meshes
    (positive can mean inside), so use contains() + absolute distance."""
    pq = ProximityQuery(mesh_other)
    sd = np.abs(pq.signed_distance(points))
    inside = mesh_other.contains(points)
    interfering = int((inside & (sd > 0.02)).sum())
    return {
        "min": round(float(sd.min()), 3),
        "p05": round(float(np.percentile(sd, 5)), 3),
        "p50": round(float(np.percentile(sd, 50)), 3),
        "points": int(len(points)),
        "interfering_points": interfering,
    }

# ---------------------------------------------------------------- 1. bboxes
nominal_h = {2: 18.4, 3: 25.4}
with open(os.path.join(ROOT, "assembly.json")) as f:
    asm = json.load(f)

bin_meshes = {}
for p in asm["parts"]:
    m = load(p["id"])
    bb = m.bounds
    size = np.round(bb[1] - bb[0], 3)
    if p["kind"] == "baseplate":
        ok = np.allclose(size, [210, 168, 4.75], atol=0.05)
    else:
        ok = (abs(size[0] - 41.5) < 0.05 and abs(size[1] - 41.5) < 0.05
              and abs(size[2] - nominal_h[p["height_u"]]) < 0.05)
    watertight = bool(m.is_watertight)
    # binary STL sanity: 84 + 50*n bytes
    with open(os.path.join(STL, p["id"] + ".stl"), "rb") as f:
        data = f.read()
    n_faces = struct.unpack("<I", data[80:84])[0]
    bin_ok = (len(data) == 84 + 50 * n_faces) and n_faces == len(m.faces)
    report(f"bbox/{p['id']}", size=list(size), watertight=watertight,
           binary_stl=bin_ok, ok=bool(ok and watertight and bin_ok))
    if p["kind"] == "bin":
        bin_meshes[p["id"]] = (m, p)

# ---------------------------------------------------------------- 2. base profile stations (spec fit)
def outer_width(mesh, z):
    xs = crossings_at_y(section_segments(mesh, z))
    return float(xs[-1] - xs[0]) if len(xs) >= 2 else None

m, _ = bin_meshes["bin_m3x10"]
stations = [(0.05, 35.6), (0.90, 37.2), (2.50, 37.2), (4.70, 41.4)]
prof = {}
ok = True
for z, w in stations:
    meas = outer_width(m, z)
    prof[f"z={z}"] = {"measured": (None if meas is None else round(meas, 3)), "nominal": w}
    ok &= meas is not None and abs(meas - w) < 0.1
report("bin_base_profile_vs_spec", **prof, ok=bool(ok))

# ---------------------------------------------------------------- 3. interior clear space
cav = {}
w_out, w_in = outer_inner_widths(m, 10.0)
floor_z = ray_down(m, 0, 0, 17.0)
cav["clear_width"] = round(w_in, 3)
cav["floor_z"] = round(floor_z, 3)
_, w_throat = outer_inner_widths(m, 14.05)     # lip throat (body_top=14 for 2u)
_, w_lip4 = outer_inner_widths(m, 14 + 4.0)
cav["lip_throat_width"] = round(w_throat, 3)
cav["lip_opening_at_+4.0"] = round(w_lip4, 3)
ok = (abs(w_in - 39.1) < 0.15 and abs(floor_z - 5.75) < 0.1
      and abs(w_throat - 36.5) < 0.2 and abs(w_lip4 - 40.7) < 0.3)
report("interior_clear_space", **cav, ok=bool(ok))

# ---------------------------------------------------------------- 4. magnet pockets + screw holes
z_mag = ray_up(m, 15.8, 13.8, -0.5)   # in the pocket annulus, off the screw hole
z_screw = ray_up(m, 13.8, 13.8, 3.0)  # up the screw hole centre
ok = abs(z_mag - 2.4) < 0.1 and abs(z_screw - 4.75) < 0.15
report("magnet_screw_holes", magnet_floor_z=round(z_mag, 3),
       screw_hole_top_z=round(z_screw, 3), ok=bool(ok))

# ---------------------------------------------------------------- 5. bin <-> baseplate clearance (seated)
plate = load("baseplate_5x4")

def base_surface_points(mesh, z_max=4.75):
    v = mesh.vertices
    sel = (v[:, 2] <= z_max) & ((np.abs(v[:, 0]) > 17.0) | (np.abs(v[:, 1]) > 17.0))
    return v[sel]

pts = base_surface_points(m) + np.array([0, -21, 0])   # seat in cell (2,1)
r = clearance_report("seat", plate, pts)
report("bin_in_baseplate_clearance", **r,
       ok=bool(r["min"] > 0.02 and r["interfering_points"] == 0))

# ---------------------------------------------------------------- 6. stacking clearance (2u on 2u)
lower = m
upper_pts = base_surface_points(m) + np.array([0, 0, 14.0 - 0.35])  # nominal stack registration
r = clearance_report("stack", lower, upper_pts)
contact_frac = None
report("stacking_clearance_2u_on_2u", **r,
       note="min=0 is the designed registration contact at the lip top edge",
       ok=bool(r["interfering_points"] == 0 and r["min"] <= 0.05))

# ---------------------------------------------------------------- 7. labels: grooves present, depth, font stroke
def label_probe(mesh, z=9.4):
    segs = section_segments(mesh, z)
    if not segs:
        return None
    pts = np.vstack([[p, q] for p, q in segs])
    # front face only, away from the R3.75 outer corner arcs and the interior wall
    front = pts[(np.abs(pts[:, 0]) < 18.0) & (pts[:, 1] < -20.0)]
    if len(front) == 0:
        return None
    indented = front[front[:, 1] > -20.55]
    if len(indented) == 0:
        return {"stroke_runs_along_front": 0, "groove_depth": 0.0}
    xs = np.sort(indented[:, 0])
    gaps = np.where(np.diff(xs) > 0.8)[0]
    runs = len(gaps) + 1
    depth = float(indented[:, 1].max() + 20.75)
    return {"stroke_runs_along_front": runs, "groove_depth": round(depth, 3)}

for probe_id in ("bin_m3x10", "bin_nut_wshr_m3"):
    mm, _ = bin_meshes[probe_id]
    r = label_probe(mm)
    ok = r and r["stroke_runs_along_front"] >= 5 and 0.45 < r["groove_depth"] < 0.75
    report(f"label_grooves/{probe_id}", **r, ok=bool(ok))

# FillaPrint: stroke = em/10 = cap/7 (measured 100 units at cap 700)
cap_mm = 6.5
stroke = cap_mm / 7
report("label_font", font="FillaPrint-Regular", cap_mm=cap_mm,
       stroke_mm=round(stroke, 3), two_beads_at_line_width=round(stroke / 2, 3),
       ok=bool(stroke >= 0.84))

# ---------------------------------------------------------------- 8. capacity vs fasteners
PACKING = 0.6
QTY = {"screw": 20, "parts": 30}
SPECS = {
    "M2":   dict(d=2.0, dk=3.8, k=2.0, af=4.0, nt=1.6, wod=5.0, wid=2.2, wt=0.3),
    "M2.5": dict(d=2.5, dk=4.5, k=2.5, af=5.0, nt=2.0, wod=6.0, wid=2.7, wt=0.5),
    "M3":   dict(d=3.0, dk=5.5, k=3.0, af=5.5, nt=2.4, wod=7.0, wid=3.2, wt=0.5),
    "M4":   dict(d=4.0, dk=7.0, k=4.0, af=7.0, nt=3.2, wod=9.0, wid=4.3, wt=0.8),
}
def compartment_volume(u, divider=False):
    a_full = 39.1**2 - (4 - math.pi) * 2.55**2
    a_bot = 35.1**2 - (4 - math.pi) * 4.55**2
    v = a_full * (7 * u - 7.75) + (a_full + a_bot) / 2 * 2.0
    if divider:
        v = (v - 1.2 * 39.1 * (7 * u - 5.75)) / 2
    return v

def solid_volume(b):
    s = SPECS[b["size"]]
    if b["kind"] == "screw":
        L = b["length"]
        v = math.pi / 4 * s["d"]**2 * (L - s["k"]) + math.pi / 4 * s["dk"]**2 * s["k"]
        return QTY["screw"] * v
    if b["kind"] == "nut":
        v = (math.sqrt(3) / 2 * s["af"]**2 - math.pi / 4 * s["d"]**2) * s["nt"]
        return QTY["parts"] * v
    v = math.pi / 4 * (s["wod"]**2 - s["wid"]**2) * s["wt"]
    return QTY["parts"] * v

worst = 0.0
# re-derive contents from the assembly content strings (checks stay independent of src/)
import re
cap_ok = True
for p in asm["parts"]:
    if p["kind"] != "bin":
        continue
    c = p["content"]
    vol_comp = compartment_volume(p["height_u"], divider="left" in c)
    need = 0.0
    ms = re.search(r"(\d+)x (M[\d.]+) x (\d+) mm socket-head", c)
    mn = re.search(r"(\d+)x (M[\d.]+) hex nuts", c)
    mw = re.search(r"(\d+)x (M[\d.]+) flat washers", c)
    if ms:
        qty, size, L = int(ms.group(1)), ms.group(2), float(ms.group(3))
        s = SPECS[size]
        need = qty * (math.pi/4*s["d"]**2*(L-s["k"]) + math.pi/4*s["dk"]**2*s["k"])
    elif "nuts (left)" in c:
        size = re.search(r"(M[\d.]+)", c).group(1)
        s = SPECS[size]
        need = 30 * (math.sqrt(3)/2*s["af"]**2 - math.pi/4*s["d"]**2) * s["nt"]
        need += 30 * math.pi/4*(s["wod"]**2 - s["wid"]**2) * s["wt"]
        need /= 2  # per compartment (half the divider bin)
    elif mn:
        qty, size = int(mn.group(1)), mn.group(2)
        s = SPECS[size]
        need = qty * (math.sqrt(3)/2*s["af"]**2 - math.pi/4*s["d"]**2) * s["nt"]
    elif mw:
        qty, size = int(mw.group(1)), mw.group(2)
        s = SPECS[size]
        need = qty * math.pi/4*(s["wod"]**2 - s["wid"]**2) * s["wt"]
    fill = need / PACKING / vol_comp
    worst = max(worst, fill)
    report(f"capacity/{p['id']}", compartment_ml=round(vol_comp/1000, 1),
           required_jumbled_ml=round(need/PACKING/1000, 1),
           fill_ratio=round(fill, 3), ok=bool(fill < 0.75))
    cap_ok &= fill < 0.75

# ---------------------------------------------------------------- 9. baseplate geometry
bb = plate.bounds
z_open = ray_down(plate, 0, -21, 10)     # through a cell opening: should hit nothing
z_rim = ray_down(plate, 0, 0, 10)        # on a rim intersection: should hit ~4.75
ok = z_open is None and z_rim is not None and abs(z_rim - 4.75) < 0.1
report("baseplate_geometry", opening_ray_clear=(z_open is None),
       rim_top_z=(None if z_rim is None else round(z_rim, 3)), ok=bool(ok))

# ---------------------------------------------------------------- 10. layout overlap sanity
cells = [tuple(p["grid_cell"]) for p in asm["parts"] if p["kind"] == "bin"]
ok = len(cells) == len(set(cells)) == 18
report("layout_unique_cells", bins=len(cells), ok=bool(ok))

# ---------------------------------------------------------------- summary
all_ok = all(v.get("ok", True) for v in results.values())
summary = {"all_ok": bool(all_ok), "worst_fill_ratio": round(worst, 3),
           "n_checks": len(results)}
results["_summary"] = summary
with open(os.path.join(ROOT, "out", "checks.json"), "w") as f:
    json.dump(results, f, indent=2)
print(json.dumps(summary, indent=2))
sys.exit(0 if all_ok else 1)
