"""Gridfinity interface constants and helpers.

Dimensions follow the Gridfinity Design Reference v5 (gridfinity.xyz/specification)
cross-checked against the gridfinity-rebuilt-openscad implementation:

  * grid pitch            42.0 mm
  * bin body width        41.5 mm          (0.5 mm total clearance per cell)
  * base profile (width, corner radius, z):
      (35.6, R0.8, 0.00)  bottom "foot"
      (37.2, R1.6, 0.80)  45 deg lower chamfer
      (37.2, R1.6, 2.60)  straight section
      (41.5, R3.75, 4.75) 45 deg upper chamfer -> body
  * height: total = 7*u + 4.4 mm (u = height units, 4.4 = stacking lip)
  * magnet pockets 6.5 dia x 2.4 deep at (+/-13.8, +/-13.8) from unit centre
  * screw holes 3.2 dia (M3)

Everything is parametric: change the constants here and rebuild.
"""
from build123d import Mode, BuildPart, BuildSketch, Plane, Locations, RectangleRounded, loft

# --- Gridfinity spec -------------------------------------------------------
PITCH = 42.0          # grid pitch
BIN_W = 41.5          # bin width at body / top of base
R_TOP = 3.75          # bin body corner radius
WALL = 1.2            # bin wall thickness
UNIT_H = 7.0          # mm per height unit (includes base profile in first unit)
LIP_H = 4.4           # stacking lip height
BASE_H = 4.75         # base profile height

# (width, corner_radius, z) stations of the bin base profile, bottom -> top
BASE_PROFILE = [
    (35.6, 0.80, 0.00),
    (37.2, 1.60, 0.80),
    (37.2, 1.60, 2.60),
    (41.5, 3.75, 4.75),
]

# Stacking-lip funnel (inner surface), (width, corner_radius, z above body top).
# Nominal spec is 36.3 / 37.7 / 41.5 with 0.7 / 1.8 / 1.9 segments; we add
# LIP_CLEAR radial clearance so stacked bins slide instead of wedge.
LIP_CLEAR = 0.10
def lip_funnel(body_top):
    c = LIP_CLEAR
    return [
        (BIN_W - 2 * WALL, R_TOP - WALL, body_top - 0.2),   # overlap with cavity
        (36.3 + 2 * c, 1.15 + c, body_top),
        (37.7 + 2 * c, 1.85 + c, body_top + 0.7),
        (37.7 + 2 * c, 1.85 + c, body_top + 2.5),
        (BIN_W, R_TOP, body_top + LIP_H),                   # meets outer wall (spec tip)
    ]

# Interior cavity (width, corner_radius, z): 45 deg floor chamfer for finger access
def cavity_profile(body_top):
    inner = BIN_W - 2 * WALL              # 39.1
    cham = 2.0                            # floor edge chamfer
    return [
        (inner - 2 * cham, R_TOP - WALL + cham, FLOOR_Z),
        (inner, R_TOP - WALL, FLOOR_Z + cham),
        (inner, R_TOP - WALL, body_top),
    ]

FLOOR_T = 1.0
FLOOR_Z = BASE_H + FLOOR_T                # 5.75

MAGNET_D = 6.5
MAGNET_DEPTH = 2.4
MAGNET_XY = 13.8                          # magnet centre from unit centre
SCREW_D = 3.2

# --- helper ----------------------------------------------------------------
def _section_face(w, r, z, cx=0.0, cy=0.0):
    with BuildSketch(Plane.XY.offset(z)) as sk:
        with Locations((cx, cy)):
            RectangleRounded(w, w, r)
    return sk.sketch


def sectioned_loft(sections, mode=Mode.ADD, ruled=True):
    """Loft through rounded-square sections.

    sections: iterable of (width, corner_radius, z) or (width, corner_radius, z, cx, cy).
    Must be called inside an active BuildPart.
    """
    faces = []
    for s in sections:
        w, r, z = s[0], s[1], s[2]
        cx, cy = (s[3], s[4]) if len(s) > 3 else (0.0, 0.0)
        faces.append(_section_face(w, r, z, cx, cy))
    loft(sections=faces, ruled=ruled, mode=mode)
