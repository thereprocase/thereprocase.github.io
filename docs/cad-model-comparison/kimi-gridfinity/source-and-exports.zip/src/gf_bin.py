"""Parametric Gridfinity fastener bin.

One reusable bin body, parameterised by:
  height_u   height in gridfinity units (2 or 3 in this assortment)
  label      list of label items laid out left-to-right on the front face:
             ("text", "M3x10") | ("hex",) hexagon ring = hex nut | ("ring",) circle ring = washer
  divider    if True, split the interior into two left/right compartments

Labels are debossed 0.6 mm into the front face using the FillaPrint font at a
cap height of LABEL_CAP_MM. FillaPrint strokes are exactly em/10 = cap/7, so
cap 6.5 mm gives 0.93 mm strokes = exactly two 0.46 mm extrusion beads, i.e.
the font's designed minimum (font docs: cap height = 14 x line width).
"""
from build123d import (
    Mode, BuildPart, BuildSketch, Plane, Locations, Axis,
    Box, Cylinder, Text, Circle, RegularPolygon, RectangleRounded, extrude, Align,
)
from fontTools.ttLib import TTFont

from gf_common import (
    BIN_W, R_TOP, WALL, UNIT_H, LIP_H, BASE_H, BASE_PROFILE, FLOOR_Z,
    MAGNET_D, MAGNET_DEPTH, MAGNET_XY, SCREW_D,
    lip_funnel, cavity_profile, sectioned_loft,
)

BASE_H_TOP = BASE_H  # screw hole stops here (1.0 mm below cavity floor)

LABEL_CAP_MM = 6.5          # cap height; stroke = cap/7 = 0.93 mm (two 0.46 beads)
LABEL_DEPTH = 0.6
LABEL_Z = 9.4               # label centre height on the front face
LABEL_GAP = 2.0             # gap between symbol and text
SYMBOL_R = 3.6              # symbol outer radius
SYMBOL_RING = 1.4           # symbol groove width (outer r minus inner r)

_font_cache = {}

def _text_width_mm(s, cap_mm, font_path):
    if font_path not in _font_cache:
        f = TTFont(font_path)
        _font_cache[font_path] = (f["hmtx"], f.getBestCmap())
    hmtx, cmap = _font_cache[font_path]
    units = sum(hmtx[cmap[ord(c)]][0] for c in s)
    return units / 700.0 * cap_mm      # cap height = 700 units


def _layout(label, font_path):
    """Return [(kind, payload, x_centre)] for the label, centred on x=0."""
    widths = []
    for item in label:
        if item[0] == "text":
            widths.append(_text_width_mm(item[1], LABEL_CAP_MM, font_path))
        else:
            widths.append(2 * SYMBOL_R)
    total = sum(widths) + LABEL_GAP * (len(label) - 1)
    out, x = [], -total / 2
    for item, w in zip(label, widths):
        out.append((item[0], item[1] if len(item) > 1 else None, x + w / 2))
        x += w + LABEL_GAP
    return out


def make_bin(height_u=2, label=None, divider=False, font_path="assets/fillaprint/Fillaprint-Regular.ttf"):
    body_top = UNIT_H * height_u
    top = body_top + LIP_H
    inner = BIN_W - 2 * WALL

    with BuildPart() as bp:
        # ---- base profile + body block (solid) ----
        sectioned_loft(BASE_PROFILE)                                  # base
        with BuildSketch(Plane.XY.offset(BASE_PROFILE[-1][2])):
            RectangleRounded(BIN_W, BIN_W, R_TOP)
        extrude(amount=top - BASE_PROFILE[-1][2])                     # body + lip block

        # ---- interior cavity with 45 deg floor chamfer ----
        sectioned_loft(cavity_profile(body_top), mode=Mode.SUBTRACT)

        # ---- stacking-lip funnel ----
        sectioned_loft(lip_funnel(body_top), mode=Mode.SUBTRACT)

        # ---- divider (optional) ----
        if divider:
            with Locations((0, 0, FLOOR_Z - 0.1)):
                Box(1.2, inner + 0.4, body_top - FLOOR_Z + 0.1,
                    align=(Align.CENTER, Align.CENTER, Align.MIN))

        # ---- magnet pockets + M3 screw holes ----
        for sx in (-1, 1):
            for sy in (-1, 1):
                with Locations((sx * MAGNET_XY, sy * MAGNET_XY, -0.05)):
                    Cylinder(MAGNET_D / 2, MAGNET_DEPTH + 0.05,
                             align=(Align.CENTER, Align.CENTER, Align.MIN), mode=Mode.SUBTRACT)
                    Cylinder(SCREW_D / 2, BASE_H_TOP + 0.05,
                             align=(Align.CENTER, Align.CENTER, Align.MIN), mode=Mode.SUBTRACT)

        # ---- debossed front label ----
        if label:
            plane = Plane(origin=(0, -BIN_W / 2 - 0.2, LABEL_Z), x_dir=(1, 0, 0), z_dir=(0, -1, 0))
            with BuildSketch(plane):
                for kind, payload, xc in _layout(label, font_path):
                    with Locations((xc, 0)):
                        if kind == "text":
                            Text(payload, font_size=LABEL_CAP_MM / 0.7,
                                 font_path=font_path,
                                 align=(Align.CENTER, Align.CENTER))
                        elif kind == "hex":
                            RegularPolygon(SYMBOL_R, 6)
                            RegularPolygon(SYMBOL_R - SYMBOL_RING, 6, mode=Mode.SUBTRACT)
                        elif kind == "ring":
                            Circle(SYMBOL_R)
                            Circle(SYMBOL_R - SYMBOL_RING, mode=Mode.SUBTRACT)
            extrude(amount=-(0.2 + LABEL_DEPTH), mode=Mode.SUBTRACT)

    part = bp.part
    assert len(part.solids()) == 1, "bin is not a single solid"
    part.label = f"bin_{height_u}u"
    return part


if __name__ == "__main__":
    p = make_bin(2, label=[("text", "M3×10")])
    print("volume:", round(p.volume, 1), "bbox:", p.bounding_box().size)
