"""Starter assortment definition.

What belongs where. One row per screw size on a 5 x 4 grid (front row = row 0).
Capacity targets: 20 socket-head screws per screw bin, 30 nuts / 30 washers per
parts compartment. Two spare cells (front right) are the extension points for
future sizes (e.g. M2 x 8 or M5): append entries here and rebuild.

Bins are 1x1 gridfinity units. Screw bins for M2/M2.5/M3 are 2u tall, M4 screw
bins are 3u (volume of 20 long M4 screws), parts bins are 2u.
"""

# layout grid: 5 columns (x), 4 rows (y). row 0 = front.
COLS, ROWS = 5, 4

# fastener reference dimensions (ISO/DIN), used for capacity checks only
SCREW_HEAD_D = {"M2": 3.8, "M2.5": 4.5, "M3": 5.5, "M4": 7.0}      # ISO 4762
SCREW_HEAD_H = {"M2": 2.0, "M2.5": 2.5, "M3": 3.0, "M4": 4.0}
NUT_AF = {"M2": 4.0, "M2.5": 5.0, "M3": 5.5, "M4": 7.0}            # ISO 4032 / DIN 934
NUT_T = {"M2": 1.6, "M2.5": 2.0, "M3": 2.4, "M4": 3.2}
WASHER_OD = {"M2": 5.0, "M2.5": 6.0, "M3": 7.0, "M4": 9.0}         # ISO 7089 (DIN 125 A)
WASHER_T = {"M2": 0.3, "M2.5": 0.5, "M3": 0.5, "M4": 0.8}

def screw(size, length, u, cell):
    return dict(kind="screw", size=size, length=length, u=u, cell=cell,
                label=[("text", f"{size}×{length}")], divider=False, qty=20)

def parts(kind, size, u, cell):
    # kind: "nut" -> hexagon symbol, "washer" -> ring symbol
    sym = "hex" if kind == "nut" else "ring"
    return dict(kind=kind, size=size, length=None, u=u, cell=cell,
                label=[(sym,), ("text", size)], divider=False, qty=30)

def combo(size, u, cell):
    return dict(kind="nut+washer", size=size, length=None, u=u, cell=cell,
                label=[("hex",), ("text", size), ("ring",)], divider=True, qty=30)

BINS = [
    # row 0 (front): M2
    screw("M2", 6, 2, (0, 0)), screw("M2", 10, 2, (1, 0)),
    parts("nut", "M2", 2, (2, 0)), parts("washer", "M2", 2, (3, 0)),
    # cell (4,0) spare
    # row 1: M2.5
    screw("M2.5", 6, 2, (0, 1)), screw("M2.5", 10, 2, (1, 1)),
    parts("nut", "M2.5", 2, (2, 1)), parts("washer", "M2.5", 2, (3, 1)),
    # cell (4,1) spare
    # row 2: M3
    screw("M3", 6, 2, (0, 2)), screw("M3", 10, 2, (1, 2)),
    screw("M3", 16, 2, (2, 2)), screw("M3", 20, 2, (3, 2)),
    combo("M3", 2, (4, 2)),
    # row 3 (back): M4
    screw("M4", 10, 3, (0, 3)), screw("M4", 16, 3, (1, 3)),
    screw("M4", 20, 3, (2, 3)),
    parts("nut", "M4", 2, (3, 3)), parts("washer", "M4", 2, (4, 3)),
]

def cell_xy(cell):
    col, row = cell
    return (col - (COLS - 1) / 2) * 42.0, (row - (ROWS - 1) / 2) * 42.0

def bin_id(b):
    if b["kind"] == "screw":
        return f"bin_{b['size'].lower().replace('.', '_')}x{b['length']}"
    if b["kind"] == "nut+washer":
        return f"bin_nut_wshr_{b['size'].lower().replace('.', '_')}"
    return f"bin_{'nut' if b['kind']=='nut' else 'wshr'}_{b['size'].lower().replace('.', '_')}"

def content_string(b):
    if b["kind"] == "screw":
        return f"{b['qty']}x {b['size']} x {b['length']} mm socket-head screws (ISO 4762)"
    if b["kind"] == "nut":
        return f"{b['qty']}x {b['size']} hex nuts (ISO 4032)"
    if b["kind"] == "washer":
        return f"{b['qty']}x {b['size']} flat washers (ISO 7089)"
    return f"{b['qty']}x {b['size']} hex nuts (left) + {b['qty']}x {b['size']} flat washers (right)"
