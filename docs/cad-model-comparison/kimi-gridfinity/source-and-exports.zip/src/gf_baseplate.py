"""Gridfinity baseplate, open-frame type.

Per-cell rim profile = bin base profile + 0.25 mm radial clearance, so any
standard 41.5 mm bin drops in and seats on its chamfers. The frame is open at
the bottom (classic Gridfinity): bins' bottom faces rest on the drawer/shelf
surface through the frame; if the plate is lifted alone, bins hang on their
chamfers and protrude ~0.25 mm below the frame bottom.

Outer vertical corners are R4 (8 mm dia per the spec drawing).
"""
from build123d import (
    Mode, BuildPart, Axis, Box, fillet, Align,
)
from gf_common import PITCH, BASE_PROFILE, sectioned_loft

PLATE_H = 4.75
OPEN_CLEAR = 0.25          # radial clearance to the bin base profile

def make_baseplate(cols=5, rows=4):
    W, D = cols * PITCH, rows * PITCH
    # cell opening = bin base profile + OPEN_CLEAR radial clearance
    secs = []
    for w, r, z in BASE_PROFILE:
        secs.append((w + 2 * OPEN_CLEAR, r + OPEN_CLEAR, z))
    # start the cut slightly below the bottom face for a clean through-cut
    secs = [(secs[0][0], secs[0][1], -0.1)] + secs
    # top opening pulled in to 41.8 (keeps 0.2 mm ridge between adjacent cells
    # and at the plate border); stops just below 45 deg slope continuation
    secs[-1] = (41.8, 3.90, PLATE_H - 0.10)
    secs.append((41.8, 3.90, PLATE_H + 0.1))

    with BuildPart() as bp:
        Box(W, D, PLATE_H, align=(Align.CENTER, Align.CENTER, Align.MIN))
        # outer corner fillets R4 (on the plain box these are the only Z edges)
        fillet(bp.edges().filter_by(Axis.Z), radius=4.0)
        for i in range(cols):
            for j in range(rows):
                cx = (i - (cols - 1) / 2) * PITCH
                cy = (j - (rows - 1) / 2) * PITCH
                sectioned_loft([s + (cx, cy) for s in secs], mode=Mode.SUBTRACT)

    part = bp.part
    assert len(part.solids()) == 1, "baseplate is not a single solid"
    return part


if __name__ == "__main__":
    p = make_baseplate()
    print("volume:", round(p.volume, 1), "bbox:", p.bounding_box().size)
