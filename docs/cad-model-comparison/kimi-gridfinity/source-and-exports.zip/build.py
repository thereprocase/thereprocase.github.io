#!/usr/bin/env python
"""Build the Gridfinity fastener organizer: baseplate + starter bin assortment.

Usage:  python build.py
Writes: out/stl/*.stl (binary), out/step/*.step, out/assembly.step, assembly.json
"""
import json
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

from build123d import Compound, Pos, export_step, export_stl  # noqa: E402
from gf_bin import make_bin                                    # noqa: E402
from gf_baseplate import make_baseplate                        # noqa: E402
from assortment import BINS, COLS, ROWS, cell_xy, bin_id, content_string  # noqa: E402

ROOT = os.path.dirname(os.path.abspath(__file__))
FONT = os.path.join(ROOT, "assets", "fillaprint", "Fillaprint-Regular.ttf")
OUT_STL = os.path.join(ROOT, "out", "stl")
OUT_STEP = os.path.join(ROOT, "out", "step")
os.makedirs(OUT_STL, exist_ok=True)
os.makedirs(OUT_STEP, exist_ok=True)


def export(part, name):
    stl = os.path.join(OUT_STL, name + ".stl")
    step = os.path.join(OUT_STEP, name + ".step")
    export_stl(part, stl)
    export_step(part, step)
    return stl, step


def main():
    t0 = time.time()
    assembly = {
        "units": "mm",
        "coordinate_system": "right-handed, Z up. Baseplate bottom face at Z=0. "
                             "Front (labelled) bin faces point to -Y. Row 0 (M2) is the front row.",
        "grid": {"pitch": 42.0, "cols": COLS, "rows": ROWS},
        "parts": [],
    }
    placed = []

    # ---- baseplate ----
    plate = make_baseplate(COLS, ROWS)
    plate.label = "baseplate_5x4"
    stl, step = export(plate, "baseplate_5x4")
    assembly["parts"].append({
        "id": "baseplate_5x4", "kind": "baseplate",
        "file_stl": os.path.relpath(stl, ROOT), "file_step": os.path.relpath(step, ROOT),
        "transform": {"translate_mm": [0, 0, 0], "rotate_xyz_deg": [0, 0, 0]},
        "notes": "5x4 open-frame baseplate, 210x168x4.75 mm",
    })
    placed.append(plate)

    # ---- bins ----
    for b in BINS:
        name = bin_id(b)
        part = make_bin(height_u=b["u"], label=b["label"], divider=b["divider"], font_path=FONT)
        part.label = name
        x, y = cell_xy(b["cell"])
        stl, step = export(part, name)
        assembly["parts"].append({
            "id": name, "kind": "bin",
            "file_stl": os.path.relpath(stl, ROOT), "file_step": os.path.relpath(step, ROOT),
            "transform": {"translate_mm": [x, y, 0], "rotate_xyz_deg": [0, 0, 0]},
            "grid_cell": list(b["cell"]),
            "height_u": b["u"],
            "content": content_string(b),
        })
        placed.append(Pos(x, y, 0) * part)
        print(f"  built {name:22s} cell={b['cell']} u={b['u']}")

    # spare cells note
    used = {tuple(b["cell"]) for b in BINS}
    spares = [(c, r) for c in range(COLS) for r in range(ROWS) if (c, r) not in used]
    assembly["spare_cells"] = [list(s) for s in spares]
    assembly["notes"] = ("Bins sit with their bottom face at Z=0 (resting on the drawer surface "
                         "through the open-frame baseplate). Spare cells are extension points.")

    # ---- combined assembly step ----
    asm = Compound(children=placed)
    asm.label = "gridfinity_fastener_organizer"
    export_step(asm, os.path.join(ROOT, "out", "assembly.step"))

    with open(os.path.join(ROOT, "assembly.json"), "w") as f:
        json.dump(assembly, f, indent=2)

    print(f"done: {len(assembly['parts'])} parts in {time.time()-t0:.1f}s")


if __name__ == "__main__":
    main()
