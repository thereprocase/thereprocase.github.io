#!/usr/bin/env python3
"""Parametric Gridfinity organizer for small hardware.
Generates a 5x4 base plate (42mm grid) and a set of bins for M2, M2.5, M3, M4 screws.
Each bin is 1x1 grid unit (42x42mm) with 6U height (42mm) and internal compartments.
The script exports STEP and STL files for the base and each bin.
"""
import pathlib
from build123d import *
from build123d import export_step, export_stl

# Constants
GRID = 42.0  # mm per grid unit
U_HEIGHT = 7.0  # mm per unit height
BIN_HEIGHT_U = 6  # total height units (42 mm)
BIN_HEIGHT = BIN_HEIGHT_U * U_HEIGHT
WALL_THICK = 2.0  # mm, gridfinity wall thickness
BASE_THICK = 4.0

# Helper to create a label using Fillaprint font
def add_label(sketch: Sketch, text: str, depth: float = 0.8):
    # Position label in the center of the bin top
    txt = Text(text, 8, font_path="assets/fillaprint/Fillaprint-Regular.ttf")
    txt = txt.translate(Vector(-txt.bounding_box().x/2, -txt.bounding_box().y/2, 0))
    sketch.add(txt)
    return extrude(txt, amount=depth)


def make_base(columns: int = 5, rows: int = 4):
    """Create a Gridfinity base plate (5x4 cells).
    Returns a Solid.
    """
    # Simple solid base plate without perimeter walls for simplicity.
    base = Box(columns * GRID, rows * GRID, BASE_THICK)
    return base


def make_bin(diameter: float, lengths: list[int], is_nut: bool = False, is_washer: bool = False, label: str = ""):
    """Create a 1x1 Gridfinity bin.
    diameter: screw nominal diameter (mm) – only used for labeling.
    lengths: list of screw lengths to allocate compartments (mm).
    is_nut / is_washer: flags for labeling.
    label: custom label string.
    Returns a Solid.
    """
    # Outer box
    outer = Box(GRID, GRID, BIN_HEIGHT, align=(Align.MIN, Align.MIN, Align.MIN))
    # Hollow interior
    inner = Box(GRID - 2*WALL_THICK, GRID - 2*WALL_THICK, BIN_HEIGHT - WALL_THICK, align=(Align.MIN, Align.MIN, Align.MIN))
    inner = inner.translate(Vector(WALL_THICK, WALL_THICK, WALL_THICK))
    bin_solid = outer - inner
    # Internal dividers for each length compartment (horizontal shelves)
    # Stack compartments vertically; each compartment height = length + clearance
    clearance = 2.0  # mm extra space above each length
    current_z = WALL_THICK
    for L in sorted(lengths):
        compartment_h = L + clearance
        if current_z + compartment_h > BIN_HEIGHT:
            break
        # create a shelf (thin plate) to separate above
        shelf = Box(GRID - 2*WALL_THICK, GRID - 2*WALL_THICK, 1.0, align=(Align.MIN, Align.MIN, Align.MIN))
        shelf = shelf.translate(Vector(WALL_THICK, WALL_THICK, current_z + compartment_h))
        bin_solid = bin_solid - shelf  # subtract shelf to create void
        current_z += compartment_h
    # Add a lid with embossed label (simple thin slab)
    lid = Box(GRID, GRID, 2.0, align=(Align.MIN, Align.MIN, Align.MAX))
    lid = lid.translate(Vector(0, 0, BIN_HEIGHT))
    # Create text shape
    if label:
        txt = Text(label, 8, font_path="assets/fillaprint/Fillaprint-Regular.ttf", align=(Align.CENTER, Align.CENTER))
        txt = extrude(txt, amount=0.8)
        # Position text centered on lid top surface
        txt = txt.translate(Vector(0, 0, BIN_HEIGHT + 1.0))
        lid = lid + txt
    return bin_solid + lid

def export_part(part, name: str, out_dir: pathlib.Path):
    step_path = out_dir / f"{name}.step"
    stl_path = out_dir / f"{name}.stl"
    # Ensure part is a Compound for export methods
    part = Compound([part])
    export_step(part, str(step_path))
    export_stl(part, str(stl_path))
    print(f"Exported {name}: STEP->{step_path}, STL->{stl_path}")

def main():
    out = pathlib.Path("output")
    out.mkdir(exist_ok=True)
    base = make_base()
    export_part(base, "base_plate", out)
    # Example bins
    bins_info = [
        (2.0, [6,8,10], False, False, "M2 screws"),
        (2.5, [6,8,10], False, False, "M2.5 screws"),
        (3.0, [6,8,10,12], False, False, "M3 screws"),
        (4.0, [6,8,10,12,16], False, False, "M4 screws"),
        (0, [0], True, False, "Hex nuts"),
        (0, [0], False, True, "Flat washers"),
    ]
    for i, (dia, lens, nut, wash, label) in enumerate(bins_info, start=1):
        bin_solid = make_bin(dia, lens, is_nut=nut, is_washer=wash, label=label)
        export_part(bin_solid, f"bin_{i}_{label.replace(' ','_')}", out)

if __name__ == "__main__":
    main()
