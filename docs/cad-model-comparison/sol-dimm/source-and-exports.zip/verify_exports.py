"""Read STEP exports independently and check mesh agreement and bag removal."""
import json
from pathlib import Path
from build123d import import_step,Box,Pos,Align
out=Path(__file__).resolve().parent/'output'
cad=json.loads((out/'measured_checks.json').read_text()); mesh=json.loads((out/'mesh_checks.json').read_text())
report={}
for name in ('base','lid'):
 s=import_step(out/f'{name}.step')
 delta=abs(s.volume-mesh[name]['volume_mm3'])/s.volume
 assert s.is_valid and len(s.solids())==1 and delta<.002
 report[name]=dict(step_valid=s.is_valid,step_solids=len(s.solids()),step_volume_mm3=s.volume,relative_mesh_volume_error=delta)
base=import_step(out/'base.step')
report['bag_vertical_extraction_sweeps']=[]
for e in cad['bag_envelopes']:
 lo,hi=e['bounds_mm']; sweep=Pos(*lo)*Box(hi[0]-lo[0],hi[1]-lo[1],40,align=(Align.MIN,Align.MIN,Align.MIN))
 overlap=base & sweep
 v=overlap.volume if overlap is not None and len(overlap.solids()) else 0
 assert v<1e-6
 report['bag_vertical_extraction_sweeps'].append(dict(bounds_min_mm=lo,sweep_height_mm=40,base_interference_mm3=v))
(out/'export_checks.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
