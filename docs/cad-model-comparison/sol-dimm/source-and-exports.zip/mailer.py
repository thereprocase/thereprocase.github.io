"""Two DDR4 module mailer. build123d; all dimensions mm. Run with supplied CAD Python."""
from build123d import *
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'; OUT.mkdir(exist_ok=True)
P=dict(bay_length=140., bay_width=42., divider=12., wall=4., floor=2.,
       support_height=1., lid_bottom=14., lid_thickness=2.2,
       rail_vertical_clearance=.4, rail_side_clearance=.4, roof=1.8,
       tongue_length=30., tongue_thickness=1.6, font_em=10., label_depth=.6)
def box(x,y,z,dx,dy,dz):
    return Pos(x,y,z)*Box(dx,dy,dz,align=(Align.MIN,Align.MIN,Align.MIN))
def rounded_box(x,y,z,dx,dy,dz,r):
    s=Box(dx,dy,dz,align=(Align.MIN,Align.MIN,Align.MIN))
    s=fillet(s.edges().filter_by(Axis.Z),r)
    return Pos(x,y,z)*s
B,C,D,w,f=P['bay_length'],P['bay_width'],P['divider'],P['wall'],P['floor']
L,W=B+2*w,2*C+D+2*w
m=W/2; y2=w+C+D; fx=L/2-16
z=P['lid_bottom']; t=P['lid_thickness']; vc=P['rail_vertical_clearance']; sc=P['rail_side_clearance']
H=z+t+vc+P['roof']; lip=1.6; groove_y=w-lip; edge_y=groove_y+sc
lid_length=L-w-.4; lid_width=W-2*edge_y
assert B>=120 and C>=38 and D>=12 and z>=13 and w>=4
base=rounded_box(0,0,0,L,W,H,2)
# Rails open at x=0; rear wall is the positive stop.
base-=box(-1,groove_y,z,L-w+1,W-2*groove_y,t+vc)
base-=box(-1,w,z+t+vc,L-w+1,W-2*w,H)
for y in (w,y2):
    base-=box(w,y,f,B,C,z-f)
beam_top=z-1.6; beam_bottom=beam_top-P['tongue_thickness']
base-=box(w,w+C,beam_top,B,D,z-beam_top)
base-=box(fx,w+C,f,32,D,z-f)
for y in (w,y2):
    sy=y+12 if y==w else y+4
    pad=rounded_box(w+2,sy,f,B-4,C-16,P['support_height'],1)
    recess_y=w+C-10 if y==w else y2
    pad-=box(fx,recess_y,f,32,10,3)
    base+=pad
# Cantilever isolated by a U slot, with clearance below for pressing.
root=8+P['tongue_length']; beam_w=D-4
base-=box(6,m-D/2+1,-1,root-6,D-2,z+1) # underside access for support removal
tongue=box(8,m-beam_w/2,beam_bottom,P['tongue_length'],beam_w,P['tongue_thickness'])
base+=tongue
profile=Plane.XZ*Polygon((8,beam_top),(8,beam_top+.6),(14,z+1.2),(16,z+1.2),(16,beam_top),align=None)
tooth=Pos(0,m+beam_w/2,0)*extrude(make_face(profile),amount=beam_w,dir=(0,-1,0))
base+=tooth
lid=rounded_box(0,edge_y,0,lid_length,lid_width,t,.8)
lid-=rounded_box(5.6,m-5,-1,12,10,t+2,1)
lid+=rounded_box(.8,m-22,t,3,44,1.6,1)
labels=[]
for txt,x,y in [('DDR4 / 2',L*.59,m),('PRESS',34,m),('SLIDE',L*.54,m+26)]:
    sk=Text(txt,font_size=P['font_em'],font_path=str(ROOT/'assets/fillaprint/Fillaprint-Regular.ttf'),align=(Align.CENTER,Align.CENTER))
    labels.append(dict(text=txt,em_mm=P['font_em'],cap_height_mm=P['font_em']*.7,bounds_mm=list(sk.bounding_box().size)))
    lid+=Pos(x,y,t)*extrude(sk,amount=P['label_depth'])
parts={'base':base,'lid':lid}
assembled_lid=Pos(.4,0,z)*lid
checks={'parameters':P,'labels':labels,'parts':{}}
for name,s in parts.items():
    assert s.is_valid and len(s.solids())==1,(name,s.is_valid,len(s.solids()))
    export_step(s,OUT/f'{name}.step')
    export_stl(s,OUT/f'{name}.stl',tolerance=.04,angular_tolerance=.1,ascii_format=False)
    bb=s.bounding_box()
    checks['parts'][name]=dict(valid=s.is_valid,solids=len(s.solids()),volume_mm3=s.volume,bounds_min_mm=list(bb.min),bounds_max_mm=list(bb.max))
common=base & assembled_lid
checks['closed_interference_mm3']=common.volume if len(common.solids()) else 0
# Check the full rectangular bag envelope, with 1 mm headroom above the support.
checks['bag_envelopes']=[]
for y in (w,y2):
    e=box(w+1,y+1,f+P['support_height'],B-2,C-2,10)
    c=base & e
    checks['bag_envelopes'].append(dict(bounds_mm=[[w+1,y+1,f+P['support_height']],[L-w-1,y+C-1,f+P['support_height']+10]],base_interference_mm3=c.volume if len(c.solids()) else 0,lid_headroom_mm=1))
# Lid withdrawal after catch depressed: only latch should obstruct undeformed motion.
checks['withdrawal_samples']=[]
base_without_catch=base-tooth-tongue
for d in (0,2,10,40,80,146):
    c=base_without_catch & (Pos(.4-d,0,z)*lid)
    checks['withdrawal_samples'].append(dict(withdrawal_mm=d,rail_interference_mm3=c.volume if len(c.solids()) else 0))
checks['catch']=dict(engagement_mm=1.2,release_deflection_mm=1.6,under_tongue_clearance_mm=beam_bottom,beam_length_mm=P['tongue_length'],beam_thickness_mm=P['tongue_thickness'],estimated_outer_fiber_strain=1.5*1.6*1.6/30**2)
checks['rail']=dict(side_running_clearance_mm=.4,vertical_running_clearance_mm=.4,captive_overlap_mm=1.2)
checks['catch_block_test']=[]
for d in (0,3,6):
    closed=Pos(.4-d,0,z)*lid
    undeformed=tooth & closed
    released=(Pos(0,0,-1.6)*tooth) & closed
    checks['catch_block_test'].append(dict(withdrawal_mm=d,engaged_intersection_mm3=undeformed.volume if len(undeformed.solids()) else 0,released_intersection_mm3=released.volume if len(released.solids()) else 0))
checks['lift_block_test_mm3']=(base & (Pos(.4,0,z+1)*lid)).volume
assert checks['closed_interference_mm3'] < 1e-6
assert all(e['base_interference_mm3'] < 1e-6 for e in checks['bag_envelopes'])
assert all(e['rail_interference_mm3'] < 1e-6 for e in checks['withdrawal_samples'])
assert checks['catch_block_test'][1]['engaged_intersection_mm3'] > 1
assert all(e['released_intersection_mm3'] < 1e-6 for e in checks['catch_block_test'])
assert checks['lift_block_test_mm3'] > 1
checks['contact_relief']=dict(width_mm=12,depth_below_support_mm=1,contacts_orientation='toward outside long walls; heatspreaders toward center',finger_well_length_mm=32)
(OUT/'measured_checks.json').write_text(json.dumps(checks,indent=2))
assembly={'units':'mm','coordinate_system':'right-handed; X slide direction, Y across bays, Z up','parts':[{'name':n,'step':f'{n}.step','stl':f'{n}.stl','quantity':1,'transform':[[1,0,0,.4 if n=='lid' else 0],[0,1,0,0],[0,0,1,z if n=='lid' else 0],[0,0,0,1]]} for n in parts],'closed_assembly_bounds_mm':[[0,0,0],[L,W,H]],'opening':'Press tongue down 1.6 mm through lid window; slide lid along -X until free.'}
(OUT/'assembly.json').write_text(json.dumps(assembly,indent=2))
print(json.dumps(checks,indent=2))
