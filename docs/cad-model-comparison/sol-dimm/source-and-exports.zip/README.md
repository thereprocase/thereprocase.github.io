# Reusable two-DIMM mailer

Two printed parts, 148 × 104 × 18.4 mm assembled. Each DDR4 desktop module travels flat in its own closed shielding bag. Use an outer cardboard box with cushioning. This enclosure is neither ESD shielding nor a stand-alone postal package.

## Fit

Supported **bare module envelope: 136 × 36 × 8 mm** (length × height including contacts × thickness including spreaders). Fold each bag and its seam/tail to **138 × 40 × 10 mm maximum**; measure the finished package, including padding. Each bay is 140 × 42 mm, giving 1 mm per side around that package, with 1 mm headroom above its 10 mm thickness on the supports. Large bags must be folded carefully; bulky closures may not fit. The module limit does not guarantee every bag will fit.

Real examples, manufacturer drawings retrieved 2026-11-03:

- [Kingston FURY Beast KF432C16BB/16](https://www.kingston.com/datasheets/KF432C16BB_16.pdf): 133.35 × 34 × 7.2 mm, drawing on page 2. Margins to the module envelope: 2.65 × 2 × 0.8 mm.
- [HyperX FURY HX432C16FB3/8](https://www.kingston.com/datasheets/HX432C16FB3_8.pdf): 133.35 × 34.1 × 7.2 mm, drawing on page 2. Margins: 2.65 × 1.9 × 0.8 mm.

The original PDFs and extracted text are in `research/`. These examples establish the intended low-profile heatspreader class. Modules taller than 36 mm or thicker than 8 mm, including many large RGB models, are excluded. Measure the actual sticks; this is not a universal DDR4 case.

## Loading and opening

1. Bag each stick separately. Orient both gold contact edges toward the outside long walls, with the heatspreader tops toward the center divider.
2. Set the bags on the raised supports. The outer 12 mm floor strips sit 1 mm lower than the supports, providing clearance beneath the contact edges. Center the sticks; nothing clamps them. Put thin folded paper or suitable foam **outside the shielding bag**, at heatspreader faces and ends only, to stop motion. Do not pack over or underneath the gold contact strips, overfill, or force the lid.
3. Feed the lid from the open short end along +X. Its edges run under the side lips. The sloping catch deflects and rises into the window when the lid meets the rear wall. Check that it has engaged. The lid can move about 2 mm before meeting the catch; retention comes from the catch and rails, not friction.
4. Press the visible catch down about 1.6 mm through the window marked PRESS. Hold the broad front grip and slide the lid about 3 mm along −X; then release the catch and withdraw the lid fully. Allow roughly 146 mm of clear sliding space. Do not pry upward against the rails.
5. Lift a bag by its heatspreader edge at the 32 mm central finger well. The supports are recessed there so a finger can get below the inner edge. Alternatively lift a folded bag tail at an end. Take out the bag before opening it; do not pull the contacts.

The lid is removable and has no hinge, screws, magnets, loose latch, or elastomer bands. The fixed rear wall sets the closed position; roof lips prevent lifting; the integral cantilever blocks withdrawal. Rounded outside corners, a rounded grip and raised labels improve handling. Interior edges should be deburred before inserting shielding bags.

## Files and regeneration

- `mailer.py`: original build123d source, with the dimensional parameter dictionary `P` at the top. Bay sizes drive the outer dimensions; lid, rails, supports, divider and finger well derive from them. Feature dimensions such as the latch ramp are explicit in the source. Large edits require renewed fit and feature-spacing checks.
- `output/base.step`, `output/lid.step`: separate exact CAD solids.
- `output/base.stl`, `output/lid.stl`: separate binary STL files, in the same local frames as the STEP files.
- `output/assembly.json`: millimeter assembly with explicit 4 × 4 local-to-assembly matrices. Base is identity; lid translates +0.4 mm in X and +14 mm in Z. Both STL and STEP use these transforms.
- `output/measured_checks.json`: CAD dimensions, volumes, fit and mechanism checks.
- `verify_mesh.py`, `output/mesh_checks.json`: independent trimesh checks.
- `verify_exports.py`, `output/export_checks.json`: STEP read-back, mesh-volume agreement and vertical bag-extraction checks.

Regenerate from this directory:

```sh
python mailer.py
python verify_mesh.py
python verify_exports.py
```

No packages were installed; no printing, slicing or rendering was performed.

## Font and manufacture assumptions

All three labels use the actual supplied `assets/fillaprint/Fillaprint-Regular.ttf`, extruded 0.6 mm. Cap height is measured at 7 mm, at a 10 mm em. The font's embedded description specifies two extrusion-width strokes, cap height 14 × line width and em 20 × line width. These labels correspond to 0.5 mm line width and 1 mm strokes; they exceed the 5.6 mm cap / 8 mm em minimum for 0.4 mm line width. Do not scale the files down or use a line width above 0.5 mm without enlarging the labels. The original font and its OFL license remain in `assets/fillaprint/`.

PETG is the intended starting material for the integral catch; its actual performance is untested. Both parts have their broad flat bottoms at local Z=0. The base requires removable support beneath its suspended catch; the 32 × 10 mm underside access window permits removal and inspection. Keep support out of the 1 mm side slots, or clean them fully. The shallow rail overhangs also need assessment on the intended process. The lid is flat with upward labels and grip. This is manufacture guidance, not a sliced or proven process recipe.

## Verification and remaining physical tests

CAD checks assert one valid solid per part, zero closed-part interference, zero interference for both folded-bag envelopes, and no rail interference at withdrawal positions 0, 2, 10, 40, 80 and 146 mm. At 3 and 6 mm withdrawal the undeformed catch intersects the lid (positive retention); after 1.6 mm downward displacement it clears. An upward lid movement of 1 mm intersects the captive rails. These are rigid geometric checks, with a translated tooth proxy for release, not a nonlinear flexure simulation or a continuous motion proof. Mesh checks verify binary encoding, watertightness, winding, connected components and bounds.

Rail running clearances are 0.4 mm per side and 0.4 mm vertically; overlap is 1.2 mm per side. Catch engagement is 1.2 mm, beam length 30 mm and thickness 1.6 mm. A simple cantilever estimate gives 0.43% outer-fiber strain for 1.6 mm release displacement. This ignores the ramp, root stress concentration, print anisotropy, creep and real material properties; it does not establish fatigue life or release force.

Before mailing valuable RAM, physically test: support removal and burr-free bag contact; the actual folded bags and padding; contact-edge clearance in both orientations; finger access; full insertion and release force; retention without pressing; repeated latch cycles and creep; and a loaded drop/shake test inside the intended cushioned cardboard box. Confirm bags remain intact and the modules cannot strike walls or move onto their contacts. No prototype or shipping qualification has been performed. Do not rely on friction alone if the catch fails to engage.
