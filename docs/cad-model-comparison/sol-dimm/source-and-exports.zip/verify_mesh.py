"""Independent binary STL and mesh checks; run with supplied physics Python."""
import json, struct
from pathlib import Path
import trimesh
out=Path(__file__).resolve().parent/'output'
report={}
for name in ('base','lid'):
 p=out/f'{name}.stl'; data=p.read_bytes()
 n=struct.unpack('<I',data[80:84])[0]
 mesh=trimesh.load_mesh(p,process=True)
 r=dict(binary_stl=len(data)==84+50*n,triangles=n,watertight=bool(mesh.is_watertight),winding_consistent=bool(mesh.is_winding_consistent),connected_components=len(mesh.split()),volume_mm3=float(mesh.volume),bounds_mm=mesh.bounds.tolist())
 assert r['binary_stl'] and r['watertight'] and r['winding_consistent'] and r['connected_components']==1,r
 report[name]=r
(out/'mesh_checks.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
