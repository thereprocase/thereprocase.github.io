#!/usr/bin/env python
"""Two-bay DDR4 mailer, dimensions in mm. Run from this directory."""
from build123d import *
from pathlib import Path
import json

# Shared dimensions. All exported parts use the assembled coordinate system.
L,W,H = 150.0,97.0,18.0
wall,floor,divider = 2.5,2.5,2.5
clearance,skirt,top = 0.35,2.0,2.0
lid_bottom,lid_top = 7.0,20.35
cavity_y=(W-2*wall-divider)/2
font=Path('assets/fillaprint/Fillaprint-Regular.ttf').resolve()
out=Path('output'); out.mkdir(exist_ok=True)
def box(l,w,h,x=0,y=0,z=0):
    return Pos(x,y,z)*Box(l,w,h,align=(Align.CENTER,Align.CENTER,Align.MIN))
# Tray wells, a divider with a finger scoop at the center, and clip pockets.
base=box(L,W,H)
for y in (-(divider+cavity_y)/2,(divider+cavity_y)/2):
    base-=box(L-2*wall,cavity_y,H-floor+1,0,y,floor)
base-=box(32,divider+0.02,10,0,0,10)
for sign in (-1,1):
    base-=box(19,1.05,2.6,0,sign*(W/2-0.525),8.3)
# Lid overlaps tray walls; two slotted, flexible tongue clips on the long sides.
outer_l=L+2*(clearance+skirt); outer_w=W+2*(clearance+skirt)
lid=box(outer_l,outer_w,lid_top-lid_bottom,0,0,lid_bottom)
lid-=box(L+2*clearance,W+2*clearance,18.35-lid_bottom,0,0,lid_bottom)
# Open-ended kerfs isolate each tongue; the tongue remains attached at the top.
for sign in (-1,1):
    for x in (-10.5,10.5):
        lid-=box(1.2,skirt+0.8,9.6,x,sign*(W/2+clearance+skirt/2),lid_bottom)
    # Bump extends inward 0.7 into the matching tray pocket; root overlaps skirt.
    lid+=box(18,1.25,1.8,0,sign*(W/2+clearance-0.375),8.7)
# Emboss labels directly onto lid, using the supplied font file.
for s,y,size in [('DDR4',6,10),('2 DIMMS',-7,8)]:
    label=Text(s,font_size=size,font_path=font,align=(Align.CENTER,Align.CENTER))
    lid+=Pos(0,y,lid_top)*extrude(label,amount=0.5)
for name,part in [('tray',base),('lid',lid)]:
    if not part.is_valid or len(part.solids()) != 1:
        raise ValueError(f'{name}: invalid or disconnected: {len(part.solids())}')
    export_step(part,out/f'{name}.step')
    export_stl(part,out/f'{name}.stl',tolerance=0.02,angular_tolerance=0.1)
    print(name,'volume',round(part.volume,2),'bounds',part.bounding_box().size,'solids',len(part.solids()))
print('assembled overlap volume', (base & lid).volume)
assembly={'units':'mm','coordinate_system':'Parts exported in assembled coordinates. Tray bottom is Z=0; lid above tray.', 'parts':[{'name':n,'step':f'{n}.step','stl':f'{n}.stl','transform':{'translation_mm':[0,0,0],'rotation_degrees_xyz':[0,0,0]}} for n in ('tray','lid')]}
(out/'assembly.json').write_text(json.dumps(assembly,indent=2)+'\n')
