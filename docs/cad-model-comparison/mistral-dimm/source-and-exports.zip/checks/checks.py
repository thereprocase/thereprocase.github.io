#!/usr/bin/env python
"""
Measured functional checks for the DDR4 dual mailer.

Run with the mesh runtime:
    python checks/checks.py

Verifies, against the exported STLs and the assembly transform:
  * files are binary STL, watertight, single solid, and match the CAD bbox
  * a bagged module of the supported envelope fits in each channel with
    measured clearance, and loads/removes vertically through the open top
  * the contact keep-out zone (gold-pad band on both module faces, module
    ends, module top) contains no solid material of base or assembled lid
  * the assembled lid does not interfere with the base (no overlap)
  * snap features exist: groove void in the base, hooks on the lid, hooks
    clear of the base when assembled, hook seated under the groove ceiling
  * finger notches, engraved slot numbers, embossed labels are present
  * font metrics from the build report: every label >= font minimum em size

Writes checks/report.json and exits non-zero on any failure.
"""

import json
import struct
import sys
from pathlib import Path

import numpy as np
import trimesh

ROOT = Path(__file__).resolve().parents[1]
PARTS = ROOT / "parts"

report = json.loads((ROOT / "build_report.json").read_text())
asm = json.loads((ROOT / "assembly.json").read_text())
P, D = report["params"], report["derived"]

results = []


def check(name, ok, detail=""):
    results.append({"check": name, "ok": bool(ok), "detail": str(detail)})
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: {detail}")


def grid(x0, x1, nx, y0, y1, ny, z0, z1, nz):
    xs = np.linspace(x0, x1, nx)
    ys = np.linspace(y0, y1, ny)
    zs = np.linspace(z0, z1, nz)
    X, Y, Z = np.meshgrid(xs, ys, zs, indexing="ij")
    return np.stack([X.ravel(), Y.ravel(), Z.ravel()], axis=1)


# ---------------------------------------------------------------- files ----
for pid in ("base", "lid"):
    path = PARTS / f"{pid}.stl"
    data = path.read_bytes()
    n_tri = struct.unpack("<I", data[80:84])[0]
    check(f"{pid}.stl is binary STL", len(data) == 84 + 50 * n_tri,
          f"{len(data)} bytes, {n_tri} triangles")
    check(f"{pid}.step exists", (PARTS / f"{pid}.step").stat().st_size > 10000,
          f"{(PARTS / f'{pid}.step').stat().st_size} bytes")

base = trimesh.load(PARTS / "base.stl")
lid = trimesh.load(PARTS / "lid.stl")

for pid, m in (("base", base), ("lid", lid)):
    check(f"{pid} watertight single solid", m.is_watertight and m.body_count == 1
          and m.is_winding_consistent and m.volume > 0,
          f"watertight={m.is_watertight} bodies={m.body_count} winding={m.is_winding_consistent} "
          f"vol={m.volume:.1f} mm^3 tris={len(m.faces)}")
    exp = report["parts"][pid]["bbox_mm"]
    bb = m.bounding_box.extents
    ok = np.allclose(bb, [exp[3] - exp[0], exp[4] - exp[1], exp[5] - exp[2]], atol=0.05)
    check(f"{pid} bbox matches CAD", ok, f"mesh {bb.round(3).tolist()} vs cad "
          f"{[round(exp[3]-exp[0],3), round(exp[4]-exp[1],3), round(exp[5]-exp[2],3)]}")

# ------------------------------------------------------- assembly pose ----
lid_t = next(p for p in asm["parts"] if p["id"] == "lid")["transform"]["translation"]
assert lid_t == [0.0, 0.0, D["assemble_z"]]
T = np.array(lid_t, dtype=float)
lid_a = lid.copy()
lid_a.apply_translation(T)
bb_a = trimesh.util.concatenate([base, lid_a]).bounding_box.extents
check("assembled bbox", np.allclose(bb_a, report["assembled_bbox_mm"], atol=0.05),
      f"{bb_a.round(3).tolist()} mm")

yc = D["yc"]
floor_t = P["floor_t"]
env_len, env_h, env_t = P["env_len"], P["env_h"], P["env_t"]
bag_len, bag_t = P["bag_len_allow"], P["bag_t_allow"]

# --------------------------------------------------- envelope fit/fit ----
for i, cy in enumerate((-yc, yc)):
    bag = grid(-env_len / 2 - bag_len / 2, env_len / 2 + bag_len / 2, 40,
               cy - (env_t + bag_t) / 2, cy + (env_t + bag_t) / 2, 7,
               floor_t + 0.02, floor_t + env_h - 0.02, 24)
    n_in = int(base.contains(bag).sum())
    check(f"channel {i+1}: bagged module envelope fits", n_in == 0,
          f"{len(bag)} sample pts inside base: {n_in}")

    mod = grid(-env_len / 2, env_len / 2, 40,
               cy - env_t / 2, cy + env_t / 2, 7,
               floor_t + 0.02, floor_t + env_h - 0.02, 24)
    n_in = int(base.contains(mod).sum())
    check(f"channel {i+1}: bare module envelope fits", n_in == 0,
          f"{len(mod)} sample pts inside base: {n_in}")

    # vertical load/remove path: channel centreline is clear over full depth
    path = grid(-D["channel_len"] / 2 + 1, D["channel_len"] / 2 - 1, 25,
                cy, cy, 1, floor_t + 0.5, D["base_H"] - 0.5, 12)
    n_in = int(base.contains(path).sum())
    check(f"channel {i+1}: open top, straight vertical load/remove", n_in == 0,
          f"{n_in} blocked pts")

    # measured side clearance: inflate the module until it touches the base
    # bare module: (channel_w - env_t)/2 = 1.10 mm air per side
    lo = grid(-env_len / 2, env_len / 2, 20, cy - env_t / 2 - 1.05, cy + env_t / 2 + 1.05, 5,
              floor_t + 0.5, floor_t + env_h - 0.5, 10)
    hi = grid(-env_len / 2, env_len / 2, 20, cy - env_t / 2 - 1.15, cy + env_t / 2 + 1.15, 5,
              floor_t + 0.5, floor_t + env_h - 0.5, 10)
    # bagged module (env_t + bag_t): (channel_w - env_t - bag_t)/2 = 0.70 mm air per side
    blo = grid(-env_len / 2, env_len / 2, 20, cy - (env_t + bag_t) / 2 - 0.65,
               cy + (env_t + bag_t) / 2 + 0.65, 5, floor_t + 0.5, floor_t + env_h - 0.5, 10)
    bhi = grid(-env_len / 2, env_len / 2, 20, cy - (env_t + bag_t) / 2 - 0.75,
               cy + (env_t + bag_t) / 2 + 0.75, 5, floor_t + 0.5, floor_t + env_h - 0.5, 10)
    ok = (int(base.contains(lo).sum()) == 0 and int(base.contains(hi).sum()) > 0
          and int(base.contains(blo).sum()) == 0 and int(base.contains(bhi).sum()) > 0)
    check(f"channel {i+1}: side clearance measured", ok,
          f"bare module clear at +1.05 ({int(base.contains(lo).sum())} hits), touches at +1.15 "
          f"({int(base.contains(hi).sum())} hits) -> 1.10 mm; bagged clear at +0.65 "
          f"({int(base.contains(blo).sum())} hits), touches at +0.75 ({int(base.contains(bhi).sum())} "
          f"hits) -> 0.70 mm air per side around the bag")

# ------------------------------------------------- contact keep-out -------
# gold-pad band: bottom ~3.5 mm of both module faces (pads wrap the edge)
viol_b = viol_l = 0
for cy in (-yc, yc):
    for s in (-1, 1):
        shell = grid(-66, 66, 36, cy + s * 4.05, cy + s * 5.0, 5, floor_t + 0.05, floor_t + 3.5, 7)
        viol_b += int(base.contains(shell).sum())
        viol_l += int(lid_a.contains(shell).sum())
check("contact zone (module faces, pad band) free of solid", viol_b == 0 and viol_l == 0,
      f"base hits {viol_b}, lid hits {viol_l}")

top = grid(-66, 66, 20, 0, 0, 1, 0, 0, 1)  # placeholder replaced below
viol = 0
for cy in (-yc, yc):
    shell = grid(-66, 66, 20, cy - (env_t + bag_t) / 2, cy + (env_t + bag_t) / 2, 5,
                 floor_t + env_h + 0.05, D["base_H"] - 0.05, 5)
    viol += int(lid_a.contains(shell).sum()) + int(base.contains(shell).sum())
check("module top clearance free of solid", viol == 0, f"{viol} hits")

viol = 0
for cy in (-yc, yc):
    shell = grid(env_len / 2 + 0.05, D["channel_len"] / 2 - 0.1, 12,
                 cy - (env_t + bag_t) / 2, cy + (env_t + bag_t) / 2, 5,
                 floor_t + 0.05, floor_t + 3.5, 5)
    viol += int(base.contains(shell).sum())
check("module end clearance free of solid", viol == 0, f"{viol} hits")

# --------------------------------------------- assembly interference ------
pl = trimesh.sample.sample_surface_even(lid, 15000)[0] + T
mask = np.abs(pl[:, 2] - D["base_H"]) > 0.02   # exclude the seating plane
n_in = int(base.contains(pl[mask]).sum())
check("lid surface does not penetrate base", n_in == 0, f"{n_in} of {int(mask.sum())} pts inside base")

pb = trimesh.sample.sample_surface_even(base, 15000)[0]
mask = np.abs(pb[:, 2] - D["base_H"]) > 0.02
n_in = int(lid_a.contains(pb[mask]).sum())
check("base surface does not penetrate lid", n_in == 0, f"{n_in} of {int(mask.sum())} pts inside lid")

# ------------------------------------------------------- snap features ----
gz0, gz1 = D["groove_z0"], D["groove_z1"]
gf = D["groove_floor_y"]
viol = 0
for s in (-1, 1):
    g = grid(-70, 70, 8, s * (gf + 0.1), s * (D["base_W"] / 2 - 0.1), 5, gz0 + 0.2, gz1 - 0.2, 5)
    g[:, 1] = s * np.abs(g[:, 1])
    viol += int(base.contains(g).sum())
check("snap groove void present in base walls", viol == 0, f"{viol} pts of groove inside base")

hook_ok = hook_clear = hook_tot = 0
for s in (-1, 1):
    # sample inside the hook body above the entry ramp (all coords already world/assembled)
    h = grid(P["hook_x"] - P["hook_len"] / 2 + 0.5, P["hook_x"] + P["hook_len"] / 2 - 0.5, 6,
             D["hook_tip_y"] + 0.05, D["skirt_inner_half"] - 0.15, 4,
             D["hook_z0w"] + P["hook_ramp"] + 0.1, D["hook_z0w"] + P["hook_h"] - 0.2, 4)
    h[:, 1] = s * np.abs(h[:, 1])
    hook_tot += len(h)
    hook_ok += int(lid_a.contains(h).sum())
    hook_clear += int(base.contains(h).sum())
check("snap hooks present on lid", hook_ok == hook_tot,
      f"{hook_ok}/{hook_tot} hook pts inside assembled lid")
check("snap hooks clear of base when assembled", hook_clear == 0, f"{hook_clear} hook pts inside base")
check("hook seated under groove ceiling (retention geometry)",
      D["hook_z0w"] + P["hook_h"] < gz1 and D["hook_tip_y"] > gf,
      f"hook top {D['hook_z0w'] + P['hook_h']:.2f} < ceiling {gz1:.2f}, "
      f"hook tip {D['hook_tip_y']:.2f} > groove floor {gf:.2f}; "
      f"undercut {D['undercut']:.2f} mm, release travel {D['release_travel']:.2f} mm")

# ------------------------------------------------------- other features ---
viol = 0
for cy in (-yc, yc):
    for xs in (-1, 1):
        n = grid(xs * (D["channel_len"] / 2 + 0.3), xs * (D["base_L"] / 2 - 0.3), 5,
                 cy - 4, cy + 4, 5, floor_t + 1, P["notch_top"] - 1, 5)
        viol += int(base.contains(n).sum())
check("finger notches through end walls", viol == 0, f"{viol} pts of notch inside base")

engrave_z = floor_t - P["engrave"]
has = bool(np.any(np.abs(base.vertices[:, 2] - engrave_z) < 0.02))
check("slot numbers engraved in channel floors", has, f"engraving depth plane z={engrave_z:.1f} present: {has}")

check("labels embossed on lid top",
      abs(lid.bounding_box.bounds[1][2] - P["emboss"]) < 0.02,
      f"lid zmax {lid.bounding_box.bounds[1][2]:.2f} = plate 0 + emboss {P['emboss']}")

# ------------------------------------------------------------ font ---------
fm = report["font"]
min_em = fm["min_printable_em_mm"]
ok = (not fm["missing_glyphs"]) and all(l["em_ok"] for l in fm["labels"]) and \
     all(l["width_mm"] <= D["lid_L"] - 12 for l in fm["labels"])
stems = list(fm["stem_units_on_straight_stems"].values())
check("font: all labels >= minimum printable em (20 x line width), glyphs present, widths fit",
      ok, f"min em {min_em:.1f} mm (w={fm['assumed_line_width_mm']} mm); "
          f"label ems {[l['em_mm'] for l in fm['labels']]}; stem {np.mean(stems):.0f}/{fm['upem']} em "
          f"= 2 beads; missing {fm['missing_glyphs']}")

# ------------------------------------------------------------ summary ------
mass_g = (base.volume + lid.volume) / 1000 * 1.27  # PETG ~1.27 g/cm^3
check("mass estimate (PETG 1.27 g/cm^3)", True, f"{mass_g:.1f} g")

out = {"checks": results, "assembled_bbox_mm": bb_a.round(3).tolist(),
       "mass_estimate_g_petg": round(mass_g, 1),
       "all_passed": all(r["ok"] for r in results)}
(ROOT / "checks" / "report.json").write_text(json.dumps(out, indent=2) + "\n")
print(f"\n{sum(r['ok'] for r in results)}/{len(results)} checks passed -> checks/report.json")
sys.exit(0 if out["all_passed"] else 1)
