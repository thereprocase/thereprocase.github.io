#!/usr/bin/env python
"""
Parametric reusable mailer for two bagged DDR4 DIMMs (ordinary heatspreaders).

Run with the build123d runtime:
    python src/mailer.py

Outputs (under the repo root):
    parts/base.step, parts/base.stl   (binary STL)
    parts/lid.step,  parts/lid.stl     (binary STL)
    assembly.json                      (assembled transforms, mm)
    build_report.json                  (parameters, derived dims, font metrics)

Design summary
--------------
* Two vertical channels in a base tray; each bagged DIMM drops in from the top
  and stands on its bare FR4 bottom edge.  Gold contact pads face sideways
  with >= 0.7 mm air gap on every side; nothing touches the contact zone.
* Lid = plate + perimeter skirt with 4 snap hooks that engage a groove in the
  base's long walls.  Close by pressing the lid down (hooks cam open, then
  snap in).  Open by squeezing the two long skirts toward each other and
  lifting.  No hardware.
* Rounded finger notches through both end walls let you pinch the bag low and
  pull a stick out after opening the lid.
* Labels are set in Fillaprint (assets/fillaprint), whose spec is
  "em = 20 x line width" (every stroke = 2 extrusion beads).  With an assumed
  line width w = 0.45 mm the minimum printable em is 9 mm; all labels use
  em >= 9 mm.

Frames: the base is modelled with its bottom at z=0.  The lid is modelled in a
local frame with the plate top at z=0 (skirt hangs down to z=-15); its
assembled transform is a pure translation of +53 mm in z (see assembly.json).
"""

import json
import math
from pathlib import Path

from build123d import (
    Align, Axis, Box, Cylinder, Plane, Text, chamfer, extrude,
    export_step, export_stl,
)

ROOT = Path(__file__).resolve().parents[1]
PARTS = ROOT / "parts"
FONT = str(ROOT / "assets" / "fillaprint" / "Fillaprint-Regular.ttf")

# ----------------------------------------------------------------------------
# Parameters (all mm unless noted)
# ----------------------------------------------------------------------------
P = dict(
    # --- supported module envelope (L x H x T), measured on the bare module ---
    env_len=136.0,      # JEDEC DDR4 UDIMM is 133.35; Corsair LPX 135 -> 136 covers common sticks
    env_h=45.0,         # covers 44 mm Trident Z / 42 mm Ripjaws V class; excludes 49+ mm RGB bars
    env_t=8.0,          # covers 6.6-7.5 mm heatsinked modules (Dominator 8 mm is excluded by height anyway)
    # --- shielding-bag allowance ---
    bag_len_allow=12.0, # extra channel length so the bag can overhang the module ends
    bag_t_allow=0.8,    # bag film thickness, both faces total
    pad_slack=1.4,      # remaining slack across channel width for paper/foam (total, both sides)
    top_clear=2.0,      # air above the tallest module (bag may poke up here)
    # --- base tray ---
    floor_t=3.0,
    wall_t=2.5,         # long side walls
    rib_t=4.0,          # rib between the two channels
    end_t=3.0,          # end walls
    base_chamfer=0.6,   # all 12 outer edges of the base box
    # --- lid ---
    plate_t=3.0,
    skirt_t=2.0,
    skirt_clear=0.25,   # air between skirt inner face and base outer wall
    skirt_h=12.0,       # skirt overlap height
    lid_top_chamfer=0.5,
    # --- snap snap-fit: groove in base walls, hooks on lid skirt ---
    groove_depth=1.2,       # into the outer wall face
    groove_h=3.0,
    groove_top_clear=6.0,   # wall material above the groove (retention ceiling)
    hook_len=18.0,          # along x
    hook_x=38.0,            # hook centre |x|
    hook_h=2.5,
    hook_protr=1.0,         # inward from skirt inner face
    hook_ramp=0.8,          # 45 deg cam on the hook's bottom-outer edge (< hook_protr)
    # --- finger notches through the end walls ---
    notch_r=5.1,            # = channel_w/2, rounded-top slot
    notch_top=13.0,         # top of the straight part (z), rounded top reaches notch_top + notch_r
    # --- labels ---
    emboss=0.8,
    engrave=0.6,
    text_title="DDR4 DIMM ×2",
    text_sub="squeeze the sides, then lift",
    text_press="PRESS",
    text_title_em=12.0,
    text_sub_em=9.0,
    text_press_em=9.0,
    text_num_em=9.0,
    line_y=5.5,         # title/sub centre offset on the lid top (y = +/- line_y)
    press_z=-9.0,       # PRESS text centre on the skirt (local z)
    num_x=-60.0,        # slot numbers engraved in the channel floors
    # --- font / print assumptions ---
    line_width=0.45,    # assumed FDM extrusion line width w (0.4 mm nozzle)
)

# ----------------------------------------------------------------------------
# Derived dimensions
# ----------------------------------------------------------------------------
D = {}
D["channel_w"] = P["env_t"] + P["bag_t_allow"] + P["pad_slack"]          # 10.2
D["channel_h"] = P["env_h"] + P["top_clear"]                              # 47
D["channel_len"] = P["env_len"] + P["bag_len_allow"]                      # 148
D["base_L"] = D["channel_len"] + 2 * P["end_t"]                           # 154
D["base_W"] = 2 * D["channel_w"] + P["rib_t"] + 2 * P["wall_t"]           # 29.4
D["base_H"] = P["floor_t"] + D["channel_h"]                               # 50
D["yc"] = D["base_W"] / 2 - P["wall_t"] - D["channel_w"] / 2              # channel centre |y| = 7.1
D["lid_L"] = D["base_L"] + 2 * P["skirt_t"] + 2 * P["skirt_clear"]        # 158.5
D["lid_W"] = D["base_W"] + 2 * P["skirt_t"] + 2 * P["skirt_clear"]        # 33.9
D["skirt_inner_half"] = D["lid_W"] / 2 - P["skirt_t"]                     # 14.95
D["assemble_z"] = D["base_H"] + P["plate_t"]                              # 53 (lid translation in z)
D["groove_z0"] = D["base_H"] - P["groove_top_clear"] - P["groove_h"]       # 41
D["groove_z1"] = D["groove_z0"] + P["groove_h"]                           # 44
D["groove_floor_y"] = D["base_W"] / 2 - P["groove_depth"]                 # 13.5
D["hook_z0w"] = D["groove_z0"] + 0.25                                     # hook bottom, world z
D["hook_tip_y"] = D["skirt_inner_half"] - P["hook_protr"]                 # 13.95
D["undercut"] = D["base_W"] / 2 - D["hook_tip_y"]                         # 0.75 engagement under the ceiling
D["release_travel"] = D["skirt_inner_half"] - D["groove_floor_y"]         # 1.45 mm squeeze to release
D["side_clearance"] = (D["channel_w"] - P["env_t"] - P["bag_t_allow"]) / 2  # 0.7 air beside module faces

LABELS = [
    ("title", P["text_title"], P["text_title_em"]),
    ("sub", P["text_sub"], P["text_sub_em"]),
    ("press", P["text_press"], P["text_press_em"]),
    ("slot number", "12", P["text_num_em"]),
]


# ----------------------------------------------------------------------------
# Font metrics (fontTools ships with the build123d runtime)
# ----------------------------------------------------------------------------
def font_metrics():
    from fontTools.ttLib import TTFont
    from fontTools.pens.basePen import BasePen

    f = TTFont(FONT)
    cmap = f.getBestCmap()
    hmtx = f["hmtx"]
    upem = f["head"].unitsPerEm
    cap = f["OS/2"].sCapHeight
    gs = f.getGlyphSet()

    class PolyPen(BasePen):
        def __init__(self, gs):
            super().__init__(gs)
            self.polys = []
            self.cur = None

        def _moveTo(self, p):
            self.cur = [p]

        def _lineTo(self, p):
            self.cur.append(p)

        def _curveToOne(self, p1, p2, p3):
            p0 = self.cur[-1]
            for i in range(1, 17):
                t = i / 16
                mt = 1 - t
                self.cur.append((mt**3 * p0[0] + 3 * mt * mt * t * p1[0] + 3 * mt * t * t * p2[0] + t**3 * p3[0],
                                 mt**3 * p0[1] + 3 * mt * mt * t * p1[1] + 3 * mt * t * t * p2[1] + t**3 * p3[1]))

        def _qCurveToOne(self, p1, p2):
            p0 = self.cur[-1]
            for i in range(1, 17):
                t = i / 16
                mt = 1 - t
                self.cur.append((mt * mt * p0[0] + 2 * mt * t * p1[0] + t * t * p2[0],
                                 mt * mt * p0[1] + 2 * mt * t * p1[1] + t * t * p2[1]))

        def _closePath(self):
            if self.cur and len(self.cur) > 2:
                self.polys.append(self.cur)
            self.cur = None

        def _endPath(self):
            self._closePath()

    def h_runs(gname, y):
        pen = PolyPen(gs)
        gs[gname].draw(pen)
        xs = []
        for poly in pen.polys:
            for i in range(len(poly)):
                (x1, y1), (x2, y2) = poly[i], poly[(i + 1) % len(poly)]
                if (y1 - y) * (y2 - y) < 0:
                    t = (y - y1) / (y2 - y1)
                    xs.append(x1 + t * (x2 - x1))
        xs.sort()
        return [xs[i + 1] - xs[i] for i in range(0, len(xs) - 1, 2)]

    def stem_units(ch):
        g = cmap[ord(ch)]
        pen = PolyPen(gs)
        gs[g].draw(pen)
        pts = [p for poly in pen.polys for p in poly]
        ymid = (min(p[1] for p in pts) + max(p[1] for p in pts)) / 2
        return min(h_runs(g, ymid))

    out = {
        "font": FONT,
        "upem": upem,
        "cap_height_units": cap,
        "stem_units_on_straight_stems": {ch: stem_units(ch) for ch in "Il1O0"},
        "design_stroke_fraction_of_em": 0.1,  # font spec: every stroke = 2 beads, em = 20 w
        "assumed_line_width_mm": P["line_width"],
        "min_printable_em_mm": 20 * P["line_width"],
        "labels": [],
    }
    missing = set()
    for name, s, em in LABELS:
        for ch in s:
            if ord(ch) not in cmap:
                missing.add(ch)
        w_units = sum(hmtx[cmap[ord(ch)]][0] for ch in s if ord(ch) in cmap)
        out["labels"].append({
            "name": name,
            "text": s,
            "em_mm": em,
            "cap_height_mm": cap / upem * em,
            "width_mm": w_units / upem * em,
            "stroke_mm": 0.1 * em,
            "em_ok": em >= 20 * P["line_width"] - 1e-9,
        })
    out["missing_glyphs"] = sorted(missing)
    return out


# ----------------------------------------------------------------------------
# Base tray
# ----------------------------------------------------------------------------
def build_base():
    L, W, H = D["base_L"], D["base_W"], D["base_H"]
    base = Box(L, W, H, align=(Align.CENTER, Align.CENTER, Align.MIN))
    base = chamfer(list(base.edges()), P["base_chamfer"])

    # two channels, open at the top, floor at z = floor_t
    for yc in (-D["yc"], D["yc"]):
        ch = Box(D["channel_len"], D["channel_w"], H - P["floor_t"] + 2,
                 align=(Align.CENTER, Align.CENTER, Align.MIN))
        base -= ch.translate((0, yc, P["floor_t"]))

    # finger notches through both end walls (one per channel per end)
    for xs in (-1, 1):
        for yc in (-D["yc"], D["yc"]):
            nb = Box(P["end_t"] + 0.4, 2 * P["notch_r"], P["notch_top"] - P["floor_t"],
                     align=(Align.CENTER, Align.CENTER, Align.MIN))
            nb = nb.translate((xs * (L / 2 - P["end_t"] / 2), yc, P["floor_t"]))
            cy = Cylinder(P["notch_r"], P["end_t"] + 0.6).rotate(Axis.Y, 90)
            cy = cy.translate((xs * L / 2, yc, P["notch_top"]))
            base -= nb + cy

    # snap grooves in the outer faces of the two long walls
    gz0, gz1 = D["groove_z0"], D["groove_z1"]
    for s in (-1, 1):
        g = Box(D["channel_len"], P["groove_depth"] + 0.1, P["groove_h"],
                align=(Align.CENTER, Align.CENTER, Align.CENTER))
        g = g.translate((0, s * (D["groove_floor_y"] + (P["groove_depth"] + 0.1) / 2), (gz0 + gz1) / 2))
        base -= g

    # slot numbers engraved into the channel floors
    for i, yc in enumerate((-D["yc"], D["yc"])):
        n = extrude(Text(str(i + 1), P["text_num_em"], font_path=FONT,
                         align=(Align.CENTER, Align.CENTER)), -P["engrave"])
        base -= n.translate((P["num_x"], yc, P["floor_t"]))

    return base


# ----------------------------------------------------------------------------
# Lid (local frame: plate top at z = 0, skirt down to z = -(plate_t + skirt_h))
# ----------------------------------------------------------------------------
def build_lid():
    L, W = D["lid_L"], D["lid_W"]
    plate = Box(L, W, P["plate_t"], align=(Align.CENTER, Align.CENTER, Align.MAX))
    skirt_out = Box(L, W, P["skirt_h"], align=(Align.CENTER, Align.CENTER, Align.MAX)).translate((0, 0, -P["plate_t"]))
    skirt_in = Box(L - 2 * P["skirt_t"], W - 2 * P["skirt_t"], P["skirt_h"] + 2,
                   align=(Align.CENTER, Align.CENTER, Align.MAX)).translate((0, 0, -P["plate_t"]))
    lid = plate + (skirt_out - skirt_in)

    # four snap hooks on the skirt inner faces, with a 45 deg entry ramp
    hz0_local = D["hook_z0w"] - D["assemble_z"]
    hz_c = hz0_local + P["hook_h"] / 2
    for s in (-1, 1):
        for hx in (P["hook_x"], -P["hook_x"]):
            h = Box(P["hook_len"], P["hook_protr"], P["hook_h"],
                    align=(Align.CENTER, Align.CENTER, Align.CENTER))
            h = h.translate((hx, s * (D["skirt_inner_half"] - P["hook_protr"] / 2), hz_c))
            ramp = [e for e in h.edges()
                    if abs(e.center().X - hx) < 1e-6
                    and abs(abs(e.center().Y) - D["skirt_inner_half"]) < 1e-6
                    and abs(e.center().Z - hz0_local) < 1e-6]
            assert len(ramp) == 1, f"ramp edge not found: {len(ramp)}"
            h = chamfer(ramp, P["hook_ramp"])
            lid += h

    # chamfer the plate top perimeter
    top = [e for e in lid.edges()
           if abs(e.center().Z) < 1e-6
           and (abs(abs(e.center().X) - L / 2) < 1e-6 or abs(abs(e.center().Y) - W / 2) < 1e-6)]
    assert len(top) == 4, f"lid top edges: {len(top)}"
    lid = chamfer(top, P["lid_top_chamfer"])

    # labels on the lid top (embossed)
    title = extrude(Text(P["text_title"], P["text_title_em"], font_path=FONT,
                         align=(Align.CENTER, Align.CENTER)), P["emboss"])
    lid += title.translate((0, P["line_y"], 0))
    sub = extrude(Text(P["text_sub"], P["text_sub_em"], font_path=FONT,
                       align=(Align.CENTER, Align.CENTER)), P["emboss"])
    lid += sub.translate((0, -P["line_y"], 0))

    # PRESS on both long skirt outer faces
    for s in (-1, 1):
        plane = Plane(origin=(0, s * W / 2, P["press_z"]),
                      x_dir=(-s, 0, 0), z_dir=(0, s, 0))
        t = extrude(Text(P["text_press"], P["text_press_em"], font_path=FONT,
                         align=(Align.CENTER, Align.CENTER)), 0.6)
        lid += t.moved(plane.location)

    return lid


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
def main():
    PARTS.mkdir(exist_ok=True)
    base = build_base()
    lid = build_lid()

    # sanity on solids
    for name, part in (("base", base), ("lid", lid)):
        assert len(part.solids()) == 1, f"{name}: {len(part.solids())} solids"
        assert part.volume > 0

    export_step(base, PARTS / "base.step")
    export_stl(base, PARTS / "base.stl")          # binary STL (ascii_format=False default)
    export_step(lid, PARTS / "lid.step")
    export_stl(lid, PARTS / "lid.stl")

    fm = font_metrics()
    for lab in fm["labels"]:
        assert lab["width_mm"] <= D["lid_L"] - 12, f"label too wide: {lab}"
        assert lab["em_ok"], f"label below font minimum size: {lab}"
    assert not fm["missing_glyphs"], fm["missing_glyphs"]

    bb_base = base.bounding_box()
    bb_lid = lid.bounding_box()
    assembly = {
        "name": "ddr4-dual-mailer",
        "units": "mm",
        "description": "Two-part reusable mailer for two bagged DDR4 DIMMs. "
                       "Base at identity; lid translated +z so its plate underside "
                       "seats on the base top (closed pose).",
        "parts": [
            {
                "id": "base",
                "step": "parts/base.step",
                "stl": "parts/base.stl",
                "local_bbox_mm": [[bb_base.min.X, bb_base.min.Y, bb_base.min.Z],
                                  [bb_base.max.X, bb_base.max.Y, bb_base.max.Z]],
                "transform": {
                    "translation": [0.0, 0.0, 0.0],
                    "rotation_matrix": [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
                },
            },
            {
                "id": "lid",
                "step": "parts/lid.step",
                "stl": "parts/lid.stl",
                "local_bbox_mm": [[bb_lid.min.X, bb_lid.min.Y, bb_lid.min.Z],
                                  [bb_lid.max.X, bb_lid.max.Y, bb_lid.max.Z]],
                "transform": {
                    "translation": [0.0, 0.0, D["assemble_z"]],
                    "rotation_matrix": [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
                },
            },
        ],
    }
    (ROOT / "assembly.json").write_text(json.dumps(assembly, indent=2) + "\n")

    report = {
        "params": P,
        "derived": D,
        "font": fm,
        "parts": {
            "base": {"volume_mm3": base.volume,
                     "bbox_mm": [bb_base.min.X, bb_base.min.Y, bb_base.min.Z,
                                 bb_base.max.X, bb_base.max.Y, bb_base.max.Z]},
            "lid": {"volume_mm3": lid.volume,
                    "bbox_mm": [bb_lid.min.X, bb_lid.min.Y, bb_lid.min.Z,
                                bb_lid.max.X, bb_lid.max.Y, bb_lid.max.Z]},
        },
        "assembled_bbox_mm": [
            bb_lid.max.X - bb_lid.min.X,
            bb_lid.max.Y - bb_lid.min.Y,
            D["assemble_z"] + bb_lid.max.Z,
        ],
    }
    (ROOT / "build_report.json").write_text(json.dumps(report, indent=2) + "\n")

    print("base: vol %.1f mm^3  bbox %s" % (base.volume, report["parts"]["base"]["bbox_mm"]))
    print("lid:  vol %.1f mm^3  bbox %s" % (lid.volume, report["parts"]["lid"]["bbox_mm"]))
    print("assembled bbox: %s mm" % report["assembled_bbox_mm"])
    print("channel: %.1f x %.1f x %.1f mm, centres y = +/-%.2f" %
          (D["channel_len"], D["channel_w"], D["channel_h"], D["yc"]))
    print("snap: undercut %.2f mm, release travel %.2f mm, side clearance %.2f mm" %
          (D["undercut"], D["release_travel"], D["side_clearance"]))
    for lab in fm["labels"]:
        print("label %-12s em %.1f mm cap %.2f mm width %.1f mm stroke %.2f mm" %
              (lab["name"], lab["em_mm"], lab["cap_height_mm"], lab["width_mm"], lab["stroke_mm"]))
    print("wrote parts/, assembly.json, build_report.json")


if __name__ == "__main__":
    main()
