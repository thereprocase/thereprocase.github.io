# DDR4 dual-stick mailer (2 parts, snap lid, no hardware)

A small reusable two-part case that holds **two desktop DDR4 DIMMs, each in its
own shielding bag**, padded with a little paper or foam, and then goes inside
an ordinary outer cardboard shipping box. Parametric build123d source plus
exported STEP and binary STL per part.

- Assembled size: **158.5 × 35.1 × 53.8 mm**, ≈ 136 g in PETG
- Base: 154.0 × 29.4 × 50.0 mm — two channels 148 × 10.2 × 47 mm at y = ±7.1
- Lid: plate + skirt with 4 snap hooks; assembled by a +53 mm z translation
  (see `assembly.json`)

## Files

| path | what |
|---|---|
| `src/mailer.py` | parametric CAD (build123d 0.13); rebuilds everything |
| `parts/base.step`, `parts/base.stl` | base tray (binary STL) |
| `parts/lid.step`, `parts/lid.stl` | lid (binary STL) |
| `assembly.json` | part files + actual assembled transforms in mm |
| `build_report.json` | parameters, derived dims, font metrics (written by the build) |
| `checks/checks.py`, `checks/report.json` | measured checks on the exported meshes (trimesh) |
| `assets/fillaprint/` | Fillaprint-Regular.ttf + OFL license (labels use this font) |

Rebuild: `python src/mailer.py`
Re-check: `python checks/checks.py` → 31/31 pass

## Supported envelope (and why)

The case supports bagged modules up to **136 mm long × 45 mm tall × 8 mm
thick** (bare module), with the bag allowed 6 mm overhang per end and
0.4 mm per face. Real examples:

| module | L × T × H (mm) | fits? |
|---|---|---|
| JEDEC DDR4 UDIMM (MO-309) bare PCB | 133.35 × ~1.3 × 31.25 | yes |
| Corsair Vengeance LPX | 135 × 6.64 × 33.53 | yes |
| G.Skill Flare X / Ripjaws V / Sniper X | 133.35 × ~7.5 × 40 / 42 / 43 | yes |
| G.Skill Trident Z / Neo / RGB / Royal | 133.35 × ~7.5 × 44 | yes |
| Kingston FURY / Crucial Ballistix class | ≤ 136 × ≤ 7.5 × ≤ 45 | yes |
| Corsair Vengeance RGB Pro SL | 138.3 × 7.5 × 44.8 | no (length 138.3 > 136) |
| Corsair Vengeance LED / RGB Pro | 136 × 7.5 × 49 / 138.3 × 7.5 × 51 | no (height) |
| Corsair Dominator Platinum RGB | 135 × 8 × 56 | no (height) |
| G.Skill Trident Z RGB DC | 59 tall | no |

Sources (via the allowed proxy): JEDEC/Wikipedia DDR4 UDIMM 133.35 mm length,
31.25 mm max height, 1.27 mm PCB (socket datasheets: 288 pins @ 0.85 mm);
Corsair "DDR4 memory module dimensions" explorer table (LPX 135×6.64×33.53,
LED 136×7.5×49, RGB Pro 138.3×7.5×51, RGB Pro SL 138.3×7.5×44.8, Dominator
135×8×56); G.Skill module-height spec PDF (DDR4: Aegis/Fortis 31.2, Flare X 40,
Ripjaws V 42, Sniper X 43, Trident Z family 44, Trident Z RGB DC 59).

So the envelope deliberately covers ordinary heatsinked sticks up to 44–45 mm
tall and 8 mm thick, and excludes the tall RGB light-bar modules (49–59 mm) —
that is the "sensible range", not every exotic heatsink.

## How it works

- **Load**: open the lid, drop each bagged stick upright into its channel
  (slot numbers "1"/"2" are engraved in the channel floors), tuck in paper or
  foam. The channel leaves 0.7 mm air per side around the bag (1.1 mm around a
  bare 8 mm module) for the padding, 2 mm above the module top, and ~3 mm at
  each end.
- **Close**: press the lid straight down. The four hooks on the lid skirt ride
  their 0.8 mm entry ramps over the chamfered wall tops, the skirt bows
  outward slightly, then the hooks snap into the groove (z 41–44 mm) in the
  base's long walls. The lid stays on by a 0.75 mm undercut under the groove
  ceiling — no screws, magnets, or straps.
- **Open**: squeeze the two long sides of the lid toward each other (the
  faces labelled **PRESS**) about 1.5 mm and lift. The hooks retract from the
  groove and the lid comes off.
- **Remove a stick**: lift it straight up out of the open channel. If you
  prefer to pull low, the rounded finger notches through both end walls let
  you pinch the bag at the bottom of the channel.

**Contact protection**: each stick stands on its bare FR4 bottom edge (the
same surface slot guides touch). The gold pads are on the faces and the contact
band at the bottom edge; measured on the exported meshes, that whole zone has
≥ 0.7 mm air to every case surface, the lid underside is 2 mm above the
tallest module, and nothing touches the module ends — and the sticks are
bagged anyway. Verified by point-sampling the keep-out shells against the
assembled base+lid meshes (0 hits).

## Labels (Fillaprint)

Fillaprint's own spec (font name table): *"every stroke is exactly two
extrusion widths (w); em = 20 × line width"* — so its minimum printable size
is em = 20·w. Assuming a 0.4 mm nozzle with w = 0.45 mm line width, the
minimum is **em 9 mm** (cap height 6.3 mm, stroke 0.9 mm = 2 beads). All labels
meet or exceed that:

- lid top: `DDR4 DIMM ×2` (em 12 mm, cap 8.4 mm) and
  `squeeze the sides, then lift` (em 9 mm) — embossed 0.8 mm
- both long skirt faces: `PRESS` (em 9 mm) — embossed 0.6 mm
- channel floors: `1`, `2` (em 9 mm) — engraved 0.6 mm

## Measured checks (checks/report.json, 31/31 pass)

Binary-STL format, watertight single solids, mesh bboxes equal the CAD bboxes,
bagged and bare envelope boxes fit both channels with zero intersections,
straight vertical load/remove path clear, side clearance measured by
inflation (1.10 mm bare / 0.70 mm bagged per side), contact/top/end keep-out
shells free of solid, no lid↔base interference in the assembled pose, groove
and hook geometry present with hooks seated under the ceiling (undercut
0.75 mm, release travel 1.45 mm), notches/engraving/emboss present, and font
metrics (all label ems ≥ 9 mm, glyphs present, widths fit the lid).

## Limitations — what still needs a physical test

- Snap **force and fatigue** are not simulated: the 0.75 mm undercut and
  1.45 mm release travel are verified geometrically only. Print in PETG (or
  similar tough filament) and cycle the lid ~50× to confirm the hooks survive.
- FDM tolerance (±0.1–0.2 mm) eats into the 0.25 mm skirt clearance and the
  0.7 mm bag-side air gap; check the first print's lid fit.
- Bag film assumed ≤ 0.4 mm per face; a thicker bag reduces the side air gap.
- No drop/vibration test was run — the mailer is meant to sit cushioned inside
  the outer cardboard box.
- Print orientation is suggested (base channels-up, lid plate-down; no
  supports expected) but not sliced/validated here. The lid STEP is ~17 MB
  because of the glyph outlines.
