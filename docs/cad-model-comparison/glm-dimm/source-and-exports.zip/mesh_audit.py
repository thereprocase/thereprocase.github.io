#!/usr/bin/env python3
"""
mesh_audit.py -- Mesh-level verification, run with the trimesh/numpy runtime.

  * re-exports both STLs as binary STL (deliverable format)
  * watertightness + volume vs CAD volume
  * print-orientation overhang audit (what prints without supports)
  * sampled clearance audit: gold-strip probe volumes from checks_cad.json
    vs. the tray mesh -- every gold finger surface stays >= 0.9 mm from
    solid material in all worst cases
  * merged result -> checks.json
"""

import json
from pathlib import Path

import numpy as np
import trimesh

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "exports"

results = {}
PASS = "pass"


def check(name, ok, detail):
    results[name] = {"pass": bool(ok), "detail": detail}
    print(("PASS " if ok else "FAIL ") + name + " :: " + str(detail)[:160])


def overhangs(mesh, flip_z=False, above_first_layer=0.25, nz_thresh=-0.7072):
    """Downward-facing facets steeper than ~45 deg, excluding the bed face."""
    m = mesh.copy()
    if flip_z:
        m.apply_transform(trimesh.transformations.reflection_matrix(
            [0, 0, m.bounds[1][2]], [0, 0, 1]))
    zmin = m.bounds[0][2]
    face_nz = m.face_normals[:, 2]
    face_minz = m.vertices[m.faces[:, :], 2].min(axis=1)
    mask = (face_nz < nz_thresh) & (face_minz > zmin + above_first_layer)
    area = float(m.area_faces[mask].sum())
    facets = [
        {"area": round(float(a), 3), "z_min": round(float(z), 2),
         "centroid": [round(float(c), 2) for c in ctr]}
        for a, z, ctr in zip(m.area_faces[mask], face_minz[mask],
                             m.triangles_center[mask])
    ]
    return area, facets


def main():
    cad = json.loads((ROOT / "checks_cad.json").read_text())

    meshes = {}
    for part in ("tray", "lid"):
        path = OUT / f"ddr4_mailer_{part}.stl"
        raw = path.read_bytes()
        was_binary = not raw.lstrip().startswith(b"solid")
        m = trimesh.load(path, force="mesh")
        meshes[part] = m

        check(f"mesh_{part}_watertight", m.is_watertight and m.is_winding_consistent,
              f"watertight={m.is_watertight}, winding_consistent={m.is_winding_consistent}, "
              f"euler={m.euler_number}, faces={len(m.faces)}, was_binary_stl={was_binary}")

        # re-export as binary STL (deliverable format)
        m.export(path, file_type="stl")  # trimesh writes binary STL by default
        raw2 = path.read_bytes()
        check(f"mesh_{part}_binary_stl", not raw2.lstrip().startswith(b"solid"),
              f"{path.name}: {len(raw2)} bytes, binary=True")

        check(f"mesh_{part}_volume", m.volume > 0,
              f"volume {m.volume / 1000.0:.1f} cm3, bbox "
              f"{np.round(m.extents, 3).tolist()} mm")

    # ------------------------------------------------------------------
    # print-orientation overhang audit
    # ------------------------------------------------------------------
    # Allowed steep overhangs (all short bridges by design):
    #   tray: 4 channel-ceiling bridges (chan_len - notch_len) x slot_depth
    #         + 2 end-pad ledges bridging the trench, pad_t x trench_w
    #   lid : 4 tab root ledges, tab_len x (tab_out - chamfer)
    pu = cad["_params_used"]
    du = cad["_derived_used"]
    ceil_bridge = 4 * (du["chan_x1"][0] - du["chan_x0"][0] - du["notch_len"]) * pu["slot_depth"]
    pad_bridge = 2 * pu["pad_t"] * du["trench_w"]
    tab_ledge = 4 * pu["tab_len"] * (pu["tab_out"] - 0.6)

    area_t, fac_t = overhangs(meshes["tray"], flip_z=False,
                              above_first_layer=0.25)
    area_l, fac_l = overhangs(meshes["lid"], flip_z=True,
                              above_first_layer=pu["lid_plate"] + pu["label_depth_lid"] + 0.1)
    z_ok_t = all((2.6 <= f["z_min"] <= 3.0) or (13.7 <= f["z_min"] <= 14.0)
                 for f in fac_t)
    check("tray_print_overhangs_bounded",
          area_t <= ceil_bridge + pad_bridge + 2.0 and z_ok_t,
          f"steep overhang area {area_t:.1f} mm2 (allowed: {ceil_bridge:.1f} mm2 "
          f"channel-ceiling bridges {round(du['chan_x1'][0]-du['chan_x0'][0]-du['notch_len'],1)}x{pu['slot_depth']} mm, "
          f"+ {pad_bridge:.1f} mm2 end-pad trench bridges {pu['pad_t']}x{round(du['trench_w'],1)} mm); "
          f"all {len(fac_t)} facets at designed bridge heights, z_min set "
          f"{sorted(set(f['z_min'] for f in fac_t))}")
    check("lid_print_overhangs_bounded",
          area_l <= tab_ledge + 2.0,
          f"steep overhang area {area_l:.1f} mm2 in {len(fac_l)} facets "
          f"(allowed: {tab_ledge:.1f} mm2 tab root ledges {pu['tab_len']}x"
          f"{round(pu['tab_out']-0.6,1)} mm at print height 20.2 mm)")

    # ------------------------------------------------------------------
    # sampled gold-clearance audit vs the tray mesh
    # ------------------------------------------------------------------
    tray = meshes["tray"]
    pq = trimesh.proximity.ProximityQuery(tray)

    def grid(a, b, n):
        return np.linspace(a, b, n)

    worst_surface = None
    all_ok = True
    for pr in cad["_gold_probes"]:
        x0, y0, z0, x1, y1, z1 = pr["bbox"]
        pts = []
        # finger-bearing faces: bottom (over the trench) and top (under the lid)
        gx = grid(x0 + 1.0, x1 - 1.0, 40)
        gy = grid(y0 + 1.0, y1 - 1.0, 8)
        GX, GY = np.meshgrid(gx, gy)
        for z in (z0, z1):
            pts.append(np.column_stack([GX.ravel(), GY.ravel(),
                                         np.full(GX.size, z)]))
        # the module END faces and the outer y-face may legitimately touch the
        # end pad / bay wall by design; only require them not to be inside.
        edge = []
        for x in (x0, x1):
            edge.append(np.column_stack([np.full(len(gy), x), gy,
                                          np.full(len(gy), (z0 + z1) / 2)]))
        P = np.vstack(pts)
        sd = pq.signed_distance(P)
        if worst_surface is None or sd.max() > worst_surface:
            worst_surface = float(sd.max())
        ok = (sd.max() < -0.9)
        E = np.vstack(edge)
        sde = pq.signed_distance(E)
        ok = ok and (sde.max() < 1e-6)
        all_ok = all_ok and ok
        if not ok:
            print("  gold probe fail:", pr["bay"], pr["h"], pr["dy"],
                  "max sd", sd.max(), "edge max", sde.max())
    check("gold_fingers_clear_tray_mesh", all_ok,
          f"closest gold finger surface to tray solid over "
          f"{len(cad['_gold_probes'])} worst-case placements: "
          f"{-worst_surface:.2f} mm (required >= 0.9 mm; trench depth 1.8 mm)")

    # ------------------------------------------------------------------
    # closed assembly consistency (mesh space)
    # ------------------------------------------------------------------
    lid_t = cad["record_dimensions"]["detail"]["lid_rest_dz"]
    lid_moved = meshes["lid"].copy()
    lid_moved.apply_translation([0.0, 0.0, lid_t])
    combined = trimesh.util.concatenate([meshes["tray"], lid_moved])
    ext = np.round(combined.extents, 3)
    expect = cad["record_dimensions"]["detail"]["closed_outer"]
    check("closed_assembly_footprint", bool(np.allclose(ext, expect, atol=0.01)),
          f"closed bbox {ext.tolist()} mm vs CAD {expect}")

    # ------------------------------------------------------------------
    # merge into checks.json
    # ----------------------------------------------------------------__
    out = dict(cad)
    for k, v in results.items():
        out["mesh_" + k] = v
    (ROOT / "checks.json").write_text(json.dumps(out, indent=2))
    n_pass = sum(1 for v in out.values() if isinstance(v, dict) and v.get("pass") is True)
    n_fail = sum(1 for v in out.values() if isinstance(v, dict) and v.get("pass") is False)
    print(f"\nchecks.json: {n_pass} passed, {n_fail} failed")
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
