#!/usr/bin/env python3
"""
checks.py -- Functional verification of the DDR4 mailer, run with the
build123d runtime. Verifies the design against its intended USE, not just
that solids exist:

  * every supported module envelope (bare PCB, tallest heatsinked) drops
    into both bays along the real insertion path without collision
  * the gold-contact strip can never touch the tray, at any supported
    module height and even when the stick is shoved against the bay wall
  * the lid: drops without collision, locks by sliding, cannot be lifted
    or over-slid when locked, cannot lift mid-slide, releases at the entry
    notches
  * label metrics: every label at or above the font's minimum printable
    size derived from measured stroke width

Writes checks_cad.json (merged by mesh_audit.py into checks.json).
"""

import json
from pathlib import Path

from build123d import Pos, Text, TextAlign

import ddr4_mailer as M

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "exports"
results = {}


def vol(part):
    return part.volume


def check(name, ok, detail):
    results[name] = {"pass": bool(ok), "detail": detail}
    print(("PASS " if ok else "FAIL ") + name + " :: " + str(detail))


def main():
    p = M.P
    d = M.derived(p)
    tray, _ = M.build_tray(p)
    lid, _ = M.build_lid(p)

    # ------------------------------------------------------------------
    # 1. Module fit: drop-in along the real vertical insertion path
    # ------------------------------------------------------------------
    for bay in (1, 2):
        for tag, h, t in (
            ("bare_pcb", p["stick_h_min"], p["stick_t_min"]),
            ("low_hs", 32.8, 7.0),           # G.Skill Flare X class
            ("max_hs", p["stick_h_max"], p["stick_t_max"]),
        ):
            mod = M.module_at(p, bay=bay, h=h, t=t)
            inter = vol(mod & tray)
            # insertion sweep: the same footprint from seated height upward
            # through the open top of the bay
            sweep_xy = M.module_at(p, bay=bay, h=h, t=60 + t)
            inter_sweep = vol(sweep_xy & tray)
            check(
                f"fit_{tag}_bay{bay}",
                inter < 1e-7 and inter_sweep < 1e-7,
                f"seated overlap {inter:.6f} mm3, sweep overlap {inter_sweep:.6f} mm3 "
                f"(h={h}, t={t})",
            )

    # ------------------------------------------------------------------
    # 2. Gold-contact protection: worst-case positions
    # ------------------------------------------------------------------
    worst = []
    for bay in (1, 2):
        for h in (p["stick_h_min"], 36.0, p["stick_h_max"]):
            dy_max = d["bay_w"] - p["rail_t"] - h  # shoved to the outer wall
            for dy in (0.0, dy_max):
                g = M.gold_strip(p, bay=bay, h=h, t=p["stick_t_max"], dy=dy)
                inter = vol(g & tray)
                worst.append(inter)
                assert inter < 1e-7, (bay, h, dy, inter)
    check(
        "gold_never_touches_tray",
        max(worst) < 1e-7,
        f"max overlap over {len(worst)} worst cases = {max(worst):.6g} mm3 "
        f"(trench {d['trench_w']} x {p['trench_depth']} mm, full bay length)",
    )

    # trench actually spans every possible gold position
    span = []
    for h in (p["stick_h_min"], p["stick_h_max"]):
        dgold = d["bay_w"] - p["rail_t"] - h          # wall -> gold edge
        span.append((dgold, dgold + p["gold_h"]))
    check(
        "trench_spans_gold_positions",
        span[0][1] <= d["trench_w"] and span[1][0] >= 0.0,
        f"gold strip positions from outer wall: {span}; trench covers 0..{d['trench_w']}",
    )

    # ------------------------------------------------------------------
    # 3. Lid function: drop, slide, lock, release
    # ------------------------------------------------------------------
    # locked/seated transform: lid rests on the detent bumps, which preload
    # it between bump and channel ceiling (no vertical rattle).
    dz_rest = p["rest_gap"] + (p["detent_h"] - p["tab_floor_clear"])

    def lid_at(dx, dz):
        return Pos(dx, 0, dz) * lid

    c = {}
    c["drop_seated"] = vol(lid_at(-p["travel"], p["rest_gap"]) & tray)
    c["locked_seated"] = vol(lid_at(0.0, dz_rest) & tray)
    c["locked_lift_0p1"] = vol(lid_at(0.0, dz_rest + 0.1) & tray)   # slop band
    c["locked_lift_0p3"] = vol(lid_at(0.0, dz_rest + 0.3) & tray)   # must block
    c["locked_press_down"] = vol(lid_at(0.0, dz_rest - 0.2) & tray)  # detent holds down
    c["locked_overslide_0p3"] = vol(lid_at(0.3, dz_rest + 0.3) & tray)  # endstop
    c["wrongway_slide_blocked"] = vol(
        lid_at(-p["travel"] - 0.6, p["rest_gap"]) & tray
    )
    c["mid_slide_lift_blocked"] = vol(
        lid_at(-p["travel"] / 2, p["rest_gap"] + 0.35) & tray
    )
    c["mid_slide_lift_blocked2"] = vol(
        lid_at(-p["travel"] + 0.5, p["rest_gap"] + 0.35) & tray
    )
    c["at_notch_lift_free"] = vol(
        lid_at(-p["travel"], p["rest_gap"] + 0.35) & tray
    )
    c["remove_after_slide"] = vol(
        lid_at(-p["travel"], p["rest_gap"] + 50.0) & tray
    )
    c["full_removal"] = vol(lid_at(0.0, p["rest_gap"] + 50.0) & tray)

    check("lid_drops_without_collision", c["drop_seated"] < 1e-6,
          f"drop overlap {c['drop_seated']:.6g} mm3")
    check("lid_locked_no_collision", c["locked_seated"] < 1e-6,
          f"locked overlap {c['locked_seated']:.6g} mm3 (dz={dz_rest:.2f})")
    check("lid_locked_lift_blocked", c["locked_lift_0p3"] > 1e-3,
          f"lift +0.3 mm overlap {c['locked_lift_0p3']:.3f} mm3 (tab under channel ceiling)")
    check("lid_locked_vertical_slop_small",
          c["locked_lift_0p1"] < 1e-6 and c["locked_press_down"] > 1e-3,
          f"lift +0.1 free: {c['locked_lift_0p1']:.3g}; press-down blocked: "
          f"{c['locked_press_down']:.3f} mm3 (detent preload)")
    check("lid_cannot_overslide", c["locked_overslide_0p3"] > 1e-3,
          f"overslide +0.3 mm overlap {c['locked_overslide_0p3']:.3f} mm3 (endstop)")
    check("lid_cannot_slide_wrong_way", c["wrongway_slide_blocked"] > 1e-3,
          f"wrong-way slide overlap {c['wrongway_slide_blocked']:.3f} mm3 "
          f"(entry notch is one-way beyond its 0.3 mm entry clearance)")
    check("lid_mid_slide_cannot_lift",
          c["mid_slide_lift_blocked"] > 1e-3 and c["mid_slide_lift_blocked2"] > 1e-3,
          f"mid-slide lift overlaps {c['mid_slide_lift_blocked']:.3f} / "
          f"{c['mid_slide_lift_blocked2']:.3f} mm3")
    check("lid_releases_at_entry_notch",
          c["at_notch_lift_free"] < 1e-6 and c["remove_after_slide"] < 1e-6
          and c["full_removal"] < 1e-6,
          f"at-notch lift {c['at_notch_lift_free']:.3g}, removal "
          f"{c['remove_after_slide']:.3g} mm3")

    # ------------------------------------------------------------------
    # 4. Label metrics
    # ------------------------------------------------------------------
    # Fillaprint-Regular.ttf measured with fontTools: upem 1000, cap height
    # 700 units, stroke width 100 units -> stroke = 0.10 em, cap = 0.70 em.
    STROKE_EM = 0.10
    labels = [("lid", s, size) for s, size, *_ in M.LID_LABELS] + \
             [("floor", s, size) for s, size, *_ in M.FLOOR_LABELS]
    metrics = []
    ok = True
    ok_extent = True
    for where, s, size in labels:
        face = Text(s, font_size=size, font_path=str(M.FONT_PATH),
                    text_align=(TextAlign.CENTER, TextAlign.CENTER))
        bb = face.bounding_box()
        w, h = bb.max.X - bb.min.X, bb.max.Y - bb.min.Y
        stroke = STROKE_EM * size
        entry = {"where": where, "text": s, "size_mm": size,
                 "bbox_w_mm": round(w, 2), "bbox_h_mm": round(h, 2),
                 "stroke_mm": round(stroke, 3)}
        metrics.append(entry)
        if size < p["min_label_size"] or stroke < 0.5:
            ok = False
    check("labels_at_or_above_min_size", ok,
          {"min_size_policy": p["min_label_size"], "labels": metrics})

    # extents: every debossed label must sit fully on its face with margin
    for (s, size, x, y) in M.LID_LABELS:
        face = Text(s, font_size=size, font_path=str(M.FONT_PATH),
                    text_align=(TextAlign.CENTER, TextAlign.CENTER))
        bb = face.bounding_box()
        x0, x1 = x + bb.min.X, x + bb.max.X
        y0, y1 = y + bb.min.Y, y + bb.max.Y
        m = 1.0
        inside = (x0 > -d["lid_out_x"] / 2 + m and x1 < d["lid_out_x"] / 2 - m and
                  y0 > -d["lid_out_y"] / 2 + m and y1 < d["lid_out_y"] / 2 - m)
        ok_extent = ok_extent and inside
        if not inside:
            print("  lid label out of plate bounds:", s, x0, x1, y0, y1)
    # floor labels must sit on the solid floor strip (between spine rail and
    # trench) and clear of the end pad and the loading-end wall
    rail_face = d["center_t"] / 2 + p["rail_t"]          # 3.0 from centre
    trench_inner = d["tray_inner_y"] / 2 - d["trench_w"]  # 28.0 from centre
    for (s, size, x, y) in M.FLOOR_LABELS:
        face = Text(s, font_size=size, font_path=str(M.FONT_PATH),
                    text_align=(TextAlign.CENTER, TextAlign.CENTER))
        bb = face.bounding_box()
        x0, x1 = x + bb.min.X, x + bb.max.X
        y0, y1 = y + bb.min.Y, y + bb.max.Y
        sgn = -1 if y < 0 else 1
        y_lo, y_hi = sgn * (rail_face + 1.0), sgn * (trench_inner - 1.0)
        inside = (x0 > -d["bay_len"] / 2 + p["pad_t"] + 2.0 and
                  x1 < d["bay_len"] / 2 - 2.0 and
                  min(y_lo, y_hi) < y0 and y1 < max(y_lo, y_hi))
        ok_extent = ok_extent and inside
        if not inside:
            print("  floor label out of solid-floor bounds:", s, x0, x1, y0, y1,
                  (y_lo, y_hi))
    check("labels_inside_their_faces", ok_extent,
          "all lid labels within the plate top with 1.0 mm margin; all floor "
          "labels on the solid floor strip between rail and trench, clear of "
          "the end pad and loading-end wall")
    # derived font minimum: stroke >= 0.5 mm (1.25x a 0.4 mm extrusion) -> 5.0 mm
    check("font_min_size_derivation",
          p["min_label_size"] >= 0.5 / STROKE_EM,
          f"min size used {p['min_label_size']} mm >= derived minimum "
          f"{0.5 / STROKE_EM:.1f} mm (stroke 0.10 em, 0.5 mm floor = 1.25x 0.4 mm nozzle)")

    # ------------------------------------------------------------------
    # 5. Structure numbers worth recording
    # ------------------------------------------------------------------
    check("record_dimensions", True, {
        "tray_outer": [d["tray_outer_x"], d["tray_outer_y"], d["tray_h"]],
        "lid_outer": [d["lid_out_x"], d["lid_out_y"], d["lid_h"]],
        "closed_outer": [d["lid_out_x"], d["lid_out_y"],
                         round(dz_rest + d["lid_h"], 2)],
        "bay": [d["bay_len"], d["bay_w"], d["bay_dep"]],
        "module_envelope": [p["stick_l"], p["stick_h_max"], p["stick_t_max"]],
        "foam_allowance_depth": round(d["bay_dep"] - p["stick_t_max"], 2),
        "length_rattle_space": round(p["c_len"], 2),
        "trench": [d["bay_len"], round(d["trench_w"], 2), p["trench_depth"]],
        "trench_bottom_web": round(p["floor_t"] - p["trench_depth"], 2),
        "slot_web_to_bay": round(p["wall_t"] - p["slot_depth"], 2),
        "channel_ceiling_thickness": round(d["tray_h"] - d["chan_ceil"], 2),
        "tab_engagement_depth": round(p["tab_out"] - p["play"], 2),
        "tab_to_ceiling_when_locked": round(
            d["chan_ceil"] - d["tab_top"] - (p["detent_h"] - p["tab_floor_clear"]), 2),
        "skirt_wall_play": p["play"],
        "slide_travel": p["travel"],
        "lid_rest_dz": round(dz_rest, 3),
        "lid_drop_dx": -p["travel"],
    })

    # gold-slab worst-case placements (for the mesh-runtime distance audit)
    probes = []
    for bay in (1, 2):
        for h in (p["stick_h_min"], p["stick_h_max"]):
            dy_max = d["bay_w"] - p["rail_t"] - h
            for dy in (0.0, dy_max):
                g = M.gold_strip(p, bay=bay, h=h, t=p["stick_t_max"], dy=dy)
                bb = g.bounding_box()
                probes.append({
                    "bay": bay, "h": h, "dy": dy,
                    "bbox": [bb.min.X, bb.min.Y, bb.min.Z, bb.max.X, bb.max.Y, bb.max.Z],
                })
    results["_gold_probes"] = probes
    results["_params_used"] = {k: v for k, v in p.items()}
    results["_derived_used"] = {k: (round(v, 4) if isinstance(v, float) else v)
                                for k, v in d.items()}

    (ROOT / "checks_cad.json").write_text(json.dumps(results, indent=2))
    print("\nwrote checks_cad.json")
    n_pass = sum(1 for k, v in results.items()
                 if isinstance(v, dict) and v.get("pass") is True)
    n_fail = sum(1 for k, v in results.items()
                 if isinstance(v, dict) and v.get("pass") is False)
    print(f"{n_pass} passed, {n_fail} failed")
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
