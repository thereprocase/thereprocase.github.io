# Reusable DDR4 Mailer (2 x UDIMM)

A small two-part 3D-printable mailer for two desktop DDR4 UDIMMs with ordinary
heatspreaders: a **tray** with two bays and a **slide-lock lid**. No hardware,
no tools, printed without supports.

```
closed size:  144.5 x 104.4 x 17.4 mm   (tray 143.9 x 99 x 14.8 + lid)
material:     ~53 cm3 tray, ~46 cm3 lid (PETG ~120 g total, PLA similar)
```

## How it is used

1. **Load**: lid off. Lay each stick flat in its own bay, gold-contact edge
   toward the outer wall (the "GOLD" arrow on the bay floor points there),
   nudge it against the spine rail beside the centre wall and against the end
   pad. Nothing touches the contacts: a full-length relief trench in the floor
   runs under every possible gold-strip position (module heights 31-42 mm), so
   the fingers face 1.0-1.6 mm of air even for a bare PCB.
2. **Pack**: put each stick in its shielding bag first, then lay one 2-3 mm
   foam or soft-paper sheet (~135 x 90 mm) over both sticks. The bays reserve
   exactly 3.0 mm above the tallest module for it, so the foam stops rattle
   without being clamped; the lid has no hold-down ribs and presses on nothing.
3. **Close**: drop the lid on, slide it toward `LOCK ->` (7 mm). Tabs on the
   lid drop into entry notches in the tray walls, then travel under covered
   channels, click over small detents and stop against channel end walls.
   Locked: the lid cannot be lifted (tabs under channel ceilings), cannot be
   slid off (blind channels), and is preloaded between detent and ceiling, so
   it has ~0.15 mm of vertical play and no rattle. The wrong direction is
   blocked at the notches.
4. **Reopen**: slide toward `<- OPEN` until the tabs line up with the entry
   notches, lift off. To get a stick out, press its spine edge down through
   the thumb scallop in the centre wall; the stick tilts up on the rail, then
   grab it by its top face. Gold is never handled.
5. Mail it inside any cardboard box that fits ~150 x 105 x 20 mm; the outer box
   provides the real crush protection, as with any rigid contents.

## What fits

Supported envelope per stick: **133.35 x 42.0 x 9.0 mm** (length x height x
thickness incl. heatspreader). All DDR4 UDIMMs share the JEDEC PCB
(133.35 x 31.25 x 1.2 mm, verified against JEDEC/Micron-published figures),
so the binding parameter is heatspreader height:

| module (manufacturer-published height) | height | fits? |
|---|---|---|
| bare / spreaderless PCB (JEDEC nominal) | 31.25 | yes |
| G.Skill Flare X class low-profile | ~32.8 | yes |
| Corsair Vengeance LPX | 34.0 | yes |
| Kingston FURY Beast | 34.9 | yes |
| Crucial Ballistix class | ~34-35 | yes |
| TeamGroup T-Force Vulcan class | ~35 | yes |
| G.Skill Ripjaws V | 42.0 | yes (limit) |
| Corsair Vengeance RGB Pro | 44.0 | **no** (by design) |
| Corsair Dominator class | ~55 | **no** |

Sources and honesty: the JEDEC PCB dimensions were verified online (JEDEC
DDR4 288-pin UDIMM, 133.35 x 31.25 x 1.2 mm). The per-model heatspreader
heights above are the manufacturers' widely-published spec-sheet values
(vendor pages are JS-heavy and were not fetchable through this network);
they were not independently re-measured. Typical thickness of ordinary
heatsinked modules is 7-8.5 mm, comfortably under the 9 mm bay depth; a
bagged stick adds ~0.4 mm and still fits unless the bare stick is already
at the limit. Want RGB Pro (44 mm) coverage? Raise `stick_h_max` in
`ddr4_mailer.py` to 44.5 and re-export: the bays grow 2.5 mm wider, and
the lid text "133 x 42 x 9" should be updated.

## Printing

- Both parts **as modeled need no supports**. Tray: floor on the bed. Lid:
  print with the lid plate on the bed (upside down vs. its installed
  orientation), then flip it over when assembled.
- Designed micro-bridges only (audited in checks): tray - 6.9 x 2.2 mm
  channel-ceiling bridges and 1.5 mm end-pad ledges over the trench; lid -
  1.6 mm-deep tab ledges. All trivially printable; tab tips carry 45 deg
  chamfers so nothing needs supports.
- Material: PETG recommended for mailing toughness; PLA is fine (there are
  no living hinges or spring flexures - the latch is pure geometry).
- 0.2 mm layers, 0.4 mm nozzle, 3+ perimeters / 20% infill. Both parts are
  single watertight shells with 2.8 mm floor, 3 mm walls.
- Labels are debossed Fillaprint (OFL, see `assets/fillaprint/`), stroke
  0.10 em, cap height 0.70 em. Smallest text used is 6 mm (0.6 mm strokes,
  1.5x a 0.4 mm extrusion); the font ships no minimum-size guidance, so the
  6 mm floor was derived from the measured stroke width - see checks. Lid
  labels land on the bed-side face of the plate: use a clean sheet and a
  0.25 mm first layer; if they come out mushy, raise `label_depth_lid`.

## Files

| file | what |
|---|---|
| `ddr4_mailer.py` | parametric source (all dimensions in `P`, two builders, exporters) |
| `exports/ddr4_mailer_tray.stl / .step` | tray, binary STL + STEP |
| `exports/ddr4_mailer_lid.stl / .step` | lid, binary STL + STEP |
| `assembly.json` | part files + assembled (locked) 4x4 transforms, mm |
| `checks.py` + `mesh_audit.py` + `checks.json` | verification suite + results |
| `assets/fillaprint/` | the label font (SIL OFL 1.1) |

Regenerate everything:
```
python ddr4_mailer.py   # exports STEP + STL
python checks.py        # CAD boolean checks
python mesh_audit.py       # mesh checks -> checks.json
```
(`mesh_audit.py` also re-writes both STLs as binary.)

## Verification - what was actually checked

`checks.json` records 30 passing checks against use, not just existence:

- Every envelope (bare PCB, low heatspreader, max 133.35 x 42 x 9) drops into
  both bays along the real vertical insertion path - zero overlap with the
  tray, and the swept volume clears too (open-top bays).
- Gold-contact strips can never touch tray material: 12 worst-case placements
  (heights 31/36/42, datum position, and shoved fully against the bay wall)
  all clear; sampled mesh distance audit reports a minimum 1.00 mm finger
  clearance (trench 18.5 x 1.8 mm, full bay length, reaching the bay wall so
  gold cannot rest on a lip).
- Lid function proved by exact boolean intersection: drops with zero
  collision; locked with zero collision; lift +0.3 mm blocked; lift +0.1 mm
  free (0.15 mm designed slop); press-down blocked by detents; over-slide
  +0.3 mm blocked by endstops; wrong-way slide blocked; mid-slide lift
  blocked (the lid cannot be lifted anywhere between entry and lock); full
  removal only after sliding back to the entry notches.
- Meshes: watertight, winding-consistent, single shell each; binary STL;
  closed-assembly footprint matches CAD (144.45 x 104.4 x 17.35 mm).
- Labels: all 9 labels measured (bbox, cap height, stroke); all at or above
  the derived minimum; all inside their faces with margin.

## What still needs a physical test

- **Detent feel and shipping slide resistance** - the latch geometry is
  proven, but whether 0.35 mm detents feel right and survive a real drop
  needs a printed part in hand. For a paranoid shipment, one strip of tape
  across the slide seam is a complete fix.
- **Printer tolerance stack** - the design assumes +/-0.2 mm part accuracy;
  the critical fits (0.3 mm skirt play, 0.2 mm tab floor clearance, 0.3 mm
  ceiling clearance) may need per-printer tuning via `play` and
  `entry_clear` if your printer runs tight or loose.
- **Lid bed-face label quality** (see Printing) and first-layer quality in
  general - cosmetic, but worth one test print.
- **Foam thickness** - 3 mm was reserved; verify your foam/paper choice
  fills the bay without making the lid hard to seat.
- The module-height figures above rely on manufacturer spec sheets; measure
  your actual sticks (and bags) before relying on the 42 mm limit.
