#!/usr/bin/env python3
"""
ddr4_mailer.py -- Parametric reusable mailer tray for two desktop DDR4 UDIMMs
with ordinary heatspreaders.

Design summary
--------------
Two side-by-side bays in a single tray; each stick lies FLAT on its heatspreader
face. The gold-contact edge of every stick points at the OUTER wall of its bay.
A full-length relief trench in the bay floor runs under the entire range of
possible gold-strip positions (module heights 31.0-42.0 mm), so no case feature
can ever touch the contacts. A low "spine" rail along the center wall of each bay
takes the stick's opposite edge as a load datum, and a low end pad sets the
length datum. Nothing in the tray or lid clamps the sticks: the user adds a
2-3 mm foam/paper sheet (the bays reserve 3 mm for it).

Lid mechanism ("slide-lock bayonet", no springs, no hardware):
  1. Drop the lid on at the entry position: four tabs on the lid skirt drop
     into open-top entry notches in the tray long walls.
  2. Slide the lid +7 mm: the tabs travel under covered channels in the tray
     walls, ride over a small detent bump, and stop against channel end walls.
     Locked, the lid cannot be lifted (tabs are under channel ceilings) and
     cannot slide off (channels are blind).
  3. To open: slide back 7 mm until the tabs line up with the entry notches,
     then lift straight off. Stick removal: press the stick's spine edge down
     through the thumb scallop in the center wall -- the stick tilts up on the
     rail -- then grab the stick by its top face. Gold is never touched.

Parts (both print without supports):
  tray: floor down on the bed.
  lid : lid plate down on the bed (labels end up on the bed face; see README).

Run this file to export STEP + STL of both parts into exports/.
"""

from pathlib import Path

from build123d import (
    Align,
    Axis,
    Box,
    Cylinder,
    Polygon,
    Pos,
    Rot,
    TextAlign,
    Text,
    export_step,
    export_stl,
    extrude,
)

ROOT = Path(__file__).resolve().parent
FONT_PATH = ROOT / "assets/fillaprint/Fillaprint-Regular.ttf"

# --------------------------------------------------------------------------
# Label placements (text, size_mm, x, y) -- shared by the builders and the
# verification suite. All Fillaprint, debossed.
#   lid labels  : y on the plate top face (lid frame), arrows show the slide
#                 direction: push -X end to lock (+X slide), +X end to open.
#   floor labels: y places each label so its rendered bbox is centred on the
#                 bay's SOLID floor strip (spine rail to trench edge). The
#                 font's glyphs sit ~0.25 em above the placement point, so the
#                 two bays use mirrored placement values, not ±y.
# --------------------------------------------------------------------------
LID_LABELS = [
    ("DDR4 \u00d72", 16.0, 0.0, 17.0),
    ("REUSABLE MAILER", 7.0, 0.0, 3.0),
    ("133 \u00d7 42 \u00d7 9 MM MAX", 6.0, 0.0, -7.0),
    ("LOCK \u2192", 6.0, -62.0, 4.0),
    ("\u2190 OPEN", 6.0, 62.0, 4.0),
]
FLOOR_LABELS = [
    ("GOLD \u2193", 6.0, 40.0, -17.0),
    ("1", 10.0, 62.0, -17.0),
    ("GOLD \u2191", 6.0, 40.0, 13.0),
    ("2", 10.0, 62.0, 13.0),
]

# --------------------------------------------------------------------------
# Parameters (all lengths in mm)
# --------------------------------------------------------------------------
P = {
    # --- module envelope -------------------------------------------------
    # JEDEC DDR4 UDIMM: 133.35 x 31.25 x 1.2 mm (288-pin, MO-309).
    "stick_l": 133.35,
    "stick_h_min": 31.0,   # bare PCB / low heatspreader (Flare X ~32.8)
    "stick_h_max": 42.0,   # Ripjaws V class heatspreader; excludes 44+ mm RGB
    "stick_t_min": 1.2,    # bare PCB
    "stick_t_max": 9.0,    # ordinary heatsinked modules are 7-8.5 mm
    "gold_h": 5.5,         # gold finger strip height from module edge
    # --- clearances -------------------------------------------------------
    "c_len": 3.0,          # free length beyond the end pad (foam takes it up)
    "c_w": 1.5,            # cross-bay clearance at the tallest module
    "c_dep": 3.0,          # reserve above the thickest module for foam sheet
    # --- bay internals ----------------------------------------------------
    "pad_t": 1.5,          # end pad thickness
    "pad_h": 2.0,          # end pad height
    "rail_t": 1.5,         # spine rail thickness
    "rail_h": 1.5,         # spine rail height
    "trench_margin": 0.5,  # trench overhang past the extreme gold positions
    "trench_depth": 1.8,   # relief under the gold strip
    # --- structure --------------------------------------------------------
    "wall_t": 3.0,
    "floor_t": 2.8,
    "center_t": 3.0,
    # --- slide-lock latch ---------------------------------------------------
    "travel": 7.0,          # lid slide distance to lock
    "play": 0.3,            # lid skirt <-> tray wall clearance (per side)
    "slot_depth": 2.2,      # latch slot cut depth into tray wall (3.0 - web)
    "tab_len": 6.0,         # tab length along X
    "tab_h": 1.6,           # tab height
    "tab_out": 2.2,         # tab protrusion inward from the skirt inner face
    "tab_ceiling_clear": 0.3,
    "tab_floor_clear": 0.2,
    "tab_half": 26.0,       # |X| of tabs from lid center
    "detent_h": 0.35,       # detent bump height in the channel floor
    "endstop_gap": 0.2,     # tab-to-endstop gap when locked
    "entry_clear": 0.3,     # per-side tab clearance in the entry notch
    # --- lid -----------------------------------------------------------------
    "lid_wall": 2.4,
    "lid_plate": 2.4,
    "rest_gap": 0.6,        # lid skirt bottom vs table when closed
    # --- thumb scallop ---------------------------------------------------------
    "scallop_x": 50.0,     # position along the bay (near the free end)
    "scallop_r": 7.0,
    "scallop_depth": 4.5,
    # --- labels ---------------------------------------------------------------
    "label_depth_lid": 0.8,    # lid text sits on the bed face; extra depth helps
    "label_depth_floor": 0.6,
    # Derived minimum label size: Fillaprint stroke = 0.10 em, cap height 0.7 em.
    # A 0.4 mm nozzle lays one 0.4 mm extrusion; keeping strokes >= 0.5 mm
    # (>= 1.25 extrusions) needs size >= 5.0 mm. We use >= 6.0 mm everywhere.
    "min_label_size": 6.0,
}

# --------------------------------------------------------------------------
# Derived geometry
# --------------------------------------------------------------------------
def derived(p: dict) -> dict:
    d = dict(p)
    d["bay_w"] = p["rail_t"] + p["stick_h_max"] + p["c_w"]            # 45.0
    d["bay_dep"] = p["stick_t_max"] + p["c_dep"]                      # 12.0
    d["bay_len"] = p["pad_t"] + p["stick_l"] + p["c_len"]             # 137.85
    # trench must cover the gold strip for all supported heights, and it runs
    # right up to the outer bay wall so gold can never rest on a solid lip.
    d["trench_w"] = (
        d["bay_w"] - p["rail_t"] - p["stick_h_min"] + p["gold_h"] + p["trench_margin"]
    )
    d["tray_inner_x"] = d["bay_len"]
    d["tray_inner_y"] = 2 * d["bay_w"] + p["center_t"]
    d["tray_outer_x"] = d["tray_inner_x"] + 2 * p["wall_t"]
    d["tray_outer_y"] = d["tray_inner_y"] + 2 * p["wall_t"]
    d["tray_h"] = p["floor_t"] + d["bay_dep"]
    d["floor_top"] = p["floor_t"]

    # latch z stack (world/tray frame)
    d["tab_top"] = d["tray_h"] - 1.2                       # 1.2 below wall top
    d["tab_bot"] = d["tab_top"] - p["tab_h"]
    d["chan_floor"] = d["tab_bot"] - p["tab_floor_clear"]
    d["chan_ceil"] = d["tab_top"] + p["tab_ceiling_clear"]
    d["notch_len"] = p["tab_len"] + 2 * p["entry_clear"]

    # X positions in the tray frame (tray centered on 0; lid locked is centered,
    # lid dropped is shifted -travel).
    d["notch_c"] = [-p["travel"] - p["tab_half"], -p["travel"] + p["tab_half"]]
    d["locked_c"] = [-p["tab_half"], p["tab_half"]]
    d["chan_x0"] = [nc - p["tab_len"] / 2 - p["entry_clear"] for nc in d["notch_c"]]
    d["chan_x1"] = [lc + p["tab_len"] / 2 + p["endstop_gap"] for lc in d["locked_c"]]

    # lid frame (footprint centered, z=0 at skirt bottom). The skirt has only
    # two long-side rails (no end walls): the latch tabs live on those rails,
    # and skipping end walls lets the lid slide `travel` mm without the lid
    # needing to be 2*travel longer than the tray. The plate covers the tray
    # fully in the locked (shipping) position; at the drop position it sits
    # 0.3 mm past the near tray end and the far tray end face is briefly
    # exposed while the lid is lowered -- that state only exists in hand.
    d["lid_out_x"] = d["tray_outer_x"] + 2 * p["play"]
    d["skirt_in_y"] = d["tray_outer_y"] + 2 * p["play"]
    d["skirt_h"] = d["tray_h"] - p["rest_gap"]
    d["lid_out_y"] = d["skirt_in_y"] + 2 * p["lid_wall"]
    d["lid_h"] = d["skirt_h"] + p["lid_plate"]
    d["lid_plate_bot"] = d["skirt_h"]
    d["lid_plate_top"] = d["lid_h"]

    # slot y band on the tray long walls (outer face +/- slot_depth)
    d["wall_out_y"] = d["tray_outer_y"] / 2          # 49.5
    d["slot_y0"] = d["wall_out_y"] - p["slot_depth"] # 47.1
    d["scallop_axis_z"] = d["tray_h"] + (p["scallop_r"] - p["scallop_depth"])
    return d


# --------------------------------------------------------------------------
# Label helper: Fillaprint text extruded to a given depth, centered on (x, y)
# --------------------------------------------------------------------------
def text_solid(s: str, size: float, x: float, y: float, z: float, depth: float):
    face = Text(
        s,
        font_size=size,
        font_path=str(FONT_PATH),
        text_align=(TextAlign.CENTER, TextAlign.CENTER),
    )
    sol = extrude(face, depth)
    return Pos(x, y, z) * sol


# --------------------------------------------------------------------------
# Tray (frame: footprint centered on origin, floor bottom at z=0)
# --------------------------------------------------------------------------
def build_tray(p: dict):
    d = derived(p)
    W, F, H = d["wall_t"], p["floor_t"], d["tray_h"]
    bay_w, bay_len, bay_dep = d["bay_w"], d["bay_len"], d["bay_dep"]
    bay_c_y = d["tray_inner_y"] / 2 - bay_w / 2   # |center| of each bay: 24.0

    tray = Box(d["tray_outer_x"], d["tray_outer_y"], H,
               align=(Align.CENTER, Align.CENTER, Align.MIN))

    # bays
    for sgn in (-1, 1):
        tray -= Pos(0, sgn * bay_c_y, F) * Box(
            bay_len, bay_w, bay_dep, align=(Align.CENTER, Align.CENTER, Align.MIN))

    # spine rails (against the center wall in each bay) + end pads
    for sgn in (-1, 1):
        rail_y = sgn * (d["center_t"] / 2 + p["rail_t"] / 2)
        tray += Pos(0, rail_y, F) * Box(
            bay_len, p["rail_t"], p["rail_h"],
            align=(Align.CENTER, Align.CENTER, Align.MIN))
        tray += Pos(-d["tray_inner_x"] / 2 + p["pad_t"] / 2, sgn * bay_c_y, F) * Box(
            p["pad_t"], bay_w, p["pad_h"],
            align=(Align.CENTER, Align.CENTER, Align.MIN))

    # gold-relief trenches, full bay length, touching the outer bay wall.
    # The cut goes DOWN into the floor (from floor_top - depth to floor_top).
    for sgn in (-1, 1):
        tr_y = sgn * (d["tray_inner_y"] / 2 - d["trench_w"] / 2)
        tray -= Pos(0, tr_y, F - p["trench_depth"]) * Box(
            bay_len, d["trench_w"], p["trench_depth"] + 0.1,
            align=(Align.CENTER, Align.CENTER, Align.MIN))

    # thumb scallop through the center wall top (serves both bays)
    tray -= Pos(d["scallop_x"], 0, d["scallop_axis_z"]) * Rot(90, 0, 0) * Cylinder(
        p["scallop_r"], d["tray_outer_y"] + 4)

    # latch slots: entry notches (open top) + covered channels, on both walls
    for sgn in (-1, 1):           # which long wall
        for i in (0, 1):          # two latches per wall
            x0, x1 = d["chan_x0"][i], d["chan_x1"][i]
            ymid = sgn * (d["slot_y0"] + d["wall_out_y"]) / 2
            # channel (covered): up to chan_ceil
            tray -= Pos((x0 + x1) / 2, ymid, d["chan_floor"]) * Box(
                x1 - x0, p["slot_depth"], d["chan_ceil"] - d["chan_floor"],
                align=(Align.CENTER, Align.CENTER, Align.MIN))
            # entry notch (open top): notch_len long, from chan_floor to wall top
            tray -= Pos(d["notch_c"][i], ymid, d["chan_floor"]) * Box(
                d["notch_len"], p["slot_depth"],
                H - d["chan_floor"], align=(Align.CENTER, Align.CENTER, Align.MIN))
            # detent bump on the channel floor at the locked tab position.
            # Profile (x, height) built in XY, extruded along +Z by the slot
            # depth, then mapped (u, v, w) -> (x, z, -y) via rotate(X, +90):
            # x stays, height goes to +Z, extrusion goes to -Y.
            bump = extrude(
                Polygon((-1.2, 0), (-0.3, p["detent_h"]),
                        (0.3, p["detent_h"]), (1.2, 0)),
                p["slot_depth"],
            ).rotate(Axis.X, 90)
            tray += Pos(d["locked_c"][i], ymid - p["slot_depth"] / 2,
                        d["chan_floor"]) * bump

    # floor labels: bay number + gold direction (arrows point at the gold edge,
    # i.e. at the outer wall of each bay)
    ld = p["label_depth_floor"]
    for s, size, x, y in FLOOR_LABELS:
        tray -= text_solid(s, size, x, y, d["floor_top"] - ld, ld + 0.1)
    return tray, d


# --------------------------------------------------------------------------
# Lid (frame: footprint centered on origin, skirt bottom at z=0)
# --------------------------------------------------------------------------
def build_lid(p: dict):
    d = derived(p)
    lw, lp = p["lid_wall"], p["lid_plate"]

    # plate (covers the tray fully when locked) ...
    lid = Box(d["lid_out_x"], d["lid_out_y"], lp,
              align=(Align.CENTER, Align.CENTER, Align.MIN))
    lid = Pos(0, 0, d["lid_plate_bot"]) * lid

    # ... plus two long-side skirt rails (no end walls: see derived())
    for sgn in (-1, 1):
        rail = Box(d["lid_out_x"], lw, d["skirt_h"],
                   align=(Align.CENTER, Align.CENTER, Align.MIN))
        rail = Pos(0, sgn * (d["skirt_in_y"] / 2 + lw / 2), 0) * rail
        lid += rail

    # latch tabs (clean helper) + labels
    lid = _add_tabs(lid, p, d)
    lid = _lid_labels(lid, p, d)
    return lid, d


def _add_tabs(lid, p, d):
    """Four latch tabs on the skirt's inner faces. Profile is built in the
    XY plane as (u, v) = (inward offset, height), extruded along +Z by
    tab_len, then mapped (u, v, w) -> (y, z, x) via two axis rotations so the
    tab runs along X, protrudes inward in Y, and spans the tab z-range."""
    tab_z0 = d["tab_bot"] - p["rest_gap"]
    tab_z1 = d["tab_top"] - p["rest_gap"]
    prof = Polygon(
        (0, tab_z0),                          # root, bottom
        (p["tab_out"], tab_z0),                # tip, bottom
        (p["tab_out"], tab_z0 + 0.6),          # tip chamfer start
        (p["tab_out"] - 0.6, tab_z1),          # 45 deg tip chamfer
        (0, tab_z1),                           # root, top
    )
    tab = extrude(prof, p["tab_len"]).rotate(Axis.Y, 90).rotate(Axis.X, 90)
    # after rotations: x in [0, tab_len], y in [0, tab_out], z in [tab_z0, tab_z1]
    face_y = d["skirt_in_y"] / 2
    for xc in (-d["tab_half"], d["tab_half"]):
        for ys in (-1, 1):
            ty = ys * face_y - (p["tab_out"] if ys > 0 else 0.0)
            lid += Pos(xc - p["tab_len"] / 2, ty, 0) * tab
    return lid


def _lid_labels(lid, p, d):
    ld = p["label_depth_lid"]
    top = d["lid_plate_top"]
    for s, size, x, y in LID_LABELS:
        lid -= text_solid(s, size, x, y, top - ld, ld + 0.1)
    return lid


# --------------------------------------------------------------------------
# Assembly helpers
# --------------------------------------------------------------------------
def lid_locked(p: dict, lid, dz=0.0):
    """Lid placed in the LOCKED position (tray frame). Pure translation."""
    d = derived(p)
    return Pos(0, 0, d["rest_gap"] + dz) * lid


def lid_dropped(p: dict, lid, dz=0.0):
    """Lid placed in the entry/drop position (tray frame)."""
    d = derived(p)
    return Pos(-p["travel"], 0, d["rest_gap"] + dz) * lid


def module_at(p: dict, bay=1, h=None, t=None, dy=0.0):
    """Module box for a bay; bay=1 (y<0) or 2 (y>0); dy shifts it toward the
    outer wall (worst case for the trench check)."""
    d = derived(p)
    h = p["stick_h_max"] if h is None else h
    t = p["stick_t_max"] if t is None else t
    sgn = -1 if bay == 1 else 1
    bay_c = d["tray_inner_y"] / 2 - d["bay_w"] / 2
    rail_face = sgn * (d["center_t"] / 2 + p["rail_t"])
    x0 = -d["tray_inner_x"] / 2 + p["pad_t"]
    y_spine = rail_face + sgn * h / 2   # center of stick when spine on rail
    box = Box(p["stick_l"], h, t, align=(Align.CENTER, Align.CENTER, Align.MIN))
    return Pos(x0 + p["stick_l"] / 2, y_spine + sgn * dy, d["floor_top"]) * box


def gold_strip(p: dict, bay=1, h=None, t=None, dy=0.0):
    """The gold finger strip of a module (the bottom-edge contact region):
    a slab stick_l x gold_h x t standing on the stick's gold edge."""
    d = derived(p)
    h = p["stick_h_max"] if h is None else h
    t = p["stick_t_max"] if t is None else t
    sgn = -1 if bay == 1 else 1
    rail_face = sgn * (d["center_t"] / 2 + p["rail_t"])
    x0 = -d["tray_inner_x"] / 2 + p["pad_t"]
    y_spine = rail_face + sgn * h / 2
    y_gold_edge = y_spine + sgn * (h / 2 + dy)
    box = Box(p["stick_l"], p["gold_h"], t + 0.4,
              align=(Align.CENTER, Align.CENTER, Align.MIN))
    # fingers run from the module edge toward the spine (inward)
    return Pos(x0 + p["stick_l"] / 2, y_gold_edge - sgn * p["gold_h"] / 2,
               d["floor_top"] - 0.2) * box


# --------------------------------------------------------------------------
# Export
# --------------------------------------------------------------------------
def main():
    out = ROOT / "exports"
    out.mkdir(exist_ok=True)
    tray, d = build_tray(P)
    lid, _ = build_lid(P)

    # ---- geometric self-checks (fail loudly on regressions) ----
    tb, lb = tray.bounding_box(), lid.bounding_box()
    assert abs(tb.min.X + d["tray_outer_x"] / 2) < 1e-6, tb
    assert abs(tb.max.X - d["tray_outer_x"] / 2) < 1e-6, tb
    assert abs(tb.min.Y + d["tray_outer_y"] / 2) < 1e-6, tb
    assert abs(tb.max.Y - d["tray_outer_y"] / 2) < 1e-6, tb
    assert abs(tb.min.Z) < 1e-6 and abs(tb.max.Z - d["tray_h"]) < 1e-6, tb
    assert abs(lb.min.X + d["lid_out_x"] / 2) < 1e-6, lb
    assert abs(lb.max.X - d["lid_out_x"] / 2) < 1e-6, lb
    assert abs(lb.min.Y + d["lid_out_y"] / 2) < 1e-6, lb
    assert abs(lb.max.Y - d["lid_out_y"] / 2) < 1e-6, lb
    assert abs(lb.min.Z) < 1e-6 and abs(lb.max.Z - d["lid_h"]) < 1e-6, lb

    step_tray = out / "ddr4_mailer_tray.step"
    step_lid = out / "ddr4_mailer_lid.step"
    export_step(tray, str(step_tray))
    export_step(lid, str(step_lid))

    stl_tray = out / "ddr4_mailer_tray.stl"
    stl_lid = out / "ddr4_mailer_lid.stl"
    export_stl(tray, str(stl_tray))
    export_stl(lid, str(stl_lid))

    print("tray bbox", tray.bounding_box())
    print("lid  bbox", lid.bounding_box())
    print("wrote", step_tray, step_lid, stl_tray, stl_lid)
    return tray, lid


if __name__ == "__main__":
    main()
