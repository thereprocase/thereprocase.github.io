"""Text to solid geometry, using the supplied FillaPrint TTF.

build123d's ``Text`` goes through OCCT's font manager, which on this machine
falls back to DejaVu Sans (the local fontconfig setup is broken), so the
outlines are taken straight from the TTF with fontTools and converted into
build123d faces.  This guarantees that the delivered label geometry is
generated from ``assets/fillaprint/Fillaprint-Regular.ttf`` and lets the
cap height be measured exactly instead of guessed.
"""

from __future__ import annotations

import math
import os
from dataclasses import dataclass
from typing import List, Sequence, Tuple

from fontTools.ttLib import TTFont
from fontTools.pens.basePen import BasePen

from build123d import (
    Face,
    Part,
    Plane,
    Pos,
    Vector,
    Wire,
    extrude,
)

FONT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "assets", "fillaprint", "Fillaprint-Regular.ttf",
)

# Flattening tolerance for curve segments, in font units.
FLATNESS = 8.0  # ~0.08 % of the em


class _FlatteningPen(BasePen):
    """Collect glyph outlines as flattened polygons (font units)."""

    def __init__(self, glyph_set):
        super().__init__(glyph_set)
        self.contours: List[List[Tuple[float, float]]] = []
        self._current: List[Tuple[float, float]] = []
        self._start: Tuple[float, float] = (0.0, 0.0)
        self._last_off: Tuple[float, float] | None = None

    # -- helpers ---------------------------------------------------------
    def _flush(self):
        if len(self._current) > 2:
            self.contours.append(self._current)
        self._current = []
        self._last_off = None

    def _line_to(self, pt):
        if self._last_off is not None:
            # implied on-curve point between two off-curve points
            mid = ((self._last_off[0] + pt[0]) / 2.0,
                   (self._last_off[1] + pt[1]) / 2.0)
            self._current.append(mid)
            self._last_off = None
        self._current.append(pt)

    def _quad(self, p0, p1, p2):
        # de Casteljau subdivision of a quadratic bezier
        n = max(2, int(math.dist(p0, p2) / FLATNESS))
        for i in range(1, n + 1):
            t = i / n
            mt = 1.0 - t
            x = mt * mt * p0[0] + 2 * mt * t * p1[0] + t * t * p2[0]
            y = mt * mt * p0[1] + 2 * mt * t * p1[1] + t * t * p2[1]
            self._current.append((x, y))

    def _cubic(self, p0, p1, p2, p3):
        n = max(2, int(math.dist(p0, p3) / FLATNESS))
        for i in range(1, n + 1):
            t = i / n
            mt = 1.0 - t
            x = (mt ** 3 * p0[0] + 3 * mt ** 2 * t * p1[0]
                 + 3 * mt * t ** 2 * p2[0] + t ** 3 * p3[0])
            y = (mt ** 3 * p0[1] + 3 * mt ** 2 * t * p1[1]
                 + 3 * mt * t ** 2 * p2[1] + t ** 3 * p3[1])
            self._current.append((x, y))

    # -- pen protocol ----------------------------------------------------
    def _moveTo(self, pt):
        self._flush()
        self._start = pt
        self._current = [pt]

    def _lineTo(self, pt):
        self._line_to(pt)

    def _curveToOne(self, p1, p2, p3):
        p0 = self._current[-1]
        self._cubic(p0, p1, p2, p3)

    def _qCurveToOne(self, p1, p2):
        p0 = self._current[-1]
        if p2 is None:  # closed contour of all off-curve points
            pts = [p1]
        else:
            pts = [p1, p2]
        # TrueType: consecutive off-curve control points
        expanded: List[Tuple[float, float]] = []
        for i, c in enumerate(pts):
            if i:
                prev = pts[i - 1]
                expanded.append(((prev[0] + c[0]) / 2.0, (prev[1] + c[1]) / 2.0))
            expanded.append(c)
        for pt in expanded:
            if self._last_off is not None:
                mid = ((self._last_off[0] + pt[0]) / 2.0,
                       (self._last_off[1] + pt[1]) / 2.0)
                self._current.append(mid)
            self._quad(self._current[-1], pt, pt)
            self._current.pop()  # _quad already appended the flattened points
            self._last_off = pt

    def _closePath(self):
        if self._last_off is not None:
            mid = ((self._last_off[0] + self._start[0]) / 2.0,
                   (self._last_off[1] + self._start[1]) / 2.0)
            self._current.append(mid)
            self._last_off = None
        if len(self._current) > 2:
            self._current.append(self._current[0])
            self.contours.append(self._current)
        self._current = []
        self._last_off = None

    def _endPath(self):
        self._closePath()


@dataclass
class FontMetrics:
    units_per_em: int
    cap_height: float      # font units
    ascender: float
    descender: float


class LabelFont:
    """The FillaPrint TTF, with helpers to lay out and build text."""

    def __init__(self, path: str = FONT_PATH):
        self.path = path
        self.tt = TTFont(path)
        self.glyph_set = self.tt.getGlyphSet()
        self.units_per_em = self.tt["head"].unitsPerEm
        hmtx = self.tt["hmtx"]
        self._advances = hmtx.metrics
        self.metrics = self._metrics()

    # -- metrics ---------------------------------------------------------
    def _glyph_bbox(self, name: str):
        pen = _FlatteningPen(self.glyph_set)
        self.glyph_set[name].draw(pen)
        pts = [p for c in pen.contours for p in c]
        if not pts:
            return (0.0, 0.0, 0.0, 0.0)
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        return (min(xs), min(ys), max(xs), max(ys))

    def _metrics(self) -> FontMetrics:
        bbox = self._glyph_bbox("H")
        cap = bbox[3]
        head = self.tt["head"]
        os2 = self.tt.get("OS/2")
        asc = os2.sTypoAscender if os2 else head.yMax
        desc = os2.sTypoDescender if os2 else head.yMin
        return FontMetrics(self.units_per_em, cap, asc, desc)

    def cap_height_mm(self, font_size: float) -> float:
        """Cap height in mm for a given font size (mm per em)."""
        return font_size * self.metrics.cap_height / self.units_per_em

    def font_size_for_cap(self, cap_mm: float) -> float:
        """Font size (em, mm) that gives a requested cap height in mm."""
        return cap_mm * self.units_per_em / self.metrics.cap_height

    # -- layout ----------------------------------------------------------
    def _char_map(self):
        cmap = self.tt.getBestCmap()
        return cmap

    def text_width_mm(self, text: str, font_size: float) -> float:
        """Advance width of the text in mm."""
        cmap = self._char_map()
        total = 0.0
        for ch in text:
            name = cmap.get(ord(ch))
            if name is None:
                continue
            total += self._advances[name][0]
        return font_size * total / self.units_per_em

    def text_faces(self, text: str, font_size: float) -> Part:
        """Return the glyphs of ``text`` as a planar Part in the XY plane.

        The origin is on the text baseline at the left edge of the first
        glyph, x to the right, y up.  Units are mm.
        """
        cmap = self._char_map()
        scale = font_size / self.units_per_em
        outlines = []          # (contours, advance)
        pen_x = 0.0
        for ch in text:
            name = cmap.get(ord(ch))
            if name is None:
                continue
            pen = _FlatteningPen(self.glyph_set)
            self.glyph_set[name].draw(pen)
            adv = self._advances[name][0]
            outlines.append((pen.contours, pen_x, adv))
            pen_x += adv

        faces: List[Face] = []
        for contours, pen_x_u, _adv in outlines:
            polys = []
            for contour in contours:
                pts = [((pen_x_u + x) * scale, y * scale) for x, y in contour]
                # drop repeated points
                clean = []
                for p in pts:
                    if not clean or (abs(p[0] - clean[-1][0]) > 1e-9
                                     or abs(p[1] - clean[-1][1]) > 1e-9):
                        clean.append(p)
                if len(clean) > 2 and abs(clean[0][0] - clean[-1][0]) < 1e-9 \
                        and abs(clean[0][1] - clean[-1][1]) < 1e-9:
                    clean.pop()
                if len(clean) > 2:
                    polys.append(clean)

            def inside(pt, poly):
                x, y = pt
                hit = False
                n = len(poly)
                for i in range(n):
                    x0, y0 = poly[i]
                    x1, y1 = poly[(i + 1) % n]
                    if (y0 > y) != (y1 > y):
                        xint = x0 + (y - y0) * (x1 - x0) / (y1 - y0)
                        if xint > x:
                            hit = not hit
                return hit

            def make_face(poly):
                w = Wire.make_polygon(
                    [Vector(p[0], p[1], 0) for p in poly], close=True)
                return Face(w)

            # depth of each contour (number of other contours containing it)
            depths = []
            for i, poly in enumerate(polys):
                depths.append(sum(1 for j, other in enumerate(polys)
                                   if j != i and inside(poly[0], other)))

            contour_faces = [make_face(p) for p in polys]
            for i, poly in enumerate(polys):
                if depths[i] % 2 == 1:
                    # a hole: subtract it from the directly enclosing contour
                    best = None
                    best_area = None
                    for j, other in enumerate(polys):
                        if j == i or depths[j] % 2 == 1:
                            continue
                        if depths[j] == depths[i] - 1 and inside(poly[0], other):
                            area = _poly_area(other)
                            if best_area is None or area < best_area:
                                best, best_area = j, area
                    if best is not None:
                        contour_faces[best] = contour_faces[best] - contour_faces[i]
            for i, f in enumerate(contour_faces):
                if depths[i] % 2 == 0:
                    faces.append(f)

        if not faces:
            return Part()
        result = faces[0]
        for f in faces[1:]:
            result = result + f
        return result


def _poly_area(poly: Sequence[Tuple[float, float]]) -> float:
    """Absolute area of a polygon (shoelace)."""
    a = 0.0
    n = len(poly)
    for i in range(n):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % n]
        a += x0 * y1 - x1 * y0
    return abs(a) / 2.0


def label_on_plane(text: str, font_size: float,
                   plane: Plane,
                   along: float = 0.0,
                   normal: float = 0.0,
                   depth: float = 0.0,
                   font: LabelFont | None = None) -> Part:
    """Build ``text`` as a solid standing on ``plane``.

    ``along`` is the offset in the plane's local y (up the slope) measured
    from the plane origin, ``normal`` the offset along the plane normal and
    ``depth`` the height of the extruded text along the normal.  The text is
    centred on the plane's local x axis.
    """
    font = font or LabelFont()
    flat = font.text_faces(text, font_size)
    if not flat.faces():
        return Part()
    bb = flat.bounding_box()
    width = bb.max.X - bb.min.X
    # centre horizontally, sit the baseline at the requested height
    flat = Pos(-bb.min.X - width / 2.0, along, normal) * flat
    solid = extrude(flat, amount=depth, dir=(0, 0, 1))
    return plane * solid
