"""Build every part of the Gridfinity screw / nut / washer organiser.

Run with:   python src/build_all.py

Outputs
    exports/base_5x4.step / .stl        the 5 x 4 base plate
    exports/bin_<type>_<label>.step/.stl one file per bin
    assembly.json                       part files + assembled transforms (mm)
    build_report.json                   measured figures used by the checks
"""

from __future__ import annotations

import json
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from build123d import export_stl, export_step  # noqa: E402

from gf_bins import BIN_TYPES, FLOOR_TOP, STACK_REACH, make_bin  # noqa: E402
from gf_layout import COLS, LAYOUT, PITCH, ROWS, cell_origin  # noqa: E402
from gf_spec import baseplate, socket_depth  # noqa: E402
from gf_text import LabelFont  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXPORTS = os.path.join(ROOT, "exports")
BASE_RELIEF = 0.08
BASE_FLOOR = 1.0


def slug(text: str) -> str:
    s = re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_")
    return s


def main():
    t0 = time.time()
    os.makedirs(EXPORTS, exist_ok=True)
    font = LabelFont()
    report = {"parts": [], "font": {
        "file": os.path.relpath(font.path, ROOT),
        "units_per_em": font.units_per_em,
        "cap_height_units": font.metrics.cap_height,
    }}

    # ---------------------------------------------------------------- base
    base = baseplate(COLS, ROWS, relief=BASE_RELIEF, floor_thickness=BASE_FLOOR)
    base_step = os.path.join(EXPORTS, f"base_{COLS}x{ROWS}.step")
    base_stl = os.path.join(EXPORTS, f"base_{COLS}x{ROWS}.stl")
    export_step(base, base_step)
    export_stl(base, base_stl)
    bb = base.bounding_box()
    report["parts"].append({
        "file": f"base_{COLS}x{ROWS}",
        "role": "base_plate",
        "volume_mm3": round(base.volume, 1),
        "bbox_mm": [round(v, 3) for v in (bb.min.X, bb.min.Y, bb.min.Z,
                                          bb.max.X, bb.max.Y, bb.max.Z)],
    })
    print(f"base: {base.volume:.0f} mm3")

    # ---------------------------------------------------------------- bins
    for i, pl in enumerate(LAYOUT):
        spec = pl.spec
        key = f"bin_{spec.name}_{slug(pl.label)}"
        if pl.stacked:
            key += "_stacked"
        part = make_bin(spec, font)
        export_step(part, os.path.join(EXPORTS, key + ".step"))
        export_stl(part, os.path.join(EXPORTS, key + ".stl"))
        bb = part.bounding_box()
        report["parts"].append({
            "file": key,
            "role": "bin",
            "bin_type": spec.name,
            "label": pl.label,
            "stacked": pl.stacked,
            "volume_mm3": round(part.volume, 1),
            "bbox_mm": [round(v, 3) for v in (bb.min.X, bb.min.Y, bb.min.Z,
                                              bb.max.X, bb.max.Y, bb.max.Z)],
        })
        print(f"{key}: {part.volume:.0f} mm3")

    # ------------------------------------------------------- assembly.json
    # Assembly frame: origin at the bottom left corner of the base plate,
    # z = 0 at the bottom face of the plate.  Each bin's local origin is the
    # centre of its base profile at the bottom of the profile.
    socket_floor_z = BASE_FLOOR
    stack_lift = 0.0
    assembled = []
    for pl in LAYOUT:
        spec = pl.spec
        cx, cy = cell_origin(pl.col, pl.row)
        if pl.stacked:
            z = socket_floor_z + stack_lift
            stack_lift = spec.height + 0.35     # filled in below
        else:
            z = socket_floor_z
        key = f"bin_{spec.name}_{slug(pl.label)}"
        if pl.stacked:
            key += "_stacked"
        assembled.append({
            "file": key,
            "label": pl.label,
            "bin_type": spec.name,
            "cell": [pl.col, pl.row],
            "stacked": pl.stacked,
            "translation_mm": [round(cx, 3), round(cy, 3), round(z, 3)],
            "rotation_deg": [0, 0, 0],
        })

    # the stacked tray drops its base profile into the mouth of the bin
    # below it: its profile bottom ends up STACK_REACH below that bin's rim
    deep_h = BIN_TYPES["deep"].height
    for entry in assembled:
        if entry["stacked"]:
            entry["translation_mm"][2] = round(
                socket_floor_z + deep_h - STACK_REACH, 3)

    assembly = {
        "units": "mm",
        "description": "Gridfinity screw / nut / washer organiser, 5 x 4 cells",
        "assembly_frame": ("origin at the bottom-left corner of the base "
                            "plate, z up, +x right, +y into the bench "
                            "(row 0 is the front row)"),
        "base": {
            "file": f"base_{COLS}x{ROWS}",
            "translation_mm": [0, 0, 0],
            "rotation_deg": [0, 0, 0],
            "size_mm": [COLS * PITCH, ROWS * PITCH],
        },
        "parts": assembled,
    }
    with open(os.path.join(ROOT, "assembly.json"), "w") as fh:
        json.dump(assembly, fh, indent=2)

    with open(os.path.join(ROOT, "build_report.json"), "w") as fh:
        json.dump(report, fh, indent=2)

    print(f"done in {time.time() - t0:.1f} s")


if __name__ == "__main__":
    main()
