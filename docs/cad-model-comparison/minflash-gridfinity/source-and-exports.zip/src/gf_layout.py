"""The starter layout: 5 x 4 cells, 21 bins in 20 cells (one bin stacked).

Columns are thread sizes, rows are content classes:

    row 1 (front)  washers + spares tray      (tray bins, 16 mm)
    row 2           nuts                       (tray bins, 16 mm)
    row 3           short screws               (std bins, 21 mm)
    row 4 (back)    long screws                (deep bins, 28 mm)

Column 5 is the overflow column: it carries the spare-parts tray, two extra
M3 lengths and the M4x20 bin with a small tray stacked on top of it, which
demonstrates (and uses) the stacking collar.
"""

from __future__ import annotations

from dataclasses import dataclass

from gf_bins import BIN_TYPES, BinSpec

COLS = 5
ROWS = 4
PITCH = 42.0


@dataclass
class Placement:
    col: int          # 0 .. 4, left to right
    row: int          # 0 .. 3, front (0) to back (3)
    bin_type: str
    label: str
    stacked: bool = False      # sits on top of the bin in the same cell

    @property
    def spec(self) -> BinSpec:
        s = BIN_TYPES[self.bin_type]
        s.label = self.label
        return s


def _p(col: int, row: int, t: str, label: str, stacked: bool = False):
    return Placement(col, row, t, label, stacked)


LAYOUT = [
    # --- row 0 : washers and the spares tray (front, easiest to reach) ---
    _p(0, 0, "tray", "M2 WASH"),
    _p(1, 0, "tray", "M2.5 WASH"),
    _p(2, 0, "tray", "M3 WASH"),
    _p(3, 0, "tray", "M4 WASH"),
    _p(4, 0, "tray", "SPARES"),
    # --- row 1 : nuts --------------------------------------------------
    _p(0, 1, "tray", "M2 NUT"),
    _p(1, 1, "tray", "M2.5 NUT"),
    _p(2, 1, "tray", "M3 NUT"),
    _p(3, 1, "tray", "M4 NUT"),
    _p(4, 1, "std", "M3x6"),
    # --- row 2 : the shorter screw of each size -------------------------
    _p(0, 2, "std", "M2x6"),
    _p(1, 2, "std", "M2.5x8"),
    _p(2, 2, "std", "M3x10"),
    _p(3, 2, "std", "M4x10"),
    _p(4, 2, "std", "M3x16"),
    # --- row 3 : the longer screw of each size (back) -------------------
    _p(0, 3, "deep", "M2x10"),
    _p(1, 3, "deep", "M2.5x12"),
    _p(2, 3, "deep", "M3x20"),
    _p(3, 3, "deep", "M4x16"),
    _p(4, 3, "deep", "M4x20"),
    # --- the tray that sits on top of the M4x20 bin ---------------------
    _p(4, 3, "tray", "M4 SPARE", stacked=True),
]


def cell_origin(col: int, row: int):
    """Centre of a cell of the base plate, in the plate's XY frame."""
    return (col * PITCH + PITCH / 2.0, row * PITCH + PITCH / 2.0)
