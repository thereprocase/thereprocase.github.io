"""Render checks.json / checks_mesh.json into checks.md (no hand typing).

Run with:   python src/make_checks_md.py
"""

from __future__ import annotations

import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(name):
    path = os.path.join(ROOT, name)
    if not os.path.exists(path):
        return []
    with open(path) as fh:
        return json.load(fh)["results"]


def table(results):
    out = ["| check | value | unit | note |", "|---|---|---|---|"]
    for r in results:
        val = r["value"]
        if isinstance(val, float):
            val = f"{val:g}"
        out.append(f"| {r['check']} | {val} | {r['unit']} | {r['note']} |")
    return "\n".join(out)


def main():
    solid = load("checks.json")
    mesh = load("checks_mesh.json")
    parts = []
    parts.append("# Measured checks\n")
    parts.append("All numbers below are produced by `src/verify.py` "
                 "(build123d / OCC, solid geometry) and `src/verify_mesh.py` "
                 "(trimesh, exported STL files and the placed assembly).  "
                 "They are measurements of the delivered files, not of the "
                 "design intent.\n")
    parts.append("## Solid model checks\n")
    parts.append(table(solid))
    parts.append("\n## Exported mesh and assembly checks\n")
    parts.append(table(mesh))
    parts.append("\nReproduce with:\n\n```\n"
                 "python src/build_all.py\n"
                 "python src/verify.py\n"
                 "python src/make_checks_md.py\n"
                 "python src/verify_mesh.py\n```\n")
    with open(os.path.join(ROOT, "checks.md"), "w") as fh:
        fh.write("\n".join(parts))
    print("wrote checks.md")


if __name__ == "__main__":
    main()
