"""Mesh level checks on the exported STL files and on the assembly.

Run with:   python src/verify_mesh.py

Checks
  * every STL is a closed, watertight, non self intersecting mesh
  * the mesh volume agrees with the volume recorded when the STEP was built
  * the parts listed in assembly.json land where they are supposed to:
    the bins sit on the floor of their socket, the bins do not overlap each
    other and the stacked tray sits in the groove of the bin below it
"""

from __future__ import annotations

import json
import os
import sys

import numpy as np
import trimesh

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXPORTS = os.path.join(ROOT, "exports")

results = []


def check(name, value, unit="", note=""):
    results.append({"check": name, "value": value, "unit": unit, "note": note})
    print(f"  {name:<56s} {value} {unit}  {note}")


def main():
    with open(os.path.join(ROOT, "build_report.json")) as fh:
        report = json.load(fh)
    with open(os.path.join(ROOT, "assembly.json")) as fh:
        assembly = json.load(fh)

    print("== exported meshes ==")
    worst = 0.0
    total_vol = 0.0
    for part in report["parts"]:
        path = os.path.join(EXPORTS, part["file"] + ".stl")
        mesh = trimesh.load(path, process=False)
        mesh.merge_vertices()
        watertight = mesh.is_watertight
        vol = float(mesh.volume)
        err = abs(vol - part["volume_mm3"]) / part["volume_mm3"]
        worst = max(worst, err)
        total_vol += vol
        ok = watertight and err < 0.005
        check(f"{part['file']}: watertight", watertight, "",
              f"vol {vol:.0f} mm3, {len(mesh.faces)} triangles"
              + ("" if ok else "  <-- PROBLEM"))
    check("worst STL volume error vs STEP", round(worst * 100, 3), "%",
          "mesh vs solid")
    check("total printed volume", round(total_vol / 1000.0, 1), "cm3",
          "all parts, PLA at 1.24 g/cm3")

    print("== assembly ==")
    base = trimesh.load(os.path.join(EXPORTS, assembly["base"]["file"] + ".stl"),
                        process=False)
    base.merge_vertices()
    check("base is watertight", base.is_watertight, "",
          f"{len(base.faces)} triangles")

    placed = []
    for entry in assembly["parts"]:
        mesh = trimesh.load(os.path.join(EXPORTS, entry["file"] + ".stl"),
                            process=False)
        mesh.merge_vertices()
        t = np.array(entry["translation_mm"], dtype=float)
        mesh.apply_translation(t)
        placed.append((entry, mesh))

    # every bin has to sit on the floor of its socket: its lowest point
    # must be at the socket floor, and it must be inside the plate
    floor_z = 1.0
    lowest = min(m.bounds[0][2] for _, m in placed)
    check("lowest point of any bin", round(lowest, 3), "mm",
          f"socket floor is at {floor_z:.1f} mm above the plate bottom")
    check("bins sit on the socket floor",
          round(abs(lowest - floor_z), 4), "mm", "deviation")

    # bins must not collide with each other
    worst_overlap = 0.0
    for i in range(len(placed)):
        for j in range(i + 1, len(placed)):
            ei, mi = placed[i]
            ej, mj = placed[j]
            inter = mi.intersection(mj)
            if inter is not None and len(inter.faces) > 0:
                v = float(abs(inter.volume))
                if v > worst_overlap:
                    worst_overlap = v
                    print(f"    overlap {ei['file']} / {ej['file']}: {v:.3f}")
    check("largest overlap between placed bins", round(worst_overlap, 4),
          "mm3", "must be 0")

    # every bin has to be inside the plate footprint
    outside = 0
    for entry, mesh in placed:
        b = mesh.bounds
        if b[0][0] < -1e-6 or b[1][0] > 210 + 1e-6 or \
           b[0][1] < -1e-6 or b[1][1] > 168 + 1e-6:
            outside += 1
    check("bins outside the plate footprint", outside, "",
          "must be 0")

    # and every bin has to sit over a socket of the plate
    bb = base.bounds
    check("base plate position in the assembly frame",
          f"x {bb[0][0]:.0f}..{bb[1][0]:.0f}, y {bb[0][1]:.0f}..{bb[1][1]:.0f}",
          "mm", "the frame origin is the bottom left corner")
    wrong = 0
    for entry, mesh in placed:
        if entry.get("stacked"):
            continue
        cx, cy = entry["translation_mm"][0], entry["translation_mm"][1]
        if abs((cx - 21) % 42) > 1e-6 or abs((cy - 21) % 42) > 1e-6:
            wrong += 1
    check("bins not over a socket centre", wrong, "", "must be 0")
    # the base profile of every bin has to sit inside its socket
    inside = 0
    for entry, mesh in placed:
        if entry.get("stacked"):
            continue
        cx, cy = entry["translation_mm"][0], entry["translation_mm"][1]
        probe = trimesh.creation.box(extents=[35.5, 35.5, 0.2])
        probe.apply_translation([cx, cy, 1.15])
        if len(probe.intersection(base).faces) > 0:
            inside += 1
    check("bins fouling the base plate material", inside, "",
          "must be 0 (the profile has to be inside the socket)")

    # the stacked tray has to sit in the groove of the bin below
    stacked = [e for e, _ in placed if e.get("stacked")]
    for entry in stacked:
        lower = [m for e, m in placed
                 if e["cell"] == entry["cell"] and not e.get("stacked")]
        if not lower:
            continue
        low = lower[0]
        m = [mm for e, mm in placed if e["file"] == entry["file"]][0]
        inter = m.intersection(low)
        v = float(abs(inter.volume)) if inter is not None and len(inter.faces) else 0.0
        check("stacked tray interference with the bin below", round(v, 4),
              "mm3", entry["file"])
        gap = m.bounds[0][2] - low.bounds[1][2]
        check("stacked tray profile reaches below the lower rim",
              round(-gap, 3), "mm",
              "its profile reaches into the mouth of the bin below")

    # the total assembled height
    top = max(m.bounds[1][2] for _, m in placed)
    check("assembled height", round(top, 2), "mm",
          "from the bottom of the base plate")

    with open(os.path.join(ROOT, "checks_mesh.json"), "w") as fh:
        json.dump({"results": results}, fh, indent=2)
    print("\nwrote checks_mesh.json")


if __name__ == "__main__":
    main()
