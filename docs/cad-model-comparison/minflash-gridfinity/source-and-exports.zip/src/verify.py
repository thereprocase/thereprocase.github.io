"""Measured checks of the delivered parts.

Everything here is measured from the built geometry (or from the exported
STL files), not from the design intent, so a mistake in the model shows up.

Run with:   python src/verify.py
"""

from __future__ import annotations

import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from build123d import Axis, Box, Part, Plane, Pos, Vector  # noqa: E402

import gf_bins  # noqa: E402
from gf_bins import (  # noqa: E402
    BIN_TYPES,
    FACET_ANGLE,
    FACET_SLOPE,
    FLOOR_TOP,
    STACK_REACH,
    TEXT_CAP,
    TEXT_RELIEF,
    WALL,
    _cavity_solid,
    _facet_plane,
    _label_solid,
    make_bin,
)
from gf_layout import COLS, LAYOUT, PITCH, ROWS  # noqa: E402
from gf_spec import (  # noqa: E402
    BASE_HEIGHT,
    BODY,
    baseplate,
    male_profile_solid,
    socket_cavity_solid,
    socket_depth,
)
from gf_text import LabelFont  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXPORTS = os.path.join(ROOT, "exports")
BASE_RELIEF = 0.08
BASE_FLOOR = 1.0

results = []


def check(name, value, unit="", note=""):
    results.append({"check": name, "value": value, "unit": unit, "note": note})
    print(f"  {name:<56s} {value} {unit}  {note}")
    return value


def section_bbox(part: Part, z: float):
    sec = part.intersect(Plane.XY.offset(z))
    if sec is None or not sec.faces():
        return None
    return Part(sec).bounding_box()


def main():
    font = LabelFont()
    print("== Gridfinity base interface ==")

    base = baseplate(COLS, ROWS, relief=BASE_RELIEF, floor_thickness=BASE_FLOOR)
    male = male_profile_solid()
    cavity = Pos(0, 0, BASE_FLOOR) * socket_cavity_solid(BASE_RELIEF)
    plate_one = (Box(PITCH, PITCH, BASE_FLOOR + socket_depth(BASE_RELIEF),
                      align=(None, None, None)) - cavity)
    seated = Pos(0, 0, BASE_FLOOR) * male
    inter = (seated & plate_one).volume
    check("male profile interference in the base socket", round(inter, 6),
          "mm3", "must be 0")
    check("socket depth", round(socket_depth(BASE_RELIEF), 3), "mm",
          "male profile is 4.75 mm high")
    check("male top below the socket mouth",
          round(socket_depth(BASE_RELIEF) - BASE_HEIGHT, 3), "mm",
          "spec 0.10 mm + 0.08 socket relief")
    for z, nominal in ((0.0, 35.6), (0.8, 37.2), (2.6, 37.2), (4.75, 41.5)):
        bb = section_bbox(male, z)
        check(f"male profile width at z={z}", round(bb.max.X - bb.min.X, 3),
              "mm", f"spec {nominal}")
    for z in (1.2, 1.5, 2.2, 3.5, 4.5):
        mb = section_bbox(seated, z)
        cb = section_bbox(cavity, z)
        gap = ((cb.max.X - cb.min.X) - (mb.max.X - mb.min.X)) / 2
        check(f"radial gap male -> socket at z={z}", round(gap, 3), "mm/side",
              "clearance in the fit")
    bb = base.bounding_box()
    check("base plate size",
          f"{bb.max.X - bb.min.X:.1f} x {bb.max.Y - bb.min.Y:.1f} x "
          f"{bb.max.Z - bb.min.Z:.1f}", "mm", "5 x 4 cells")
    check("base plate volume", round(base.volume, 0), "mm3", "")

    print("== bin bodies ==")
    bins = {}
    for name in ("tray", "std", "deep"):
        spec = BIN_TYPES[name]
        spec.label = "M3x10"
        b = make_bin(spec, font)
        bins[name] = b
        bb = b.bounding_box()
        check(f"{name}: overall size",
              f"{bb.max.X - bb.min.X:.1f} x {bb.max.Y - bb.min.Y:.1f} x "
              f"{bb.max.Z - bb.min.Z:.1f}", "mm", "42 grid footprint")
        cav = _cavity_solid(spec)
        cbb = cav.bounding_box()
        check(f"{name}: pocket width", round(cbb.max.X - cbb.min.X, 2), "mm",
              "clear width between the walls")
        check(f"{name}: pocket depth", round(spec.interior_depth, 2), "mm",
              "floor to the rim")
        pocket = cav.intersect(
            Pos(-BODY, -BODY, FLOOR_TOP) * Box(
                2 * BODY, 2 * BODY, spec.height - FLOOR_TOP,
                align=(None, None, None)))
        pocket_vol = Part(pocket).volume
        check(f"{name}: pocket volume", round(pocket_vol, 0), "mm3",
              "usable pocket below the rim")
        check(f"{name}: floor slab thickness",
              round(FLOOR_TOP - BASE_HEIGHT, 2), "mm",
              "1.2 above the base profile")
        wb = section_bbox(b, FLOOR_TOP + 2.0)
        check(f"{name}: wall thickness",
              round(((wb.max.X - wb.min.X) - (cbb.max.X - cbb.min.X)) / 2, 2),
              "mm", "measured from the section")
        check(f"{name}: label facet band",
              f"{spec.facet_bottom:.2f} .. {spec.facet_top:.2f}", "mm",
              f"clear of the {3.6:.1f} mm a stacked profile reaches down")

    print("== stacking ==")
    deep = bins["deep"]
    # a second bin drops its base profile into the mouth of the bin below
    # and rests on the rim; the profile's cone touches the rim's inner edge
    for name in ("tray", "std", "deep"):
        spec = BIN_TYPES[name]
        seat = spec.height - 3.6
        inter = (Pos(0, 0, seat) * male & bins[name]).volume
        check(f"{name}: stacked profile interference at the seat",
              round(inter, 6), "mm3", "profile in the mouth of the bin below")
        check(f"{name}: stacked profile seats at z", round(seat, 3), "mm",
              "its cone rests on the rim's inner edge")
        check(f"{name}: upper bin body stands proud of the rim",
              round(seat + BASE_HEIGHT - spec.height, 3), "mm",
              "0 = flush")
    check("cavity width at the rim",
          round(section_bbox(bins["deep"],
                             BIN_TYPES["deep"].height - 0.05).max.Y * 2, 2),
          "mm", "uniform, so a stacked bin sits flat")

    print("== clear spaces and capacity ==")
    for name in ("tray", "std", "deep"):
        spec = BIN_TYPES[name]
        slot_top = spec.facet_bottom - 0.5
        slot_bot = slot_top - spec.slot_h
        check(f"{name}: finger slot", f"{spec.slot_w:.0f} x {spec.slot_h:.1f}",
              "mm", f"z {slot_bot:.1f} .. {slot_top:.1f}")
        # the slot has to be a real hole through the front wall
        probe = Pos(0, -BODY / 2 + WALL / 2, (slot_bot + slot_top) / 2) * Box(
            2.0, WALL, spec.slot_h * 0.5, align=(None, None, None))
        solid_at_slot = bins[name].intersect(probe)
        check(f"{name}: material in the slot",
              round(Part(solid_at_slot).volume, 3), "mm3", "must be 0")
        check(f"{name}: slot sill above the floor",
              round(slot_bot - FLOOR_TOP, 2), "mm",
              "a 0.8 mm M2 washer cannot pass")
        check(f"{name}: label facet rise",
              round(spec.facet_rise, 2), "mm",
              f"{FACET_ANGLE:.0f} deg facet, {FACET_SLOPE} mm slope")
        check(f"{name}: label height above the floor",
              round(spec.facet_bottom - FLOOR_TOP, 2), "mm", "")

    cav = _cavity_solid(BIN_TYPES["tray"])
    cav_vol = Part(cav.intersect(
        Pos(-BODY, -BODY, FLOOR_TOP) * Box(
            2 * BODY, 2 * BODY, BIN_TYPES["tray"].height - FLOOR_TOP,
            align=(None, None, None)))).volume
    items = {
        "30 x M4 flat washer (9.0 x 0.8)": 30 * math.pi * 4.5 ** 2 * 0.8 / 0.62,
        "30 x M4 hex nut (7 AF x 4.4)": 30 * 7 * 7 * 4.4 * 0.62,
        "30 x M2 flat washer (5.0 x 0.5)": 30 * math.pi * 2.5 ** 2 * 0.5 / 0.62,
        "20 x M4x20 SHCS": 20 * (math.pi * 2 ** 2 * 20 + 90),
        "20 x M3x10 SHCS": 20 * (math.pi * 1.5 ** 2 * 10 + 45),
    }
    for name, vol in items.items():
        check(f"tray holds {name}", round(vol, 0), "mm3",
              f"{100 * vol / cav_vol:.0f} % of the pocket")

    print("== labels ==")
    for label in ("M2 WASH", "M2.5 WASH", "M4 NUT", "M3x16", "M2.5x12",
                  "SPARES", "M4 SPARE"):
        spec = BIN_TYPES["tray"]
        spec.label = label
        lab = _label_solid(spec, font)
        if not lab.faces():
            check(f"label {label!r}", "MISSING", "", "")
            continue
        plane = _facet_plane(spec)
        origin = plane.origin
        along = []
        relief = []
        for v in lab.vertices():
            p = Vector(v.X, v.Y, v.Z) - origin
            along.append(p.dot(plane.z_dir.cross(plane.x_dir)))
            relief.append(p.dot(plane.z_dir))
        bb = lab.bounding_box()
        check(f"label {label!r}: cap height",
              round(max(along) - min(along), 3), "mm",
              "measured along the facet")
        check(f"label {label!r}: relief above the facet",
              round(max(relief), 3), "mm", "raised text")
        check(f"label {label!r}: width", round(bb.max.X - bb.min.X, 2), "mm",
              "facet flat width is 34.5 mm")

    # the label has to be readable from a standing position: the row in
    # front must not hide the facet of the row behind
    print("== sight lines ==")
    beta = 90.0 - FACET_ANGLE          # the facet normal, above horizontal
    for elev in (35, 45, 60, 90):
        factor = math.sin(math.radians(elev + beta))
        check(f"label foreshortening at {elev} deg elevation",
              round(100 * factor, 1), "%", "of the true cap height")
    heights = {"tray": BIN_TYPES["tray"].height,
               "std": BIN_TYPES["std"].height,
               "deep": BIN_TYPES["deep"].height}
    for front in ("tray", "std", "deep"):
        for back in ("tray", "std", "deep"):
            if back == front:
                continue
            facet_bottom = BIN_TYPES[back].facet_bottom
            # elevation angle needed to see the bottom of the rear facet
            need = math.degrees(math.atan((heights[front] - facet_bottom)
                                           / PITCH))
            check(f"elevation to read a {back} label behind a {front} bin",
                  round(max(need, 0), 1), "deg", "0 = blocked")

    print("== assembly ==")
    with open(os.path.join(ROOT, "assembly.json")) as fh:
        assembly = json.load(fh)
    check("parts in assembly.json", len(assembly["parts"]), "",
          "20 bins + 1 stacked tray")
    check("cells used", len({tuple(p["cell"]) for p in assembly["parts"]}), "",
          f"{COLS} x {ROWS}")
    xs = [p["translation_mm"][0] for p in assembly["parts"]]
    ys = [p["translation_mm"][1] for p in assembly["parts"]]
    zs = [p["translation_mm"][2] for p in assembly["parts"]]
    check("assembly extent X", round(max(xs) - min(xs) + PITCH, 2), "mm",
          "base plate width")
    check("assembly extent Y", round(max(ys) - min(ys) + PITCH, 2), "mm",
          "base plate depth")
    check("assembly height", round(max(zs), 2), "mm",
          "highest bin bottom above the plate bottom")
    stacked = [p for p in assembly["parts"] if p.get("stacked")]
    check("stacked parts", len(stacked), "",
          f"z = {stacked[0]['translation_mm'][2] if stacked else 0}")

    with open(os.path.join(ROOT, "checks.json"), "w") as fh:
        json.dump({"results": results}, fh, indent=2)
    print("\nwrote checks.json")


if __name__ == "__main__":
    main()
