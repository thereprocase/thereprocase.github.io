"""The three reusable bin types of the screw / nut / washer organiser.

Geometry summary (all dimensions in mm, z = 0 at the bottom of the Gridfinity
base profile, x / y centred on the bin):

  * 0 .. 4.75        standard Gridfinity base profile (35.6 -> 41.5 across)
  * 4.75 .. 5.95     floor slab, 1.2 thick
  * 5.95 .. height   cavity, 39.2 across (1.4 walls), corner radius 2.35
  * top of the front wall: a 60 deg label facet carrying raised FillaPrint
    text, 5.0 mm cap height, 0.6 mm relief.  A 1.4 mm wall is too thin to
    take that ramp, so the front wall is locally thickened over the height
    of the facet (the "cheek" in _cheek()).
  * a 14 x 2.4/3.2 mm finger slot through the front wall, under the facet:
    it is the grip for lifting one bin out of the mat and, in the shallow
    tray, a scoop for the smallest parts
  * the wall keeps a 1.5 mm flat face above the facet and then the normal
    1.4 mm rim, so the inner edge of the rim is the same all round and a
    second bin's base profile can drop into the mouth and rest on it the
    way a normal Gridfinity bin does

Bin types
  tray : height 18.0, 12.05 deep  -> washers, nuts, tiny parts
  std  : height 21.0, 15.05 deep  -> screws up to ~12
  deep : height 28.0, 22.05 deep  -> long screws
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from build123d import (
    Box,
    Part,
    Plane,
    Pos,
    Rectangle,
    Rot,
    Vector,
    extrude,
    fillet,
    loft,
)

from gf_spec import (
    BASE_HEIGHT,
    BASE_TOP_RADIUS,
    BODY,
    male_profile_solid,
)
from gf_text import LabelFont, label_on_plane

WALL = 1.4                  # wall thickness
FLOOR_THICKNESS = 1.2       # floor slab above the base profile
FLOOR_TOP = BASE_HEIGHT + FLOOR_THICKNESS      # 5.95

FACET_ANGLE = 60.0          # degrees above horizontal
FACET_SLOPE = 6.8           # slope length of the facet
TEXT_CAP = 5.0              # label cap height (mm)
TEXT_RELIEF = 0.6           # raised label height (mm)
EMBOSS_SINK = 0.1           # how far the text sinks into the facet
TEXT_MARGIN = 1.3           # space below the text on the facet

# A bin that is stacked on drops its base profile 3.6 mm into the mouth of
# the bin below (the profile's cone meets the rim's inner edge there), so
# nothing may stick out of the wall within that band.
STACK_REACH = 3.6
FACET_CLEARANCE = 0.3       # extra clearance above the label facet


@dataclass
class BinSpec:
    name: str
    height: float
    slot_w: float = 14.0
    slot_h: float = 2.4
    label: str = ""
    label_cap: float = TEXT_CAP

    @property
    def interior_depth(self) -> float:
        return self.height - FLOOR_TOP

    @property
    def facet_rise(self) -> float:
        return FACET_SLOPE * math.sin(math.radians(FACET_ANGLE))

    @property
    def facet_run(self) -> float:
        return FACET_SLOPE * math.cos(math.radians(FACET_ANGLE))

    @property
    def facet_top(self) -> float:
        """Height of the top edge of the label facet.

        It has to stay clear of the band a stacked bin's base profile
        reaches down into, otherwise the two would foul each other.
        """
        return self.height - STACK_REACH - FACET_CLEARANCE

    @property
    def facet_bottom(self) -> float:
        return self.facet_top - self.facet_rise


BIN_TYPES = {
    "tray": BinSpec("tray", 21.0, slot_h=2.4),
    "std": BinSpec("std", 25.0, slot_h=2.4),
    "deep": BinSpec("deep", 30.0, slot_h=3.2),
}


def _rounded_square(size: float, radius: float, z: float = 0.0):
    r = min(radius, size / 2.0 - 1e-3)
    sk = Rectangle(size, size)
    if r > 1e-6:
        sk = fillet(sk.vertices(), radius=r)
    return Pos(0, 0, z) * sk


def _cavity_solid(spec: BinSpec) -> Part:
    """The void inside the bin, from the floor up and out of the top."""
    inner = BODY - 2 * WALL            # 39.2
    inner_r = BASE_TOP_RADIUS - WALL   # 2.35
    secs = [
        _rounded_square(inner, inner_r, FLOOR_TOP),
        _rounded_square(inner, inner_r, spec.height),
        _rounded_square(inner, inner_r, spec.height + 1.0),
    ]
    return loft(secs, ruled=True)


def _cheek(spec: BinSpec) -> Part:
    """Local thickening of the front wall that carries the label facet.

    A 1.4 mm wall is too thin to take a 60 deg label facet: the ramp would
    cut through it and open the bin.  The cheek fills the front wall up to
    the depth the ramp needs, so the ramp becomes the outer face of a solid
    wedge instead of a hole.  The inner face of the cheek is 3.2 mm further
    back, which takes 3.2 mm off the front of the pocket over that band.
    """
    depth = WALL + spec.facet_run
    half = BODY / 2 - WALL - (BASE_TOP_RADIUS - WALL)   # flat part of the cavity
    box = Box(2 * half, depth, spec.facet_top - spec.facet_bottom,
              align=(None, None, None))
    return Pos(-half, -BODY / 2 + WALL, spec.facet_bottom) * box


def _facet_plane(spec: BinSpec) -> Plane:
    """The plane of the front label facet.

    The facet rises at FACET_ANGLE above the horizontal, going back into
    the bin, so its normal points forward and up at (90 - FACET_ANGLE)
    above the horizontal.
    """
    z0 = spec.facet_bottom
    n = Vector(0, -math.sin(math.radians(FACET_ANGLE)),
               math.cos(math.radians(FACET_ANGLE)))
    origin = Vector(0, -BODY / 2, z0)
    return Plane(origin=origin, x_dir=(1, 0, 0), z_dir=n)


def _facet_cutter(spec: BinSpec) -> Part:
    """The wedge that forms the label facet on the outside of the front wall.

    The cut is limited to the height of the facet, so the wall above it
    keeps its full thickness and the rim of the bin stays uniform - which
    is what a bin stacked on top of this one rests on.
    """
    plane = _facet_plane(spec)
    box = Box(BODY + 20, 200, 200, align=(None, None, None))
    above = plane * Pos(-(BODY + 20) / 2, -100, 0) * box
    limit = Pos(-200, -200, spec.facet_top - 200) * Box(400, 400, 200,
                                                        align=(None, None, None))
    return above & limit


def _slot_cutter(spec: BinSpec) -> Part:
    """The finger slot through the front wall, under the label facet."""
    z_top = spec.facet_bottom - 0.5
    z_bot = z_top - spec.slot_h
    sk = Rectangle(spec.slot_w, spec.slot_h)
    sk = fillet(sk.vertices(), radius=spec.slot_h / 2.0)
    sk = Rot(90, 0, 0) * sk                           # into the XZ plane
    sk = Pos(0, 0, (z_bot + z_top) / 2.0) * sk       # and up to its height
    depth = WALL + 6.0
    return extrude(Pos(0, -BODY / 2 - 3.0, 0) * sk,
                   amount=depth, dir=(0, 1, 0))


def _label_solid(spec: BinSpec, font: LabelFont) -> Part:
    """The raised label sitting on the front facet.

    The text is set back from the lower edge of the facet far enough that
    its 0.6 mm relief does not push past the 42 mm footprint of the bin -
    the bins sit next to each other with no gap.
    """
    if not spec.label:
        return Part()
    plane = _facet_plane(spec)
    size = font.font_size_for_cap(spec.label_cap)
    flat = font.text_faces(spec.label, size)
    if not flat.faces():
        return Part()
    bb = flat.bounding_box()
    # the text sits TEXT_MARGIN up the slope, which keeps the relief
    # inside the 42 mm footprint of the bin
    along = TEXT_MARGIN - bb.min.Y
    return label_on_plane(spec.label, size, plane,
                          along=along, normal=-EMBOSS_SINK,
                          depth=TEXT_RELIEF + EMBOSS_SINK, font=font)


def make_bin(spec: BinSpec, font: LabelFont | None = None) -> Part:
    """Build one bin of the given type."""
    font = font or LabelFont()
    body = male_profile_solid()
    outer = Pos(0, 0, BASE_HEIGHT) * extrude(
        _rounded_square(BODY, BASE_TOP_RADIUS), spec.height - BASE_HEIGHT)
    solid = body + outer
    solid = solid - _cavity_solid(spec)
    solid = solid + _cheek(spec)
    solid = solid - _facet_cutter(spec)
    solid = solid - _slot_cutter(spec)
    label = _label_solid(spec, font)
    if label.faces():
        solid = solid + label
    return solid
