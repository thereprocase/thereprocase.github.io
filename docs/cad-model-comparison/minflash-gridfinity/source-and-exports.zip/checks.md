# Measured checks

All numbers below are produced by `src/verify.py` (build123d / OCC, solid geometry) and `src/verify_mesh.py` (trimesh, exported STL files and the placed assembly).  They are measurements of the delivered files, not of the design intent.

## Solid model checks

| check | value | unit | note |
|---|---|---|---|
| male profile interference in the base socket | 0 | mm3 | must be 0 |
| socket depth | 4.92 | mm | male profile is 4.75 mm high |
| male top below the socket mouth | 0.17 | mm | spec 0.10 mm + 0.08 socket relief |
| male profile width at z=0.0 | 35.6 | mm | spec 35.6 |
| male profile width at z=0.8 | 37.2 | mm | spec 37.2 |
| male profile width at z=2.6 | 37.2 | mm | spec 37.2 |
| male profile width at z=4.75 | 41.5 | mm | spec 41.5 |
| radial gap male -> socket at z=1.2 | 0.15 | mm/side | clearance in the fit |
| radial gap male -> socket at z=1.5 | 0.08 | mm/side | clearance in the fit |
| radial gap male -> socket at z=2.2 | 0.25 | mm/side | clearance in the fit |
| radial gap male -> socket at z=3.5 | 0.25 | mm/side | clearance in the fit |
| radial gap male -> socket at z=4.5 | 0.08 | mm/side | clearance in the fit |
| base plate size | 210.0 x 168.0 x 5.9 | mm | 5 x 4 cells |
| base plate volume | 63526 | mm3 |  |
| tray: overall size | 42.0 x 42.0 x 21.0 | mm | 42 grid footprint |
| tray: pocket width | 39.2 | mm | clear width between the walls |
| tray: pocket depth | 15.05 | mm | floor to the rim |
| tray: pocket volume | 23055 | mm3 | usable pocket below the rim |
| tray: floor slab thickness | 1.2 | mm | 1.2 above the base profile |
| tray: wall thickness | 1.4 | mm | measured from the section |
| tray: label facet band | 11.21 .. 17.10 | mm | clear of the 3.6 mm a stacked profile reaches down |
| std: overall size | 42.0 x 42.0 x 25.0 | mm | 42 grid footprint |
| std: pocket width | 39.2 | mm | clear width between the walls |
| std: pocket depth | 19.05 | mm | floor to the rim |
| std: pocket volume | 29183 | mm3 | usable pocket below the rim |
| std: floor slab thickness | 1.2 | mm | 1.2 above the base profile |
| std: wall thickness | 1.4 | mm | measured from the section |
| std: label facet band | 15.21 .. 21.10 | mm | clear of the 3.6 mm a stacked profile reaches down |
| deep: overall size | 42.0 x 42.0 x 30.0 | mm | 42 grid footprint |
| deep: pocket width | 39.2 | mm | clear width between the walls |
| deep: pocket depth | 24.05 | mm | floor to the rim |
| deep: pocket volume | 36842 | mm3 | usable pocket below the rim |
| deep: floor slab thickness | 1.2 | mm | 1.2 above the base profile |
| deep: wall thickness | 1.4 | mm | measured from the section |
| deep: label facet band | 20.21 .. 26.10 | mm | clear of the 3.6 mm a stacked profile reaches down |
| tray: stacked profile interference at the seat | 0 | mm3 | profile in the mouth of the bin below |
| tray: stacked profile seats at z | 17.4 | mm | its cone rests on the rim's inner edge |
| tray: upper bin body stands proud of the rim | 1.15 | mm | 0 = flush |
| std: stacked profile interference at the seat | 0 | mm3 | profile in the mouth of the bin below |
| std: stacked profile seats at z | 21.4 | mm | its cone rests on the rim's inner edge |
| std: upper bin body stands proud of the rim | 1.15 | mm | 0 = flush |
| deep: stacked profile interference at the seat | 0 | mm3 | profile in the mouth of the bin below |
| deep: stacked profile seats at z | 26.4 | mm | its cone rests on the rim's inner edge |
| deep: upper bin body stands proud of the rim | 1.15 | mm | 0 = flush |
| cavity width at the rim | 42 | mm | uniform, so a stacked bin sits flat |
| tray: finger slot | 14 x 2.4 | mm | z 8.3 .. 10.7 |
| tray: material in the slot | 0 | mm3 | must be 0 |
| tray: slot sill above the floor | 2.36 | mm | a 0.8 mm M2 washer cannot pass |
| tray: label facet rise | 5.89 | mm | 60 deg facet, 6.8 mm slope |
| tray: label height above the floor | 5.26 | mm |  |
| std: finger slot | 14 x 2.4 | mm | z 12.3 .. 14.7 |
| std: material in the slot | 0 | mm3 | must be 0 |
| std: slot sill above the floor | 6.36 | mm | a 0.8 mm M2 washer cannot pass |
| std: label facet rise | 5.89 | mm | 60 deg facet, 6.8 mm slope |
| std: label height above the floor | 9.26 | mm |  |
| deep: finger slot | 14 x 3.2 | mm | z 16.5 .. 19.7 |
| deep: material in the slot | 0 | mm3 | must be 0 |
| deep: slot sill above the floor | 10.56 | mm | a 0.8 mm M2 washer cannot pass |
| deep: label facet rise | 5.89 | mm | 60 deg facet, 6.8 mm slope |
| deep: label height above the floor | 14.26 | mm |  |
| tray holds 30 x M4 flat washer (9.0 x 0.8) | 2463 | mm3 | 11 % of the pocket |
| tray holds 30 x M4 hex nut (7 AF x 4.4) | 4010 | mm3 | 17 % of the pocket |
| tray holds 30 x M2 flat washer (5.0 x 0.5) | 475 | mm3 | 2 % of the pocket |
| tray holds 20 x M4x20 SHCS | 6827 | mm3 | 30 % of the pocket |
| tray holds 20 x M3x10 SHCS | 2314 | mm3 | 10 % of the pocket |
| label 'M2 WASH': cap height | 5 | mm | measured along the facet |
| label 'M2 WASH': relief above the facet | 0.6 | mm | raised text |
| label 'M2 WASH': width | 21.86 | mm | facet flat width is 34.5 mm |
| label 'M2.5 WASH': cap height | 5 | mm | measured along the facet |
| label 'M2.5 WASH': relief above the facet | 0.6 | mm | raised text |
| label 'M2.5 WASH': width | 26.86 | mm | facet flat width is 34.5 mm |
| label 'M4 NUT': cap height | 5 | mm | measured along the facet |
| label 'M4 NUT': relief above the facet | 0.6 | mm | raised text |
| label 'M4 NUT': width | 18.29 | mm | facet flat width is 34.5 mm |
| label 'M3x16': cap height | 5 | mm | measured along the facet |
| label 'M3x16': relief above the facet | 0.6 | mm | raised text |
| label 'M3x16': width | 16.61 | mm | facet flat width is 34.5 mm |
| label 'M2.5x12': cap height | 5 | mm | measured along the facet |
| label 'M2.5x12': relief above the facet | 0.6 | mm | raised text |
| label 'M2.5x12': width | 21.61 | mm | facet flat width is 34.5 mm |
| label 'SPARES': cap height | 5 | mm | measured along the facet |
| label 'SPARES': relief above the facet | 0.6 | mm | raised text |
| label 'SPARES': width | 18.57 | mm | facet flat width is 34.5 mm |
| label 'M4 SPARE': cap height | 5 | mm | measured along the facet |
| label 'M4 SPARE': relief above the facet | 0.6 | mm | raised text |
| label 'M4 SPARE': width | 24.01 | mm | facet flat width is 34.5 mm |
| label foreshortening at 35 deg elevation | 90.6 | % | of the true cap height |
| label foreshortening at 45 deg elevation | 96.6 | % | of the true cap height |
| label foreshortening at 60 deg elevation | 100 | % | of the true cap height |
| label foreshortening at 90 deg elevation | 86.6 | % | of the true cap height |
| elevation to read a std label behind a tray bin | 7.8 | deg | 0 = blocked |
| elevation to read a deep label behind a tray bin | 1.1 | deg | 0 = blocked |
| elevation to read a tray label behind a std bin | 18.2 | deg | 0 = blocked |
| elevation to read a deep label behind a std bin | 6.5 | deg | 0 = blocked |
| elevation to read a tray label behind a deep bin | 24.1 | deg | 0 = blocked |
| elevation to read a std label behind a deep bin | 19.4 | deg | 0 = blocked |
| parts in assembly.json | 21 |  | 20 bins + 1 stacked tray |
| cells used | 20 |  | 5 x 4 |
| assembly extent X | 210 | mm | base plate width |
| assembly extent Y | 168 | mm | base plate depth |
| assembly height | 27.4 | mm | highest bin bottom above the plate bottom |
| stacked parts | 1 |  | z = 27.4 |

## Exported mesh and assembly checks

| check | value | unit | note |
|---|---|---|---|
| base_5x4: watertight | True |  | vol 63527 mm3, 43568 triangles |
| bin_tray_M2_WASH: watertight | True |  | vol 12854 mm3, 6482 triangles |
| bin_tray_M2_5_WASH: watertight | True |  | vol 12859 mm3, 6970 triangles |
| bin_tray_M3_WASH: watertight | True |  | vol 12854 mm3, 6486 triangles |
| bin_tray_M4_WASH: watertight | True |  | vol 12854 mm3, 6322 triangles |
| bin_tray_SPARES: watertight | True |  | vol 12850 mm3, 6486 triangles |
| bin_tray_M2_NUT: watertight | True |  | vol 12849 mm3, 5662 triangles |
| bin_tray_M2_5_NUT: watertight | True |  | vol 12854 mm3, 6150 triangles |
| bin_tray_M3_NUT: watertight | True |  | vol 12849 mm3, 5666 triangles |
| bin_tray_M4_NUT: watertight | True |  | vol 12848 mm3, 5502 triangles |
| bin_std_M3x6: watertight | True |  | vol 13723 mm3, 5694 triangles |
| bin_std_M2x6: watertight | True |  | vol 13723 mm3, 5690 triangles |
| bin_std_M2_5x8: watertight | True |  | vol 13728 mm3, 6050 triangles |
| bin_std_M3x10: watertight | True |  | vol 13726 mm3, 5838 triangles |
| bin_std_M4x10: watertight | True |  | vol 13726 mm3, 5674 triangles |
| bin_std_M3x16: watertight | True |  | vol 13726 mm3, 5986 triangles |
| bin_deep_M2x10: watertight | True |  | vol 14812 mm3, 5834 triangles |
| bin_deep_M2_5x12: watertight | True |  | vol 14816 mm3, 6454 triangles |
| bin_deep_M3x20: watertight | True |  | vol 14813 mm3, 5946 triangles |
| bin_deep_M4x16: watertight | True |  | vol 14811 mm3, 5822 triangles |
| bin_deep_M4x20: watertight | True |  | vol 14813 mm3, 5782 triangles |
| bin_tray_M4_SPARE_stacked: watertight | True |  | vol 12856 mm3, 6506 triangles |
| worst STL volume error vs STEP | 0.003 | % | mesh vs solid |
| total printed volume | 348.5 | cm3 | all parts, PLA at 1.24 g/cm3 |
| base is watertight | True |  | 43568 triangles |
| lowest point of any bin | 1 | mm | socket floor is at 1.0 mm above the plate bottom |
| bins sit on the socket floor | 0 | mm | deviation |
| largest overlap between placed bins | 0 | mm3 | must be 0 |
| bins outside the plate footprint | 0 |  | must be 0 |
| base plate position in the assembly frame | x 0..210, y 0..168 | mm | the frame origin is the bottom left corner |
| bins not over a socket centre | 0 |  | must be 0 |
| bins fouling the base plate material | 0 |  | must be 0 (the profile has to be inside the socket) |
| stacked tray interference with the bin below | 0 | mm3 | bin_tray_M4_SPARE_stacked |
| stacked tray profile reaches below the lower rim | 3.6 | mm | its profile reaches into the mouth of the bin below |
| assembled height | 48.4 | mm | from the bottom of the base plate |

Reproduce with:

```
python src/build_all.py
python src/verify.py
python src/make_checks_md.py
python src/verify_mesh.py
```
