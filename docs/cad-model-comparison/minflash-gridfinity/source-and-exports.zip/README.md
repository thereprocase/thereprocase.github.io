# Gridfinity screw, nut and washer organiser

A bench organiser for socket head screws, plain hex nuts and flat washers,
built as a 5 x 4 cell Gridfinity mat (210 x 168 mm) with 21 bins:

* 4 washer trays, 4 nut trays (type **tray**)
* 11 screw bins (type **std** for the shorter screws, type **deep** for the
  long ones)
* 1 spares tray
* 1 shallow tray stacked on top of the M4 x 20 bin, which is where the
  stacking interface is used in the starter layout

Everything is parametric CAD.  The Gridfinity profile is the published
standard, the bins are three reusable types, and the label is real text
from `assets/fillaprint/Fillaprint-Regular.ttf` raised 0.6 mm off a 60 deg
facet.

```
                 back
 +--------+--------+--------+--------+--------+
 | M2x10  | M2.5x12| M3x20  | M4x16  | M4x20  |   deep  (30 mm)
 |        |        |        |        |        |   ... M4 SPARE tray on top
 +--------+--------+--------+--------+--------+
 | M2x6   | M2.5x8 | M3x10  | M4x10  | M3x16  |   std   (25 mm)
 +--------+--------+--------+--------+--------+
 | M2 NUT | M2.5   | M3 NUT | M4 NUT | M3x6   |   tray (21) / std
 |        | NUT    |        |        |        |
 +--------+--------+--------+--------+--------+
 | M2 WASH| M2.5   | M3 WASH| M4 WASH| SPARES |   tray  (21 mm)
 |        | WASH   |        |        |        |
 +--------+--------+--------+--------+--------+
                 front (labels face this way)
```

Column 1 = M2, column 2 = M2.5, column 3 = M3, column 4 = M4, column 5 =
the overflow column (a spares tray, two extra M3 lengths and the M4 x 20
bin).  Row 1 = washers, row 2 = nuts, row 3 = the shorter screw of each
size, row 4 = the longer one.  The rows step up in height (21 -> 25 ->
30 mm) and each label sits on the front facet, so nothing in the front row
hides the label of the row behind it.

## What is in the box, and how much of it fits

| cell (col, row) | label | bin | holds (typical count) |
|---|---|---|---|
| 1,1 | M2 WASH | tray | 30 M2 flat washers (5.0 x 0.5) |
| 2,1 | M2.5 WASH | tray | 30 M2.5 flat washers |
| 3,1 | M3 WASH | tray | 30 M3 flat washers |
| 4,1 | M4 WASH | tray | 30 M4 flat washers (9.0 x 0.8) |
| 5,1 | SPARES | tray | odd small hardware, shims, clips |
| 1,2 | M2 NUT | tray | 30 M2 hex nuts |
| 2,2 | M2.5 NUT | tray | 30 M2.5 hex nuts |
| 3,2 | M3 NUT | tray | 30 M3 hex nuts |
| 4,2 | M4 NUT | tray | 30 M4 hex nuts (7 across flats) |
| 5,2 | M3x6 | std | 20 M3 x 6 screws |
| 1,3 | M2x6 | std | 20 M2 x 6 screws |
| 2,3 | M2.5x8 | std | 20 M2.5 x 8 screws |
| 3,3 | M3x10 | std | 20 M3 x 10 screws |
| 4,3 | M4x10 | std | 20 M4 x 10 screws |
| 5,3 | M3x16 | std | 20 M3 x 16 screws |
| 1,4 | M2x10 | deep | 20 M2 x 10 screws |
| 2,4 | M2.5x12 | deep | 20 M2.5 x 12 screws |
| 3,4 | M3x20 | deep | 20 M3 x 20 screws |
| 4,4 | M4x16 | deep | 20 M4 x 16 screws |
| 5,4 | M4x20 | deep | 20 M4 x 20 screws |
| 5,4 | M4 SPARE (on top) | tray | odd M4 hardware |

The counts are the practical "one handful" quantities: 30 washers or nuts
per tray, 20 screws per bin.  Measured against the pocket volumes in
`checks.md`, 30 M4 washers fill 11 % of a tray pocket and 30 M4 hex nuts
17 %, so the parts stay in a shallow layer and stay individually visible.

## The three bin types

| | tray | std | deep |
|---|---|---|---|
| overall height | 21 mm | 25 mm | 30 mm |
| clear pocket | 39.2 across, 15.05 deep | 39.2 across, 19.05 deep | 39.2 across, 24.05 deep |
| pocket volume | 23 055 mm3 | 29 183 mm3 | 36 842 mm3 |
| floor | 1.2 mm slab over the base profile | same | same |
| wall | 1.4 mm | 1.4 mm | 1.4 mm |
| label facet | 60 deg, 6.8 mm of slope, text 5.0 mm cap height, 0.6 mm relief | same | same |
| facet band (above the floor) | 11.21 .. 17.10 mm | 15.21 .. 21.10 mm | 20.21 .. 26.10 mm |
| finger slot | 14 x 2.4 mm, sill 2.36 mm above the floor | 14 x 2.4 mm, sill 6.36 mm | 14 x 3.2 mm, sill 10.56 mm |

## The interfaces

**Gridfinity base profile.**  Every bin carries the published male profile
(35.6 mm across at the bottom, 37.2 mm across the vertical section, 41.5 mm
across at the top, 4.75 mm tall, 0.5 mm gap at the 42 mm pitch).  The
numbers come from the Gridfinity Design Reference v5 and were cross checked
against the `gridfinity-rebuilt-openscad` implementation; they are in
`src/gf_spec.py` with the citations.  The bins therefore drop into any
ordinary 42 mm Gridfinity base, and the base plate in this package uses the
matching socket.

**Base plate.**  `base_5x4` is a solid 210 x 168 x 5.9 mm plate with 20
sockets, a 1.0 mm solid floor under every socket and a flat bottom
(63.5 cm3, 79 g in PLA).  It prints bottom down and sits flat on the
bench.  Note that the published socket mouth is 42.0 mm wide at a 42 mm
pitch, so neighbouring sockets touch and the material between them tapers
to a knife edge in the top 2.15 mm; the same happens at the outer edge of
the plate, which is why the corners are left square rather than rounded.
That is the standard's geometry, not a shortcut here, and it means the bins
are located by their base profiles rather than by a flat top surface.

**Label facet.**  The top of the front wall is chamfered at 60 deg to the
horizontal and carries the label raised 0.6 mm.  A 1.4 mm wall is far too
thin to take that ramp - the ramp would cut straight through it and open
the bin - so the front wall is locally thickened over the height of the
facet (`_cheek()` in `src/gf_bins.py`).  The thickening takes 3.2 mm off the
front of the pocket over that band, which is above the fill line.
A 60 deg facet is readable from directly above (86.6 % of the true cap
height) and from a standing position (96.6 % at 45 deg of elevation), which
is the angle you actually have over a bench.

**Finger slot.**  A 14 mm wide slot through the front wall, just under the
facet.  It is the grip for lifting one bin out of the mat, and in the
shallow tray it is at the level of the parts, so a single washer can be
scooped forward and pinched out of it.

**Stacking.**  A second bin drops its base profile into the mouth of the
bin below and rests on the rim, the way any Gridfinity bin does: the
profile's cone meets the rim's inner edge 3.6 mm below the rim, and the
stacked bin ends up 1.15 mm proud of the rim it sits on.  Everything on
the wall therefore has to stay clear of that 3.6 mm band, which is why the
label facet stops 3.9 mm below the rim.

## Handling

**Reading a size without picking anything up.**  The label is on the front
facet of every bin and the bins are ordered by size, so the whole mat can
be read from the front.  The row in front never blocks the row behind: the
worst case in this layout is a `tray` label behind a `deep` bin, which
needs 24 deg of elevation to see the bottom of the label, and any standing
position over a bench is well above that.

**Getting one part out.**  The tray pocket is 15 mm deep and the parts sit
in a single shallow layer, so a washer is visible and can be pinched
between two fingers.  The slot in the front wall gives the fingers room at
the level of the parts, and its 2.36 mm sill stops a washer falling out of
it.  The screw bins are deeper (19 and 24 mm), which is still within reach
of a finger.

**Lifting one bin and carrying it.**  Hook a finger into the slot and lift:
the bin is held by the slot, not by the neighbouring bins, so nothing next
to it moves.  The walls are 1.4 mm and keep the contents in when the bin is
tilted; the finger slot sits well above the floor in the `std` and `deep`
bins, so nothing can leave through it, and the tray's slot sill is
2.36 mm.  A bin that is lifted out of the mat is a normal Gridfinity bin
and drops straight back into its socket.  The fit is a light press fit
(0.08 - 0.25 mm of clearance, measured), so a small tilt frees it: lift
the front edge, the base profile clears the cone of the socket.

**Stacking.**  The M4 x 20 bin in the back right corner carries the
`M4 SPARE` tray, which drops into its mouth and sits 1.15 mm proud.  The
same works for any bin on any bin.

## Adding a size later

The bins are parametric, so a new size is one line in the layout table:

```python
# src/gf_layout.py
_p(4, 1, "std", "M3x8"),          # column, row, bin type, label
```

then rebuild:

```
python src/build_all.py
```

The label is cut from the same TTF, so the new bin gets the same 5.0 mm
cap height and the same facet.  The base plate is parametric too
(`baseplate(nx, ny)`), so a second 5 x 4 plate can be printed and the two
mats tiled side by side for more sizes.  Nothing in the design is specific
to M2, M2.5, M3 or M4; the bin types are sized for the parts, not for the
thread.

## Files

```
src/gf_spec.py        Gridfinity standard: male profile, female socket,
                      base plate.  Constants carry their citations.
src/gf_text.py        TTF -> geometry.  The label outlines come from
                      assets/fillaprint/Fillaprint-Regular.ttf via
                      fontTools (build123d's own Text() silently falls back
                      to DejaVu Sans on this machine).  Fillaprint is
                      licensed under the OFL in assets/fillaprint/OFL.txt.
src/gf_bins.py        The three bin types, the label facet and the finger
                      slot.
src/gf_layout.py      The starter layout table.
src/build_all.py      Builds every part, writes exports/ and assembly.json.
src/verify.py         Measured checks on the solid model.
src/verify_mesh.py    Measured checks on the exported STL files and the
                      placed assembly (trimesh).
src/make_checks_md.py Renders checks.md from the JSON results.
exports/*.step        One STEP per part (solid, editable).
exports/*.stl         One binary STL per part.
assembly.json         Part files and their assembled transforms in mm.
checks.md             The measured checks, generated from the run.
```

`assembly.json` uses one frame: the origin is the bottom left corner of
the base plate, z is up, +x is to the right and +y goes into the bench, so
row 0 is the front row.  Each bin's local origin is the centre of its base
profile at the bottom of the profile, and its transform is the translation
that puts it in its socket (z = 1.0 mm, the socket floor) or in the mouth
of the bin below (z = 27.4 mm for the stacked tray).

## Printing notes

* Print the base plate flat side down; it is the only large part and the
  only one that will warp.  If your printer cannot hold 210 x 168 mm, print
  `baseplate(3, 4)` and `baseplate(2, 4)` instead and butt them together -
  they tile exactly at the 42 mm pitch.
* The label is raised 0.6 mm, so it prints in the second colour of a
  two-colour print, or in the same colour and stays legible under a light.
* Print the bins and the base with the same settings: the fit is a
  0.08 - 0.25 mm clearance, so a change of material or of nozzle size
  between the two will show up as a tight or loose fit.
* The whole set is about 348 cm3, roughly 432 g of PLA: 79 g of that is the
  base plate, the rest is 21 bins of 13 to 15 cm3 each.

## Limitations and what still needs a physical fit test

* **Nothing here has been printed or physically fitted.**  The geometry is
  verified by solid model and mesh measurements (`checks.md`), not by a
  printer.
* The socket and the stacking seat follow the published Gridfinity profile,
  whose conical surfaces are nominally line to line with the male profile.
  The socket was given a 0.08 mm radial relief (`BASE_RELIEF` in
  `src/build_all.py`) so that a printed fit is a slip fit rather than a
  press fit.  If a specific printer needs more or less, change that one
  number and rebuild.
* The socket's nominal fit relies on printed shrinkage being similar
  between the bin and the plate.  If the plate comes out loose, print it
  with a slightly larger socket by raising `BASE_RELIEF`.
* The label says "WASH", not "WASHER", on the M2.5 tray: "M2.5 WASHER" is
  34.0 mm of text and the flat part of the front facet is 34.5 mm wide, so
  the full word would touch the corner radii.  "M2.5 WASH" is 26.9 mm and
  sits with 3.8 mm of margin each side.
* The thickened front wall takes 3.2 mm off the front of the pocket over
  the height of the label facet.  That is above the fill line, but it does
  mean a washer pushed to the very front of a tray sits in a slightly
  narrower space.
* The stacked `M4 SPARE` tray is deliberately a small part bin; it
  demonstrates and uses the stacking interface, but the obvious use for it
  is the odd M4 hardware.  If you would rather have M4 washers up top, move
  that tray and give the M4 washers their own cell.
* The base plate's top surface between two sockets is a knife edge, and so
  is the material at the outer edge of the plate (that is the published
  socket geometry).  It is not a load path - the bins are located and held
  by their base profiles - but the plate is worth printing with a brim or
  on a well-textured bed.
* The stacking seat was verified as "the profile's cone meets the rim's
  inner edge with no interference" and the stacked bin was checked for
  interference against the bin below in the placed assembly, but the actual
  friction and how easily a stacked bin can be pulled off again still has
  to be tried by hand.
