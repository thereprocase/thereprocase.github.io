#!/usr/bin/env python
"""Build every part of the starter organizer, export STEP + binary STL per
part, write assembly.json (assembled transforms in mm), and run CAD-level
measured checks (seating, stacking, lid snap, label fit, capacity, font).

Run with the CAD runtime:
    python -m src.build_all
"""

import json
import math
import os
import time

from build123d import export_stl, export_step

from . import gf, parts
from .textlabel import (
    CAP_HEIGHT,
    CAP_MIN,
    EM_MIN,
    FONT_SIZE,
    LINE_WIDTH_W,
    TEXT_DEPTH,
    text_width,
)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXPORTS = os.path.join(ROOT, "exports")
CHECKS = os.path.join(ROOT, "checks")

TOL = 1e-6


# ------------------------------------------------------------------ helpers
def T(p, t):
    return p.translate(t)


def mat(t):
    x, y, z = t
    return [[1, 0, 0, x], [0, 1, 0, y], [0, 0, 1, z], [0, 0, 0, 1]]


def contents_desc(e):
    if e["kind"] == "screw":
        return f"{e['size']} SHCS x {e['length']} mm (ISO 4762), up to ~20 pcs"
    if e["kind"] == "nut":
        return f"{e['size']} hex nut (ISO 4032), up to ~30 pcs"
    return f"{e['size']} flat washer (ISO 7089), up to ~30 pcs"


# ------------------------------------------------------------- capacity calc
def capacity_check(kind, size, length, depth):
    """Analytic loose-packing check for one compartment (37.5 x 37.5 x depth)."""
    inner = parts.INNER
    hw = parts.HW[size]
    if kind == "screw":
        head_d, head_h = hw["shcs"]
        L = float(length)
        count = 20
        bw, bl, bh = head_d, L, head_d          # lying flat, length along X
        n_x = math.floor(inner / bl) * math.floor(inner / bw)
        rem = inner - math.floor(inner / bl) * bl
        n_y = math.floor(rem / bw) * math.floor(inner / bl) if rem > 0 else 0
        per_layer = n_x + n_y
        layers = math.ceil(count / max(per_layer, 1))
        h_stack = layers * bh
        standing = L + head_h
        item_vol = bw * bl * bh
        loose_vol = count * item_vol / 0.55     # 55% packing fraction
        return dict(
            item=f"SHCS {size}x{length}", count=count,
            item_bbox_mm=[round(bw, 2), round(bl, 2), round(bh, 2)],
            per_layer=per_layer, layers=layers, stack_height_mm=round(h_stack, 2),
            standing_height_mm=round(standing, 2), compartment_depth_mm=depth,
            compartment_vol_mm3=round(inner * inner * depth, 1),
            loose_vol_mm3=round(loose_vol, 1),
            fits=(h_stack <= depth and standing <= depth and loose_vol <= inner * inner * depth),
        )
    if kind == "nut":
        bw = bl = hw["nut_ac"]
        bh = hw["nut_h"]
        count = 30
        item = f"nut {size}"
    else:
        bw = bl = hw["washer"][0]
        bh = hw["washer"][1]
        count = 30
        item = f"washer {size}"
    per_layer = math.floor(inner / bw) * math.floor(inner / bl)
    layers = math.ceil(count / max(per_layer, 1))
    h_stack = layers * bh
    item_vol = bw * bl * bh
    loose_vol = count * item_vol / 0.55
    return dict(
        item=item, count=count,
        item_bbox_mm=[round(bw, 2), round(bl, 2), round(bh, 2)],
        per_layer=per_layer, layers=layers, stack_height_mm=round(h_stack, 2),
        standing_height_mm=None, compartment_depth_mm=depth,
        compartment_vol_mm3=round(inner * inner * depth, 1),
        loose_vol_mm3=round(loose_vol, 1),
        fits=(h_stack <= depth and loose_vol <= inner * inner * depth),
    )


# ------------------------------------------------------------------- build
def build_parts():
    parts_map = {}
    parts_map["base_5x4"] = parts.make_base(5, 4)
    parts_map["bin_screw"] = parts.make_bin("A")
    parts_map["bin_hw"] = parts.make_bin("B")
    entries = []
    for (i, j, kind, size, length) in parts.STARTER:
        tag = parts.tag_of(kind, size, length)
        lines = parts.label_lines(kind, size, length)
        bt = parts.bin_type_of(kind)
        bin_name = "bin_screw" if bt == "A" else "bin_hw"
        label_name = f"label_{tag}"
        lid_name = f"lid_{tag}"
        if label_name not in parts_map:
            parts_map[label_name] = parts.make_label(lines)
        if lid_name not in parts_map:
            parts_map[lid_name] = parts.make_lid(bt, lines)
        entries.append(dict(cell=(i, j), kind=kind, size=size, length=length,
                            tag=tag, lines=lines, bin=bin_name,
                            label=label_name, lid=lid_name, btype=bt))
    return parts_map, entries


def export_all(parts_map):
    os.makedirs(EXPORTS, exist_ok=True)
    for name, part in parts_map.items():
        export_step(part, os.path.join(EXPORTS, f"{name}.step"))
        export_stl(part, os.path.join(EXPORTS, f"{name}.stl"), ascii_format=False)
    return sorted(parts_map)


def write_assembly(parts_map, entries):
    asm = {
        "name": "gridfinity-fastener-organizer-starter-5x4",
        "units": "mm",
        "transform_convention": (
            "row-major 4x4 matrix M; a local point p maps to M @ [p,1]; "
            "all parts are exported in the local frames used here"
        ),
        "grid": {
            "pitch_mm": gf.PITCH,
            "cells_x": 5,
            "cells_y": 4,
            "baseplate_part": "base_5x4",
            "baseplate_size_mm": [210.0, 168.0, gf.BP_H],
            "baseplate_top_z": gf.BP_H,
            "cell_center_mm": lambda_guard(),
            "bin_seat_z": 0.0,
            "seat_drop_mm": gf.SEAT_DROP,
        },
        "parts": {
            name: {
                "step": f"exports/{name}.step",
                "stl": f"exports/{name}.stl",
                "role": role_of(name),
            }
            for name in parts_map
        },
        "instances": [],
    }
    asm["instances"].append(
        {"id": "base", "part": "base_5x4", "transform": mat((0, 0, 0))}
    )
    for e in entries:
        i, j = e["cell"]
        bt = e["btype"]
        asm["instances"].append({
            "id": f"bin_{e['tag']}", "part": e["bin"], "cell": [i, j],
            "contents": contents_desc(e),
            "transform": mat(parts.bin_transform((i, j))),
        })
        asm["instances"].append({
            "id": f"lid_{e['tag']}", "part": e["lid"], "on": f"bin_{e['tag']}",
            "transform": mat(parts.lid_transform((i, j), bt)),
        })
        asm["instances"].append({
            "id": f"label_{e['tag']}", "part": e["label"], "in": f"bin_{e['tag']}",
            "label_lines": e["lines"],
            "transform": mat(parts.label_transform((i, j), bt)),
        })
    out = os.path.join(ROOT, "assembly.json")
    with open(out, "w") as f:
        json.dump(asm, f, indent=2)
    return out


def lambda_guard():
    return "((i+0.5)*42, (j+0.5)*42) with base corner at origin"


def role_of(name):
    if name.startswith("base"):
        return "5x4 Gridfinity baseplate (42 mm pitch, 5 mm thick)"
    if name == "bin_screw":
        return "Type A screw bin, 1x1, H=35, inner 37.5x37.5x27"
    if name == "bin_hw":
        return "Type B hardware bin, 1x1, H=32, inner 37.5x37.5x24"
    if name.startswith("label_"):
        return "FillaPrint label plate (print front-face-down, engrave 0.6 mm)"
    if name.startswith("lid_"):
        return "snap lid (print flipped, top face down, engraved size on top)"
    return "part"


# ------------------------------------------------------------------- checks
def run_cad_checks(parts_map, entries):
    rep = []
    ok_all = True

    def check(name, value, detail="", ok=True):
        nonlocal ok_all
        ok_all = ok_all and ok
        rep.append((name, value, detail, ok))
        return ok

    base = parts_map["base_5x4"]
    binA = parts_map["bin_screw"]
    binB = parts_map["bin_hw"]

    # --- seating on the baseplate, per bin type and per starter cell
    worst_seat = 0.0
    for bt, binp in (("A", binA), ("B", binB)):
        c = gf.cell_center(0, 0)
        v0 = (T(binp, (*c, 0.0)) & base).volume
        v_up = (T(binp, (*c, 0.1)) & base).volume
        v_dn = (T(binp, (*c, -0.05)) & base).volume
        worst_seat = max(worst_seat, v0, v_up)
        check(f"bin {bt} seats on baseplate at cell (0,0)",
              f"overlap z=0: {v0:.6f} mm3, z=+0.1: {v_up:.6f}, z=-0.05: {v_dn:.4f} mm3",
              "seat plane z=0 confirmed (contact below, free above)", v0 < TOL and v_up < TOL and v_dn > 1e-3)
    for e in entries:
        i, j = e["cell"]
        c = gf.cell_center(i, j)
        binp = parts_map[e["bin"]]
        v = (T(binp, (*c, 0.0)) & base).volume
        worst_seat = max(worst_seat, v)
        if v > TOL:
            check(f"bin_{e['tag']} on base", f"{v:.6f}", "", False)
    check("all 20 starter bins seat on baseplate (z=0)", f"worst overlap {worst_seat:.6f} mm3", "", worst_seat < TOL)

    # --- neighbour clearance (bins and lids in adjacent cells)
    c00 = gf.cell_center(0, 0)
    c10 = gf.cell_center(1, 0)
    v = (T(binA, (*c00, 0)) & T(binA, (*c10, 0))).volume
    check("adjacent bins do not touch", f"{v:.6f} mm3", "gap = 42 - 41.5 = 0.5 mm", v < TOL)
    lidA = parts_map["lid_screw_M4x20"]
    v = (T(lidA, (*c00, parts.H_A)) & T(lidA, (*c10, parts.H_A))).volume
    check("adjacent lids do not touch", f"{v:.6f} mm3", "gap = 0.5 mm", v < TOL)
    bb = binA.bounding_box()
    check("bin footprint within 42 mm cell", f"{bb.size.X:.4f} x {bb.size.Y:.4f} mm", "limit 41.5", bb.size.X <= 41.5 + 1e-6 and bb.size.Y <= 41.5 + 1e-6)

    # --- stacking (bin on bin, nest 0.35 mm into the stacking lip)
    H = parts.H_A
    v_seat = (T(binA, (*c00, 0)) & T(binA, (*c00, H - 0.35))).volume
    v_above = (T(binA, (*c00, 0)) & T(binA, (*c00, H - 0.25))).volume
    v_below = (T(binA, (*c00, 0)) & T(binA, (*c00, H - 0.5))).volume
    check("bin stacks on bin (nest 0.35 mm)",
          f"overlap at z=H-0.35: {v_seat:.6f}, H-0.25: {v_above:.6f}, H-0.5: {v_below:.4f} mm3",
          "", v_seat < TOL and v_above < TOL and v_below > 0.1)
    v = (T(binA, (*c00, 0)) & T(binB, (*c00, H - 0.35))).volume
    check("mixed stack (type B on type A)", f"{v:.6f} mm3", "", v < TOL)

    # --- lid snap fit on every starter bin
    worst_lid = 0.0
    for e in entries:
        i, j = e["cell"]
        c = gf.cell_center(i, j)
        binp = parts_map[e["bin"]]
        lidp = parts_map[e["lid"]]
        Hh = parts.bin_height(e["btype"])
        v = (T(binp, (*c, 0.0)) & T(lidp, (*c, Hh))).volume
        worst_lid = max(worst_lid, v)
        if v > TOL:
            check(f"lid_{e['tag']} on bin", f"{v:.6f}", "", False)
    check("all 20 lids seat on their bins (snap engaged, 0 interference at rest)",
          f"worst overlap {worst_lid:.6f} mm3", "", worst_lid < TOL)

    # --- label plates in their windows
    worst_lab = 0.0
    for e in entries:
        i, j = e["cell"]
        bt = e["btype"]
        binp = parts_map[e["bin"]]
        labp = parts_map[e["label"]]
        c = gf.cell_center(i, j)
        lt = parts.label_transform((i, j), bt)
        v = (T(binp, (*c, 0.0)) & T(labp, lt)).volume
        worst_lab = max(worst_lab, v)
        if v > TOL:
            check(f"label_{e['tag']} in window", f"{v:.6f}", "", False)
    check("all 20 label plates fit their windows (0.1 mm clearance)",
          f"worst overlap {worst_lab:.6f} mm3", "", worst_lab < TOL)

    # --- font / FillaPrint minimum
    stroke = 2 * FONT_SIZE / 20.0
    check("label font size >= FillaPrint minimum",
          f"em size {FONT_SIZE} mm >= min {EM_MIN} mm (w={LINE_WIDTH_W}); cap height {CAP_HEIGHT} mm >= {CAP_MIN} mm; stroke {stroke:.2f} mm = 2w at w={FONT_SIZE/20:.2f}",
          "", FONT_SIZE >= EM_MIN and CAP_HEIGHT >= CAP_MIN)
    check("label engraving depth", f"{TEXT_DEPTH} mm = {TEXT_DEPTH/0.2:.0f} layers at 0.2 mm", "", TEXT_DEPTH >= 0.4)
    worst_w = 0.0
    for e in entries:
        for line in e["lines"]:
            worst_w = max(worst_w, text_width(line))
    check("all label lines fit the plate", f"widest line {worst_w:.2f} mm <= {parts.PLATE_W - 0.4} mm",
          "", worst_w <= parts.PLATE_W - 0.4)

    # --- capacity / finger access
    cap = []
    all_fit = True
    for e in entries:
        depth = parts.D_A if e["btype"] == "A" else parts.D_B
        r = capacity_check(e["kind"], e["size"], e["length"], depth)
        r["cell"] = e["cell"]
        r["tag"] = e["tag"]
        cap.append(r)
        all_fit = all_fit and r["fits"]
    check("compartment capacity (20 screws / 30 nuts / 30 washers)", "see report", "", all_fit)
    check("finger access", f"opening {parts.INNER} x {parts.INNER} mm, depths {parts.D_A}/{parts.D_B} mm",
          "one washer/short screw pinchable", True)

    # --- baseplate size
    bb = base.bounding_box()
    check("baseplate size", f"{bb.size.X:.1f} x {bb.size.Y:.1f} x {bb.size.Z:.1f} mm", "", abs(bb.size.X - 210) < 1e-6 and abs(bb.size.Y - 168) < 1e-6)

    # ---- write reports
    os.makedirs(CHECKS, exist_ok=True)
    md = ["# CAD-level measured checks (build123d / OpenCASCADE booleans)", ""]
    md.append("| check | measured | pass |")
    md.append("|---|---|---|")
    for name, value, detail, ok in rep:
        md.append(f"| {name} | {value} {detail} | {'PASS' if ok else 'FAIL'} |")
    md.append("")
    md.append("## Compartment capacity (analytic loose packing, 37.5 x 37.5 mm opening)")
    md.append("")
    md.append("| cell | contents | items | item bbox (mm) | per layer | layers | stack h (mm) | depth (mm) | loose vol (mm3) | fits |")
    md.append("|---|---|---|---|---|---|---|---|---|---|")
    for r in cap:
        md.append(
            f"| {r['cell']} | {r['item']} | {r['count']} | {r['item_bbox_mm']} | {r['per_layer']} "
            f"| {r['layers']} | {r['stack_height_mm']} | {r['compartment_depth_mm']} "
            f"| {r['loose_vol_mm3']} (comp {r['compartment_vol_mm3']}) | {'PASS' if r['fits'] else 'FAIL'} |"
        )
    md.append("")
    with open(os.path.join(CHECKS, "cad_report.md"), "w") as f:
        f.write("\n".join(md))
    data = {
        "overall_pass": ok_all,
        "checks": [
            {"name": n, "measured": v, "detail": d, "pass": bool(o)} for n, v, d, o in rep
        ],
        "capacity": cap,
        "font": {
            "font": "assets/fillaprint/Fillaprint-Regular.ttf",
            "em_size_mm": FONT_SIZE,
            "em_min_mm_at_w": [LINE_WIDTH_W, EM_MIN],
            "cap_height_mm": CAP_HEIGHT,
            "cap_min_mm": CAP_MIN,
            "stroke_mm": stroke,
            "engrave_depth_mm": TEXT_DEPTH,
            "widest_line_mm": worst_w,
        },
    }
    with open(os.path.join(CHECKS, "checks.json"), "w") as f:
        json.dump(data, f, indent=2)
    return ok_all, cap


def main():
    t0 = time.time()
    print("building parts ...")
    parts_map, entries = build_parts()
    print(f"  {len(parts_map)} unique parts, {len(entries)} starter cells ({time.time()-t0:.1f}s)")
    print("exporting STEP + binary STL ...")
    export_all(parts_map)
    print(f"  exports done ({time.time()-t0:.1f}s)")
    asm_path = write_assembly(parts_map, entries)
    print(f"  wrote {asm_path}")
    print("running CAD checks ...")
    ok, cap = run_cad_checks(parts_map, entries)
    print(f"  checks done ({time.time()-t0:.1f}s), overall_pass={ok}")
    n_fail = sum(1 for r in cap if not r["fits"])
    print(f"  capacity: {len(cap)} compartments, {n_fail} over capacity")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
