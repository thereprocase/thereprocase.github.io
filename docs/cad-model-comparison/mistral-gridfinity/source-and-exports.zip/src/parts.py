"""Parametric organizer parts: Gridfinity 1x1 bins, snap lids, FillaPrint
label plates, and the 5x4 baseplate, plus the starter assortment spec.

Bin types (both 1x1, standard Gridfinity refined bottom, stack via the
standard top lip):
  Type A "bin_screw" : H=35, inner depth 27  -> 20x M4x20 SHCS (worst case)
  Type B "bin_hw"    : H=32, inner depth 24  -> 30x M4 nuts / washers
Each bin has one open compartment (no tiny holes), a through-window in the
front wall for a glued FillaPrint label plate, and an inner snap groove for
its lid.  Lids are insert-style snap caps with the size engraved on top
(print lids flipped, top face down, for a first-layer colour swap).

All dimensions in millimetres.
"""

from build123d import (
    Align,
    Box,
    BuildPart,
    BuildSketch,
    Cylinder,
    Face,
    Wire,
    Locations,
    Mode,
    Plane,
    Rectangle,
    Text,
    Axis,
    extrude,
    fillet,
)

from .gf import (
    BASE_STRUCT_H,
    BIN_TOP,
    FRUSTUM_H,
    PITCH,
    RC_TOP,
    bin_frustum,
    make_baseplate,
    rr_face,
)
from .textlabel import (
    FONT_PATH,
    FONT_SIZE,
    TEXT_DEPTH,
    line_v_offsets,
)

# ---------------------------------------------------------------- parameters
WALL = 2.0                    # bin wall thickness
INNER = BIN_TOP - 2 * WALL    # 37.5 compartment width
RC_IN = RC_TOP - WALL         # 1.75 inner corner radius

H_A, D_A = 35.0, 27.0         # Type A screw bin: outer height / inner depth
H_B, D_B = 32.0, 24.0         # Type B hardware bin
FLOOR_Z = 8.0                 # compartment floor height (above frustum)

WIN_W, WIN_H = 37.0, 22.0     # label window in the front wall (outer face)
WIN_Z0 = {"A": 7.5, "B": 4.75}  # window bottom z per bin type
PLATE_W, PLATE_H, PLATE_T = 36.8, 21.8, 2.0   # label plate (0.1 clearance)

LIP_H = 0.6                   # stacking lip protrusion height at the top
LIP_IN = 36.3                 # opening across the lip at the very top
LIP_RC_IN = 1.15
TOP_FILLET = 0.6              # top outer edge fillet (spec)
FLOOR_FILLET = 1.5            # scoop fillet at compartment floor (< inner corner radius 1.75 to avoid degenerate geometry)

GROOVE_Z = 4.9                # snap groove: from H-4.9 to H-3.9
GROOVE_DEPTH = 0.3
GROOVE_OUT = INNER + 2 * GROOVE_DEPTH      # 38.1
GROOVE_RC_OUT = RC_IN + GROOVE_DEPTH       # 2.05

LID_PLATE_T = 2.0
LID_RIM_OUT = 36.1            # passes the 36.3 lip opening with 0.1/side
LID_RIM_RC = 1.05
LID_RIM_IN = 33.7
LID_RIM_H = 4.9               # rim length below the plate
LID_BEAD_OUT = 37.9           # snap bead outer (retention interference 0.2)
LID_BEAD_RC = LID_RIM_RC + (LID_BEAD_OUT - LID_RIM_OUT) / 2
LID_BEAD_Z1, LID_BEAD_Z0 = -3.95, -4.75    # bead z-range (lid local), inside groove
LID_SLOT_W = 1.2
LID_SCOOP_R = 4.0

# ------------------------------------------------------------- hardware data
# ISO 4762 / DIN 912 socket head cap screw: (head dia, head height)
# ISO 4032 / DIN 934 hex nut: across flats, height (across corners derived)
# ISO 7089 / DIN 125A flat washer: outer dia, thickness
HW = {
    "M2":   dict(shcs=(3.8, 2.0), nut_af=4.0, nut_h=1.6, washer=(5.0, 0.3)),
    "M2.5": dict(shcs=(4.5, 2.5), nut_af=5.0, nut_h=2.0, washer=(6.0, 0.5)),
    "M3":   dict(shcs=(5.5, 3.0), nut_af=5.5, nut_h=2.4, washer=(7.0, 0.5)),
    "M4":   dict(shcs=(7.0, 4.0), nut_af=7.0, nut_h=3.2, washer=(9.0, 0.8)),
}
for v in HW.values():
    v["nut_ac"] = v["nut_af"] * 2.0 / 3**0.5   # across corners (bounding box)

# ------------------------------------------------------- starter assortment
# (cell_x, cell_y, kind, size, length)  -- cells of the 5x4 base, y=0 is front
STARTER = [
    (0, 3, "screw", "M4", 20), (1, 3, "screw", "M4", 16), (2, 3, "screw", "M4", 12),
    (3, 3, "screw", "M3", 20), (4, 3, "screw", "M3", 16),
    (0, 2, "screw", "M3", 12), (1, 2, "screw", "M3", 10),
    (2, 2, "screw", "M2.5", 12), (3, 2, "screw", "M2.5", 10), (4, 2, "screw", "M2.5", 8),
    (0, 1, "screw", "M2", 8), (1, 1, "screw", "M2", 6),
    (2, 1, "nut", "M2", None), (3, 1, "nut", "M2.5", None), (4, 1, "nut", "M3", None),
    (0, 0, "nut", "M4", None),
    (1, 0, "washer", "M2", None), (2, 0, "washer", "M2.5", None),
    (3, 0, "washer", "M3", None), (4, 0, "washer", "M4", None),
]


def tag_of(kind: str, size: str, length) -> str:
    s = size.replace(".", "p")
    if kind == "screw":
        return f"{kind}_{s}x{length}"
    return f"{kind}_{s}"


def label_lines(kind: str, size: str, length) -> list:
    if kind == "screw":
        return [f"{size} x {length}", "SCREW"]
    return [size, kind.upper()]          # "M3" / "NUT"  or  "M3" / "WASHER"


def bin_type_of(kind: str) -> str:
    return "A" if kind == "screw" else "B"


# ---------------------------------------------------------------- builders
def _ring(outer, rc_out, inner, rc_in, z0, height):
    """Vertical annulus solid from z0 to z0+height."""
    return extrude(rr_face(outer, rc_out).translate((0, 0, z0)), amount=height) - \
        extrude(rr_face(inner, rc_in).translate((0, 0, z0)), amount=height)


def _text_solid_xy(lines, depth):
    """Text solid in the XY plane, z in [0, depth], lines centred on x=0."""
    with BuildPart() as p:
        with BuildSketch(Plane.XY) as sk:
            for line, v in zip(lines, line_v_offsets(len(lines))):
                with Locations((0, v)):
                    Text(line, FONT_SIZE, font_path=FONT_PATH,
                         align=(Align.CENTER, Align.CENTER))
        extrude(amount=depth)
    return p.part


def make_bin(btype: str):
    """Type 'A' (screw) or 'B' (hardware) bin.  Local origin: cell centre,
    z=0 at the bottom of the Gridfinity frustum."""
    H = H_A if btype == "A" else H_B
    win_z0 = WIN_Z0[btype]
    floor = FLOOR_Z
    assert floor >= BASE_STRUCT_H - 0.01

    part = bin_frustum()                                        # z 0..4.75
    part = part + extrude(                                      # outer column
        rr_face(BIN_TOP, RC_TOP).translate((0, 0, FRUSTUM_H)), amount=H - FRUSTUM_H
    )
    part = fillet(                                              # top outer edge
        [e for e in part.edges() if abs(e.center().Z - H) < 1e-6], TOP_FILLET
    )
    part = part - extrude(                                      # compartment
        rr_face(INNER, RC_IN).translate((0, 0, floor)), amount=H + 2 - floor
    )
    part = fillet(                                              # floor scoop
        [e for e in part.edges() if abs(e.center().Z - floor) < 1e-6], FLOOR_FILLET
    )
    # stacking lip: ring with 45 deg underside, top LIP_H of the wall
    lip_outer = extrude(rr_face(BIN_TOP, RC_TOP).translate((0, 0, H - LIP_H)), LIP_H)
    lip_inner = extrude(rr_face(LIP_IN, LIP_RC_IN).translate((0, 0, H)),
                        amount=-LIP_H, taper=-45)
    part = part + (lip_outer - lip_inner)
    # lid snap groove in the inner wall (H-4.9 .. H-3.9)
    part = part - _ring(GROOVE_OUT, GROOVE_RC_OUT, INNER, RC_IN, H - GROOVE_Z, 1.0)
    # label window through the front wall (-Y)
    win = Box(WIN_W, 6.0, WIN_H).translate(
        (0, -(BIN_TOP / 2 + 0.25), win_z0 + WIN_H / 2)
    )
    part = part - win
    return part


def make_lid(btype: str, lines: list):
    """Snap lid.  Local origin: centre of the plate bottom face (z=0), rim
    hangs below.  Size text engraved 0.6 mm into the top face (print the lid
    flipped, top face down, for a FillaPrint first-layer colour swap)."""
    plate = extrude(rr_face(BIN_TOP, RC_TOP), amount=LID_PLATE_T)   # z 0..2
    rim = _ring(LID_RIM_OUT, LID_RIM_RC, LID_RIM_IN, 0.3, -LID_RIM_H, LID_RIM_H)
    bead = _ring(LID_BEAD_OUT, LID_BEAD_RC, LID_RIM_OUT, LID_RIM_RC,
                 LID_BEAD_Z0, LID_BEAD_Z1 - LID_BEAD_Z0)
    part = plate + rim + bead
    # flex slots at the 4 mid-edges, through rim + bead
    r = LID_RIM_OUT / 2
    for x, y, sx, sy in ((0, r, LID_SLOT_W, 5.0), (0, -r, LID_SLOT_W, 5.0),
                         (r, 0, 5.0, LID_SLOT_W), (-r, 0, 5.0, LID_SLOT_W)):
        part = part - Box(sx, sy, LID_RIM_H + 0.4).translate((x, y, -LID_RIM_H / 2 + 0.05))
    # finger scoop at the front edge of the top face
    part = part - Cylinder(LID_SCOOP_R, 1.4).translate((0, -BIN_TOP / 2, LID_PLATE_T - 0.7))
    # size text engraved into the top face
    part = part - _text_solid_xy(lines, TEXT_DEPTH).translate((0, 0, LID_PLATE_T - TEXT_DEPTH))
    return part


def make_label(lines: list):
    """FillaPrint label plate.  Local frame: X = width, Y = thickness (front
    face at y=-PLATE_T/2 with the engraving), Z = height, centred on the
    origin.  Print front-face-down so the engraved glyphs are layer 1."""
    with BuildSketch(Plane.XY) as sk:
        Rectangle(PLATE_W, PLATE_H)
    plate = extrude(Face(Wire.combine(sk.edges())[0]), amount=PLATE_T)  # z 0..T
    txt = _text_solid_xy(lines, TEXT_DEPTH)                # z 0..depth
    part = plate - txt.translate((0, 0, PLATE_T - TEXT_DEPTH))  # engrave top face
    # rotate so thickness is along Y and the engraved face points to -Y
    part = part.rotate(Axis.X, 90).translate((0, PLATE_T / 2, 0))
    return part


def make_base(gx=5, gy=4):
    return make_baseplate(gx, gy)


# ------------------------------------------------- assembly placement (mm)
def bin_transform(cell):
    i, j = cell
    return ((i + 0.5) * PITCH, (j + 0.5) * PITCH, 0.0)


def bin_height(btype):
    return H_A if btype == "A" else H_B


def lid_transform(cell, btype):
    x, y, _ = bin_transform(cell)
    return (x, y, bin_height(btype))


def label_transform(cell, btype):
    x, y, _ = bin_transform(cell)
    return (x, y - BIN_TOP / 2 + PLATE_T / 2, WIN_Z0[btype] + WIN_H / 2)
