"""Gridfinity "refined" interface profiles (42 mm pitch), implemented from the
published spec constants (gridfinity.xyz / kennetek gridfinity-rebuilt):

  BASE_PROFILE (bin bottom, cross-section from outer surface, x in / y up):
      [0,0] -> [0.8,0.8] -> [0.8,2.6] -> [2.95,4.75]
  BASE_TOP_DIMENSIONS = 41.5, BASE_TOP_RADIUS = 3.75
  baseplate: 42 mm cells, plate height 5 mm, outer corner radius 4 mm,
  cell pocket = bin profile + 0.25 mm/side clearance, seat drop 0.25 mm.

All dimensions in millimetres.  Bins built here are 1x1 (single cell) and seat
on any standard 42 mm Gridfinity baseplate.
"""

from build123d import (
    BuildSketch,
    Face,
    Plane,
    Rectangle,
    Wire,
    extrude,
    fillet,
)

PITCH = 42.0               # grid pitch
BIN_TOP = 41.5             # bin outer size at top of base profile / walls
RC_TOP = 3.75              # corner radius at BIN_TOP
FRUSTUM_H = 4.75           # height of the interlocking bottom profile
BRIDGE_H = 2.25            # flat bridge above the frustum (bin bottom = 7.0)
BASE_STRUCT_H = FRUSTUM_H + BRIDGE_H   # 7.0 mm solid bottom of a bin
BP_H = 5.0                 # baseplate height
BP_RC = 4.0                # baseplate outer corner radius
SEAT_DROP = 0.25           # bin sinks 0.25 mm into a baseplate when seated

# bin bottom frustum cross-section key points (z, size, corner radius)
FRUSTUM_SECTIONS = [
    (0.00, 35.6, 0.80),
    (0.80, 37.2, 1.60),
    (2.60, 37.2, 1.60),
    (4.75, 41.5, 3.75),
]

# baseplate cell pocket (the negative of the frustum + 0.25/side clearance)
POCKET_SECTIONS = [
    (0.00, 36.3, 1.15),
    (0.35, 36.3, 1.15),
    (1.05, 37.7, 1.85),
    (2.85, 37.7, 1.85),
    (5.00, 42.0, 4.00),
]


def rr_face(size: float, rc: float) -> Face:
    """Rounded-square face of `size` with corner radius `rc`, at z=0."""
    with BuildSketch(Plane.XY) as sk:
        r = Rectangle(size, size)
        fillet(r.vertices(), rc)
    return Face(Wire.combine(sk.edges())[0])


def _profile_solid(sections) -> "Part":
    """Solid built bottom-up through [(z, size, corner_radius), ...].
    45 deg tapers where the size changes, vertical walls where it does not."""
    secs = sorted(sections, key=lambda s: s[0])
    part = None
    for k in range(len(secs) - 1):
        z0, s0, rc0 = secs[k]
        z1, s1, _ = secs[k + 1]
        h = z1 - z0
        taper = 0.0 if abs(s1 - s0) < 1e-9 else -45.0
        seg = extrude(rr_face(s0, rc0).translate((0, 0, z0)), amount=h, taper=taper)
        part = seg if part is None else part + seg
    return part


def bin_frustum():
    """The 4.75 mm Gridfinity interlocking bottom of a 1x1 bin (z = 0..4.75)."""
    return _profile_solid(FRUSTUM_SECTIONS)


def baseplate_cell_pocket():
    """Cutter for one baseplate cell (z = 0..5), centred on the cell origin."""
    return _profile_solid(POCKET_SECTIONS)


def rect_face(w: float, h: float, rc: float) -> Face:
    """Rounded-rectangle face w x h with corner radius rc, at z=0."""
    with BuildSketch(Plane.XY) as sk:
        r = Rectangle(w, h)
        fillet(r.vertices(), rc)
    return Face(Wire.combine(sk.edges())[0])


def make_baseplate(gx: int, gy: int):
    """Standard Gridfinity baseplate of gx x gy cells (42 mm pitch).
    Origin at the plate corner; cells centred at ((i+0.5)*42, (j+0.5)*42)."""
    w, h = gx * PITCH, gy * PITCH
    part = extrude(rect_face(w, h, BP_RC), amount=BP_H)
    pocket = baseplate_cell_pocket()
    for i in range(gx):
        for j in range(gy):
            part = part - pocket.translate(((i + 0.5) * PITCH, (j + 0.5) * PITCH, 0))
    return part


def cell_center(i: int, j: int):
    """Centre of cell (i, j) of a baseplate whose corner is at the origin."""
    return ((i + 0.5) * PITCH, (j + 0.5) * PITCH)
