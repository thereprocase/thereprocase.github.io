"""FillaPrint label text helpers.

Font: assets/fillaprint/Fillaprint-Regular.ttf (OFL, see assets/fillaprint/OFL.txt).
The typeface is a two-bead FDM font: at the reference size the em is 20 x line
width w, cap height is 14 x w, and every stroke / clear gap is >= 2w.
For a 0.4 mm nozzle with w = 0.42 mm line width the font minimum is therefore
em size 8.4 mm (cap height 5.88 mm).  We label at em size 10 mm (cap 7.0 mm,
stroke 1.0 mm), i.e. above the minimum.

Labels are engraved 0.6 mm (3 x 0.2 mm layers) into the face that is printed
down, so a FillaPrint-style first-layer colour swap fills the glyphs with the
second colour.
"""

import os

from build123d import Align, BuildSketch, Plane, Text

FONT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "assets",
    "fillaprint",
    "Fillaprint-Regular.ttf",
)

LINE_WIDTH_W = 0.42          # assumed slicer line width (0.4 mm nozzle)
FONT_SIZE = 10.0             # em size in mm (cap height = 14/20 * 10 = 7.0 mm)
CAP_HEIGHT = 14.0 / 20.0 * FONT_SIZE          # 7.0 mm
EM_MIN = 20.0 * LINE_WIDTH_W                   # 8.4 mm font minimum at w = 0.42
CAP_MIN = 14.0 * LINE_WIDTH_W                  # 5.88 mm
BASELINE_DIST = 28.0 / 20.0 * FONT_SIZE        # 14.0 mm default line spacing
TEXT_DEPTH = 0.6                               # engraving depth (3 layers @0.2)


def text_width(s: str, size: float = FONT_SIZE) -> float:
    """Measured advance width of a string in mm at the given em size."""
    with BuildSketch(Plane.XY) as sk:
        Text(s, size, font_path=FONT_PATH, align=(Align.CENTER, Align.CENTER))
    boxes = [f.bounding_box() for f in sk.faces()]
    lo = min(b.min.X for b in boxes)
    hi = max(b.max.X for b in boxes)
    return hi - lo


def text_block_height(n_lines: int, size: float = FONT_SIZE) -> float:
    """Height of an n-line block: (n-1) baseline distances + cap height."""
    if n_lines <= 1:
        return CAP_HEIGHT * (size / FONT_SIZE)
    return (n_lines - 1) * BASELINE_DIST * (size / FONT_SIZE) + CAP_HEIGHT * (size / FONT_SIZE)


def line_v_offsets(n_lines: int, size: float = FONT_SIZE):
    """Vertical centre offsets of each line of an n-line block, centred on 0."""
    block = text_block_height(n_lines, size)
    cap = CAP_HEIGHT * (size / FONT_SIZE)
    step = BASELINE_DIST * (size / FONT_SIZE)
    # vertical centre (cap mid-height) of each line, block centred on 0
    return [block / 2 - cap / 2 - k * step for k in range(n_lines)]
