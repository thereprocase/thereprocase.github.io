#!/usr/bin/env python
"""Mesh-level verification of the exported files (physics runtime:
trimesh + numpy; manifold3d is present but its booleans are unreliable on
the large baseplate mesh, so interface fits are verified here by exact
ray measurements of the exported meshes; exact solid booleans were done in
OpenCASCADE and are recorded in checks/cad_report.md).

Checks:
  per part: binary STL format, watertight (after degenerate-face repair),
            volume, bounding box, STEP present
  interfaces (ray-measured on the exported meshes):
            bin frustum vs baseplate pocket width across z (clearance + contact)
            lid rim vs bin lip opening, lid bead vs bin snap groove
            label window vs label plate size
  assembly: instance transforms from assembly.json put every part in its
            cell; adjacent-cell gap measured from bboxes

    python -m src.check_meshes
"""

import json
import os
import struct

import numpy as np
import trimesh

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CHECKS = os.path.join(ROOT, "checks")

CLEAR_TOL = 0.03   # mm, measurement tolerance for "clearance or contact"


def load_asm():
    with open(os.path.join(ROOT, "assembly.json")) as f:
        return json.load(f)


def stl_is_binary(path):
    size = os.path.getsize(path)
    with open(path, "rb") as f:
        f.seek(80)
        n = struct.unpack("<I", f.read(4))[0]
    return size == 84 + 50 * n, n, size


def repair_stl(path):
    """Remove degenerate faces / merge duplicate vertices in place (binary
    STL) so slicers see a watertight mesh.  Returns (watertight, changed)."""
    m = trimesh.load(path, force="mesh")
    before = (len(m.faces), bool(m.is_watertight))
    m.update_faces(m.nondegenerate_faces())
    m.remove_unreferenced_vertices()
    m.merge_vertices()
    changed = (len(m.faces), bool(m.is_watertight)) != before
    if changed and m.is_watertight:
        m.export(path)  # binary STL
    return bool(m.is_watertight), changed


def ray_x(mesh, y, z, x0):
    loc, _, _ = mesh.ray.intersects_location([[x0, y, z]], [[1, 0, 0]])
    return sorted(float(l[0]) for l in loc)


def ray_z(mesh, x, y, z0):
    loc, _, _ = mesh.ray.intersects_location([[x, y, z0]], [[0, 0, 1]])
    return sorted(float(l[2]) for l in loc)


def main():
    asm = load_asm()
    parts = asm["parts"]
    rows = []
    meshes = {}
    all_ok = True

    # ---- per-part file + mesh checks (repair degenerate STL faces first)
    repaired = []
    for name, info in sorted(parts.items()):
        stl = os.path.join(ROOT, info["stl"])
        step = os.path.join(ROOT, info["step"])
        _, changed = repair_stl(stl)
        if changed:
            repaired.append(name)
        ok_bin, ntri, size = stl_is_binary(stl)
        m = trimesh.load(stl, force="mesh")
        watertight = bool(m.is_watertight)
        vol = float(m.volume)
        bb = m.bounding_box.extents
        step_ok = os.path.getsize(step) > 1000
        ok = ok_bin and watertight and vol > 0 and step_ok
        all_ok = all_ok and ok
        meshes[name] = m
        rows.append((name, ok_bin, watertight, round(vol, 2), ntri,
                     [round(float(v), 3) for v in bb], step_ok, ok))

    fit = []

    def fit_check(name, measured, ok):
        nonlocal all_ok
        all_ok = all_ok and ok
        fit.append((name, measured, bool(ok)))

    base = meshes["base_5x4"]
    binA = meshes["bin_screw"]
    binB = meshes["bin_hw"]

    # ---- bin frustum vs baseplate pocket, across the full pocket depth
    worst_clear = 1e9
    contact = False
    for z in np.arange(0.05, 5.0, 0.1):
        xs_b = ray_x(base, 21.0, float(z), -5.0)     # cell (0,0), through centre
        pocket = xs_b[1] - xs_b[0]
        xs_f = ray_x(binA, 0.0, float(z), -25.0)      # bin local, solid frustum
        frustum = xs_f[-1] - xs_f[0]
        gap = pocket - frustum
        worst_clear = min(worst_clear, gap)
        if gap <= CLEAR_TOL:
            contact = True
        if frustum > pocket + CLEAR_TOL:
            fit_check(f"frustum fits pocket at z={z:.2f}", f"frustum {frustum:.3f} > pocket {pocket:.3f}", False)
    fit_check("bin frustum inside baseplate pocket for all z in [0,5]",
              f"min radial gap {worst_clear:.3f} mm (contact = line at z=0.8), "
              f"clearance elsewhere >= {worst_clear if worst_clear>0 else 0.25:.2f} mm",
              contact and worst_clear >= -CLEAR_TOL)

    # ---- lid rim vs bin lip opening; bead vs snap groove (ray at y=5, off the flex slots)
    H_A = 35.0
    rim = ray_x(meshes["lid_screw_M4x20"], 5.0, -2.0, -25.0)
    rim_out = rim[-1] - rim[0]
    lip = ray_x(binA, 0.0, H_A - 0.02, -25.0)
    lip_open = lip[2] - lip[1]
    fit_check("lid rim passes bin lip opening", f"rim {rim_out:.3f} vs opening {lip_open:.3f} (gap {lip_open-rim_out:.3f} mm)",
              rim_out < lip_open - 0.05)
    bead = ray_x(meshes["lid_screw_M4x20"], 5.0, -4.3, -25.0)
    bead_out = bead[-1] - bead[0]
    groove = ray_x(binA, 0.0, H_A - 4.4, -25.0)
    groove_open = groove[2] - groove[1]
    fit_check("lid bead sits in bin snap groove", f"bead {bead_out:.3f} vs groove {groove_open:.3f} (gap {groove_open-bead_out:.3f} mm)",
              bead_out < groove_open - 0.05)
    wall = ray_x(binA, 0.0, H_A - 2.5, -25.0)
    wall_open = wall[2] - wall[1]
    fit_check("snap retention: bead wider than plain wall above groove",
              f"bead {bead_out:.3f} > wall {wall_open:.3f} (interference {bead_out-wall_open:.3f} mm)",
              bead_out > wall_open + 0.1)

    # ---- label window (in bin front wall) vs plate size
    wxs = ray_x(binA, -19.75, 18.5, -25.0)          # along x through wall mid-depth
    win_w = wxs[-2] - wxs[1]                        # window side walls = middle hits
    wzs = [z for z in ray_z(binA, 0.0, -19.75, 0.0) if 5.0 < z < 34.0]
    win_h = max(wzs) - min(wzs)
    plate = meshes["label_screw_M4x20"].bounding_box.extents
    fit_check("label plate fits window",
              f"plate {plate[0]:.2f} x {plate[2]:.2f} mm vs window {win_w:.2f} x {win_h:.2f} mm",
              plate[0] < win_w - 0.1 and plate[2] < win_h - 0.1)

    # ---- instance transforms + neighbour gap from assembly.json
    insts = {it["id"]: it for it in asm["instances"]}

    def placed(part_name, inst_id):
        M = np.array(insts[inst_id]["transform"], dtype=float)
        m = meshes[part_name].copy()
        m.apply_translation(M[:3, 3])
        return m

    ok_pos = True
    for it in asm["instances"]:
        if it["id"].startswith("bin_"):
            m = placed(it["part"], it["id"])
            i, j = it["cell"]
            cx, cy = (i + 0.5) * 42.0, (j + 0.5) * 42.0
            b = m.bounds
            c = ((b[0][0]+b[1][0])/2, (b[0][1]+b[1][1])/2, (b[0][2]+b[1][2])/2)
            if abs(c[0] - cx) > 1e-6 or abs(c[1] - cy) > 1e-6 or abs(b[0][2]) > 1e-6:
                ok_pos = False
    fit_check("all bins placed at their cell centres, z=0", "checked 20 instances", ok_pos)

    m1 = placed("bin_screw", "bin_screw_M4x20")
    m2 = placed("bin_screw", "bin_screw_M4x16")
    gap = m2.bounds[0][0] - m1.bounds[1][0]
    fit_check("adjacent bins gap (cells (0,3)/(1,3))", f"{gap:.3f} mm", abs(gap - 0.5) < 1e-6)
    l1 = placed("lid_screw_M4x20", "lid_screw_M4x20")
    l2 = placed("lid_screw_M4x16", "lid_screw_M4x16")
    lgap = l2.bounds[0][0] - l1.bounds[1][0]
    fit_check("adjacent lids gap", f"{lgap:.3f} mm", abs(lgap - 0.5) < 1e-6)
    # lid plate bottom rests on bin top: instance transform z == bin top z
    bz = m1.bounds[1][2]
    tz = float(insts["lid_screw_M4x20"]["transform"][2][3])
    fit_check("lid plate bottom rests on bin top", f"lid transform z {tz:.3f} == bin top {bz:.3f} (rim hangs to {tz - 4.9:.1f})",
              abs(tz - bz) < 1e-6)

    # ---- reports
    os.makedirs(CHECKS, exist_ok=True)
    md = ["# Mesh-level checks on exported files (trimesh; fits by ray measurement)", ""]
    md.append("Exact solid-boolean checks (OpenCASCADE) are in cad_report.md / checks.json.")
    md.append("")
    md.append("## Per-part files")
    md.append("")
    md.append("| part | binary STL | watertight | volume mm3 | triangles | bbox X,Y,Z mm | STEP ok | pass |")
    md.append("|---|---|---|---|---|---|---|---|")
    for r in rows:
        md.append(f"| {r[0]} | {'yes' if r[1] else 'NO'} | {'yes' if r[2] else 'NO'} | {r[3]} | {r[4]} | {r[5]} | {'yes' if r[6] else 'NO'} | {'PASS' if r[7] else 'FAIL'} |")
    md.append("")
    if repaired:
        md.append(f"STL repair pass (degenerate faces removed / vertices merged): {', '.join(repaired)}")
        md.append("")
    md.append("## Interface + assembly checks (ray-measured on exported meshes)")
    md.append("")
    md.append("| check | measured | pass |")
    md.append("|---|---|---|")
    for name, measured, ok in fit:
        md.append(f"| {name} | {measured} | {'PASS' if ok else 'FAIL'} |")
    md.append("")
    with open(os.path.join(CHECKS, "mesh_report.md"), "w") as f:
        f.write("\n".join(md))

    with open(os.path.join(CHECKS, "checks.json")) as f:
        data = json.load(f)
    data["mesh"] = {
        "overall_pass": all_ok,
        "stl_repaired": repaired,
        "parts": [
            {"part": r[0], "binary_stl": r[1], "watertight": r[2], "volume_mm3": r[3],
             "triangles": r[4], "bbox_mm": r[5], "step_ok": r[6], "pass": r[7]}
            for r in rows
        ],
        "fits": [{"name": n, "measured": str(m), "pass": bool(o)} for n, m, o in fit],
    }
    with open(os.path.join(CHECKS, "checks.json"), "w") as f:
        json.dump(data, f, indent=2, default=lambda o: bool(o) if isinstance(o, np.generic) else str(o))
    print("mesh checks overall_pass =", all_ok)
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
