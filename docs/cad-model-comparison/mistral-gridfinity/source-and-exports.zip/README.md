# Gridfinity fastener organizer — starter set (5 x 4 cells, M2 / M2.5 / M3 / M4)

A coherent Gridfinity organizer for socket-head screws, hex nuts and flat
washers: one standard 5x4 baseplate (210 x 168 x 5 mm, 42 mm pitch) plus 20
1x1 bins, each with its own snap lid and a permanent FillaPrint label plate.
Everything is parametric (build123d); STEP + binary STL per part are in
`exports/`, assembled placements in `assembly.json`, measured checks in
`checks/`.

## What belongs where (starter assortment)

Cells are `(x, y)` with `y = 0` the front row (labels face `-Y`).

| cell | contents | cell | contents |
|---|---|---|---|
| (0,3) | M4 SHCS x20 | (0,2) | M3 SHCS x12 |
| (1,3) | M4 SHCS x16 | (1,2) | M3 SHCS x10 |
| (2,3) | M4 SHCS x12 | (2,2) | M2.5 SHCS x12 |
| (3,3) | M3 SHCS x20 | (3,2) | M2.5 SHCS x10 |
| (4,3) | M3 SHCS x16 | (4,2) | M2.5 SHCS x8 |
| (0,1) | M2 SHCS x8 | (2,1) | M2 nuts |
| (1,1) | M2 SHCS x6 | (3,1) | M2.5 nuts |
| (0,0) | M4 nuts | (4,1) | M3 nuts |
| (1,0) | M2 washers | (2,0) | M2.5 washers |
| (3,0) | M3 washers | (4,0) | M4 washers |

Rationale: M3 gets the full length range (workhorse), M4/M2.5/M2 get the
most useful subset; every size has matching nuts and washers. Each
compartment holds ~20 screws or ~30 nuts/washers (measured in
`checks/cad_report.md`: worst case M4x20 needs 3 loose layers = 21 mm of the
27 mm depth; 30 M4 nuts need 2 layers = 6.4 mm of 24 mm). Any other size or
length is one extra Type A bin + lid + label (see "Extending").

## Bin types (few, reusable)

- **Type A `bin_screw`** — 1x1, outer 41.5 x 41.5 x **35 mm**, one open
  compartment 37.5 x 37.5 x **27 mm** deep, 2 mm walls, floor scoop fillet
  1.5 mm. Standard Gridfinity refined bottom (41.5 -> 35.6 frustum) and top
  stacking lip.
- **Type B `bin_hw`** — same footprint, outer **32 mm**, compartment
  37.5 x 37.5 x **24 mm** (nuts/washers).
- **`lid_<tag>`** — insert-style snap cap per bin (plate 41.5, rim goes inside
  the lid opening, snap bead engages a groove in the bin wall, 4 flex slots,
  finger scoop; size engraved 0.6 mm into the top face).
- **`label_<tag>`** — FillaPrint plate 36.8 x 21.8 x 2 mm, glued into a
  37 x 22 mm through-window in the front wall, front face flush with the bin.
- **`base_5x4`** — standard Gridfinity baseplate profile (5 mm thick, pockets
  = bin profile + 0.25 mm/side, outer corner r4).

Interfaces (all verified by exact booleans, see `checks/`): bins seat on any
ordinary 42 mm Gridfinity base (0.25 mm seat drop, line contact at z = 0.8 of
the pocket, >= 0.25 mm clearance elsewhere); adjacent bins/lids keep the
standard 0.5 mm gap, so lifting one bin never disturbs its neighbours; bins
stack on bins nesting 0.35 mm into the stacking lip (mixed types too); lids
snap on with 0 mm interference at rest; label plates have 0.1 mm clearance.

## Reading and handling

- **Read without lifting:** every front face carries a two-line label —
  `M3 x 12` / `SCREW`, `M3` / `NUT`, `M3` / `WASHER` — so size, length and
  nut-vs-washer are unambiguous from across the bench. The lid top carries the
  same text (useful when bins are stacked).
- **One tiny part with fingers:** single open compartment, 37.5 x 37.5 mm
  opening, 24-27 mm deep, scooped floor — pinch a washer or short screw
  directly; nothing hides in small holes.
- **Take a bin to a project:** snap the lid on (bead in groove) and lift the
  bin by its walls; contents cannot spill, and neighbours are untouched
  (independent cells, 0.5 mm gaps). Without the lid, the 35 mm tall walls
  still keep contents in when carried upright.

## Labels / FillaPrint

Font: `assets/fillaprint/Fillaprint-Regular.ttf` (OFL, license beside it).
The face is a two-bead FDM font: at reference size em = 20w, cap height 14w,
strokes/gaps >= 2w. For a 0.4 mm nozzle at line width w = 0.42 mm the font
minimum is **em 8.4 mm (cap 5.88 mm)**; the labels use **em 10 mm (cap
7.0 mm, stroke 1.0 mm)** — above the minimum, widest line 33.75 mm of the
36.4 mm available. Text is engraved **0.6 mm (3 layers at 0.2 mm)** into the
print face.

- Print each `label_*.stl` **front face down** — the engraved glyphs are then
  layer 1; run your FillaPrint colour swap on the first 3 layers (accent
  colour fills the glyphs). Glue the plate into the bin's front window with
  cyanoacrylate (permanent; the window's 0.1 mm clearance locates it).
- Print each `lid_*.stl` **flipped, top face down** so the engraved size on
  the lid top is layer 1 for the same colour swap.
- Bins print upright (frustum down), baseplate flat — no supports anywhere
  (all overhangs are <= 45 deg or tiny). PETG recommended (lid snap flex);
  0.2 mm layers, 2 walls+ are already in the model.

## Extending to another size later

All parts are parametric in `src/parts.py` (`STARTER`, `HW`, `make_bin`,
`make_lid`, `make_label`, `make_base(gx, gy)`). To add e.g. M5x25:

```python
from src import parts
bin_part   = parts.make_bin("A")                       # any length fits Type A
lid_part   = parts.make_lid("A", ["M5 x 25", "SCREW"])
label_part = parts.make_label(["M5 x 25", "SCREW"])
# add ("M5", 25) etc. to parts.HW, append (i, j, "screw", "M5", 25) to STARTER
```

and print another `base_5x4` (or any `make_base(gx, gy)`) — baseplates tile
edge to edge at the 42 mm pitch, so extra bins simply drop into the new
plate's cells. Regenerate everything with:

```
python -m src.build_all     # parts, exports, assembly.json, CAD checks
python -m src.check_meshes      # mesh/export checks
```

## Files

- `src/gf.py` — Gridfinity refined profile constants + baseplate/bin-bottom builders
- `src/parts.py` — parametric bins, lids, label plates, starter spec, transforms
- `src/textlabel.py` — font metrics (Fillaprint minimum, widths)
- `src/build_all.py` — build + export + `assembly.json` + CAD boolean checks
- `src/check_meshes.py` — export/mesh checks (physics runtime)
- `exports/*.step`, `exports/*.stl` — one STEP + one binary STL per part (43 parts)
- `assembly.json` — part files + 61 assembled instances, row-major 4x4 mm
  transforms (global = M @ local); base at origin, bins at cell centres
  `(21+42i, 21+42j, 0)`, lids at bin top, labels in the front windows
- `checks/cad_report.md`, `checks/mesh_report.md`, `checks/checks.json` — measured checks

## Measured checks (summary — full tables in `checks/`)

Seating (OCP booleans): all 20 bins overlap the baseplate by 0.000000 mm3 at
z = 0 and 17.8 mm3 when pushed 0.05 mm down (seat confirmed). Adjacent bins
and lids: 0.000000 mm3 (0.5 mm gap). Stacking: 0.000000 mm3 at nest 0.35 mm,
0.81 mm3 when pushed 0.15 mm lower. Lids on bins: worst 0.000000 mm3.
Labels in windows: worst 0.000000 mm3. All 43 STLs are binary, watertight,
positive volume; STEP files re-import with matching volumes. Ray-measured on
the exported meshes: frustum inside pocket for all z in [0,5] with line
contact at z = 0.8 and >= 0.25 mm clearance elsewhere; lid rim 36.10 vs lip
opening 36.34; bead 37.90 in groove 38.10; bead 0.40 mm wider than the wall
above the groove (snap retention); label plate 36.8 x 21.8 in window 37 x 22.
Capacity table (20 screws / 30 nuts / 30 washers per compartment): all PASS.

## Limitations / still needs a physical fit test

- The lid snap bead needs ~0.8 mm flex to pass the lip and retains with
  0.2 mm interference — **not yet tested in real filament**. If too tight or
  loose in PETG/PLA, adjust `LID_BEAD_OUT` / `GROOVE_DEPTH` in `src/parts.py`
  and re-export.
- Label plates are **glued** (CA) into the window; the 0.1 mm clearance is a
  locator, not a press fit.
- Gridfinity compatibility was verified against the published refined
  profile by exact booleans and ray measurements, **not against a physical
  third-party baseplate** — drop one bin on your own base as a fit test.
- Capacity figures are analytic loose-packing estimates (55% packing,
  axis-aligned layers), not a physical fill test.
- Hardware sizes are nominal ISO 4762 / 4032 / 7089 values; real parts vary.
  M2 washers exist in 4.5-5.0 mm OD series — compartments are sized for 5.0.
- Baseplate is plain (no magnet/screw holes) — easy to add later.
- Labels use `x` for the multiplication sign (font has no `x`-glyph issue but
  `x` is unambiguous in this font) and uppercase only.
- `assembly.json` shows the stored state (lids on); working state = lids off.

## References used for interfaces and dimensions

- Gridfinity refined profile (42 mm pitch, bin bottom 41.5->35.6 frustum,
  baseplate 5 mm, 0.25 mm seat): gridfinity.xyz specification as implemented
  in kennetek/gridfinity-rebuilt-openscad (`src/core/standard.scad`,
  `gridfinity-baseplate.scad`).
- FillaPrint font minimum (em = 20w, cap = 14w, strokes/gaps >= 2w; at
  w = 0.42 mm: em 8.4 mm, cap 5.88 mm): font name table of the supplied
  `Fillaprint-Regular.ttf` and the double-bead/Fillaprint font README.
- Hardware: ISO 4762 / DIN 912 SHCS head dia/height, ISO 4032 / DIN 934 hex
  nut across-flats/height, ISO 7089 / DIN 125A washer OD/thickness (M2-M4).

