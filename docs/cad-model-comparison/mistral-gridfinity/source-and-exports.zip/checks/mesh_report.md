# Mesh-level checks on exported files (trimesh; fits by ray measurement)

Exact solid-boolean checks (OpenCASCADE) are in cad_report.md / checks.json.

## Per-part files

| part | binary STL | watertight | volume mm3 | triangles | bbox X,Y,Z mm | STEP ok | pass |
|---|---|---|---|---|---|---|---|
| base_5x4 | yes | yes | 139475.64 | 11466 | [210.0, 168.0, 5.0] | yes | PASS |
| bin_hw | yes | yes | 18090.46 | 10098 | [41.5, 41.5, 32.0] | yes | PASS |
| bin_screw | yes | yes | 19084.34 | 10118 | [41.5, 41.5, 35.0] | yes | PASS |
| label_nut_M2 | yes | yes | 1557.08 | 1832 | [36.8, 2.0, 21.8] | yes | PASS |
| label_nut_M2p5 | yes | yes | 1547.68 | 2416 | [36.8, 2.0, 21.8] | yes | PASS |
| label_nut_M3 | yes | yes | 1557.35 | 1812 | [36.8, 2.0, 21.8] | yes | PASS |
| label_nut_M4 | yes | yes | 1557.98 | 1668 | [36.8, 2.0, 21.8] | yes | PASS |
| label_screw_M2p5x10 | yes | yes | 1509.1 | 4864 | [36.8, 2.0, 21.8] | yes | PASS |
| label_screw_M2p5x12 | yes | yes | 1510.56 | 5040 | [36.8, 2.0, 21.8] | yes | PASS |
| label_screw_M2p5x8 | yes | yes | 1514.12 | 4540 | [36.8, 2.0, 21.8] | yes | PASS |
| label_screw_M2x6 | yes | yes | 1524.79 | 4096 | [36.8, 2.0, 21.8] | yes | PASS |
| label_screw_M2x8 | yes | yes | 1523.52 | 3956 | [36.8, 2.0, 21.8] | yes | PASS |
| label_screw_M3x10 | yes | yes | 1518.78 | 4260 | [36.8, 2.0, 21.8] | yes | PASS |
| label_screw_M3x12 | yes | yes | 1520.24 | 4436 | [36.8, 2.0, 21.8] | yes | PASS |
| label_screw_M3x16 | yes | yes | 1519.14 | 4416 | [36.8, 2.0, 21.8] | yes | PASS |
| label_screw_M3x20 | yes | yes | 1516.48 | 4376 | [36.8, 2.0, 21.8] | yes | PASS |
| label_screw_M4x12 | yes | yes | 1520.86 | 4292 | [36.8, 2.0, 21.8] | yes | PASS |
| label_screw_M4x16 | yes | yes | 1519.77 | 4272 | [36.8, 2.0, 21.8] | yes | PASS |
| label_screw_M4x20 | yes | yes | 1517.1 | 4232 | [36.8, 2.0, 21.8] | yes | PASS |
| label_washer_M2 | yes | yes | 1528.13 | 3408 | [36.8, 2.0, 21.8] | yes | PASS |
| label_washer_M2p5 | yes | yes | 1518.73 | 3992 | [36.8, 2.0, 21.8] | yes | PASS |
| label_washer_M3 | yes | yes | 1528.41 | 3388 | [36.8, 2.0, 21.8] | yes | PASS |
| label_washer_M4 | yes | yes | 1529.04 | 3244 | [36.8, 2.0, 21.8] | yes | PASS |
| lid_nut_M2 | yes | yes | 4221.35 | 4904 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_nut_M2p5 | yes | yes | 4211.95 | 5488 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_nut_M3 | yes | yes | 4221.63 | 4884 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_nut_M4 | yes | yes | 4222.25 | 4740 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_screw_M2p5x10 | yes | yes | 4173.37 | 7936 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_screw_M2p5x12 | yes | yes | 4174.83 | 8112 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_screw_M2p5x8 | yes | yes | 4178.39 | 7612 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_screw_M2x6 | yes | yes | 4189.06 | 7168 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_screw_M2x8 | yes | yes | 4187.8 | 7028 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_screw_M3x10 | yes | yes | 4183.05 | 7332 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_screw_M3x12 | yes | yes | 4184.51 | 7508 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_screw_M3x16 | yes | yes | 4183.42 | 7488 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_screw_M3x20 | yes | yes | 4180.75 | 7448 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_screw_M4x12 | yes | yes | 4185.14 | 7364 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_screw_M4x16 | yes | yes | 4184.04 | 7344 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_screw_M4x20 | yes | yes | 4181.38 | 7304 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_washer_M2 | yes | yes | 4192.41 | 6480 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_washer_M2p5 | yes | yes | 4183.01 | 7064 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_washer_M3 | yes | yes | 4192.69 | 6460 | [41.5, 41.5, 6.9] | yes | PASS |
| lid_washer_M4 | yes | yes | 4193.31 | 6316 | [41.5, 41.5, 6.9] | yes | PASS |

## Interface + assembly checks (ray-measured on exported meshes)

| check | measured | pass |
|---|---|---|
| bin frustum inside baseplate pocket for all z in [0,5] | min radial gap -0.000 mm (contact = line at z=0.8), clearance elsewhere >= 0.25 mm | PASS |
| lid rim passes bin lip opening | rim 36.100 vs opening 36.340 (gap 0.240 mm) | PASS |
| lid bead sits in bin snap groove | bead 37.900 vs groove 38.100 (gap 0.200 mm) | PASS |
| snap retention: bead wider than plain wall above groove | bead 37.900 > wall 37.500 (interference 0.400 mm) | PASS |
| label plate fits window | plate 36.80 x 21.80 mm vs window 37.00 x 22.00 mm | PASS |
| all bins placed at their cell centres, z=0 | checked 20 instances | PASS |
| adjacent bins gap (cells (0,3)/(1,3)) | 0.500 mm | PASS |
| adjacent lids gap | 0.500 mm | PASS |
| lid plate bottom rests on bin top | lid transform z 35.000 == bin top 35.000 (rim hangs to 30.1) | PASS |
