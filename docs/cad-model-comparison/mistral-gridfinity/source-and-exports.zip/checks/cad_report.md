# CAD-level measured checks (build123d / OpenCASCADE booleans)

| check | measured | pass |
|---|---|---|
| bin A seats on baseplate at cell (0,0) | overlap z=0: 0.000000 mm3, z=+0.1: 0.000000, z=-0.05: 17.8457 mm3 seat plane z=0 confirmed (contact below, free above) | PASS |
| bin B seats on baseplate at cell (0,0) | overlap z=0: 0.000000 mm3, z=+0.1: 0.000000, z=-0.05: 17.7994 mm3 seat plane z=0 confirmed (contact below, free above) | PASS |
| all 20 starter bins seat on baseplate (z=0) | worst overlap 0.000000 mm3  | PASS |
| adjacent bins do not touch | 0.000000 mm3 gap = 42 - 41.5 = 0.5 mm | PASS |
| adjacent lids do not touch | 0.000000 mm3 gap = 0.5 mm | PASS |
| bin footprint within 42 mm cell | 41.5000 x 41.5000 mm limit 41.5 | PASS |
| bin stacks on bin (nest 0.35 mm) | overlap at z=H-0.35: 0.000000, H-0.25: 0.000000, H-0.5: 0.8083 mm3  | PASS |
| mixed stack (type B on type A) | 0.000000 mm3  | PASS |
| all 20 lids seat on their bins (snap engaged, 0 interference at rest) | worst overlap 0.000000 mm3  | PASS |
| all 20 label plates fit their windows (0.1 mm clearance) | worst overlap 0.000000 mm3  | PASS |
| label font size >= FillaPrint minimum | em size 10.0 mm >= min 8.4 mm (w=0.42); cap height 7.0 mm >= 5.88 mm; stroke 1.00 mm = 2w at w=0.50  | PASS |
| label engraving depth | 0.6 mm = 3 layers at 0.2 mm  | PASS |
| all label lines fit the plate | widest line 33.75 mm <= 36.4 mm  | PASS |
| compartment capacity (20 screws / 30 nuts / 30 washers) | see report  | PASS |
| finger access | opening 37.5 x 37.5 mm, depths 27.0/24.0 mm one washer/short screw pinchable | PASS |
| baseplate size | 210.0 x 168.0 x 5.0 mm  | PASS |

## Compartment capacity (analytic loose packing, 37.5 x 37.5 mm opening)

| cell | contents | items | item bbox (mm) | per layer | layers | stack h (mm) | depth (mm) | loose vol (mm3) | fits |
|---|---|---|---|---|---|---|---|---|---|
| (0, 3) | SHCS M4x20 | 20 | [7.0, 20.0, 7.0] | 7 | 3 | 21.0 | 27.0 | 35636.4 (comp 37968.8) | PASS |
| (1, 3) | SHCS M4x16 | 20 | [7.0, 16.0, 7.0] | 10 | 2 | 14.0 | 27.0 | 28509.1 (comp 37968.8) | PASS |
| (2, 3) | SHCS M4x12 | 20 | [7.0, 12.0, 7.0] | 15 | 2 | 14.0 | 27.0 | 21381.8 (comp 37968.8) | PASS |
| (3, 3) | SHCS M3x20 | 20 | [5.5, 20.0, 5.5] | 9 | 3 | 16.5 | 27.0 | 22000.0 (comp 37968.8) | PASS |
| (4, 3) | SHCS M3x16 | 20 | [5.5, 16.0, 5.5] | 14 | 2 | 11.0 | 27.0 | 17600.0 (comp 37968.8) | PASS |
| (0, 2) | SHCS M3x12 | 20 | [5.5, 12.0, 5.5] | 18 | 2 | 11.0 | 27.0 | 13200.0 (comp 37968.8) | PASS |
| (1, 2) | SHCS M3x10 | 20 | [5.5, 10.0, 5.5] | 21 | 1 | 5.5 | 27.0 | 11000.0 (comp 37968.8) | PASS |
| (2, 2) | SHCS M2.5x12 | 20 | [4.5, 12.0, 4.5] | 24 | 1 | 4.5 | 27.0 | 8836.4 (comp 37968.8) | PASS |
| (3, 2) | SHCS M2.5x10 | 20 | [4.5, 10.0, 4.5] | 27 | 1 | 4.5 | 27.0 | 7363.6 (comp 37968.8) | PASS |
| (4, 2) | SHCS M2.5x8 | 20 | [4.5, 8.0, 4.5] | 36 | 1 | 4.5 | 27.0 | 5890.9 (comp 37968.8) | PASS |
| (0, 1) | SHCS M2x8 | 20 | [3.8, 8.0, 3.8] | 40 | 1 | 3.8 | 27.0 | 4200.7 (comp 37968.8) | PASS |
| (1, 1) | SHCS M2x6 | 20 | [3.8, 6.0, 3.8] | 54 | 1 | 3.8 | 27.0 | 3150.5 (comp 37968.8) | PASS |
| (2, 1) | nut M2 | 30 | [4.62, 4.62, 1.6] | 64 | 1 | 1.6 | 24.0 | 1861.8 (comp 33750.0) | PASS |
| (3, 1) | nut M2.5 | 30 | [5.77, 5.77, 2.0] | 36 | 1 | 2.0 | 24.0 | 3636.4 (comp 33750.0) | PASS |
| (4, 1) | nut M3 | 30 | [6.35, 6.35, 2.4] | 25 | 2 | 4.8 | 24.0 | 5280.0 (comp 33750.0) | PASS |
| (0, 0) | nut M4 | 30 | [8.08, 8.08, 3.2] | 16 | 2 | 6.4 | 24.0 | 11403.6 (comp 33750.0) | PASS |
| (1, 0) | washer M2 | 30 | [5.0, 5.0, 0.3] | 49 | 1 | 0.3 | 24.0 | 409.1 (comp 33750.0) | PASS |
| (2, 0) | washer M2.5 | 30 | [6.0, 6.0, 0.5] | 36 | 1 | 0.5 | 24.0 | 981.8 (comp 33750.0) | PASS |
| (3, 0) | washer M3 | 30 | [7.0, 7.0, 0.5] | 25 | 2 | 1.0 | 24.0 | 1336.4 (comp 33750.0) | PASS |
| (4, 0) | washer M4 | 30 | [9.0, 9.0, 0.8] | 16 | 2 | 1.6 | 24.0 | 3534.5 (comp 33750.0) | PASS |
