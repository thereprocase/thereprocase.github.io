# Gridfinity fastener organizer — M2 / M2.5 / M3 / M4

A parametric Gridfinity system for socket-head screws, hex nuts and flat
washers, built on the standard 42 mm grid. One 5×4 baseplate (210 × 168 mm
of grid) holds a 23-compartment starter assortment in 15 bins, with one
empty cell reserved for the next size you add. Bins read from the front
without lifting, shallow scoop-floor compartments release single small
washers, and every bin lifts out alone without disturbing its neighbors.

Everything here is generated from the parametric source in `src/` — no
stock models. Parts are in `parts/step/` (STEP) and `parts/stl/` (binary
STL). `assembly.json` lists every part file and its assembled transform in
millimetres. `measured_checks.json` contains the full verification record.

---

## What belongs where

Front row (2U = 14 mm body), all bins face −Y with labels on the front:

| cells | part | holds |
|---|---|---|
| 0–1 | `bin_washer_m2_m25_m3` (2×1, 3 compartments) | M2, M2.5, M3 flat washers |
| 2 | `bin_washer_m4` (1×1) | M4 flat washers |
| 3–4 | `bin_nut_m2_m25_m3` (2×1, 3 compartments) | M2, M2.5, M3 hex nuts |

Second row (3U = 21 mm):

| cells | part | holds |
|---|---|---|
| 0 | `bin_nut_m4` (1×1) | M4 hex nuts |
| 1–2 | `bin_m2_screws` (2×1, 3 compartments) | M2×6, M2×8, M2×12 |
| 3–4 | `bin_m2_5_screws` (2×1, 3 compartments) | M2.5×6, M2.5×8, M2.5×12 |

Back rows (4U = 28 mm), one compartment per length:

| cells | parts | lengths |
|---|---|---|
| row 2, cells 0–4 | `bin_m3x6` … `bin_m3x16` | M3 × 6, 8, 10, 12, 16 |
| row 3, cells 0–3 | `bin_m3x20`, `bin_m4x8`, `bin_m4x12`, `bin_m4x20` | M3×20, M4×8/12/20 |
| row 3, cell 4 | *(empty — the extension slot)* | e.g. M3.5, M5, or M4×16 |

Why these choices: M3 is the workhorse size so it gets the full length run
in single bins (est. 49–114 screws per compartment). M4 gets the structural
lengths 8/12/20; M4×16 is the first candidate for the spare cell. M2 and
M2.5 screws are small and lightly used, so they share divided bins (est.
44–113 per compartment). Washers sit in the widest compartments (hardest
part to pick up; est. 82–511 per compartment) and nuts share theirs (est.
43–121). Every compartment exceeds the brief of 20 screws / 30
nuts-or-washers; the full per-compartment estimates are in
`measured_checks.json` (`capacity_estimates`).

Two bin families only, both with the same scoop cavity:

* **1×1 scoop bin** — single compartment, 2U/3U/4U heights, front label.
* **2×1 divided scoop bin** — 3 compartments (1.2 mm dividers, matching
  the community standard divider thickness), 2U/3U heights, one label
  per compartment.
* **baseplate_5x4** — spec cavities, 12 mm border, four M4 (4.5 mm
  clearance) countersunk mounting holes from below.

### How the bins handle small parts

* **Read the size without lifting.** Labels are engraved at the same
  height on every bin (baseline 5.95 mm above the bin bottom), and the
  rows step up 2U → 3U → 4U toward the back, so every label is visible
  from the front.
* **One tiny washer out with fingers.** Compartments are 19–39 mm wide
  and 9–23 mm deep at the front. The floor slopes 6° toward the front
  so disturbance (opening the drawer, nudging) migrates parts into the
  front scoop, and the 8 mm front floor fillet is a spoon: press a
  washer against it with a fingertip and roll it up — it presents at a
  pinchable angle instead of lying flat. Washers get the widest
  compartments and the shallowest bins for exactly this reason.
* **Lift one bin without spilling its neighbors.** Bins are independent
  (no shared walls), 0.25 mm clearance per side in the grid, and every
  compartment keeps ≥ 2 mm freeboard at the target fill. The measured
  bin-to-bin gap is exactly 0.5 mm.
* **Stacking.** Every bin carries the standard stacking lip, so any bin
  stacks on any *same-footprint* bin (1×1 on 1×1, 2×1 on 2×1), full or
  empty, seated on the spec 45° cone with zero measured interference.
  Stacking is for overflow and for bins you use rarely; a stacked bin
  hides the label of the bin below. Dividers end 1 mm below the seat
  plane; divided-bin stacking measures zero interference (the 0.65 mm
  gap to a stacked base block follows from the geometry).

---

## Gridfinity interface (what makes these fit "ordinary" bases)

Constants follow the Gridfinity specification as maintained in the
reference open-source reconstruction (gridfinity.xyz; the
gridfinity-rebuilt-openscad project's `standard.scad`). All values in mm:

| quantity | value |
|---|---|
| grid pitch | 42 |
| bin footprint | 42·u − 0.5 (41.5 for 1×1; 0.25 per side clearance) |
| base block | 35.6 bottom face, 0.8/45° chamfer, 37.2 vertical, 2.15/45° flare to full footprint at z = 4.75; corner radius 3.75 |
| baseplate cavity | 36.3 floor (r1.15), 0.7/45° to 37.7 (r1.85), vertical to 2.85, 2.15/45° flare to the full 42 pitch at depth 5.0 (knife-edge ribs) |
| stacking lip | funnel from the outer face: 2.6 deep at the nominal top, 0.7/45° lead-in, 1.8 vertical, 1.9/45° flare to flush at +4.4; tip filleted 0.6 (top at +3.55) |
| height unit | 7 per U of body; the lip adds 3.55 |

Measured seat behaviour (see `measured_checks.json`): a bin rests on its
bottom face (0.35 per side floor clearance) with its flare on the plate's
flare cone (0.25 per side on the verticals) — zero interference volume,
contact at the intended surfaces. Multi-cell bins follow the spec's
per-unit base blocks with a bridge slab from 4.75 to 7 mm; between
z = 4.75 and 5.05 the bin's underside steps back to the per-cell
outlines, which clears the plate ribs *and* the small corner notches
where ribs meet cavity walls (these rise 0.25 mm past the bridge plane;
stock multi-cell bins nominally pinch on them, these do not).

Compatibility in both directions: the bins' base blocks and the plate's
cavities are exact spec, so the bins fit any ordinary 42 mm baseplate and
the plate accepts ordinary bins.

## Labels

* Font: **Fillaprint Regular** (`assets/fillaprint/`, SIL OFL 1.1 — kept
  with its license). It is a two-bead FDM typeface: at its reference size
  every stroke and gap equals two extrusion line widths.
* Sizing: **em 8.4 mm → cap height 5.88 mm = 14 × 0.42 mm line width**,
  which is exactly the font's documented minimum (reference) size for a
  0.42 mm line width — the default for 0.4 mm nozzles in PrusaSlicer and
  OrcaSlicer. Measured cap height 5.88 mm, stroke 0.84 mm. Print the text
  with ≤ 0.42 mm line width; with 0.5 mm lines the text would fall below
  the font's minimum.
* Engraved, not raised: bin side faces have only 0.25 mm to their
  neighbors, so anything proud of the wall would collide. Grooves are
  0.7 mm deep into the 1.6 mm wall (0.9 mm remains). The pictograms use
  the same 0.84 mm two-bead stroke width.
* Content: screws get `M3 × 12` (spaced where it fits, compact `M2.5×12`
  where compartments are narrow — auto-chosen per bin); nuts get
  `M2 ⬡` (hexagon + bore); washers get `M2 ◯◯` (OD + ID circles). Length
  is always explicit on screw bins; nut vs washer is distinguishable at
  a glance by shape, not just by word.

## Printing

* Bins: opening up, no supports. Walls print vertical; all base and lip
  chamfers are 45°. The only horizontal "ceilings" are engraved-glyph
  stroke undersides (0.84 mm wide, inside 0.7 mm deep grooves — standard
  engraved-text behaviour) and, on the 2×1 bins, the 0.5 mm wide
  rib-clearance pockets in the underside (0.3 mm tall; single-bead
  bridges).
* Baseplate: flat side down, no supports. Cavities flare upward. Mount
  holes: M4 socket/countersunk screws from below (4.5 mm clearance hole,
  8.6 mm countersink).
* 0.2 mm layers, ≤ 0.42 mm line width for the text, 3–4 perimeters.
  PLA/PETG both fine.
* Fit: parts are at full spec size (41.5 mm footprint). If your printer
  runs fat and a bin is tight in its cell, print that bin at 99.5 % — or
  better, tune horizontal expansion once.

## Assembly

`assembly.json` holds the complete layout. World frame: the plate's front
left corner is the origin, +X across the width, +Y toward the back, bins'
fronts face −Y. The plate sits at z = 0; every bin's translation places its
own origin (bin center, bottom face) at its cell center, z = 3.2 mm (bins
rest on the cavity floor, verified). Rotations are all identity.

## Extending the system

All geometry is parametric. To add a size (say M5 washers, or M4×16):

1. Add a row to `PARTS` in `src/build_all.py`, e.g.
   `("bin_washer_m5", 1, 1, 2, 0, [("M5", "washer")], 4, 3)` — that fills
   the spare cell. Or move things freely: cells are just (x, y).
2. `python src/build_all.py` regenerates STEP + STL for every part and
   rewrites `assembly.json`.
3. `python src/cad_checks.py` then `python src/mesh_checks.py` re-verify.

Bin geometry itself (`src/gf_core.py`): `make_bin(cells_w, cells_d,
units_h, dividers, labels)`; the plate: `make_baseplate(cells_x, cells_y,
border, slab)`. Fastener reference sizes used by the capacity checks live
in `FASTENERS` in `src/cad_checks.py`.

## Verification record

`measured_checks.json` (written by the two check scripts) contains:

* **geometry** — all 16 parts valid single solids with nominal bounding
  boxes (41.5/83.5 footprints, heights 7U + 3.5515).
* **assembly interference** — every near pair in the assembled layout:
  max overlap 0.000000 mm³.
* **interface distances** — bin↔plate contact 0.0 mm with zero overlap;
  adjacent bins exactly 0.5000 mm apart; stacked bins contact 0.0 mm with
  zero overlap (seat drop 0.35 mm).
* **labels** — cap 5.88 mm ≥ font minimum 5.88 mm; stroke 0.84 mm.
* **capacity** — all 23 compartments meet the 20-screw / 30-nut-or-washer
  targets (analytic model: usable volume below a 2 mm freeboard fill line,
  loose-pile packing fractions 0.50–0.55 applied to true part volumes;
  see the file for per-compartment numbers).
* **mesh** — every STL is binary, watertight, consistently wound, the
  right size; label grooves measured at 0.70 mm deep by ray casting; the
  plate's cavity floor measures 3.200 mm; mount holes are through.

Assumptions that need a physical fit test are listed below.

## What still needs a physical fit test

No printing or measuring of physical parts was possible here. Before
relying on the system, check:

1. **Cell fit on your printer** — the 0.25 mm per-side clearances are spec,
   but extrusion width variance matters. Drop each bin into your printed
   plate and into any commercial plate you own; it should insert and lift
   with light friction, not force.
2. **Stacking feel** — stack a full 2×1 on a full 2×1 and confirm it
   seats without rocking and separates without prying.
3. **Washer pinch** — put three M2 washers in the front scoop and pick
   them one at a time. The fillet geometry is verified, but fingertip
   feel is the real test; if the valley feels too tight, the scoop radius
   is one parameter (`SCOOP_R`).
4. **Label legibility** — 5.88 mm caps in your filament colour and your
   bench lighting, printed at your actual line width. Dark filament with
   a light top layer (or a swipe of paint) reads best.
5. **Capacity model** — the packing fractions are stated assumptions.
   Pour real screws (they interleave better than the model assumes, so
   the estimates are conservative) and confirm the fill line.
6. **Rib-clearance pockets** (2×1 bins) — confirm the 0.5 mm bridge
   ceilings on the underside print cleanly on your machine.

## Known limitations (stated honestly)

* Fastener reference dimensions (ISO 4762 heads, ISO 4032 nuts, ISO
  7089/DIN 125A washers) are nominal; verify against your actual stock.
  Capacity estimates use them analytically.
* The stacking lip uses the spec profile with the community-standard 0.6
  tip fillet; the lip's support cone's corner radius (1.95 → 1.15 at the
  mouth) differs slightly from the cavity's ergonomic 6 mm corners,
  leaving a small cosmetic step in the bin's upper inner corners. It is
  invisible in use and keeps the stacking seat exact.
* Multi-cell bins stack only on same-footprint bins (standard Gridfinity
  behaviour), not on any arbitrary bin.
* The plate has knife-edge ribs per the spec, like ordinary plates; they
  are printable but will wear like any gridfinity plate's do.
* The 6° floor slope gathers parts toward the front when disturbed; it
  does not auto-feed (PLA-on-PLA static friction exceeds tan 6°). It is a
  tidying aid, not a gravity feeder.

## Files

```
assembly.json            parts + assembled transforms (mm)
measured_checks.json     full verification record
parts/step/*.step        16 STEP files (mm)
parts/stl/*.stl          16 binary STL files
src/gf_core.py           interface constants + bin/plate geometry
src/gf_labels.py         Fillaprint text + nut/washer pictograms
src/build_all.py         assortment definition, exports, assembly.json
src/cad_checks.py        CAD-level verification (build123d runtime)
src/mesh_checks.py       mesh verification (trimesh/numpy runtime)
assets/fillaprint/       Fillaprint-Regular.ttf + OFL.txt (SIL OFL 1.1)
```

Reproduce with the CAD runtime:
`FONTCONFIG_FILE=<minimal conf> python
src/build_all.py`, then the two check scripts (mesh checks use
`python`).
