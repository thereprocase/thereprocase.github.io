"""CAD-level verification: interfaces, interference, labels, capacity.

Run with the CAD runtime (build123d).  Writes measured_checks.json.

Checks:
  1. every part is a valid single solid with the nominal bounding box
  2. pairwise interference of the assembled layout is zero (all 16 parts,
     bbox-prefiltered), i.e. nothing collides and nothing interpenetrates
  3. measured interface distances:
       - bin seated in baseplate cavity  -> contact (0) with zero overlap
       - two adjacent bins in the grid   -> exactly 0.5 mm gap
       - one bin stacked on another      -> contact (0) with zero overlap
  4. label metrics: Fillaprint cap height and stroke width measured from
     the real text geometry vs the font's minimum (14 x line width)
  5. analytic compartment capacity vs the 20 screws / 30 nuts & washers
     targets, with stated packing assumptions
"""

from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

from build123d import BuildSketch, Location, Plane, Pos, Text, TextAlign, Box
from OCP.BRepExtrema import BRepExtrema_DistShapeShape

sys.path.insert(0, str(Path(__file__).parent))
import gf_core as core
import gf_labels as lab
from build_all import (BORDER, CELLS_X, CELLS_Y, PARTS, SLAB, build_bin,
                       compact, fit_labels)

ROOT = Path(__file__).resolve().parent.parent
FONT = lab.FONT

# fastener envelopes (mm): ISO 4762 socket head screws (head dia x head height),
# ISO 4032 hex nuts (across flats x thickness), ISO 7089 / DIN 125A washers
# (OD x thickness).  Nominal values; verify against your actual stock.
FASTENERS = {
    "M2":    {"shank_d": 2.0, "screw_head": (3.8, 2.0),  "nut": (4.0, 1.6),  "washer": (4.5, 0.3)},
    "M2.5":  {"shank_d": 2.5, "screw_head": (4.5, 2.5),  "nut": (5.0, 2.0),  "washer": (5.0, 0.5)},
    "M3":    {"shank_d": 3.0, "screw_head": (5.5, 3.0),  "nut": (5.5, 2.4),  "washer": (7.0, 0.5)},
    "M4":    {"shank_d": 4.0, "screw_head": (7.0, 4.0),  "nut": (7.0, 3.2),  "washer": (9.0, 0.8)},
}
# loose-pile packing fractions applied to true part volume (assumptions,
# deliberately conservative; see README fit-test notes)
PACKING = {"screw": 0.50, "nut": 0.55, "washer": 0.50}

TOL_INTERFERENCE = 0.02   # mm^3: allowed boolean sliver noise


def min_distance(a, b) -> float:
    ds = BRepExtrema_DistShapeShape(a.wrapped, b.wrapped)
    ds.Perform()
    return ds.Value()


def overlap_volume(a, b) -> float:
    try:
        return (a & b).volume
    except Exception:
        return a.intersect(b).volume


def bbox_gap(a, b) -> float:
    """Gap between axis-aligned bounding boxes (prefilter for pair checks)."""
    ba, bb = a.bounding_box(), b.bounding_box()
    dx = max(ba.min.X - bb.max.X, bb.min.X - ba.max.X, 0)
    dy = max(ba.min.Y - bb.max.Y, bb.min.Y - ba.max.Y, 0)
    dz = max(ba.min.Z - bb.max.Z, bb.min.Z - ba.max.Z, 0)
    return math.sqrt(dx * dx + dy * dy + dz * dz)


def measure_text_metrics():
    """Measure cap height and stroke width from real Fillaprint geometry."""
    with BuildSketch(Plane.XY) as s:
        Text("MI3", font_size=lab.LABEL_EM, font_path=FONT,
             text_align=(TextAlign.LEFT, TextAlign.BOTTOM))
    xs = [f.bounding_box() for f in s.sketch.faces()]
    x0 = min(b.min.X for b in xs); x1 = max(b.max.X for b in xs)
    y0 = min(b.min.Y for b in xs); y1 = max(b.max.Y for b in xs)
    cap = y1 - y0
    # the hyphen is a pure two-bead bar: its height is the stroke width
    with BuildSketch(Plane.XY) as s2:
        Text("-", font_size=lab.LABEL_EM, font_path=FONT,
             text_align=(TextAlign.LEFT, TextAlign.BOTTOM))
    ib = [f.bounding_box() for f in s2.sketch.faces()][0]
    stroke = ib.size.Y
    return cap, stroke, (x1 - x0)


def true_part_volume(size, kind, length=None):
    """Solid volume of one fastener (mm^3) from nominal dimensions."""
    f = FASTENERS[size]
    if kind == "screw":
        dk, k = f["screw_head"]
        d = f["shank_d"]
        head = math.pi * (dk / 2) ** 2 * k * 0.75     # hex socket recess
        shank = math.pi * (d / 2) ** 2 * max(length - k, 0.5)
        return head + shank
    if kind == "nut":
        s, m = f["nut"]
        return 0.866 * s * s * m * 0.7                # hex ring with bore
    if kind == "washer":
        od, t = f["washer"]
        id_ = od * 0.55
        return math.pi / 4 * (od * od - id_ * id_) * t
    raise ValueError(kind)


def capacity_of(comp_w, comp_d, front_depth, back_depth, part_vol, kind,
                n_target):
    """Estimate how many parts fit below the carry fill line.

    Fill line = front cavity depth minus 2 mm freeboard.  Usable floor area
    discounts the scoop and perimeter fillets (conservative flat zone).
    """
    flat_d = max(comp_d - 7.2 - 4.2, comp_d * 0.4)     # minus scoop/back fillets
    flat_w = max(comp_w - 8.4, comp_w * 0.4)           # minus side fillets
    area = flat_w * flat_d
    fill_h = max(front_depth - 2.0, 0.5)
    usable_vol = area * fill_h + area * max(back_depth - front_depth, 0) / 2
    per_part = part_vol / PACKING[kind]
    return usable_vol / per_part, per_part, usable_vol


def main():
    t0 = time.time()
    checks = {"units": "mm", "tolerances": {"interference_mm3": TOL_INTERFERENCE}}

    # --- rebuild everything -------------------------------------------------
    plate = core.make_baseplate(CELLS_X, CELLS_Y, BORDER, SLAB)
    plate_w = core.GRID * CELLS_X + 2 * BORDER
    plate_d = core.GRID * CELLS_Y + 2 * BORDER
    plate_top = SLAB + core.PLATE_CAVITY_H
    bin_z = plate_top - core.PLATE_CAVITY_H

    placed = [("baseplate_5x4", plate.moved(Location((plate_w / 2, plate_d / 2, 0))))]
    specs = {}
    for spec in PARTS:
        pid, cw, cd, uh, divs, labels, cx, cy = spec
        shape, labels_used = build_bin(spec)
        tx = BORDER + core.GRID * (cx + cw / 2)
        ty = BORDER + core.GRID * (cy + 0.5)
        placed.append((pid, shape.moved(Location((tx, ty, bin_z)))))
        specs[pid] = spec
    print(f"rebuilt {len(placed)} parts in {time.time()-t0:.0f}s")

    # --- 1. validity + bbox --------------------------------------------------
    nominal = {
        "baseplate_5x4": (plate_w, plate_d, plate_top),
    }
    for spec in PARTS:
        pid, cw, cd, uh, divs, labels, cx, cy = spec
        nominal[pid] = (core.GRID * cw - 0.5, core.GRID * cd - 0.5,
                        core.U * uh + 3.5515)
    geom = []
    for pid, shape in placed:
        bb = shape.bounding_box()
        n = nominal[pid]
        ok = (abs(bb.size.X - n[0]) < 0.01 and abs(bb.size.Y - n[1]) < 0.01
              and abs(bb.size.Z - n[2]) < 0.01)
        geom.append({"id": pid, "valid": bool(shape.is_valid),
                     "solids": len(shape.solids()),
                     "bbox": [round(v, 3) for v in (bb.size.X, bb.size.Y, bb.size.Z)],
                     "nominal": list(n), "bbox_ok": bool(ok),
                     "volume_mm3": round(shape.volume, 1)})
    checks["geometry"] = geom
    print("geometry:", sum(1 for g in geom if g["bbox_ok"] and g["valid"]
                           and g["solids"] == 1), "/", len(geom), "ok")

    # --- 2. pairwise interference -------------------------------------------
    worst = 0.0
    pairs_checked = 0
    worst_pair = None
    for i in range(len(placed)):
        for j in range(i + 1, len(placed)):
            a_id, a = placed[i]
            b_id, b = placed[j]
            if bbox_gap(a, b) > 0.05:
                continue
            pairs_checked += 1
            v = overlap_volume(a, b)
            if v > worst:
                worst, worst_pair = v, (a_id, b_id)
    checks["assembly_interference"] = {
        "pairs_checked": pairs_checked,
        "max_overlap_mm3": round(worst, 6),
        "worst_pair": worst_pair,
        "pass": worst <= TOL_INTERFERENCE,
    }
    print(f"interference: {pairs_checked} near pairs, worst overlap {worst:.6f} mm^3")

    # --- 3. interface distances ----------------------------------------------
    # bin seated in plate (use the placed/moved plate and an M3 1x1 bin)
    m3 = dict((s[0], s) for s in PARTS)["bin_m3x12"]
    shape_m3, _ = build_bin(m3)
    cx = BORDER + core.GRID * (m3[6] + 0.5)
    cy = BORDER + core.GRID * (m3[7] + 0.5)
    seated = shape_m3.moved(Location((cx, cy, bin_z)))
    plate_moved = placed[[p[0] for p in placed].index("baseplate_5x4")][1]
    d_seat = min_distance(plate_moved, seated)
    v_seat = overlap_volume(plate_moved, seated)

    # two adjacent 1x1 bins (M3x8 next to M3x10)
    s8 = dict((s[0], s) for s in PARTS)["bin_m3x8"]
    sh8, _ = build_bin(s8)
    p8 = sh8.moved(Location((BORDER + core.GRID * (s8[6] + 0.5),
                             BORDER + core.GRID * (s8[7] + 0.5), bin_z)))
    p10 = placed[[p[0] for p in placed].index("bin_m3x10")][1]
    d_adj = min_distance(p8, p10)
    v_adj = overlap_volume(p8, p10)

    # stacking: one bin stacked on another (spec seat drop of 0.35 mm)
    stack_drop = 0.35
    base = sh8.moved(Location((BORDER + core.GRID * (s8[6] + 0.5),
                               BORDER + core.GRID * (s8[7] + 0.5), bin_z)))
    top_bin = shape_m3.moved(Location((BORDER + core.GRID * (s8[6] + 0.5),
                                       BORDER + core.GRID * (s8[7] + 0.5),
                                       bin_z + core.U * 4 - stack_drop)))
    d_stack = min_distance(base, top_bin)
    v_stack = overlap_volume(base, top_bin)

    checks["interface_distances"] = {
        "bin_in_baseplate": {"min_distance": round(d_seat, 4),
                             "overlap_mm3": round(v_seat, 6),
                             "expected_contact": True, "pass": v_seat <= TOL_INTERFERENCE},
        "adjacent_bins": {"min_distance": round(d_adj, 4),
                          "overlap_mm3": round(v_adj, 6),
                          "expected_gap": 0.5,
                          "pass": abs(d_adj - 0.5) < 0.01 and v_adj <= TOL_INTERFERENCE},
        "stacked_bins": {"min_distance": round(d_stack, 4),
                         "overlap_mm3": round(v_stack, 6),
                         "expected_contact": True, "pass": v_stack <= TOL_INTERFERENCE},
        "stacking_seat_drop_mm": stack_drop,
    }
    print(f"distances: seat {d_seat:.4f} (overlap {v_seat:.6f}), "
          f"adjacent {d_adj:.4f}, stacked {d_stack:.4f} (overlap {v_stack:.6f})")

    # --- 4. label metrics -----------------------------------------------------
    cap, stroke, w_MI3 = measure_text_metrics()
    w_min = 14 * core.LABEL_LINE_W
    checks["labels"] = {
        "font": "Fillaprint-Regular (SIL OFL 1.1)",
        "em_mm": core.LABEL_EM,
        "cap_height_measured_mm": round(cap, 3),
        "stroke_width_measured_mm": round(stroke, 3),
        "font_minimum_cap_mm": round(w_min, 3),
        "reference_line_width_mm": core.LABEL_LINE_W,
        "at_or_above_minimum": bool(cap >= w_min - 1e-6),
        "engrave_depth_mm": core.LABEL_DEPTH,
        "wall_behind_groove_mm": round(core.WALL - core.LABEL_DEPTH, 2),
    }
    print(f"labels: cap {cap:.3f} mm (min {w_min:.3f}), stroke {stroke:.3f} mm")

    # --- 5. capacity -----------------------------------------------------------
    cap_table = []
    for spec in PARTS:
        pid, cw, cd, uh, divs, labels, cx, cy = spec
        w, d = core.bin_footprint(cw, cd)
        centers, iw, comp_w = core.compartment_centers(cw, cd, divs)
        body_h = core.U * uh
        front = body_h - core.FLOOR_FRONT
        back = front - (d - 2 * core.WALL) * math.tan(math.radians(core.FLOOR_SLOPE_DEG))
        comp_d = d - 2 * core.WALL
        for (txt, glyph) in labels:
            kind = "screw" if "×" in txt or "x" in txt.lower() else (
                "nut" if glyph == "nut" else "washer")
            if kind == "screw":
                size, length = txt.replace(" ", "").split("×")
                length = int(length)
                target = 20
            else:
                size = txt
                target = 30
            part_vol = true_part_volume(size, kind,
                                        length if kind == "screw" else None)
            est, per_part, usable = capacity_of(comp_w, comp_d, front, back,
                                                part_vol, kind, target)
            cap_table.append({
                "bin": pid, "label": txt, "kind": kind,
                "compartment_mm": [round(comp_w, 1), round(comp_d, 1)],
                "cavity_front_depth_mm": round(front, 1),
                "part_true_volume_mm3": round(part_vol, 2),
                "target_count": target,
                "estimated_capacity": round(est, 1),
                "pass": bool(est >= target),
            })
    checks["capacity_estimates"] = cap_table
    fails = [c for c in cap_table if not c["pass"]]
    print(f"capacity: {len(cap_table)-len(fails)}/{len(cap_table)} compartments "
          f"meet targets" + (f"; FAILS: {[c['label'] for c in fails]}" if fails else ""))

    with open(ROOT / "measured_checks.json", "w") as f:
        json.dump(checks, f, indent=2)
    print(f"\nwrote measured_checks.json ({time.time()-t0:.0f}s total)")


if __name__ == "__main__":
    main()
