"""Parametric Gridfinity core: spec-exact interfaces + organizer bins + baseplate.

Interface constants follow the Gridfinity specification as reconstructed and
maintained in the reference open-source implementations (gridfinity.xyz /
gridfinity-rebuilt-openscad, see README for provenance):

  grid pitch                42 mm
  bin footprint             42*u - 0.5  (0.5 mm total clearance per axis)
  base block profile (bin)  0.8/45deg chamfer, 1.8 vertical, 2.15/45deg flare,
                            total height 4.75, top corner radius 3.75
  baseplate cavity          same shape inverted: 36.3 bottom (r1.15),
                            0.7/45deg to 37.7 (r1.85) at 1.05, vertical to 2.85,
                            2.15/45deg flare to the full 42.0 pitch at 5.0
  stacking lip (bin top)    funnel measured from the OUTER face:
                            2.6 deep at the nominal top, 0.7/45deg lead-in,
                            1.8 vertical, 1.9/45deg flare to flush at +4.4,
                            tip blunted with a 0.6 fillet (top at +3.5515)
  height unit               7 mm  (bin body height = 7*u, lip adds on top)

Clearances that result (all per side):
  bin in plate / bin in bin funnel:  0.25 vertical section, 0.35 bottom face
  adjacent bins in the grid:         0.25 (0.5 total between bins)
  seat: bin flare rests on plate flare cone, bottom face on cavity floor.
"""

from __future__ import annotations

import math
from build123d import (Box, Circle, Cylinder, Location, Mode,
                       Plane, Polygon, Pos, Rectangle, Shape,
                       BuildSketch, chamfer, extrude, fillet, loft)

# ---------------------------------------------------------------------------
# Interface constants (see module docstring)
# ---------------------------------------------------------------------------
GRID = 42.0
BIN_CLEAR = 0.5
R_OUT = 3.75                 # outer corner radius: base top + walls
BASE_BOT_INSET = 2.95        # per side, bottom face of bin
BASE_VERT_INSET = 2.15       # per side, vertical section of base block
BASE_BOT_CH = 0.8            # bottom chamfer height (45 deg)
BASE_PROFILE_H = 4.75        # base profile height
LIP_DEPTH = 2.6              # lip material depth from OUTER face at nominal top
LIP_LEAD = 0.7               # lip lower 45 deg run
LIP_VERT = 1.8
LIP_FLARE = 1.9              # lip upper 45 deg run
LIP_H = 4.4                  # total lip height (before tip fillet)
LIP_TIP_R = 0.6              # tip fillet -> actual lip top at 3.5515
PLATE_CAVITY_H = 5.0         # cavity depth: 4.65 profile + 0.35 clearance
PLATE_R_OUT = 4.0            # plate outer corner radius
U = 7.0                      # gridfinity height unit

# derived
PLATE_CAV_BOT_INSET = 2.85   # cavity bottom = pitch - 2*2.85 (36.3 for 1x1)
PLATE_CAV_VERT_INSET = 2.15  # cavity vertical section = pitch - 2*2.15 (37.7)

# ---------------------------------------------------------------------------
# Organizer (non-interface) parameters -- the design layer of this system
# ---------------------------------------------------------------------------
WALL = 1.6                   # bin wall thickness (engrave 0.7 leaves 0.9)
# Floor plane height at the front wall.  It must sit ABOVE the base profile
# top (4.75) so the floor meets fully backed walls; below that the floor
# would intersect the base block's outer flare, leaving a knife edge and a
# hairline slot at the wall base (and the scoop fillet becomes impossible).
FLOOR_FRONT = 4.8
FLOOR_SLOPE_DEG = 6.0         # floor rises toward the back; parts gather front
SCOOP_R = 8.0                 # front floor fillet: the finger scoop
FILLET_R = 4.0                # floor fillet elsewhere
CAV_CORNER_R = 6.0            # cavity vertical corner radius (wiping-friendly,
                              # and long enough for the scoop fillet to wrap)
DIVIDER_T = 1.2                # divider wall thickness (gridfinity standard)
DIVIDER_TOP_DROP = 1.0        # divider top below nominal top (stacking clear)
DIVIDER_TOP_CH = 0.4           # divider top chamfer
LABEL_DEPTH = 0.7              # engraving depth (leaves WALL-0.7 = 0.9 mm)
LABEL_BASELINE_Z = 5.95        # text baseline height above bin bottom (uniform)
LABEL_EM = 8.4                 # Fillaprint em -> cap 5.88 mm = 14 * 0.42 line
LABEL_LINE_W = 0.42            # extrusion line width the labels are sized for
GLYPH_GAP = 2.0                # gap between text and pictogram glyph
# Fillaprint reference (minimum) size: cap = 14*line width, em = 20*line width.
LABEL_CAP = LABEL_EM * 0.7     # 5.88 mm == 14 * 0.42: at the font minimum


def bin_footprint(cells_w: int, cells_d: int):
    return GRID * cells_w - BIN_CLEAR, GRID * cells_d - BIN_CLEAR


# ---------------------------------------------------------------------------
# 2D helpers
# ---------------------------------------------------------------------------
def rrect_face(w: float, d: float, r: float, z: float = 0.0):
    """Rounded rectangle face on Plane.XY moved to height z."""
    with BuildSketch(Plane.XY) as s:
        Rectangle(w, d)
        fillet(s.vertices(), r)
    return s.sketch.faces()[0].moved(Location((0, 0, z)))


def _hex_points(af: float):
    r = af / math.sqrt(3.0)
    return [(r * math.cos(math.radians(60 * i + 30)),
             r * math.sin(math.radians(60 * i + 30))) for i in range(6)]


# ---------------------------------------------------------------------------
# Bin construction
# ---------------------------------------------------------------------------
def _prism(w: float, d: float, r: float, z0: float, z1: float) -> Shape:
    """Vertical rounded-rect prism between z0 and z1."""
    p = extrude(rrect_face(w, d, r), z1 - z0)
    return p.moved(Location((0, 0, z0)))


def _edges_at(solid: Shape, z: float, tol: float = 1e-6):
    return [e for e in solid.edges() if abs(e.center().Z - z) < tol]


def _unit_base_block() -> Shape:
    """One spec base block for a single 42 mm cell, centered at origin.

    Built from chamfered prisms so every interface surface is an exact
    45-degree plane or cone (lofted rounded rectangles would only
    approximate them, which is visible at the stacking seat).
    """
    # vertical section (37.2, r1.6) with 0.8/45 bottom chamfer: the prism
    # starts at z=0 so the chamfer cuts down to the 35.6 bottom face at z=0.
    # Extended upward to overlap the flare piece (abutting solids with
    # coincident faces leave zero-thickness flaps in the boolean result).
    p37 = _prism(42 - BIN_CLEAR - 2 * BASE_VERT_INSET,
                 42 - BIN_CLEAR - 2 * BASE_VERT_INSET,
                 R_OUT - BASE_VERT_INSET, 0.0, 3.6)
    p37 = chamfer(_edges_at(p37, 0.0), BASE_BOT_CH)
    # top flare: 41.5 prism (r3.75) with 2.15/45 bottom chamfer; extended
    # upward because a chamfer cannot span a prism's full height (the wall
    # prism occupies the same footprint above 4.75, so the overlap is inert)
    p41 = _prism(42 - BIN_CLEAR, 42 - BIN_CLEAR, R_OUT, 2.6, 8.0)
    p41 = chamfer(_edges_at(p41, 2.6), BASE_PROFILE_H - 2.6)
    return (p37 + p41).clean()


def _outer_solid(w: float, d: float, body_h: float,
                 cells_w: int, cells_d: int) -> Shape:
    """Bin outer envelope: per-unit base blocks + bridge + walls + lip zone.

    Multi-unit bins follow the spec: each 42 mm cell gets its own base block
    placed at the cell center, leaving a 0.5 mm gap centered on every
    internal cell line (which straddles the baseplate rib) plus a 0.25 mm
    inset at the outer ends.  A full-footprint bridge slab from the base
    profile top (4.75) to 7 mm ties the blocks together; a groove over each
    internal cell line clears the plate ribs' knife tops.
    """
    outer = None
    for i in range(cells_w):
        for j in range(cells_d):
            cx = -GRID * cells_w / 2 + GRID / 2 + GRID * i
            cy = -GRID * cells_d / 2 + GRID / 2 + GRID * j
            blk = _unit_base_block().moved(Location((cx, cy, 0)))
            outer = blk if outer is None else outer + blk

    # walls / bridge: full footprint from the base profile top upward
    prism = _prism(w, d, R_OUT, BASE_PROFILE_H, body_h + LIP_H)
    outer = outer + prism

    # multi-unit rib clearance: baseplate ribs between cells end in corner
    # notches that rise 0.25 mm above the base profile top.  Between 4.75
    # and 5.05 the bin's underside therefore follows the per-cell 41.5/r3.75
    # outlines (0.5 mm gaps on every internal cell line, corners clear of
    # the notches); the full footprint resumes above 5.05.
    if cells_w > 1 or cells_d > 1:
        z0, z1 = BASE_PROFILE_H, BASE_PROFILE_H + 0.30
        cell_slabs = None
        for i in range(cells_w):
            for j in range(cells_d):
                cx = -GRID * cells_w / 2 + GRID / 2 + GRID * i
                cy = -GRID * cells_d / 2 + GRID / 2 + GRID * j
                slab = _prism(GRID - BIN_CLEAR, GRID - BIN_CLEAR, R_OUT,
                               z0 - 0.5, z1 + 0.5)
                slab = slab.moved(Location((cx, cy, 0)))
                cell_slabs = slab if cell_slabs is None else cell_slabs + slab
        band = Pos(0, 0, (z0 + z1) / 2) * Box(w, d, z1 - z0)
        pocket = band - cell_slabs
        outer = outer - pocket
    return outer


def _floor_wedge(w: float, d: float, span_x: tuple[float, float],
                 undersink: float = 0.0) -> Shape:
    """Solid below the sloped floor plane, extruded along X over span_x.

    All coordinates use the bin's centered frame (bin spans -w/2..w/2,
    -d/2..d/2).  The top edge of the (y,z) profile lies exactly on the
    floor plane, optionally lowered by `undersink` (used for divider feet
    that must sink into the floor slab so the fuse is robust)."""
    tan_t = math.tan(math.radians(FLOOR_SLOPE_DEG))
    y_f = -(d / 2 - WALL)               # front inner face (front = -Y)
    y_b = +(d / 2 - WALL)               # back inner face
    z_f = FLOOR_FRONT - undersink
    z_b = z_f + (y_b - y_f) * tan_t
    o = 1.0
    with BuildSketch(Plane.YZ) as s:
        Polygon(*(
            (y_f - o, z_f - o * tan_t),
            (y_b + o, z_b + o * tan_t),
            (y_b + o, -1.0),
            (y_f - o, -1.0),
        ))
    width = span_x[1] - span_x[0]
    wedge = extrude(s.sketch.faces()[0], width)
    return wedge.moved(Location((span_x[0], 0, 0)))


def _cavity_solid(w: float, d: float, body_h: float) -> Shape:
    """Air inside the bin: opening + wedge support cone + stacking funnel,
    with the sloped floor cut in by subtracting the floor wedge.

    Built from chamfered prisms so every interface surface (the stacking
    seat and the funnel walls) is an exact 45-degree plane or cone.
    """
    iw, id_ = w - 2 * WALL, d - 2 * WALL
    cr = CAV_CORNER_R                     # cavity vertical corner radius
    z_nom = body_h                          # nominal wall top (funnel start)
    support_h = LIP_DEPTH - WALL            # 0.8 -> 45 deg support wedge

    # vertical prism up to the support wedge zone (overlaps the cone below)
    prism = _prism(iw, id_, cr, 0.0, z_nom - support_h + 1.0)

    # support wedge cone: 37.9 prism with 0.8/45 top chamfer -> 36.3 mouth
    # with the spec mouth corner radius (1.15). Corner radius chosen so the
    # chamfered top face lands exactly on it; the cavity prism below has
    # larger (ergonomic) corners, leaving a small harmless corner step.
    # Extended downward (same air as the prism below) so the chamfer fits.
    r_cone = R_OUT - LIP_DEPTH + support_h        # 1.95 -> chamfers to 1.15
    cone = _prism(iw, id_, r_cone, z_nom - 4.0, z_nom)
    cone = chamfer(_edges_at(cone, z_nom), support_h)

    # stacking funnel above the nominal top (spec profile, from outer face):
    # 0.7/45 lead-in from the 36.3 mouth, vertical 1.8, then 1.9/45 flare
    # out to the full footprint at the lip tip plane.  Bands overlap each
    # other (and the mouth prism overlaps the cone) by ~1 mm so no
    # coincident faces survive the fuse; coincident faces leave
    # zero-thickness flaps that imprint on the final solid.
    f_vert = w - 2 * (LIP_DEPTH - LIP_LEAD)     # 37.7 for 1x1
    r_fvert = R_OUT - (LIP_DEPTH - LIP_LEAD)    # 1.85

    # lower band: 37.7 prism with 0.7/45 bottom chamfer -> 36.3 mouth.
    # Both bands extend past the tip plane and the union is trimmed there,
    # so no internal horizontal faces exist for the fuse to mishandle.
    f_low = _prism(f_vert, f_vert, r_fvert, z_nom, z_nom + LIP_H + 2.0)
    f_low = chamfer(_edges_at(f_low, z_nom), LIP_LEAD)
    # upper band: full prism with 1.9/45 bottom chamfer -> 37.7 at +2.5
    f_up = _prism(w, d, R_OUT, z_nom + LIP_LEAD + LIP_VERT, z_nom + LIP_H + 2.0)
    f_up = chamfer(_edges_at(f_up, z_nom + LIP_LEAD + LIP_VERT), LIP_FLARE)
    tip_box = Box(w + 2, d + 2, LIP_H + 3.0)
    tip_box = Pos(0, 0, z_nom + LIP_H - (LIP_H + 3.0) / 2) * tip_box
    funnel = (f_low + f_up) & tip_box

    cav = (prism + cone + funnel) - _floor_wedge(
        w, d, (-(iw / 2 + 1.0), iw / 2 + 1.0))
    return cav


def _floor_plane_normal():
    t = math.tan(math.radians(FLOOR_SLOPE_DEG))
    n = (0.0, -t, 1.0)
    l = math.hypot(t, 1.0)
    return (n[0] / l, n[1] / l, n[2] / l)


def _get_floor_face(solid: Shape):
    """The sloped cavity floor face, found by its plane normal."""
    nrm = _floor_plane_normal()
    for f in solid.faces():
        n = f.normal_at(f.center())
        dot = n.X * nrm[0] + n.Y * nrm[1] + n.Z * nrm[2]
        if dot > 0.999:
            return f
    return None


def _fillet_cavity_bottom(bin_solid: Shape, d: float) -> Shape:
    """Fillet the floor/wall edges: big scoop at the front, smaller elsewhere."""
    # front zone: edges whose center Y is within the rounded-front band
    front_lim = -(d / 2) + WALL + CAV_CORNER_R + 2.5

    # --- front edges (scoop) ---
    for radius in (SCOOP_R, 6.0, 4.0):
        floor = _get_floor_face(bin_solid)
        if floor is None:
            break
        edges = [e for e in floor.edges() if e.center().Y < front_lim]
        if not edges:
            break
        try:
            bin_solid = fillet(edges, radius)
            break
        except Exception:
            continue

    # --- remaining floor edges ---
    for radius in (FILLET_R, 2.5):
        floor = _get_floor_face(bin_solid)
        if floor is None:
            break
        edges = [e for e in floor.edges() if e.center().Y >= front_lim]
        if not edges:
            break
        try:
            bin_solid = fillet(edges, radius)
            break
        except Exception:
            continue
    return bin_solid


def _divider_solid(x_center: float, w: float, d: float, body_h: float) -> Shape:
    """Divider slab following the sloped floor, top chamfered, below seat plane."""
    top_z = body_h - DIVIDER_TOP_DROP
    slab = Box(DIVIDER_T, d + 2.0, top_z + 1.0)
    slab = Pos(x_center, 0, (top_z + 1.0) / 2 - 1.0) * slab

    # sink the divider foot 0.3 mm below the floor plane so the fuse with the
    # floor slab overlaps real material (coincident faces alone fuse poorly)
    wedge = _floor_wedge(w, d, (x_center - DIVIDER_T / 2 - 1.0,
                                x_center + DIVIDER_T / 2 + 1.0),
                         undersink=0.3)
    slab = slab - wedge

    top_edges = [e for e in slab.edges()
                 if abs(e.center().Z - top_z) < 1e-6]
    if top_edges:
        slab = chamfer(top_edges, DIVIDER_TOP_CH)
    return slab


def compartment_centers(cells_w: int, cells_d: int, dividers: int):
    """X centers (bin centered at origin) of the dividers+1 compartments.

    Returns (centers, inner_width, compartment_width).
    """
    w, _ = bin_footprint(cells_w, cells_d)
    iw = w - 2 * WALL
    comp_w = (iw - dividers * DIVIDER_T) / (dividers + 1)
    centers = [-iw / 2 + k * (comp_w + DIVIDER_T) + comp_w / 2
               for k in range(dividers + 1)]
    return centers, iw, comp_w


def make_bin(cells_w: int = 1, cells_d: int = 1, units_h: int = 3,
             dividers: int = 0, label_solids=None) -> Shape:
    """Build one organizer bin, centered at the origin.

    cells_w/cells_d : gridfinity footprint in grid cells
    units_h         : body height in 7 mm units (lip adds 3.55 mm)
    dividers        : number of interior dividers across the width
                      (compartments = dividers + 1)
    label_solids    : list of (x_center, solid) engraving solids on the front
    """
    w, d = bin_footprint(cells_w, cells_d)
    body_h = U * units_h

    outer = _outer_solid(w, d, body_h, cells_w, cells_d)
    cav = _cavity_solid(w, d, body_h)
    bin_ = outer - cav

    if dividers > 0:
        iw = w - 2 * WALL
        comp_w = (iw - dividers * DIVIDER_T) / (dividers + 1)
        for k in range(1, dividers + 1):
            xc = -iw / 2 + k * comp_w + (k - 0.5) * DIVIDER_T
            bin_ = bin_ + _divider_solid(xc, w, d, body_h)
        # dividers overshoot front/back/bottom for a robust fuse; clip back
        bin_ = bin_ & outer

    bin_ = _fillet_cavity_bottom(bin_, d)

    # blunted lip tip (spec 0.6 fillet)
    z_tip = body_h + LIP_H
    tip_edges = [e for e in bin_.edges()
                 if abs(e.center().Z - z_tip) < 1e-4]
    if tip_edges:
        bin_ = fillet(tip_edges, LIP_TIP_R)

    if label_solids:
        for _xc, ls in label_solids:
            bin_ = bin_ - ls

    bin_ = bin_.clean()
    assert len(bin_.solids()) == 1, f"bin is not a single solid ({len(bin_.solids())})"
    return bin_


# ---------------------------------------------------------------------------
# Baseplate
# ---------------------------------------------------------------------------
def plate_cavity_solid() -> Shape:
    """One spec baseplate cavity for a 42x42 cell, centered at origin, z=0..5.

    Built from chamfered prisms so the cavity walls are exact 45-degree
    planes/cones: 36.3 flat bottom, 0.7/45 to 37.7, vertical 1.8, then
    2.15/45 flaring to the full 42 pitch at the plate top (knife-edge ribs).
    """
    bot = GRID - 2 * PLATE_CAV_BOT_INSET        # 36.3
    vert = GRID - 2 * PLATE_CAV_VERT_INSET      # 37.7
    r_bot = PLATE_R_OUT - PLATE_CAV_BOT_INSET   # 1.15
    r_vert = PLATE_R_OUT - PLATE_CAV_VERT_INSET  # 1.85
    flat = 0.35                                  # flat bottom region height

    lower = _prism(vert, vert, r_vert, flat, PLATE_CAVITY_H - 2.15 + 1.0)
    lower = chamfer(_edges_at(lower, flat), 0.7)
    # upper flare: full-pitch prism with 2.15/45 bottom chamfer, extended
    # upward for the chamfer then trimmed at the plate top plane; overlaps
    # the lower band so no coincident faces survive the fuse
    upper = _prism(GRID, GRID, PLATE_R_OUT, PLATE_CAVITY_H - 2.15,
                   PLATE_CAVITY_H + 2.0)
    upper = chamfer(_edges_at(upper, PLATE_CAVITY_H - 2.15), 2.15)
    upper = upper & (Pos(0, 0, PLATE_CAVITY_H / 2) * Box(GRID + 2, GRID + 2,
                                                         PLATE_CAVITY_H))
    bottom = _prism(bot, bot, r_bot, 0.0, flat + 1.0)
    return (bottom + lower + upper).clean()


def make_baseplate(cells_x: int = 5, cells_y: int = 4, border: float = 12.0,
                   slab: float = 3.2, mount_holes: bool = True,
                   mount_d: float = 4.5, csink_d: float = 8.6) -> Shape:
    """Baseplate: spec cavities + solid slab + optional countersunk mounts.

    The plate is centered at the origin; cell (i, j) has its cavity centered
    at (-w/2 + border + 42*(i+0.5), -d/2 + border + 42*(j+0.5)).
    """
    w = GRID * cells_x + 2 * border
    d = GRID * cells_y + 2 * border
    total_h = slab + PLATE_CAVITY_H
    plate = extrude(rrect_face(w, d, PLATE_R_OUT), total_h)

    cavity = plate_cavity_solid()
    for i in range(cells_x):
        for j in range(cells_y):
            cx = -w / 2 + border + GRID * (i + 0.5)
            cy = -d / 2 + border + GRID * (j + 0.5)
            plate = plate - cavity.moved(Location((cx, cy, slab)))

    if mount_holes:
        csink_h = (csink_d - mount_d) / 2.0     # 90 deg countersink
        hole_positions = [(-(w - border) / 2, -(d - border) / 2),
                          ((w - border) / 2, -(d - border) / 2),
                          (-(w - border) / 2, (d - border) / 2),
                          ((w - border) / 2, (d - border) / 2)]
        for px, py in hole_positions:
            hole = Cylinder(mount_d / 2, total_h + 2)
            hole = Pos(px, py, total_h / 2) * hole
            csink = loft([
                Circle(csink_d / 2).moved(Location((0, 0, -1.0))),
                Circle(mount_d / 2).moved(Location((0, 0, csink_h))),
            ], ruled=True)
            csink = Pos(px, py, 0) * csink
            plate = plate - hole - csink

    plate = plate.clean()
    assert len(plate.solids()) == 1
    return plate


def plate_size(cells_x: int, cells_y: int, border: float):
    return GRID * cells_x + 2 * border, GRID * cells_y + 2 * border
