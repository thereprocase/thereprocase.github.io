"""Fillaprint labels: engraved text + pictogram glyphs on bin front walls.

The Fillaprint font (assets/fillaprint/Fillaprint-Regular.ttf, SIL OFL 1.1) is a
"two-bead FDM" typeface: at its reference size every stroke and every clear gap
is exactly two extrusion line widths.  Its documented reference size is

    capital height = 14 * w,   em = 20 * w     (w = extrusion line width)

Below that size strokes and gaps fall under two bead widths.  All text here is
sized at em = 8.4 mm -> cap height 5.88 mm, which is exactly the reference
size for the common w = 0.42 mm line width (the 0.4 mm nozzle default in
PrusaSlicer / OrcaSlicer).  Labels are therefore at the font's minimum size;
print them with line widths <= 0.42 mm.  Pictogram strokes and internal gaps
use the same two-bead width (0.84 mm).

Labels are ENGRAVED 0.7 mm deep into the front wall (1.6 mm thick, 0.9 mm
remains) rather than raised: side faces of gridfinity bins have only 0.25 mm
of clearance to their neighbors, which rules out any protruding text.

Pictograms (same two-bead stroke):
  nut    : hexagon outline + round bore  (a hex-nut face)
  washer : two concentric circles        (a washer face)
"""

from __future__ import annotations

import math
from build123d import (BuildSketch, Circle, Mode, Plane, Polygon, Shape,
                       Text, TextAlign, extrude)

FONT = "./assets/fillaprint/Fillaprint-Regular.ttf"

# keep in sync with gf_core
LABEL_EM = 8.4                # em size: cap height = 0.7*em
LABEL_CAP = LABEL_EM * 0.7    # 5.88 mm = 14 * 0.42 (font reference size)
LABEL_DEPTH = 0.7
STROKE = 0.84                 # two-bead stroke at w = 0.42 (= em/10)
GLYPH_GAP = 2.0               # gap between text and pictogram
GLYPH_OUTER = 7.6             # pictogram outer size (washer dia / nut AF)
ENGRAVE_START_Y = -0.05        # start slightly outside the wall (clean cut)


def _scratch_faces(text: str, em: float):
    with BuildSketch(Plane.XY) as s:
        Text(text, font_size=em, font_path=FONT,
             text_align=(TextAlign.LEFT, TextAlign.BOTTOM))
    return s.sketch.faces()


def measure_text(text: str, em: float = LABEL_EM) -> float:
    """Width of a text string at the given em size (mm)."""
    fs = _scratch_faces(text, em)
    x0 = min(f.bounding_box().min.X for f in fs)
    x1 = max(f.bounding_box().max.X for f in fs)
    return x1 - x0


def _hex_points(af: float):
    """Hexagon vertices, flats top/bottom (looks like a nut face), centered."""
    r = af / math.sqrt(3.0)
    return [(r * math.cos(math.radians(60 * i)),
             r * math.sin(math.radians(60 * i))) for i in range(6)]


def glyph_width(glyph: str | None) -> float:
    if glyph is None:
        return 0.0
    if glyph == "nut":
        return 2.0 * (GLYPH_OUTER / math.sqrt(3.0))    # across corners
    if glyph == "washer":
        return GLYPH_OUTER                              # outer circle diameter
    raise ValueError(glyph)


def _glyph_faces(glyph: str):
    """Pictogram faces centered on local (0, 0), two-bead stroke width.

    Gaps inside each glyph are at least one stroke (0.84 mm) wide so both
    the grooves and the material between them print as two beads.
    """
    s = STROKE
    o = GLYPH_OUTER
    if glyph == "nut":
        # hexagon band (flats top/bottom, like a nut face) + round bore
        af = o - s                      # band centerline across-flats
        with BuildSketch(Plane.XY) as s2:
            Polygon(*_hex_points(af + s))
            Polygon(*_hex_points(af - s), mode=Mode.SUBTRACT)
            r_bore = (af / 2 - s) / 2   # bore band centerline
            Circle(r_bore + s / 2)
            Circle(r_bore - s / 2, mode=Mode.SUBTRACT)
        return s2.sketch.faces()
    if glyph == "washer":
        # two concentric bands: a washer's OD and ID
        r1 = o / 2                      # outer band centerline
        r2 = (r1 - s - s) / 2           # inner band centerline
        with BuildSketch(Plane.XY) as s3:
            Circle(r1 + s / 2)
            Circle(r1 - s / 2, mode=Mode.SUBTRACT)
            Circle(r2 + s / 2)
            Circle(r2 - s / 2, mode=Mode.SUBTRACT)
        return s3.sketch.faces()
    raise ValueError(glyph)


def front_plane(x: float, y: float, z: float) -> Plane:
    """Sketch plane on the front wall (y = const), normal -Y, x right, z up.

    Viewed from in front of the bin (from -Y) text reads left-to-right, not
    mirrored, and the plane normal faces the viewer.
    """
    return Plane(origin=(x, y, z), x_dir=(1, 0, 0), z_dir=(0, -1, 0))


def label_solid(text: str, glyph: str | None, x_center: float,
                y_front: float, z_base: float = 5.95, em: float = LABEL_EM,
                depth: float = LABEL_DEPTH):
    """Engraving solid for one compartment label, centered at x_center.

    y_front is the bin's front outer face (bin centered frame): the groove is
    cut from y_front-0.05 to y_front+depth.  Returns (solid, total_width).
    """
    tw = measure_text(text, em)
    gw = glyph_width(glyph) if glyph else 0.0
    total = tw + (GLYPH_GAP + gw if glyph else 0.0)

    x_text = x_center - total / 2.0
    plane = front_plane(x_text, y_front - 0.05, z_base)
    with BuildSketch(plane) as s:
        Text(text, font_size=em, font_path=FONT,
             text_align=(TextAlign.LEFT, TextAlign.BOTTOM))
    solid = _extrude_faces(s.sketch.faces(), depth)

    if glyph:
        gx = x_text + tw + GLYPH_GAP + gw / 2.0
        gplane = front_plane(gx, y_front - 0.05, z_base + LABEL_CAP / 2.0)
        gfaces = [f.moved(gplane.location) for f in _glyph_faces(glyph)]
        solid = solid + _extrude_faces(gfaces, depth)

    return solid, total


def _extrude_faces(faces, depth: float):
    """Extrude a set of coplanar label faces into one groove solid.

    Extrudes opposite to each face's normal (i.e. into the wall, +Y), each
    face separately, then fuses so multi-glyph and holed outlines are safe.
    """
    amount = -(depth + 0.05)
    out = None
    for f in faces:
        s = extrude(f, amount)
        out = s if out is None else out + s
    if out is None:
        raise ValueError("no label faces")
    return out
