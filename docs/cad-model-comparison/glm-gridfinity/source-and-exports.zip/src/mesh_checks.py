"""Mesh-level verification of the exported STLs (trimesh/numpy runtime).

Run with the physics runtime.  Reads assembly.json, verifies every STL, and
appends a "mesh" section to measured_checks.json.

Checks:
  1. every STL is a binary STL (file size == 84 + 50*triangle count)
  2. watertight, consistent winding, positive volume, bbox vs nominal
  3. label grooves exist and measure 0.7 mm deep (ray casting on the front
     wall: groove floors at wall plane + 0.7, solid wall at the plane)
  4. baseplate: cavity floor depth via ray casting; mounting holes through
  5. printability: steepest downward-facing surfaces (>= 1 mm^2 faces)
     are 45-degree chamfers; remaining down-faces are sub-millimetre
     bridges (rib-clearance pocket ceilings), which print unsupported
"""

from __future__ import annotations

import json
import struct
import sys
from pathlib import Path

import numpy as np
import trimesh

ROOT = Path(__file__).resolve().parent.parent
STL_DIR = ROOT / "parts" / "stl"


def is_binary_stl(path: Path) -> bool:
    data = path.read_bytes()
    if len(data) < 84:
        return False
    n = struct.unpack("<I", data[80:84])[0]
    return len(data) == 84 + 50 * n


def groove_depth(mesh, front_y: float, z: float, x_span: float,
                 n_rays: int = 240):
    """Ray-cast the front wall label zone; return (n_groove_hits, depth_min,
    depth_max, wall_ok). Rays travel +Y from outside."""
    xs = np.linspace(-x_span / 2, x_span / 2, n_rays)
    origins = np.column_stack([xs, np.full(n_rays, front_y - 15.0),
                               np.full(n_rays, z)])
    dirs = np.tile([0.0, 1.0, 0.0], (n_rays, 1))
    locs, idx_ray, idx_tri = mesh.ray.intersects_location(
        origins, dirs, multiple_hits=False)
    hits_y = locs[:, 1]
    groove = hits_y > front_y + 0.05        # first surface behind the wall plane
    depths = hits_y[groove] - front_y
    return int(groove.sum()), (float(depths.min()) if len(depths) else None), \
        (float(depths.max()) if len(depths) else None), \
        bool(np.all(hits_y[~groove] < front_y + 0.05))


def downward_angle_stats(mesh):
    """Overhang audit, excluding the build-plate face (z = zmin).

    Returns (worst_overhang_deg, ceiling_area_mm2); ceilings are
    near-horizontal downward faces other than the plate face.  For these
    parts the only such faces are the rib-clearance pocket ceilings, which
    are 0.5 mm wide (single-bead bridges) and print unsupported.
    """
    tri = mesh.triangles
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    norm = np.linalg.norm(n, axis=1)
    n = n / np.where(norm[:, None] == 0, 1e-12, norm[:, None])
    areas = mesh.area_faces
    zmin = mesh.bounds[0][2]
    centers = tri.mean(axis=1)
    on_plate = centers[:, 2] < zmin + 0.02
    down_idx = np.where((n[:, 2] < -0.05) & ~on_plate)[0]
    ang = np.degrees(np.arccos(np.clip(-n[down_idx, 2], -1, 1)))
    overhang = 90.0 - ang                       # 0 = vertical, 90 = ceiling
    a_down = areas[down_idx]
    big = a_down >= 1.0
    worst = float(overhang[big].max()) if big.any() else 0.0
    ceiling = float(a_down[overhang > 60.0].sum())
    return worst, ceiling


def main():
    assembly = json.load(open(ROOT / "assembly.json"))
    checks = json.load(open(ROOT / "measured_checks.json"))
    mesh_checks = []
    ok_all = True
    for part in assembly["parts"]:
        path = ROOT / part["stl"]
        m = trimesh.load(path)
        n_degenerate = int((~m.nondegenerate_faces()).sum())
        m.merge_vertices()
        m.update_faces(m.nondegenerate_faces())
        m.fix_normals()
        binary = is_binary_stl(path)
        watertight = bool(m.is_watertight)
        winding = bool(m.is_winding_consistent)
        vol = float(m.volume)
        bb = m.bounds
        size = bb[1] - bb[0]
        entry = {
            "id": part["id"],
            "binary_stl": binary,
            "watertight": watertight,
            "winding_consistent": winding,
            "degenerate_faces_removed": n_degenerate,
            "volume_mm3": round(vol, 1),
            "faces": int(len(m.faces)),
            "size_mm": [round(float(v), 3) for v in size],
        }
        if part["type"] == "bin":
            cw, cd = part["grid_cells"]["w"], part["grid_cells"]["d"]
            nominal = [42 * cw - 0.5, 42 * cd - 0.5,
                       7 * part["height_units"] + 3.5515]
            front_y = -float(size[1]) / 2        # bins are centered
            z_probe = 5.95 + 5.88 / 2            # label cap mid-height
            n_g, d_min, d_max, wall_ok = groove_depth(
                m, front_y, z_probe, size[0] - 10.0)
            entry["grooves"] = {
                "probe_z": round(z_probe, 2),
                "groove_hits": n_g,
                "depth_min_mm": None if d_min is None else round(d_min, 3),
                "depth_max_mm": None if d_max is None else round(d_max, 3),
                "expected_depth_mm": 0.7,
                "wall_solid_between": wall_ok,
            }
        worst, ceiling_area = downward_angle_stats(m)
        entry["printability"] = {
            "max_overhang_deg_big_faces": round(worst, 1),
            "ceiling_bridge_area_mm2": round(ceiling_area, 2),
            "note": "ceilings are 0.5 mm wide pocket bridges; no supports needed",
        }
        size_ok = all(abs(a - b) < 0.05 for a, b in zip(size, nominal)) \
            if part["type"] == "bin" else None
        entry["size_ok"] = size_ok
        good = binary and watertight and winding and vol > 0
        if size_ok is not None:
            good = good and size_ok
        if "grooves" in entry:
            g = entry["grooves"]
            good = good and n_g > 0 and wall_ok and \
                abs((d_min or 0) - 0.7) < 0.05 and \
                abs((d_max or 0) - 0.7) < 0.05
        entry["pass"] = bool(good)
        ok_all = ok_all and entry["pass"]
        mesh_checks.append(entry)
        print("%-24s binary %d watertight %d vol %9.1f size %s pass %s" %
              (part["id"], binary, watertight, vol,
               entry["size_mm"], entry["pass"]))

    # baseplate specifics: cavity floor via downward ray at cell (0,0) center
    plate = trimesh.load(ROOT / "parts/stl/baseplate_5x4.stl")
    border = assembly["grid"]["border"]
    cx, cy = border + 21, border + 21
    locs, _, _ = plate.ray.intersects_location(
        [[cx, cy, 50]], [[0, 0, -1]], multiple_hits=False)
    floor_z = float(locs[0][2]) if len(locs) else None
    # mounting hole: ray through the hole center must miss
    hm = plate.ray.intersects_any([[border / 2, border / 2, 50]],
                                  [[0, 0, -1]])
    mesh_checks[0]["cavity_floor_z_measured"] = \
        None if floor_z is None else round(floor_z, 3)
    mesh_checks[0]["cavity_floor_z_expected"] = 3.2
    mesh_checks[0]["mount_hole_through"] = bool(not hm[0])
    mesh_checks[0]["pass"] = mesh_checks[0]["pass"] and \
        floor_z is not None and abs(floor_z - 3.2) < 0.05 and not hm[0]
    print("plate cavity floor z=%.3f (expect 3.2), mount hole through=%s" %
          (floor_z or -1, not hm[0]))

    checks["mesh"] = mesh_checks
    checks["mesh_summary"] = {
        "parts": len(mesh_checks),
        "pass": bool(ok_all and mesh_checks[0]["pass"]),
    }
    with open(ROOT / "measured_checks.json", "w") as f:
        json.dump(checks, f, indent=2)
    print("\nmesh checks:", "ALL PASS" if checks["mesh_summary"]["pass"]
          else "FAILURES PRESENT")


if __name__ == "__main__":
    main()
