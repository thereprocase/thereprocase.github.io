"""Build every part of the starter assortment and export STEP + binary STL.

Layout: a 5 x 4 grid (210 x 168 mm) on one baseplate, front row facing -Y:

  row 0 (front, 2U): washers M2 | M2.5 | M3   (2x1, 3 compartments)
                     washers M4              (1x1)
                     nuts M2 | M2.5 | M3     (2x1, 3 compartments)
  row 1 (3U):        nuts M4                (1x1)
                     M2 screws 6/8/12       (2x1, 3 compartments)
                     M2.5 screws 6/8/12     (2x1, 3 compartments)
  row 2 (4U):        M3 screws 6/8/10/12/16  (1x1 each)
  row 3 (4U):        M3x20, M4x8, M4x12, M4x20 (1x1 each) + one spare cell

Bin types are deliberately few: a 1x1 scoop bin and a divided 2x1 scoop bin
(1-3 compartments), each at 2U/3U/4U heights, plus the baseplate.
"""

from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

from build123d import export_step, export_stl

sys.path.insert(0, str(Path(__file__).parent))
import gf_core as core
import gf_labels as lab

ROOT = Path(__file__).resolve().parent.parent
PARTS_DIR = ROOT / "parts"
STEP_DIR = PARTS_DIR / "step"
STL_DIR = PARTS_DIR / "stl"

CELLS_X, CELLS_Y = 5, 4
BORDER = 12.0
SLAB = 3.2
MIN_LABEL_GAP = 1.5          # min material between adjacent compartment labels
                            # (>= two extrusion beads at 0.42: 0.84 mm)

# (id, cells_w, cells_d, units_h, dividers, [(label_text, glyph), ...], cell_x, cell_y)
PARTS = [
    ("bin_washer_m2_m25_m3", 2, 1, 2, 2,
     [("M2", "washer"), ("M2.5", "washer"), ("M3", "washer")], 0, 0),
    ("bin_washer_m4", 1, 1, 2, 0, [("M4", "washer")], 2, 0),
    ("bin_nut_m2_m25_m3", 2, 1, 2, 2,
     [("M2", "nut"), ("M2.5", "nut"), ("M3", "nut")], 3, 0),
    ("bin_nut_m4", 1, 1, 3, 0, [("M4", "nut")], 0, 1),
    ("bin_m2_screws", 2, 1, 3, 2,
     [("M2 × 6", None), ("M2 × 8", None), ("M2 × 12", None)], 1, 1),
    ("bin_m2_5_screws", 2, 1, 3, 2,
     [("M2.5 × 6", None), ("M2.5 × 8", None), ("M2.5 × 12", None)], 3, 1),
    ("bin_m3x6", 1, 1, 4, 0, [("M3 × 6", None)], 0, 2),
    ("bin_m3x8", 1, 1, 4, 0, [("M3 × 8", None)], 1, 2),
    ("bin_m3x10", 1, 1, 4, 0, [("M3 × 10", None)], 2, 2),
    ("bin_m3x12", 1, 1, 4, 0, [("M3 × 12", None)], 3, 2),
    ("bin_m3x16", 1, 1, 4, 0, [("M3 × 16", None)], 4, 2),
    ("bin_m3x20", 1, 1, 4, 0, [("M3 × 20", None)], 0, 3),
    ("bin_m4x8", 1, 1, 4, 0, [("M4 × 8", None)], 1, 3),
    ("bin_m4x12", 1, 1, 4, 0, [("M4 × 12", None)], 2, 3),
    ("bin_m4x20", 1, 1, 4, 0, [("M4 × 20", None)], 3, 3),
    # cell (4, 3) is deliberately left empty: the extension slot
]

SPARE_CELLS = [(4, 3)]


def compact(text: str) -> str:
    return text.replace(" × ", "×")


def fit_labels(labels, pitch: float):
    """Ensure adjacent centered labels keep >= MIN_LABEL_GAP.

    Falls back to the compact 'M3x12' form for the whole bin if the spaced
    form would collide. Returns the (possibly compacted) label list.
    """
    def widths(txts):
        return [lab.measure_text(t) + (lab.GLYPH_GAP + lab.glyph_width(g)
                                      if g else 0.0)
                for t, g in txts]
    if max(widths(labels), default=0) == 0:
        return labels
    ok = True
    ws = widths(labels)
    for a, b in zip(ws, ws[1:]):
        if (a + b) / 2 > pitch - MIN_LABEL_GAP:
            ok = False
    if ok:
        return labels
    labels_c = [(compact(t), g) for t, g in labels]
    ws = widths(labels_c)
    for a, b in zip(ws, ws[1:]):
        assert (a + b) / 2 <= pitch - MIN_LABEL_GAP, \
            f"labels collide even compacted: {labels_c} {ws}"
    return labels_c


def build_bin(spec):
    pid, cw, cd, uh, divs, labels, cx, cy = spec
    w, d = core.bin_footprint(cw, cd)
    centers, iw, comp_w = core.compartment_centers(cw, cd, divs)
    pitch = comp_w + core.DIVIDER_T if divs else w
    labels = fit_labels(labels, pitch)
    label_solids = []
    for (txt, glyph), xc in zip(labels, centers):
        ls, total = lab.label_solid(txt, glyph, xc, y_front=-d / 2,
                                    z_base=core.LABEL_BASELINE_Z)
        # labels must stay on their own wall face: divided bins keep the
        # label inside the compartment clear width (0.3 mm margin per side
        # to the divider faces); 1x1 bins stay on the flat face zone
        if divs:
            lim = comp_w - 0.6
        else:
            lim = (w - 2 * core.R_OUT) - 2.0
        assert total <= lim + 1e-6, \
            f"{pid}: label '{txt}' width {total:.2f} > {lim:.2f}"
        label_solids.append((xc, ls))
    return core.make_bin(cw, cd, uh, divs, label_solids), labels


def main():
    STEP_DIR.mkdir(parents=True, exist_ok=True)
    STL_DIR.mkdir(parents=True, exist_ok=True)

    plate_w = core.GRID * CELLS_X + 2 * BORDER
    plate_d = core.GRID * CELLS_Y + 2 * BORDER
    plate_top = SLAB + core.PLATE_CAVITY_H
    bin_z = plate_top - core.PLATE_CAVITY_H       # bins rest on cavity floor

    assembly = {
        "units": "mm",
        "system": "Gridfinity 42 mm pitch organizer (see README.md)",
        "grid": {"pitch": core.GRID, "cells_x": CELLS_X, "cells_y": CELLS_Y,
                 "border": BORDER,
                 "plate_size": [plate_w, plate_d, plate_top],
                 "height_unit": core.U},
        "parts": [],
        "spare_cells": [{"cell": [c[0], c[1]]} for c in SPARE_CELLS],
    }

    # baseplate: move so front-left corner sits at the origin
    plate = core.make_baseplate(CELLS_X, CELLS_Y, BORDER, SLAB)
    plate_moved = plate.moved(__import__("build123d").Location(
        (plate_w / 2, plate_d / 2, 0)))
    export_step(plate_moved, str(STEP_DIR / "baseplate_5x4.step"))
    export_stl(plate_moved, str(STL_DIR / "baseplate_5x4.stl"))
    assembly["parts"].append({
        "id": "baseplate_5x4",
        "type": "baseplate",
        "stl": "parts/stl/baseplate_5x4.stl",
        "step": "parts/step/baseplate_5x4.step",
        "transform": {"translation": [plate_w / 2, plate_d / 2, 0],
                      "rotation_deg": [0, 0, 0]},
    })
    print(f"plate {plate_w}x{plate_d}x{plate_top} vol {plate.volume:.0f} mm^3")

    for spec in PARTS:
        t0 = time.time()
        pid, cw, cd, uh, divs, labels, cx, cy = spec
        shape, labels_used = build_bin(spec)
        export_step(shape, str(STEP_DIR / f"{pid}.step"))
        export_stl(shape, str(STL_DIR / f"{pid}.stl"))

        # assembled placement: bin local origin is its center (x,y) and z=0
        # at the bin's bottom face; move to cell center on the plate
        tx = BORDER + core.GRID * (cx + cw / 2)
        ty = BORDER + core.GRID * (cy + 0.5)
        assembly["parts"].append({
            "id": pid,
            "type": "bin",
            "grid_cells": {"x": cx, "y": cy, "w": cw, "d": cd},
            "height_units": uh,
            "dividers": divs,
            "compartments": [{"label": t, "glyph": g}
                             for t, g in labels_used],
            "stl": f"parts/stl/{pid}.stl",
            "step": f"parts/step/{pid}.step",
            "transform": {"translation": [tx, ty, bin_z],
                          "rotation_deg": [0, 0, 0]},
        })
        bb = shape.bounding_box()
        print(f"{pid:24s} {cw}x{cd} {uh}U  vol {shape.volume:8.0f}  "
              f"bbox {bb.size.X:.2f}x{bb.size.Y:.2f}x{bb.size.Z:.4f}  "
              f"({time.time()-t0:.1f}s)")

    with open(ROOT / "assembly.json", "w") as f:
        json.dump(assembly, f, indent=2)
    print(f"\nwrote assembly.json with {len(assembly['parts'])} parts")


if __name__ == "__main__":
    main()
