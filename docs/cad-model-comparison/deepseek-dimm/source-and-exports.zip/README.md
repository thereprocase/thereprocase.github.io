# DDR4 pair mailer

A reusable two-stick mailer for desktop DDR4 modules with ordinary
heatspreaders. Two pockets side by side, each module flat in its own
shielding bag on a foam pad, closed by a sliding lid. No hardware, no
hinges, no snap latches, no load on the gold contacts.

Body 147.05 x 108.40 x 20.50 mm, plus 0.8 mm where the embossed end label
stands proud, so its measured bounding box is 147.85 x 108.40 x 20.50 mm.
Lid 142.05 x 104.70 x 2.0 mm plate (158.05 mm including the pull tab).
Closed assembly is 158.85 x 108.40 x 20.50 mm; a stock carton of about
183 x 132 x 44 mm carries it with 12 mm of padding on every side.

## What fits

Supported module envelope, measured over the heatspreader and including
the shielding bag: **133.35 x 44.0 x 9.0 mm**.

- 133.35 mm is the JEDEC DDR4 DIMM length.
- 44.0 mm is the tallest ordinary DDR4 heatspreader. G.SKILL's published
  DDR4 height table lists Trident Z, Trident Z Neo, Trident Z RGB and
  Trident Z Royal all at 44 mm, Sniper X at 43 mm, Ripjaws V at 42 mm,
  Flare X and Ripjaws 4 at 40 mm, and Aegis/Fortis at 31.2 mm.
- 9.0 mm is the widest heatspreader across both plates. Typical
  aluminium plate pairs sit at 7–9 mm; the pocket takes 9 mm plus bag.

Fits: Corsair Vengeance LPX, G.SKILL Ripjaws V (42 mm), Flare X (40 mm),
Aegis/Fortis (31.2 mm), Kingston Fury Beast, Crucial Ballistix, and any
other module whose heatspreader is no taller than 44 mm and no thicker
than 9 mm.

Does not fit: G.SKILL Trident Z RGB DC (59 mm) and other extra-tall
overclocking modules, and RGB diffusers wider than 9 mm across the pair
of plates. Those need a taller box, and this one deliberately does not
grow to cover them.

Each pocket is 137.05 x 47.70 x 12.70 mm. With the module bagged there is
1.85 mm clearance at each end and each side, 1.0 mm above it, and the lid
sits 1.4 mm above the tallest supported module.

## How the lid stays on

The lid is a flat plate whose two long edges are rails. Each rail runs in
a groove cut 3.4 mm into the 5 mm long wall, leaving a 1.6 mm outer skin.
The grooves are closed at the -X end and roofed over, so the lid is
captured in Y and Z: it cannot be lifted off, only slid.

The lid enters at +X and slides until its leading edge meets the closed
-X end wall. A trapezoidal detent bump on the underside of a cantilever
finger cut into each rail drops into a matching pocket in the groove
floor, with 45-degree ramps on both sides. Seated, the bump sits fully
inside the pocket with zero interference. Sliding either way forces the
finger to climb the ramp; the leaf has 1.0 mm of relief above it, more
than the 0.6 mm bump. That click is the retention. A 34 x 16 mm pull tab
overhangs the mouth by 16 mm and carries an engraved PULL label.

The +X end wall is cut down to pocket-top height, so the lid passes over
it while both pockets stay closed. Modules cannot escape through the
mouth.

## How the modules come out

1. Slide the lid out by the tab (one firm pull; the detent clicks twice).
2. At the mouth end of each pocket the plinth is cut away over a 14 mm
   finger well, 30 mm wide, centred on the pocket. The module end
   overhangs that well, so a fingertip goes under the bagged module's
   end and lifts it.
3. Lift the module out flat. Nothing clips it, nothing grips it.

The gold-finger band is never touched. Along the contact edge the pocket
floor drops into a 12 mm wide, 2 mm deep relief channel, so there is air
under the contacts, and the side wall stands bag + 1.5 mm clear of them.
The foam pad is cut back to stop at the edge of that relief channel.

## Files

```
src/params.py      every dimension and the design notes
src/build.py       parametric build123d model; writes parts and assembly.json
checks/check.py    functional checks (36), run after any parameter change
checks/mesh_check.py  trimesh watertightness pass
parts/body.step    parts/body.stl
parts/lid.step     parts/lid.stl
parts/foam_pad_a.step  parts/foam_pad_a.stl
parts/foam_pad_b.step  parts/foam_pad_b.stl
parts/dims.json    measured bounding boxes and volumes
assembly.json      part files and their assembled transforms, in mm
```

Rebuild:

```
python src/build.py
python checks/check.py
```

## Labels

Set in Fillaprint (`assets/fillaprint/Fillaprint-Regular.ttf`, SIL OFL
1.1; licence alongside). The font's guidance is cap height = 14 x
extrusion width and em = 20 x width, with a stated starting point of
5.88 mm caps at a 0.42 mm line width.

- Body end face: **DDR4 PAIR**, 8.0 mm caps, 1.14 mm stroke, embossed
  0.8 mm.
- Both long walls: **SLIDE TO OPEN**, 6.0 mm caps, 0.86 mm stroke,
  engraved 0.6 mm.
- Lid top: **DDR4 ×2**, 8.0 mm caps, 1.14 mm stroke, embossed 0.8 mm.
- Pull tab: **PULL**, 6.0 mm caps, 0.86 mm stroke, engraved 0.6 mm.

Every label is above the 5.88 mm reference, and the two main labels are
1.36x it. Labels are real geometry (embossed or cut), not textures.

## Printing

Body and lid print without support in the orientations they are modelled
in: the body opens upward, the lid plate lies flat with its finger
relief pockets on top. Suggested 0.4 mm nozzle, 0.2 mm layers, 3 walls,
25% infill, PETG or PLA. The cantilever fingers are 1.7 mm wide and
1.2 mm thick; print the lid in a material that flexes a little rather
than a brittle one, and do not use more than 3 perimeters in the finger
region.

## What is verified and what is not

Verified in CAD, by boolean intersection and by mesh inspection:

- Each supported module sits in its pocket with clearance on all six
  faces and zero intersection with the body (checked with a solid at the
  full 133.35 x 44.0 x 9.0 envelope).
- The contact band has air under it and beside it.
- The lid seats with zero interference, cannot be lifted 4 mm without
  colliding with the body, and slides out through the mouth with only
  detent-bump contact.
- All four parts are valid solids and watertight binary STLs.
- The assembly transforms in `assembly.json` place every part with zero
  interference against the body.
- Label cap heights and stroke widths, measured from the actual outlines.

Not verified, and needing a physical test:

- Detent click force and pull-out force. These depend on material,
  layer orientation and printer tolerance; the geometry gives 0.6 mm of
  bump travel and 1.0 mm of finger relief, but the force is unmeasured.
- Finger fatigue over many open/close cycles, and whether the 1.2 mm
  leaf cracks at the root in PLA.
- Sliding fit. Groove clearance is 0.25 mm per side and 0.20 mm
  vertically; on a printer with poor dimensional accuracy this may be
  tight or loose, and the detent may not engage. Print one lid first and
  check the slide before printing the body.
- Whether a particular heatspreader actually measures within
  44 x 9 mm. Measure the sticks before mailing; the envelope is from
  published figures and typical plate spacing, not from every module.
- Drop and crush performance inside the outer carton. The foam pads are
  cut templates, not supplied parts; 1.5 mm closed-cell foam is assumed.
- Bag thickness. 0.35 mm per side is assumed for an anti-static
  shielding bag; thicker bags reduce the clearances listed above.
