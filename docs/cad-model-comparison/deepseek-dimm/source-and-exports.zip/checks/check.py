"""Functional checks against the requested use, not just solid validity.

    python checks/check.py
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "src"))
import params as P                                    # noqa: E402
import build as B                                     # noqa: E402
from build123d import *                               # noqa: E402

results = []


def check(name, ok, detail):
    results.append({"check": name, "pass": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + ": " + detail)


body = B.add_labels_body(B.build_body())
lid = B.build_lid()
lid_seated = B.lid_placed()

# 1. module envelope fits each pocket with clearance on every face
for label, mirror in (("A", False), ("B", True)):
    y0, y1, contact_low = B.pocket_ys()[1 if mirror else 0]
    mx0, mx1, my0, my1 = B.module_box(y0, y1, contact_low)
    bagged_l = P.MOD_LEN + 2 * P.BAG
    bagged_w = P.MOD_TIP_H + 2 * P.BAG
    bagged_d = P.MOD_TIP_T + 2 * P.BAG
    cl = min(mx0 - P.WALL, P.WALL + P.CAV_L - mx1)
    cw = min(my0 - y0, y1 - my1)
    cd = P.POCKET_TOP - P.PLINTH_TOP
    check("pocket %s length clearance" % label, cl >= P.CLEAR - 1e-6,
          "%.2f mm each end (need %.2f)" % (cl, P.CLEAR))
    check("pocket %s width clearance" % label, cw >= P.CLEAR - 1e-6,
          "%.2f mm each side (need %.2f)" % (cw, P.CLEAR))
    check("pocket %s depth clearance" % label, cd - bagged_d >= P.CLEAR_ABOVE - 1e-6,
          "%.2f mm above the bagged module (need %.2f)"
          % (cd - bagged_d, P.CLEAR_ABOVE))

# 2. tallest / widest supported module: build it and test the solid
def module_solid(tall=P.MOD_TIP_H, thick=P.MOD_TIP_T, mirror=False):
    y0, y1, contact_low = B.pocket_ys()[1 if mirror else 0]
    mx0, mx1, my0, my1 = B.module_box(y0, y1, contact_low)
    m = box = Pos((mx0 + mx1) / 2, (my0 + my1) / 2, P.PLINTH_TOP + thick / 2) \
        * Box(P.MOD_LEN, tall, thick)
    return m

for label, mirror in (("A", False), ("B", True)):
    m = module_solid(mirror=mirror)
    inter = body & m
    check("module %s does not touch the body" % label, inter.volume < 1e-6,
          "intersection %.4f mm3" % inter.volume)

# 3. gold-finger band has air under it (relief channel)
for label, mirror in (("A", False), ("B", True)):
    y0, y1, contact_low = B.pocket_ys()[1 if mirror else 0]
    mx0, mx1, my0, my1 = B.module_box(y0, y1, contact_low)
    if contact_low:
        yc = my0 + P.CONTACT_BAND / 2
    else:
        yc = my1 - P.CONTACT_BAND / 2
    xc = (mx0 + mx1) / 2
    # probe a 1 mm cube just under the module in the contact band
    probe = Pos(xc, yc, P.PLINTH_TOP - 1.0) * Box(1, 1, 1)
    solid = (body & probe).volume
    check("contact relief %s is open" % label, solid < 1e-6,
          "material under contacts: %.4f mm3 (relief floor at %.1f mm)"
          % (solid, P.PLINTH_TOP - P.RELIEF_D))
    # side gap from contacts to the wall
    if contact_low:
        gap = my0 - y0
    else:
        gap = y1 - my1
    check("contact side gap %s" % label, gap >= P.BAG + P.CLEAR - 1e-6,
          "%.2f mm from module edge to wall (bag %.2f + air %.2f)"
          % (gap, P.BAG, P.CLEAR))

# 4. lid seated with no interference
inter = body & lid_seated
check("lid seats without interference", inter.volume < 1e-6,
      "intersection %.4f mm3" % inter.volume)
check("lid sits above the modules",
      P.GROOVE_Z0 + P.GROOVE_CLEAR_Z - P.MODULE_TOP >= 1.0,
      "%.2f mm clear above the tallest module"
      % (P.GROOVE_Z0 + P.GROOVE_CLEAR_Z - P.MODULE_TOP))

# 5. lid is captured: cannot lift straight out
lid_up = Pos(0, 0, 4.0) * lid_seated
lift_inter = body & lid_up
check("lid cannot lift out (captured in grooves)", lift_inter.volume > 1.0,
      "lifting 4 mm collides with %.1f mm3 of body material" % lift_inter.volume)

# 6. lid slides out through the mouth.  The only allowed interference is
# the detent bump riding the dimple ramp inside the finger footprint.
def finger_x_range():
    fx1 = P.WALL + P.LID_L - P.FINGER_FROM_TRAIL
    return fx1 - P.FINGER_L, fx1

bump_x = P.WALL + P.LID_L - P.DETENT_FROM_TRAIL_EDGE
trav = 0.0
bad = None
worst = 0.0
while trav <= P.LID_L + 2.0:
    moved = Pos(trav, 0, 0) * lid_seated
    inter = body & moved
    if inter.volume > 1e-6:
        bb = inter.bounding_box()
        # allowed: the detent bump riding the groove floor / dimple ramp,
        # which moves with the lid and sits in a thin band below the floor
        ok_x = bb.min.X >= bump_x + trav - 3.0 and bb.max.X <= bump_x + trav + 3.0
        ok_z = bb.min.Z >= P.GROOVE_Z0 - P.DIMPLE_D - 0.1 and bb.max.Z <= P.GROOVE_Z0 + 0.1
        worst = max(worst, inter.volume)
        if not (ok_x and ok_z):
            bad = (trav, inter.volume, bb)
            break
    trav += 2.0
check("lid slides out through the mouth", bad is None,
      "travel 0-%.0f mm in 2 mm steps; only detent-bump contact (max %.2f mm3)"
      % (P.LID_L, worst) if bad is None else "collision at %.0f mm" % bad[0])

# 6b. detent actually holds the lid: a rigid pull collides with the ramp
held = (body & (Pos(1.0, 0, 0) * lid_seated)).volume
check("detent resists sliding", held > 0.5,
      "1 mm rigid pull collides with %.2f mm3 (finger must flex)" % held)

# 6c. finger has room to flex over the bump
relief = P.FINGER_RELIEF + P.GROOVE_CLEAR_Z
check("finger flex room", relief >= P.DETENT_H,
      "%.2f mm available above the finger, bump is %.2f mm"
      % (relief, P.DETENT_H))

# 7. extraction: finger well exposes the module end
for label, mirror in (("A", False), ("B", True)):
    y0, y1, contact_low = B.pocket_ys()[1 if mirror else 0]
    mx0, mx1, my0, my1 = B.module_box(y0, y1, contact_low)
    yc = (y0 + y1) / 2
    # just above the plinth at the open end, inside the finger well
    probe = Pos(mx1 - 4.0, yc, P.PLINTH_TOP + 0.5) * Box(6, 10, 1)
    solid = (body & probe).volume
    check("finger well %s is open" % label, solid < 1e-6,
          "material beside the module end: %.4f mm3" % solid)

# 8. labels: measured cap height and stroke width vs the font's stated minimum
import subprocess
def glyph_metrics(txt, cap):
    comp = Compound.make_text(txt, font_size=cap / 0.7, font_path=B.FONT)
    bb = comp.bounding_box()
    return bb.size.Y, bb.size.X

for txt, cap in (("DDR4 PAIR", P.CAP), ("SLIDE TO OPEN", P.CAP_SMALL),
                 ("DDR4 ×2", P.CAP), ("PULL", P.CAP_SMALL)):
    h, w = glyph_metrics(txt, cap)
    stroke = 2 * cap / 14.0
    check("label '%s' cap height" % txt, abs(h - cap) < 0.02,
          "%.2f mm cap, %.2f mm stroke, %.1f mm wide" % (h, stroke, w))
    check("label '%s' above font minimum" % txt, cap >= 5.88 - 1e-6,
          "%.2f mm cap vs 5.88 mm reference at w=0.42"
          % cap)

# 9. label widths fit their faces
h, w = glyph_metrics("SLIDE TO OPEN", P.CAP_SMALL)
check("side label fits the long wall", w < P.BODY_L - 2 * P.WALL,
      "%.1f mm text on a %.1f mm wall" % (w, P.BODY_L))
h, w = glyph_metrics("DDR4 PAIR", P.CAP)
check("end label fits the end face", w < P.BODY_W - 2 * P.WALL,
      "%.1f mm text on a %.1f mm face" % (w, P.BODY_W))
h, w = glyph_metrics("DDR4 ×2", P.CAP)
check("lid label fits the lid", w < P.LID_L - P.TAB_L,
      "%.1f mm text on a %.1f mm lid" % (w, P.LID_L))

# 9b. assembly transforms: every part seated with no interference
asm = json.load(open(os.path.join(ROOT, "assembly.json")))
placed = {}
for entry in asm["parts"]:
    t = entry["transform"]["translate"]
    if entry["id"] == "body":
        placed["body"] = body
    elif entry["id"] == "lid":
        placed["lid"] = Pos(*t) * lid
    elif entry["id"] == "foam_pad_a":
        placed["foam_pad_a"] = Pos(*t) * B.build_foam_pad(False)
    else:
        placed["foam_pad_b"] = Pos(*t) * B.build_foam_pad(True)

for pid in ("lid", "foam_pad_a", "foam_pad_b"):
    inter = body & placed[pid]
    check("assembly: %s seated clear of body" % pid, inter.volume < 1e-6,
          "intersection %.4f mm3 at %s" % (inter.volume,
                                           [round(v, 2) for v in asm["parts"][
                                               [p["id"] for p in asm["parts"]].index(pid)
                                           ]["transform"]["translate"]]))

# foam must stay off the contact band
for pid in ("foam_pad_a", "foam_pad_b"):
    pad = placed[pid]
    bb = pad.bounding_box()
    y0, y1, contact_low = B.pocket_ys()[0 if pid == "foam_pad_a" else 1]
    mx0, mx1, my0, my1 = B.module_box(y0, y1, contact_low)
    if contact_low:
        relief_end = my0 + P.RELIEF_W
        check("foam A clear of contacts", bb.min.Y >= relief_end,
              "pad starts at y=%.2f, contact relief ends at %.2f"
              % (bb.min.Y, relief_end))
    else:
        relief_start = my1 - P.RELIEF_W
        check("foam B clear of contacts", bb.max.Y <= relief_start,
              "pad ends at y=%.2f, contact relief starts at %.2f"
              % (bb.max.Y, relief_start))

# 10. STL sanity via trimesh
print()
os.system("python -I " +
          os.path.join(HERE, "mesh_check.py"))

json.dump(results, open(os.path.join(HERE, "results.json"), "w"), indent=2)
fails = [r for r in results if not r["pass"]]
print("\n%d checks, %d failed" % (len(results), len(fails)))
sys.exit(1 if fails else 0)
