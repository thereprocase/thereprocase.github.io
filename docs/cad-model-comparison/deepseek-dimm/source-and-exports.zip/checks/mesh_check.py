"""Mesh-level checks with the physics runtime (trimesh)."""
import os
import trimesh
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ok = True
for name in ("body", "lid", "foam_pad_a", "foam_pad_b"):
    m = trimesh.load(os.path.join(ROOT, "parts", name + ".stl"), force="mesh")
    e = m.edges_sorted
    _, cnt = np.unique(e, axis=0, return_counts=True)
    boundary = int((cnt == 1).sum())
    print("%-12s tris %5d  watertight %-5s  boundary edges %d  volume %9.1f mm3"
          % (name, len(m.faces), m.is_watertight, boundary, m.volume))
    ok = ok and m.is_watertight and boundary == 0
print("mesh check", "PASS" if ok else "FAIL")
