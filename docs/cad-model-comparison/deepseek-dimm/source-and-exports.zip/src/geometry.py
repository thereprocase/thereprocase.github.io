"""Shared geometry helpers for the DDR4 mailer."""
from build123d import *

def box_at(x0, y0, z0, dx, dy, dz):
    """Axis-aligned box from a minimum corner and three sizes."""
    return Pos(x0 + dx / 2, y0 + dy / 2, z0 + dz / 2) * Box(dx, dy, dz)

def text_solid(txt, cap, font_path, z=0.0):
    """Fillaprint text as a sketch, positioned with its baseline at y=0."""
    comp = Compound.make_text(txt, font_size=cap / 0.7, font_path=font_path)
    faces = [f for f in comp.faces()]
    sk = Sketch() + faces
    return sk
