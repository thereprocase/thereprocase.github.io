"""Parameters for the DDR4 pair mailer.  Millimetres throughout.

Frame (all parts built in the positive octant)
  X = module length; X = 0 is the closed end, +X the open end
  Y = module height; pocket A at low Y, pocket B at high Y
  Z = stack; body underside at Z = 0

Vertical stack inside a pocket
  0.0 - 3.0    body floor skin
  3.0 - 5.0    plinth bed; 1.5 mm foam recess for a foam pad
  5.0 - 14.7   module in its bag (9.0 heatspreader + 0.35 bag per side)
 14.7 - 15.7   clearance under the lid
 15.7         body rim / pocket top
 15.9 - 18.3  lid plate, captured in closed grooves in the long walls

Modules lie FLAT, broad face down on a 1.5 mm closed-cell foam pad.  The
gold-finger band along the contact edge overhangs a 12 mm wide, 2 mm deep
relief channel, so no surface touches the contacts; the pocket wall also
stands bag + 1.5 mm clear of them.  Pockets face opposite ways.

Extraction: at the open end of each pocket the plinth is cut away over a
14 mm finger well, so the module end overhangs and can be pinched up.

Lid: a flat plate with two side rails.  The rails run in CLOSED grooves
cut horizontally into the long walls, so the lid is captured in Y and Z
and cannot be lifted off; it can only slide in X.  It enters at +X, slides
until its leading edge meets the closed -X end wall.  A cantilever finger
cut into each rail carries a 0.6 mm bump that drops into a dimple in the
groove floor: the finger flexes as the lid passes, then clicks into the
dimple, holding the lid shut with no interference in the seated state.
Pull the overhanging tab at +X to flex the fingers back and slide it out.
The +X end wall is cut down to pocket-top height so the lid passes over it
while the pockets stay closed.
"""

# ----------------------------------------------------------------- module
MOD_LEN = 133.35
MOD_PCB_H = 31.25
MOD_TIP_H = 44.0
MOD_TIP_T = 9.0
BAG = 0.35
CLEAR = 1.5
CONTACT_BAND = 10.0

# ------------------------------------------------------------------- body
WALL = 5.0                 # 5 mm walls: 3.4 mm groove + 1.6 mm outer skin
FLOOR = 3.0
PLINTH = 2.0
DIVIDER = 3.0
CLEAR_ABOVE = 1.0

POCKET_L = MOD_LEN + 2 * BAG + 2 * CLEAR          # 137.05
POCKET_W = MOD_TIP_H + 2 * BAG + 2 * CLEAR        # 47.70
POCKET_D = MOD_TIP_T + 2 * BAG + 2 * CLEAR        # 11.70

CAV_L = POCKET_L
CAV_W = 2 * POCKET_W + DIVIDER                    # 98.40

BODY_L = CAV_L + 2 * WALL                          # 145.05
BODY_W = CAV_W + 2 * WALL                          # 106.40
PLINTH_TOP = FLOOR + PLINTH                        # 5.0
MODULE_TOP = PLINTH_TOP + MOD_TIP_T + 2 * BAG      # 14.7
POCKET_TOP = MODULE_TOP + CLEAR_ABOVE              # 15.7

FOAM_T = 1.5
FOAM_BORDER = 2.0
RELIEF_D = 2.0
RELIEF_W = CONTACT_BAND + 2.0                      # 12.0

FINGER_WELL_L = 14.0
FINGER_WELL_W = 30.0

# --------------------------------------------------------------------- lid
LID_T = 2.4
GROOVE_D = 3.4            # groove depth; leaves 1.6 mm outer skin
# The lid rail occupies the groove.  A cantilever finger is cut from the
# rail's inner strip, leaving an outer strip that stays in the groove and
# keeps the lid captured.
FINGER_W = 1.7            # finger width in Y
FINGER_GAP = 0.30         # slit between finger and outer strip
RAIL_INNER = FINGER_GAP   # inner clearance strip of the rail
GROOVE_CLEAR_Y = 0.25     # rail-to-groove side clearance
GROOVE_CLEAR_Z = 0.20     # rail-to-groove vertical clearance
RAIL_T = 2.0              # lid plate thickness (rail section)
GROOVE_Z0 = POCKET_TOP + 0.2       # groove floor
GROOVE_ROOF = 1.8                  # material above the groove
BODY_H = GROOVE_Z0 + LID_T + 2 * GROOVE_CLEAR_Z + GROOVE_ROOF

LID_W = CAV_W + 2 * GROOVE_D - 2 * GROOVE_CLEAR_Y   # 103.1

LID_L = BODY_L - WALL      # leading edge stops against the -X end wall
LID_LEAD_GAP = 0.0
TAB_L = 16.0               # tab overhangs the mouth for grip
TAB_W = 34.0
TAB_T = 2.0

# cantilever detent finger cut into each rail
FINGER_L = 26.0
FINGER_SLIT = 0.6
FINGER_RELIEF = 0.8       # pocket cut into the finger's top face, giving
                          # the leaf room to flex up over the detent bump
FINGER_T = RAIL_T - FINGER_RELIEF   # 1.2 mm leaf thickness
FINGER_FROM_TRAIL = 12.0
# Detent: the finger carries a 0.6 mm dome on its underside.  A matching
# 0.6 mm deep pocket in the groove floor (with 45-degree ramps at both ends)
# swallows the dome when the lid is fully home, so the seated state has no
# interference at all.  Sliding either way forces the finger to climb the
# ramp: that lift is the click and the anti-slide retention.
DETENT_R = 1.2
DETENT_H = 0.6
DIMPLE_D = 0.6
DIMPLE_L = 3.0
# dome centre, measured from the lid's trailing edge.  The finger is fixed
# at its trailing end and free at its leading end, so the dome sits near the
# free end where compliance is greatest.
DETENT_FROM_TRAIL_EDGE = FINGER_FROM_TRAIL + FINGER_L - 4.0

# ------------------------------------------------------------------ labels
FONT = "assets/fillaprint/Fillaprint-Regular.ttf"
CAP = 8.0                 # Fillaprint stroke = 2*CAP/14 = 1.14 mm
CAP_SMALL = 6.0           # above the 5.88 mm reference
RAISE = 0.8
ENGRAVE = 0.6

# ------------------------------------------------------------------ carton
CARTON_L = BODY_L + TAB_L + 20.0
CARTON_W = BODY_W + 24.0
CARTON_H = BODY_H + 24.0
