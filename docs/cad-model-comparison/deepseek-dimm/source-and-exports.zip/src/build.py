"""Parametric build of the DDR4 pair mailer.

    python src/build.py

Writes parts/*.step, parts/*.stl (binary), parts/dims.json.
Geometry is built in the positive octant; see src/params.py for the frame.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import params as P                                   # noqa: E402
from build123d import *                              # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "parts")
os.makedirs(OUT, exist_ok=True)
FONT = os.path.join(ROOT, P.FONT)


def box(x0, y0, z0, dx, dy, dz):
    return Pos(x0 + dx / 2, y0 + dy / 2, z0 + dz / 2) * Box(dx, dy, dz)


def label_sketch(txt, cap):
    comp = Compound.make_text(txt, font_size=cap / 0.7, font_path=FONT)
    return Sketch() + list(comp.faces())


def pocket_ys():
    return [(P.WALL, P.WALL + P.POCKET_W, True),
            (P.WALL + P.POCKET_W + P.DIVIDER, P.WALL + P.CAV_W, False)]


def module_box(y0, y1, contact_low):
    mx0 = P.WALL + (P.CAV_L - P.MOD_LEN) / 2
    if contact_low:
        my0 = y0 + (P.POCKET_W - P.MOD_TIP_H) / 2
        my1 = my0 + P.MOD_TIP_H
    else:
        my1 = y1 - (P.POCKET_W - P.MOD_TIP_H) / 2
        my0 = my1 - P.MOD_TIP_H
    return mx0, mx0 + P.MOD_LEN, my0, my1



def detent_pocket(x, y0, width, z_face, depth, sign):
    """Trapezoidal detent profile, extruded across `width` in Y.

    sign=-1 cuts a pocket downward into the groove floor (body);
    sign=+1 builds a proud bump downward from the lid finger underside.
    Ramp angle is 45 degrees, so the finger rides up smoothly.
    """
    d, ramp, half = depth, depth, P.DIMPLE_L / 2
    pts = [(x - half - ramp, z_face),
           (x - half, z_face + sign * d),
           (x + half, z_face + sign * d),
           (x + half + ramp, z_face)]
    with BuildSketch(Plane.XZ) as sk:
        with BuildLine():
            Polyline(*pts, close=True)
        make_face()
    return Pos(0, y0, 0) * extrude(sk.sketch, amount=width, dir=(0, 1, 0))



def text_solid(txt, cap):
    """Fillaprint text extruded +Z, centred in XY with its baseline at y=0."""
    comp = Compound.make_text(txt, font_size=cap / 0.7, font_path=FONT)
    sk = Sketch() + list(comp.faces())
    bb = sk.bounding_box()
    # centre horizontally; put the cap-height centre on y=0
    return Pos(-(bb.min.X + bb.max.X) / 2, -(bb.min.Y + bb.max.Y) / 2, 0) * \
        extrude(sk, amount=0)


def label_on_plane(txt, cap, plane, depth, emboss=True):
    """Text placed on `plane` and extruded along the plane normal."""
    comp = Compound.make_text(txt, font_size=cap / 0.7, font_path=FONT)
    sk = Sketch() + list(comp.faces())
    bb = sk.bounding_box()
    sk = Pos(-(bb.min.X + bb.max.X) / 2, -(bb.min.Y + bb.max.Y) / 2, 0) * sk
    solid = extrude(sk, amount=depth)
    return plane * solid


def wall_plane(y, outward):
    """Plane on a long wall: text reads horizontally, up is +Z."""
    if outward < 0:
        return Plane(origin=(0, y, 0), x_dir=(1, 0, 0), z_dir=(0, -1, 0))
    return Plane(origin=(0, y, 0), x_dir=(-1, 0, 0), z_dir=(0, 1, 0))


def end_plane(x, outward):
    """Plane on an end wall: text reads along Y, up is +Z."""
    if outward < 0:
        return Plane(origin=(x, 0, 0), x_dir=(0, -1, 0), z_dir=(-1, 0, 0))
    return Plane(origin=(x, 0, 0), x_dir=(0, 1, 0), z_dir=(1, 0, 0))

# --------------------------------------------------------------------- body
def build_body():
    body = box(0, 0, 0, P.BODY_L, P.BODY_W, P.BODY_H)
    body -= box(P.WALL, P.WALL, P.FLOOR,
                P.CAV_L, P.CAV_W, P.BODY_H - P.FLOOR + 1.0)

    y_div = P.WALL + P.POCKET_W
    body += box(P.WALL, y_div, P.FLOOR,
                P.CAV_L, P.DIVIDER, P.POCKET_TOP - P.FLOOR)

    for y0, y1, contact_low in pocket_ys():
        body += box(P.WALL, y0, P.FLOOR, P.CAV_L, y1 - y0, P.PLINTH)
        mx0, mx1, my0, my1 = module_box(y0, y1, contact_low)

        if contact_low:
            r0, r1 = y0, my0 + P.RELIEF_W
        else:
            r0, r1 = my1 - P.RELIEF_W, y1
        body -= box(P.WALL, r0, P.PLINTH_TOP - P.RELIEF_D,
                    P.CAV_L, r1 - r0, P.RELIEF_D)

        if contact_low:
            f0, f1 = max(my0 + P.RELIEF_W, y0), min(my1 + P.FOAM_BORDER, y1)
        else:
            f0, f1 = max(my0 - P.FOAM_BORDER, y0), min(my1 - P.RELIEF_W, y1)
        fx0 = max(mx0 - P.FOAM_BORDER, P.WALL)
        fx1 = min(mx1 + P.FOAM_BORDER, P.WALL + P.CAV_L)
        body -= box(fx0, f0, P.PLINTH_TOP - P.FOAM_T,
                    fx1 - fx0, f1 - f0, P.FOAM_T)

        wy0 = (y0 + y1) / 2 - P.FINGER_WELL_W / 2
        body -= box(P.WALL + P.CAV_L - P.FINGER_WELL_L, wy0, P.FLOOR,
                    P.FINGER_WELL_L + 1.0, P.FINGER_WELL_W,
                    P.PLINTH_TOP - P.FLOOR + 0.1)

    # closed lid grooves in the long walls: full length, roofed over
    for gy0 in (P.WALL - P.GROOVE_D, P.WALL + P.CAV_W):
        body -= box(P.WALL, gy0, P.GROOVE_Z0, P.BODY_L - P.WALL + 2.0,
                    P.GROOVE_D, P.LID_T + 2 * P.GROOVE_CLEAR_Z)

    # detent dimple in each groove floor, with 45-degree ramps at both ends
    dome_x = P.WALL + P.LID_L - P.DETENT_FROM_TRAIL_EDGE
    for gy0 in (P.WALL - P.GROOVE_D, P.WALL + P.CAV_W):
        yc = gy0 + P.GROOVE_D / 2
        body -= detent_pocket(dome_x, gy0, P.GROOVE_D, P.GROOVE_Z0,
                              P.DIMPLE_D, -1)


    # mouth: the +X end wall above pocket-top is cut away across the full
    # lid cross-section, leaving the pockets closed and giving the lid a
    # 4 mm deep entry slot
    body -= box(P.WALL + P.CAV_L, P.WALL - P.GROOVE_D, P.POCKET_TOP,
                P.WALL + 1.0, P.CAV_W + 2 * P.GROOVE_D,
                P.BODY_H - P.POCKET_TOP + 1.0)
    return body


def add_labels_body(body):
    # -X end face: main title, embossed
    pl = end_plane(0.0, -1)
    pl = pl.offset(-P.RAISE) * Plane.XY.offset(0) if False else pl
    lab = label_on_plane("DDR4 PAIR", P.CAP,
                         Plane(origin=(0, P.BODY_W / 2, P.BODY_H / 2),
                               x_dir=(0, -1, 0), z_dir=(-1, 0, 0)),
                         P.RAISE)
    body += lab

    # long walls: engraved handling instruction, centred.  The plane keeps
    # its OUTWARD normal so the letters read correctly from outside; the cut
    # is made with a negative extrusion, into the wall.
    for y, out in ((0.0, -1), (P.BODY_W, 1)):
        pl = Plane(origin=(P.BODY_L / 2, y, P.BODY_H / 2),
                   x_dir=(1, 0, 0) if out < 0 else (-1, 0, 0),
                   z_dir=(0, -1, 0) if out < 0 else (0, 1, 0))
        body -= label_on_plane("SLIDE TO OPEN", P.CAP_SMALL, pl, -P.ENGRAVE)
    return body


# ---------------------------------------------------------------------- lid
def build_lid():
    L, W = P.LID_L, P.LID_W
    lid = box(0, 0, 0, L, W, P.RAIL_T)

    # pull tab on the trailing edge, same thickness as the plate
    lid += box(L, W / 2 - P.TAB_W / 2, 0, P.TAB_L, P.TAB_W, P.TAB_T)

    # cantilever detent fingers: a slit pair along X plus one across at the
    # free end isolates a leaf on the inner side of each rail.  The outer
    # strip of the rail stays solid, so the lid remains captured in Z.
    fx1 = L - P.FINGER_FROM_TRAIL
    fx0 = fx1 - P.FINGER_L
    # rail strips: the outer 3.15 mm of each side.  Finger sits on the inner
    # part of the strip; the outer 0.35 mm stays solid and keeps the lid in
    # the groove.
    for fy0 in (0.0, W - P.FINGER_W):
        inner = fy0 < W / 2
        if inner:
            # finger 0..2.2, gap 2.2..2.8, outer strip 2.8..3.15
            gap0 = fy0 + P.FINGER_W
            end_slit = (fx0, fy0 - P.FINGER_GAP, P.FINGER_GAP)
        else:
            # outer strip 101.55..101.9, gap 101.9..102.5, finger 102.5..104.7
            gap0 = fy0 - P.FINGER_GAP
            end_slit = (fx0, fy0, P.FINGER_GAP)
        lid -= box(fx0, gap0, -1.0, P.FINGER_L, P.FINGER_GAP, P.RAIL_T + 2.0)
        lid -= box(end_slit[0], end_slit[1], -1.0, end_slit[2],
                   P.FINGER_W + P.FINGER_GAP, P.RAIL_T + 2.0)
        # relief pocket on the finger's top face so the leaf can flex up
        # clear of the groove roof when the bump rides out of the dimple
        lid -= box(fx0, fy0, P.RAIL_T - P.FINGER_RELIEF,
                   P.FINGER_L, P.FINGER_W, P.FINGER_RELIEF + 0.5)
        # bump hangs BELOW the finger underside (sign=-1), so it engages the
        # dimple in the groove floor and must climb out to let the lid slide
        lid += detent_pocket(L - P.DETENT_FROM_TRAIL_EDGE, fy0,
                             P.FINGER_W, 0.0, P.DETENT_H, -1)

    top = Plane(origin=((L + P.TAB_L) / 2, W / 2, P.RAIL_T),
                x_dir=(1, 0, 0), z_dir=(0, 0, 1))
    lid += label_on_plane("DDR4 ×2", P.CAP, top, P.RAISE)
    tabp = Plane(origin=(L + P.TAB_L / 2, W / 2, P.TAB_T),
                 x_dir=(1, 0, 0), z_dir=(0, 0, 1))
    lid -= label_on_plane("PULL", P.CAP_SMALL, tabp, -(P.ENGRAVE + 0.2))
    return lid


# --------------------------------------------------------------- foam pad
def build_foam_pad(mirror_y=False):
    y0, y1, contact_low = pocket_ys()[1 if mirror_y else 0]
    mx0, mx1, my0, my1 = module_box(y0, y1, contact_low)
    if contact_low:
        f0 = max(my0 + P.RELIEF_W, y0)
        f1 = min(my1 + P.FOAM_BORDER, y1)
    else:
        f0 = max(my0 - P.FOAM_BORDER, y0)
        f1 = min(my1 - P.RELIEF_W, y1)
    # full FOAM_T thickness, 0.3 mm clearance all round so the pad drops
    # into the recess freely.  Its top face is flush with the plinth, so the
    # module rests on foam, not on bare plastic.
    pad = box(mx0 - P.FOAM_BORDER + 0.3, f0 + 0.3, 0,
              P.MOD_LEN + 2 * P.FOAM_BORDER - 0.6, f1 - f0 - 0.6,
              P.FOAM_T)
    try:
        pad = fillet(pad.edges().filter_by(Axis.Z), radius=3.0)
    except Exception:
        pass
    return pad


def lid_placed():
    """Lid seated, in the body frame."""
    lid = build_lid()
    return Pos(P.WALL + P.LID_LEAD_GAP, P.WALL - P.GROOVE_D + P.GROOVE_CLEAR_Y,
               P.GROOVE_Z0 + P.GROOVE_CLEAR_Z) * lid


def assembled_transforms():
    """Actual placement of each part in the closed, loaded assembly."""
    foam_a_z = P.PLINTH_TOP - P.FOAM_T
    foam_b_z = foam_a_z
    # foam pads are built in their own pocket coordinates, so they are
    # already in the body frame when seated in the recess
    return {
        "body":      {"translate": [0.0, 0.0, 0.0], "rotate": [0, 0, 0]},
        "lid":       {"translate": [P.WALL, P.WALL - P.GROOVE_D + P.GROOVE_CLEAR_Y,
                                    P.GROOVE_Z0 + P.GROOVE_CLEAR_Z],
                      "rotate": [0, 0, 0]},
        "foam_pad_a": {"translate": [0.0, 0.0, foam_a_z], "rotate": [0, 0, 0]},
        "foam_pad_b": {"translate": [0.0, 0.0, foam_b_z], "rotate": [0, 0, 0]},
    }


if __name__ == "__main__":
    body = add_labels_body(build_body())
    lid = build_lid()
    foam_a = build_foam_pad()
    foam_b = build_foam_pad(mirror_y=True)
    parts = {"body": body, "lid": lid,
             "foam_pad_a": foam_a, "foam_pad_b": foam_b}
    dims = {}
    for name, part in parts.items():
        bb = part.bounding_box()
        dims[name] = {
            "valid": part.is_valid,
            "volume_mm3": round(part.volume, 1),
            "bbox_mm": [round(bb.size.X, 2), round(bb.size.Y, 2),
                        round(bb.size.Z, 2)],
        }
        print(name, dims[name])
        export_step(part, os.path.join(OUT, name + ".step"))
        export_stl(part, os.path.join(OUT, name + ".stl"), ascii_format=False)
    json.dump(dims, open(os.path.join(OUT, "dims.json"), "w"), indent=2)

    asm = {
        "units": "mm",
        "frame": {
            "description": "positive octant; X = module length, Y = module height, Z = up",
            "body_origin": [0, 0, 0],
        },
        "parts": [
            {"id": "body", "file": "parts/body.step",
             "mesh": "parts/body.stl",
             "transform": assembled_transforms()["body"]},
            {"id": "lid", "file": "parts/lid.step",
             "mesh": "parts/lid.stl",
             "transform": assembled_transforms()["lid"]},
            {"id": "foam_pad_a", "file": "parts/foam_pad_a.step",
             "mesh": "parts/foam_pad_a.stl",
             "transform": assembled_transforms()["foam_pad_a"]},
            {"id": "foam_pad_b", "file": "parts/foam_pad_b.step",
             "mesh": "parts/foam_pad_b.stl",
             "transform": assembled_transforms()["foam_pad_b"]},
        ],
        "notes": [
            "Lid enters at +X and slides to -X until its leading edge meets "
            "the body's closed end wall.",
            "Foam pads are consumables cut from 1.5 mm closed-cell foam; the "
            "STLs are cut templates.",
            "Modules are not modelled as parts; the supported envelope is "
            "133.35 x 44.0 x 9.0 mm bagged.",
        ],
    }
    json.dump(asm, open(os.path.join(ROOT, "assembly.json"), "w"), indent=2)
    print("exported to", OUT)
