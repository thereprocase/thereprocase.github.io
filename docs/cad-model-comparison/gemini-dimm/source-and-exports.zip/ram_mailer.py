#!/usr/bin/env python3
"""
Parametric CAD model for a Reusable Dual-Stick Desktop DDR4 UDIMM Mailer.
Parts:
  - mailer_base: Dual-bay pin-safe cradle tray with end saddles, 4.0 mm deep
    gold-contact relief trench, wide central finger-pinch retrieval cutout,
    and integrated dual cantilever snap-latches with textured thumb buttons.
  - mailer_lid: Deep telescoping protective cover with internal latch keeper
    grooves, thumb-release access cutouts, upper center divider fin, end ceiling
    pads, and central foam/paper cushion vault.
  - FillaPrint labels debossed on horizontal top and bottom exterior faces at
    >= 9.0 mm font_size (>= 6.30 mm cap height, >= 0.90 mm stroke width).
"""

from dataclasses import dataclass
from pathlib import Path
from build123d import *


@dataclass(frozen=True)
class MailerParams:
    # Supported module envelope (each bay, bagged + light paper/foam damping)
    supported_length_min: float = 133.0
    supported_length_max: float = 140.0
    supported_height_min: float = 30.0
    supported_height_max: float = 43.0
    supported_thickness_min: float = 3.5
    supported_thickness_max: float = 8.5

    # Exterior envelope (mm)
    outer_length: float = 160.00   # X in [-80.00, +80.00]
    outer_width: float = 38.40     # Y in [-19.20, +19.20]
    outer_height: float = 56.00    # Z in [0.00, 56.00]
    outer_corner_r: float = 3.60
    outer_edge_chamfer: float = 1.00

    # Bay cross-section (Y axis)
    divider_t: float = 3.60        # Y in [-1.80, +1.80]
    bay_w: float = 12.60           # Bay 1: [+1.80, +14.40], Bay 2: [-14.40, -1.80]
    neck_side_wall_t: float = 2.20 # Base neck outer Y = +/- 16.60
    xy_clearance: float = 0.25     # Lid inner skirt Y = +/- 16.85 (lid wall = 2.35 mm)

    # Bay longitudinal layout (X axis)
    contact_trench_half_x: float = 64.50  # 129.0 mm central pin-free span at saddle plane (127.0 mm at floor)
    bay_lower_half_x: float = 68.20       # 136.4 mm lower PCB locating span
    bay_upper_half_x: float = 71.80       # 143.6 mm upper heatspreader + bag span
    bag_tail_slot_w: float = 6.60         # Central slot at ends for folded bag corners
    base_inner_end_x: float = 74.00       # Solid inner end wall: |X| in [71.80, 74.00]

    # Cantilever latch geometry (X axis at each end)
    latch_gap_outer_x: float = 75.75      # Flex travel gap: |X| in [74.00, 75.75] (1.75 mm)
    latch_shaft_outer_x: float = 77.55    # Beam thickness t = 1.80 mm: [75.75, 77.55]
    latch_catch_peak_x: float = 78.65     # Detent nose protrusion = 1.10 mm
    latch_button_outer_x: float = 79.80   # Thumb button outer face
    latch_beam_w: float = 13.60           # Y in [-6.80, +6.80]
    latch_slot_w: float = 0.70            # Side clearance slots: |Y| in [6.80, 7.50]

    # Lid end skirt & keeper groove (X axis)
    lid_end_inner_x: float = 77.80        # 0.25 mm clearance to 77.55 mm neck/shaft
    lid_keeper_peak_x: float = 78.95      # 0.30 mm static clearance to 78.65 mm catch

    # Vertical stack-up (Z axis)
    z_bottom: float = 0.00
    z_trench_floor: float = 3.00          # 4.0 mm below saddle plane
    z_saddle: float = 7.00                # Raised end-saddles support non-contact ends
    z_lower_step: float = 12.00           # Height where bay widens from 137.0 to 143.6 mm
    z_latch_root: float = 9.00            # Cantilever root
    z_parting_base: float = 16.00         # Base lower exterior shoulder
    z_parting_lid: float = 16.20          # Lid bottom skirt rim (0.20 mm gap)
    z_pinch_waist: float = 19.00          # Central finger-pinch cutout floor
    z_catch_bot: float = 21.50
    z_catch_peak: float = 24.00
    z_catch_top: float = 26.50
    z_button_top: float = 32.50
    z_base_top: float = 34.00             # End cradle wall top rim
    z_lid_divider_bot: float = 34.60      # Upper divider bottom edge (0.60 mm clearance)
    z_lid_end_pad: float = 50.50          # 43.5 mm above z_saddle (fits <= 43 mm sticks)
    z_lid_vault: float = 53.00            # 46.0 mm above z_saddle (central foam/pin vault)
    z_top: float = 56.00

    # Central finger-pinch retrieval cutout (X axis)
    pinch_flat_half_x: float = 27.00      # 54.0 mm flat bottom at Z = 19.00
    pinch_top_half_x: float = 42.00       # 45-deg ramps up to Z = 34.00 at |X| = 42.00

    # FillaPrint typography parameters
    font_path: str = "assets/fillaprint/Fillaprint-Regular.ttf"
    text_depth: float = 0.60
    lid_title_size: float = 11.0          # Cap height = 7.70 mm, stroke = 1.10 mm
    lid_sub_size: float = 9.0             # Cap height = 6.30 mm, stroke = 0.90 mm
    base_line1_size: float = 9.5          # Cap height = 6.65 mm, stroke = 0.95 mm
    base_line2_size: float = 9.0          # Cap height = 6.30 mm, stroke = 0.90 mm


def _rounded_rect_prism(length: float, width: float, height: float, radius: float, z0: float = 0.0) -> Solid:
    """Create a Z-extruded rounded rectangle prism spanning z0 .. z0 + height."""
    sk = RectangleRounded(length, width, radius)
    solid = extrude(sk, amount=height)
    if z0 != 0.0:
        solid = Pos(0, 0, z0) * solid
    return solid


def build_mailer_base(p: MailerParams = MailerParams()) -> Part:
    """Build the mailer_base part in assembled world coordinates."""
    half_L = p.outer_length / 2.0
    half_W = p.outer_width / 2.0
    neck_half_L = p.latch_shaft_outer_x   # 77.55 mm
    neck_half_W = p.divider_t / 2.0 + p.bay_w + p.neck_side_wall_t  # 16.60 mm
    neck_corner_r = max(1.2, p.outer_corner_r - (half_W - neck_half_W))

    # 1. Lower base body (Z = 0 .. 16.00)
    lower_body = _rounded_rect_prism(
        p.outer_length, p.outer_width, p.z_parting_base, p.outer_corner_r, z0=0.0
    )
    # Chamfer bottom outer perimeter edge for clean printing and pleasant handling
    bot_edges = lower_body.edges().filter_by_position(
        Axis.Z, minimum=-0.01, maximum=0.01
    )
    lower_body = chamfer(bot_edges, length=p.outer_edge_chamfer)

    # 2. Upper stepped neck block (Z = 16.00 .. 34.00)
    upper_neck = _rounded_rect_prism(
        2.0 * neck_half_L,
        2.0 * neck_half_W,
        p.z_base_top - p.z_parting_base,
        neck_corner_r,
        z0=p.z_parting_base,
    )
    base = lower_body + upper_neck

    # 3. Carve out the two RAM module bays (Bay 1 at +Y, Bay 2 at -Y)
    bay_y_centers = [
        +(p.divider_t / 2.0 + p.bay_w / 2.0),  # +8.10 mm
        -(p.divider_t / 2.0 + p.bay_w / 2.0),  # -8.10 mm
    ]
    for yc in bay_y_centers:
        # 3a. Upper bay volume (Z = 12.00 .. 36.00, X in [-71.80, +71.80])
        upper_bay = Pos(0, yc, p.z_lower_step) * Box(
            2.0 * p.bay_upper_half_x,
            p.bay_w,
            p.z_base_top - p.z_lower_step + 2.0,
            align=(Align.CENTER, Align.CENTER, Align.MIN),
        )
        # 3b. Lower PCB locating zone (Z = 7.00 .. 12.00, X in [-68.50, +68.50])
        lower_bay = Pos(0, yc, p.z_saddle) * Box(
            2.0 * p.bay_lower_half_x,
            p.bay_w,
            p.z_lower_step - p.z_saddle + 0.1,
            align=(Align.CENTER, Align.CENTER, Align.MIN),
        )
        # 3c. Tapered transition between lower PCB zone (68.50) and upper zone (71.80)
        # Plus central bag-tail relief slot (width 6.60 mm) all the way down to Z = 7.00
        bag_tail_slot = Pos(0, yc, p.z_saddle) * Box(
            2.0 * p.bay_upper_half_x,
            p.bag_tail_slot_w,
            p.z_base_top - p.z_saddle + 2.0,
            align=(Align.CENTER, Align.CENTER, Align.MIN),
        )
        # 3d. Central gold-contact relief trench (Z = 3.00 .. 7.00, X in [-64.50, +64.50] at top, [-63.50, +63.50] at floor)
        trench_pts = [
            (-p.contact_trench_half_x, p.z_saddle + 0.05),
            (-p.contact_trench_half_x + 1.0, p.z_trench_floor),
            (p.contact_trench_half_x - 1.0, p.z_trench_floor),
            (p.contact_trench_half_x, p.z_saddle + 0.05),
        ]
        trench_prof = Plane.XZ * Polyline(trench_pts, close=True)
        trench_face = make_face(trench_prof)
        trench_cut = Pos(0, yc, 0) * extrude(trench_face, amount=p.bay_w / 2.0, both=True)

        # Ramp from lower_bay (68.5) to upper_bay (71.8) across Z = 10.0 .. 12.0
        end_ramp_pts = [
            (-p.bay_lower_half_x, p.z_lower_step - 2.5),
            (-p.bay_upper_half_x, p.z_lower_step),
            (-p.bay_upper_half_x, p.z_base_top + 1.0),
            (p.bay_upper_half_x, p.z_base_top + 1.0),
            (p.bay_upper_half_x, p.z_lower_step),
            (p.bay_lower_half_x, p.z_lower_step - 2.5),
        ]
        end_ramp_face = make_face(Plane.XZ * Polyline(end_ramp_pts, close=True))
        end_ramp_cut = Pos(0, yc, 0) * extrude(end_ramp_face, amount=p.bay_w / 2.0, both=True)

        base = base - upper_bay - lower_bay - bag_tail_slot - trench_cut - end_ramp_cut

    # 4. Central Finger-Pinch Retrieval Cutout across outer side walls AND center divider
    # Drops from Z = 34.00 at |X| = 42.00 down to Z = 19.00 across X in [-27.00, +27.00]
    pinch_pts = [
        (-p.pinch_top_half_x, p.z_base_top + 1.0),
        (-p.pinch_flat_half_x, p.z_pinch_waist),
        (p.pinch_flat_half_x, p.z_pinch_waist),
        (p.pinch_top_half_x, p.z_base_top + 1.0),
    ]
    pinch_face = make_face(Plane.XZ * Polyline(pinch_pts, close=True))
    pinch_cut = extrude(pinch_face, amount=p.outer_width, both=True)
    base = base - pinch_cut

    # 5. Integrated End Cantilever Flex-Latches (at -X and +X ends)
    latch_total_span_y = p.latch_beam_w + 2.0 * p.latch_slot_w  # 15.00 mm
    for sign_x in (-1.0, 1.0):
        # 5a. Cut the flex clearance pocket behind the beam: |X| in [74.00, 75.75], Z in [9.00, 35.00]
        pocket_x_min = p.base_inner_end_x
        pocket_x_max = p.latch_gap_outer_x
        pocket_cx = sign_x * 0.5 * (pocket_x_min + pocket_x_max)
        flex_pocket = Pos(pocket_cx, 0, p.z_latch_root) * Box(
            pocket_x_max - pocket_x_min,
            latch_total_span_y,
            p.z_base_top - p.z_latch_root + 2.0,
            align=(Align.CENTER, Align.CENTER, Align.MIN),
        )
        base = base - flex_pocket

        # 5b. Cut the two side separation slots isolating the cantilever beam from corner pillars
        # |X| in [74.00, 80.50], |Y| in [6.80, 7.50], Z in [9.00, 35.00]
        slot_x_len = half_L - p.base_inner_end_x + 1.0
        slot_cx = sign_x * (p.base_inner_end_x + 0.5 * slot_x_len)
        for sign_y in (-1.0, 1.0):
            slot_cy = sign_y * (0.5 * p.latch_beam_w + 0.5 * p.latch_slot_w)
            side_slot = Pos(slot_cx, slot_cy, p.z_latch_root) * Box(
                slot_x_len,
                p.latch_slot_w,
                p.z_base_top - p.z_latch_root + 2.0,
                align=(Align.CENTER, Align.CENTER, Align.MIN),
            )
            base = base - side_slot

        # 5c. Trim the outer lower shoulder in the latch zone above Z = 16.00 (already at 77.55)
        # And trim top of cantilever beam above z_button_top (32.50 mm)
        top_trim_cx = sign_x * 0.5 * (p.latch_gap_outer_x + half_L + 2.0)
        top_trim = Pos(top_trim_cx, 0, p.z_button_top) * Box(
            half_L - p.latch_gap_outer_x + 4.0,
            latch_total_span_y,
            p.z_base_top - p.z_button_top + 2.0,
            align=(Align.CENTER, Align.CENTER, Align.MIN),
        )
        base = base - top_trim

        # 5d. Add the Snap-Detent Catch Nose and Textured Thumb-Press Release Button
        # Profile in XZ plane extending outward from latch_shaft_outer_x (77.55 mm)
        x0 = sign_x * p.latch_shaft_outer_x
        x_catch = sign_x * p.latch_catch_peak_x
        x_btn = sign_x * p.latch_button_outer_x
        x_root_in = sign_x * (p.latch_shaft_outer_x - 0.40)

        # Detent nose + thumb button profile
        catch_pts = [
            (x_root_in, p.z_catch_bot),
            (x0, p.z_catch_bot),
            (x_catch, p.z_catch_peak),
            (x0, p.z_catch_top),
            (x_btn, p.z_catch_top + 1.20),
            (x_btn, p.z_button_top - 0.60),
            (x0, p.z_button_top),
            (x_root_in, p.z_button_top),
        ]
        catch_face = make_face(Plane.XZ * Polyline(catch_pts, close=True))
        catch_solid = extrude(catch_face, amount=p.latch_beam_w / 2.0, both=True)

        # Subtract two tactile grip grooves across the thumb button face
        for gz in (28.60, 30.60):
            groove = Pos(x_btn, 0, gz) * Box(
                0.80,
                p.latch_beam_w + 1.0,
                0.70,
                align=(Align.CENTER, Align.CENTER, Align.CENTER),
            )
            catch_solid = catch_solid - groove

        base = base + catch_solid

    # 6. Ergonomic Side Finger-Grip Grooves on Base Lower Pedestal (Z = 5.50 & 10.50)
    for sign_y in (-1.0, 1.0):
        yc_groove = sign_y * half_W
        for gz in (6.00, 10.50):
            grip_cut = Pos(0, yc_groove, gz) * Box(
                52.0,
                1.00,
                1.40,
                align=(Align.CENTER, Align.CENTER, Align.CENTER),
            )
            base = base - grip_cut

    # 7. FillaPrint Debossed Labels on Bottom Exterior Face (Z = 0.00 .. 0.60)
    # Mirrored in X so when viewing the bottom face from outside (-Z), text reads left-to-right!
    txt_b1 = Text(
        "BAG + FOAM / PINS SAFE",
        font_size=p.base_line1_size,
        font_path=p.font_path,
        align=(Align.CENTER, Align.CENTER),
    )
    txt_b2 = Text(
        "PRESS ENDS TO OPEN",
        font_size=p.base_line2_size,
        font_path=p.font_path,
        align=(Align.CENTER, Align.CENTER),
    )
    b1_solid = Pos(0, 5.80, 0) * mirror(extrude(txt_b1, amount=p.text_depth), Plane.YZ)
    b2_solid = Pos(0, -5.80, 0) * mirror(extrude(txt_b2, amount=p.text_depth), Plane.YZ)
    base = base - b1_solid - b2_solid

    base_part = Part(base.wrapped)
    base_part.label = "mailer_base"
    return base_part


def build_mailer_lid(p: MailerParams = MailerParams()) -> Part:
    """Build the mailer_lid part in assembled world coordinates."""
    half_L = p.outer_length / 2.0
    half_W = p.outer_width / 2.0

    lid_inner_half_L = p.lid_end_inner_x  # 77.80 mm
    lid_inner_half_W = (
        p.divider_t / 2.0 + p.bay_w + p.neck_side_wall_t + p.xy_clearance
    )  # 16.85 mm
    lid_inner_r = max(1.0, p.outer_corner_r - (half_W - lid_inner_half_W))

    # 1. Outer lid shell (Z = 16.20 .. 56.00)
    lid_outer = _rounded_rect_prism(
        p.outer_length,
        p.outer_width,
        p.z_top - p.z_parting_lid,
        p.outer_corner_r,
        z0=p.z_parting_lid,
    )
    # Chamfer top outer perimeter edge
    top_edges = lid_outer.edges().filter_by_position(
        Axis.Z, minimum=p.z_top - 0.01, maximum=p.z_top + 0.01
    )
    lid_outer = chamfer(top_edges, length=p.outer_edge_chamfer)

    # 2. Hollow out lower telescoping skirt cavity (Z = 16.00 .. 34.40)
    # Fits over base neck (which reaches X = +/-77.55, Y = +/-16.60, Z = 34.00)
    skirt_cavity_top = p.z_base_top + 0.40  # 34.40 mm (0.40 mm vertical clearance to base rim)
    skirt_cavity = _rounded_rect_prism(
        2.0 * lid_inner_half_L,
        2.0 * lid_inner_half_W,
        skirt_cavity_top - (p.z_parting_lid - 0.50),
        lid_inner_r,
        z0=p.z_parting_lid - 0.50,
    )

    # 3. Upper dual-bay interior cavities (Z = 34.40 .. 50.50 at ends, up to 53.00 in central vault)
    bay_y_centers = [
        +(p.divider_t / 2.0 + p.bay_w / 2.0),  # +8.10 mm
        -(p.divider_t / 2.0 + p.bay_w / 2.0),  # -8.10 mm
    ]
    lid = lid_outer - skirt_cavity

    for yc in bay_y_centers:
        # 3a. Full upper bay span up to end ceiling pads (Z = 34.00 .. 50.50, X in [-71.80, +71.80])
        upper_bay_box = Pos(0, yc, p.z_base_top) * Box(
            2.0 * p.bay_upper_half_x,
            p.bay_w,
            p.z_lid_end_pad - p.z_base_top,
            align=(Align.CENTER, Align.CENTER, Align.MIN),
        )
        # 3b. Central ceiling vault / foam cushion pocket (Z = 50.50 .. 53.00, X in [-63.00, +63.00])
        # With 45-degree end ramps for support-free printing when lid is printed upside down
        vault_pts = [
            (-p.contact_trench_half_x, p.z_lid_end_pad - 0.05),
            (-p.contact_trench_half_x + 2.5, p.z_lid_vault),
            (p.contact_trench_half_x - 2.5, p.z_lid_vault),
            (p.contact_trench_half_x, p.z_lid_end_pad - 0.05),
        ]
        vault_face = make_face(Plane.XZ * Polyline(vault_pts, close=True))
        vault_cut = Pos(0, yc, 0) * extrude(vault_face, amount=p.bay_w / 2.0, both=True)

        lid = lid - upper_bay_box - vault_cut

    # 4. Trim central divider bottom edge in lid to Z = 34.60 so it clears base divider cleanly
    # (skirt_cavity already removed Z <= 34.40; remove up to Z = 34.60 across divider width)
    div_clearance_trim = Pos(0, 0, p.z_base_top) * Box(
        2.0 * p.bay_upper_half_x,
        p.divider_t + 0.40,
        p.z_lid_divider_bot - p.z_base_top,
        align=(Align.CENTER, Align.CENTER, Align.MIN),
    )
    lid = lid - div_clearance_trim

    # 5. Internal Latch Keeper Grooves & Thumb-Button Access Windows at both ends (-X and +X)
    keeper_w = p.latch_beam_w + 0.80      # 14.40 mm (0.40 mm side clearance per side to 13.60 mm catch)
    window_w = p.latch_beam_w + 0.80      # 14.40 mm thumb button cutout width

    for sign_x in (-1.0, 1.0):
        x_in = sign_x * p.lid_end_inner_x
        x_keep = sign_x * p.lid_keeper_peak_x
        x_lead = sign_x * (p.lid_end_inner_x + 0.90)

        # 5a. Bottom lead-in chamfer inside lid end skirt so latch snaps in smoothly during closing
        lead_pts = [
            (x_in - sign_x * 0.2, p.z_parting_lid - 0.1),
            (x_lead, p.z_parting_lid - 0.1),
            (x_in, p.z_parting_lid + 2.0),
            (x_in - sign_x * 0.2, p.z_parting_lid + 2.0),
        ]
        lead_face = make_face(Plane.XZ * Polyline(lead_pts, close=True))
        lead_cut = extrude(lead_face, amount=keeper_w / 2.0, both=True)

        # 5b. Internal Keeper Groove matching the catch nose (with >= 0.30 mm clearance all around)
        keeper_pts = [
            (x_in - sign_x * 0.2, p.z_catch_bot - 0.35),
            (x_in, p.z_catch_bot - 0.35),
            (x_keep, p.z_catch_peak),
            (x_in, p.z_catch_top + 0.35),
            (x_in - sign_x * 0.2, p.z_catch_top + 0.35),
        ]
        keeper_face = make_face(Plane.XZ * Polyline(keeper_pts, close=True))
        keeper_cut = extrude(keeper_face, amount=keeper_w / 2.0, both=True)

        # 5c. Thumb-Button Access Cutout Window (Z = 26.20 .. 33.40) through the lid end wall
        # Allows thumb to press the base's textured release button inward!
        win_z_bot = p.z_catch_top - 0.20   # 26.30 mm
        win_z_top = p.z_button_top + 0.70  # 33.20 mm
        win_pts = [
            (x_in - sign_x * 0.5, win_z_bot),
            (sign_x * (half_L + 1.0), win_z_bot),
            (sign_x * (half_L + 1.0), win_z_top),
            (x_in - sign_x * 0.5, win_z_top + 1.2),  # 45-deg print-friendly roof inside
        ]
        win_face = make_face(Plane.XZ * Polyline(win_pts, close=True))
        win_cut = extrude(win_face, amount=window_w / 2.0, both=True)

        lid = lid - lead_cut - keeper_cut - win_cut

    # 6. Ergonomic Side Grip Grooves on Lid Flanks (Z = 42.00 & 46.50)
    for sign_y in (-1.0, 1.0):
        yc_groove = sign_y * half_W
        for gz in (42.00, 46.50):
            grip_cut = Pos(0, yc_groove, gz) * Box(
                52.0,
                1.00,
                1.40,
                align=(Align.CENTER, Align.CENTER, Align.CENTER),
            )
            lid = lid - grip_cut

    # 7. FillaPrint Debossed Labels on Top Exterior Face (Z = 55.40 .. 56.00)
    txt_l1 = Text(
        "2x DDR4 UDIMM",
        font_size=p.lid_title_size,
        font_path=p.font_path,
        align=(Align.CENTER, Align.CENTER),
    )
    txt_l2 = Text(
        "MAX 140x43x8.5MM",
        font_size=p.lid_sub_size,
        font_path=p.font_path,
        align=(Align.CENTER, Align.CENTER),
    )
    l1_solid = Pos(0, 5.80, p.z_top - p.text_depth) * extrude(txt_l1, amount=p.text_depth + 0.1)
    l2_solid = Pos(0, -6.20, p.z_top - p.text_depth) * extrude(txt_l2, amount=p.text_depth + 0.1)
    lid = lid - l1_solid - l2_solid

    lid_part = Part(lid.wrapped)
    lid_part.label = "mailer_lid"
    return lid_part


def export_all(output_dir: Path = Path(".")) -> dict:
    """Build parts and export STEP and binary STL files."""
    params = MailerParams()
    base = build_mailer_base(params)
    lid = build_mailer_lid(params)

    base_step = output_dir / "mailer_base.step"
    lid_step = output_dir / "mailer_lid.step"
    assy_step = output_dir / "mailer_assembly.step"
    base_stl = output_dir / "mailer_base.stl"
    lid_stl = output_dir / "mailer_lid.stl"

    export_step(base, str(base_step))
    export_step(lid, str(lid_step))

    assy = Compound(label="ddr4_ram_mailer_assembly", children=[base, lid])
    export_step(assy, str(assy_step))

    export_stl(base, str(base_stl), tolerance=0.02, angular_tolerance=0.1)
    export_stl(lid, str(lid_stl), tolerance=0.02, angular_tolerance=0.1)

    return {
        "params": params,
        "base": base,
        "lid": lid,
        "files": {
            "base_step": str(base_step),
            "lid_step": str(lid_step),
            "assembly_step": str(assy_step),
            "base_stl": str(base_stl),
            "lid_stl": str(lid_stl),
        },
    }


if __name__ == "__main__":
    info = export_all()
    b_bb = info["base"].bounding_box()
    l_bb = info["lid"].bounding_box()
    print("Export complete.")
    print("mailer_base bbox:", b_bb.min, "to", b_bb.max, "size:", b_bb.size)
    print("mailer_lid  bbox:", l_bb.min, "to", l_bb.max, "size:", l_bb.size)
