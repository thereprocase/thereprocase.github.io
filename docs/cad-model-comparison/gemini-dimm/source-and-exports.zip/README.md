# Reusable Dual-Stick Desktop DDR4 UDIMM Mailer

A compact, two-part 3D-printable reusable protective mailer (`mailer_base` and `mailer_lid`) designed to hold **two desktop DDR4 UDIMM memory sticks with ordinary heatspreaders**, each inside its own static-shielding (ESD) bag with a light paper or thin foam wrap, for mailing inside an outer corrugated shipping box.

---

## 1. Supported Module Envelope & Real-World Fit Table

- **Assembled Exterior Dimensions:** `160.0 mm (L) × 38.4 mm (W) × 56.0 mm (H)`
- **Supported Module Envelope (per bay, 2 bays total):**
  - **Module Length:** `133.0 mm – 140.0 mm` (lower 5 mm PCB edge zone locates standard `133.35 mm` JEDEC PCBs within a `136.4 mm` span; upper bay flares to `143.6 mm` with a `6.6 mm` full-depth central bag-tail channel to accommodate overhanging heatspreaders and folded `2" × 6"` or `3" × 6"` ESD shielding bag ends).
  - **Module Height:** `30.0 mm – 43.0 mm` (`43.5 mm` vertical clearance at the end ceiling pads; `46.0 mm` in the `129.0 mm` central ceiling cushion vault).
  - **Module Thickness:** `3.5 mm – 8.5 mm` (`12.6 mm` bay width per stick, leaving `4.1 mm – 9.1 mm` per bay for the folded 3-mil ESD shielding bag and a slip of paper or `2–3 mm` foam sheet).

### Real-World Module Compatibility (Verified in `checks.json`)

| DDR4 Desktop UDIMM Model | Length × Height × Thickness (mm) | Fits Mailer? | Side Bag + Foam Margin (mm) | Top Headroom End / Vault (mm) | Exposed Pinch Height (mm) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **JEDEC Bare UDIMM** (Crucial / Kingston ValueRAM / Samsung) | `133.35 × 31.25 × 3.90` | **YES** | `8.70` | `12.25 / 14.75` | `19.25` |
| **Corsair Vengeance LPX DDR4** | `135.00 × 34.00 × 7.00` | **YES** | `5.60` | `9.50 / 12.00` | `22.00` |
| **Kingston FURY Beast DDR4 (Non-RGB)** | `133.35 × 34.10 × 7.20` | **YES** | `5.40` | `9.40 / 11.90` | `22.10` |
| **TeamGroup T-Force Vulcan Z DDR4** (winged ends) | `140.00 × 32.00 × 7.00` | **YES** | `5.60` | `11.50 / 14.00` | `20.00` |
| **Crucial Ballistix DDR4** | `133.35 × 39.20 × 7.00` | **YES** | `5.60` | `4.30 / 6.80` | `27.20` |
| **G.Skill Ripjaws V DDR4** | `133.35 × 42.00 × 8.00` | **YES** | `4.60` | `1.50 / 4.00` | `30.00` |
| **Kingston FURY Beast RGB / Renegade DDR4** | `133.35 × 43.00 × 8.20` | **YES** (Max) | `4.40` | `0.50 / 3.00` | `31.00` |
| **G.Skill Trident Z Royal / Neo DDR4** *(Exotic RGB)* | `133.35 × 44.50 × 9.00` | **NO** | Exceeds height (`+1.0 mm`) & thickness | `-1.00 / +1.50` | — |
| **Corsair Vengeance RGB Pro DDR4** *(Exotic Tall RGB)* | `138.00 × 51.00 × 7.50` | **NO** | Exceeds height (`+7.5 mm`) | `-7.50 / -5.00` | — |
| **Corsair Dominator Platinum RGB DDR4** *(Exotic Tall)* | `135.00 × 56.00 × 8.50` | **NO** | Exceeds height (`+12.5 mm`) | `-12.50 / -10.00` | — |

---

## 2. Key Mechanisms & Functional Engineering

### A. Zero Gold-Contact Pressure (Pin-Safe Cradle + Top Cushion Vault)
- On a standard 288-pin JEDEC MO-309 DDR4 UDIMM (`133.35 mm` PCB length), the gold edge contacts span the central `124.35 mm` (`|X| <= 62.18 mm`), leaving bare FR4 PCB margin at both ends (`4.50 mm` and `5.65 mm`).
- Each bay in `mailer_base` supports the module only on **raised non-contact end saddles** at `Z = 7.00 mm` (`|X| in [64.50, 71.80] mm`, `7.30 mm` long at each end), while the entire central `129.00 mm` span (`127.00 mm` at the floor) drops down `4.00 mm` to `Z = 3.00 mm` in an unobstructed **gold-contact relief trench**.
- Lower PCB end-locating stops at `X = ±68.20 mm` (`136.40 mm` span) limit longitudinal PCB travel to `±1.525 mm`, guaranteeing that the gold contacts stay within `|X| <= 63.70 mm` and float over the `4.00 mm` deep air trench.
- Because the module loads **contacts-down** into the pin-safe cradle, the solid top spine of the aluminum heatspreader faces upward toward `mailer_lid`. Any folded paper or foam pad placed in the lid's `2.50 mm` recessed ceiling vault (`Z = 53.00 mm`) presses only against the top of the heatspreader—never the gold contacts. Even if a stick is loaded inverted (contacts-up), the lid's central ceiling vault is recessed `2.50 mm` above the `Z = 50.50 mm` end pads across the central `129.00 mm` span.

### B. Lid Retention & One-Handed / Two-Thumb Reopening
- **Deep Telescoping Skirt (`17.80 mm` overlap):** `mailer_lid` telescopes down over the stepped upper neck of `mailer_base` from `Z = 34.00 mm` down to `Z = 16.20 mm` with `0.25 mm` per-side XY clearance and a `0.20 mm` parting-line gap above the `Z = 16.00 mm` lower shoulder, preventing twisting or shear dislodgement during shipping.
- **Dual End Cantilever Snap-Latches:** Each short end (`X = ±80.00 mm`) of `mailer_base` incorporates a U-slotted vertical cantilever spring beam (`t = 1.80 mm` thick, `b = 13.60 mm` wide, rooted at `Z = 9.00 mm` and isolated from the RAM bays by a solid `2.20 mm` inner end wall plus a `1.75 mm` deflection gap so flexing the latch never touches the bagged RAM sticks).
- **Positive Engagement & Release:** The ramped catch nose (`Z = 24.00 mm`) engages an internal keeper groove inside the lid end skirt with `0.85 mm` mechanical overlap per end (`1.70 mm` total; `0.30 mm` static clearance inside the keeper pocket in the closed position). Above the catch sits a **textured thumb-press release button** (`Z = 26.50 – 32.50 mm`) exposed through a matching thumb window in the lid. Pressing both end buttons inward by `~1.0 mm` (`~5.1 N` per thumb in PETG; `0.64%` button bending strain, `1.02%` snap-closing strain) disengages the catches so the lid lifts straight off.

### C. Effortless Module Retrieval
- When `mailer_lid` is removed, the end cradle walls of `mailer_base` remain `27.00 mm` above the saddle plane (`Z = 34.00 mm`) so both bagged sticks stay upright without tipping.
- Across the central `54.00 mm` flat waist (`84.00 mm` top opening), both outer side walls and the `3.60 mm` center divider drop down via `45°` ramps to `Z = 19.00 mm` (just `12.00 mm` above the `Z = 7.00 mm` saddles).
- This exposes **`19.25 mm` to `31.00 mm` (62%–72%) of each stick's height** in the middle of the tray with a `16.20 mm` center-to-center bay pitch, allowing thumb and forefinger to pinch either bagged stick directly by its heatspreader faces and lift it straight out.

---

## 3. FillaPrint Typography (`assets/fillaprint/Fillaprint-Regular.ttf`)

Per the supplied `Fillaprint-Regular.ttf` metadata (`Two-bead FDM font: every stroke is exactly two extrusion widths (w). Fusion text Height = 14 x line width (cap height); em = 20 x line width`), the minimum printable size for a `0.40 mm` nozzle (`w = 0.40–0.45 mm`) is `font_size (em) = 8.0–9.0 mm` (`cap height = 5.6–6.3 mm`, `stroke width = 0.80–0.90 mm`). All labels are debossed `0.60 mm` deep on horizontal XY faces for exact two-bead slicing:

- **`mailer_lid` Top Face (`Z = 56.00 mm`):**
  - `2x DDR4 UDIMM` — `font_size = 11.0 mm`, cap height `7.70 mm`, stroke width `1.10 mm` (`w = 0.55 mm`), width `60.76 mm`.
  - `MAX 140x43x8.5MM` — `font_size = 9.0 mm`, cap height `6.30 mm`, stroke width `0.90 mm` (`w = 0.45 mm`), width `64.23 mm`.
- **`mailer_base` Bottom Face (`Z = 0.00 mm`, mirrored for outside-bottom readability):**
  - `BAG + FOAM / PINS SAFE` — `font_size = 9.5 mm`, cap height `6.65 mm`, stroke width `0.95 mm` (`w = 0.475 mm`), width `81.18 mm`.
  - `PRESS ENDS TO OPEN` — `font_size = 9.0 mm`, cap height `6.30 mm`, stroke width `0.90 mm` (`w = 0.45 mm`), width `67.65 mm`.

---

## 4. Delivered Files

- `ram_mailer.py` — Parametric `build123d` CAD source generating both parts and assemblies.
- `mailer_base.step` / `mailer_base.stl` — Base tray STEP and verified binary STL (`14,700` triangles, watertight).
- `mailer_lid.step` / `mailer_lid.stl` — Protective over-lid STEP and verified binary STL (`11,552` triangles, watertight).
- `mailer_assembly.step` — Combined two-part assembly STEP in closed position.
- `assembly.json` — Part file references and actual assembled transforms in millimeters.
- `verify_design.py` & `checks.json` — Automated B-Rep, mesh, pin-clearance, latch-retention, module-envelope, and FillaPrint typography verification suite and measured outputs.

---

## 5. Printing Recommendations & Honest Limitations Requiring Physical Test

- **Print Orientation & Settings:** Print `mailer_base` upright on its flat `Z = 0` bottom face; print `mailer_lid` flipped `180°` on its flat `Z = 56.0 mm` top face. No supports are required on either part (all internal transitions, keeper grooves, thumb windows, and ceiling vaults use `<= 45°` self-supporting ramps). Use PETG or tough PLA with a `0.4 mm` nozzle, `0.20 mm` layer height, `3` perimeters, and Arachne perimeter generator enabled for crisp two-bead FillaPrint text.
- **What Still Needs a Physical Test:**
  1. **Snap-Latch Tactile Feel & Layer-Line Friction:** While the `0.85 mm` catch overlap (`0.30 mm` static keeper clearance) and `1.80 mm` cantilever beam thickness are analytically sized for `~5.1 N` thumb release force and `1.02%` peak strain in PETG, layer-line ridges on the `45°` catch ramps increase friction on the first few cycles; physical test prints should confirm whether `xy_clearance` (`0.25 mm`) or `latch_catch_peak_x` needs a `±0.10 mm` tune for a specific printer/filament combination.
  2. **ESD Bag Stiffness & Damping Thickness:** Standard `2" × 6"` (`50.8 × 152.4 mm`) or `3" × 6"` 3-mil metal-in ESD bags vary in side-weld width; physical packing with the user's specific bags and foam/paper thickness should confirm snugness inside the `12.6 mm × 143.6 mm` bays during drop/shake testing inside an outer cardboard box.
