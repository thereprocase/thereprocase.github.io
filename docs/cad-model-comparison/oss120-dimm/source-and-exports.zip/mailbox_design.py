"""
Parametric CAD design for a reusable DDR4 RAM mailer.
Two-part clamshell box (base + lid) with snap-fit latch and optional foam spacer.
Generated using build123d.
"""

from pathlib import Path
from build123d import *

# ==================== Parameters ====================
# DDR4 stick dimensions (including heat spreader)
STICK_LENGTH = 133.35  # mm (standard DDR4 DIMM length)
STICK_WIDTH = 34.0     # mm (height of stick with heatspreader)
STICK_THICKNESS = 2.5  # mm (thickness of PCB)

# Clearance for each stick inside cavity
CLEARANCE_X = 2.0   # mm clearance along length
CLEARANCE_Y = 2.0   # mm clearance along width (height direction)
CLEARANCE_Z = 0.5   # mm clearance depth

# Gap between two sticks (foam spacer)
SPACER_GAP = 2.0    # mm

# Box wall thickness and lid overlap
WALL_THICKNESS = 1.5   # mm
LID_OVERLAP = 1.0       # mm (lip of base that the lid snaps over)

# Snap latch dimensions
LATCH_HEIGHT = 3.0      # mm
LATCH_THICK = 2.0       # mm
LATCH_OFFSET = 5.0      # mm from front edge

# Text label
LABEL_TEXT = "DDR4 Mailer"
LABEL_HEIGHT = 2.0      # extrusion height for emboss
LABEL_SIZE = 10.0       # approximate font size (mm)
FONT_PATH = Path("assets/fillaprint/Fillaprint-Regular.ttf")

# ==================== Derived dimensions ====================
# Cavity size for one stick
CAVITY_LENGTH = STICK_LENGTH + 2 * CLEARANCE_X
CAVITY_WIDTH = STICK_WIDTH + 2 * CLEARANCE_Y
CAVITY_DEPTH = STICK_THICKNESS + CLEARANCE_Z

# Overall inner dimensions for two sticks side‑by‑side
INNER_LENGTH = CAVITY_LENGTH
INNER_WIDTH = 2 * CAVITY_WIDTH + SPACER_GAP
INNER_HEIGHT = CAVITY_DEPTH

# Overall outer dimensions (base)
OUTER_LENGTH = INNER_LENGTH + 2 * WALL_THICKNESS
OUTER_WIDTH = INNER_WIDTH + 2 * WALL_THICKNESS
OUTER_HEIGHT = 10.0   # mm (base thickness)

# Lid outer dimensions (same as base)
LID_OUTER_HEIGHT = 10.0

# Helper function to create a cavity for one stick
def stick_cavity() -> Solid:
    return Box(CAVITY_LENGTH, CAVITY_WIDTH, CAVITY_DEPTH)

# ==================== Base ====================
base = Box(OUTER_LENGTH, OUTER_WIDTH, OUTER_HEIGHT)
# Create two cavities for the sticks
cav1 = stick_cavity()
# Position first cavity inside base (aligned to front‑left corner with clearance)
# Origin is at base lower‑left‑front corner
cav1 = cav1.translate((WALL_THICKNESS, WALL_THICKNESS, WALL_THICKNESS))

cav2 = stick_cavity()
# Second cavity offset in Y by CAVITY_WIDTH + SPACER_GAP
cav2 = cav2.translate((WALL_THICKNESS, WALL_THICKNESS + CAVITY_WIDTH + SPACER_GAP, WALL_THICKNESS))

# Subtract cavities from base
base = base - (cav1 + cav2)

# Add a thin lip around the interior to catch the lid (extra 0.5 mm)
LIP_THICK = 0.5
# A shallow ridge on the top edge of the base for the lid to snap over
ridge = Box(OUTER_LENGTH, OUTER_WIDTH, LIP_THICK)
ridge = ridge.translate((0, 0, OUTER_HEIGHT - LIP_THICK))
base = base + ridge

# Snap latch on the lid (will be added later in lid definition)
# ==================== Lid ====================
lid = Box(OUTER_LENGTH, OUTER_WIDTH, LID_OUTER_HEIGHT)
# Create inner cavity (slightly larger than base inner dimensions to allow easy removal)
inner_cav = Box(INNER_LENGTH, INNER_WIDTH, INNER_HEIGHT + 0.5)  # small extra clearance
inner_cav = inner_cav.translate((WALL_THICKNESS, WALL_THICKNESS, WALL_THICKNESS))
lid = lid - inner_cav

# Add snap latch protrusion on lid front edge
latch = Box(LATCH_THICK, LATCH_HEIGHT, LID_OUTER_HEIGHT)
# Position latch near front left side, centered vertically
latch = latch.translate((LATCH_OFFSET, (OUTER_WIDTH - LATCH_HEIGHT)/2, 0))
lid = lid + latch

# Add emboss text on lid front center (disabled for now)
# if FONT_PATH.exists():
#     txt = Text(
#         txt=LABEL_TEXT,
#         font_size=LABEL_SIZE,
#         font_path=str(FONT_PATH),
#         align=Align.CENTER,
#     )
#     txt = txt.translate((OUTER_LENGTH/2, OUTER_WIDTH - LIP_THICK - 0.2, LID_OUTER_HEIGHT/2))
#     lid = lid + txt

# ==================== Export ====================
out_dir = Path('output')
out_dir.mkdir(exist_ok=True)

# STEP files
export_step(base, out_dir / 'base.step')
export_step(lid, out_dir / 'lid.step')

# STL files (binary)
export_stl(base, out_dir / 'base.stl')
export_stl(lid, out_dir / 'lid.stl')

print('Export completed')
