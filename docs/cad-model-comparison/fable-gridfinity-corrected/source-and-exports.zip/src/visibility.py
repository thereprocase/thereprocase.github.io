"""Label visibility by ray casting on the assembled meshes (trimesh).

For every label line, sample points on the text band (5 across x 3 high), and for each viewing
direction (elevation above the bench, azimuth from straight in front) cast a ray from the point
towards the viewer.  The label is 'clear' at that direction if no sampled ray hits anything within
600 mm.  Returns the lowest elevation from which the label is clear at every higher elevation.
"""
import math
import numpy as np, trimesh

ELEVATIONS = list(range(15, 91, 5))
AZIMUTHS = (0, -20, 20)


def sample_points(line_centre_world, half_width, cap_h, face_angle_deg):
    a = math.radians(face_angle_deg)
    up = np.array([0, math.cos(a), math.sin(a)]); right = np.array([1.0, 0, 0])
    pts = []
    for u in np.linspace(-half_width, half_width, 5):
        for v in (-cap_h / 2, 0.0, cap_h / 2):
            pts.append(np.asarray(line_centre_world) + u * right + v * up)
    return np.array(pts)


def view_dir(elev_deg, azim_deg):
    e, z = math.radians(elev_deg), math.radians(azim_deg)
    return np.array([math.sin(z) * math.cos(e), -math.cos(z) * math.cos(e), math.sin(e)])


def min_clear_elevation(mesh, pts, azim_deg, elevations=ELEVATIONS):
    """Lowest elevation such that the label is clear there and at all higher sampled elevations."""
    clear = []
    for e in elevations:
        d = view_dir(e, azim_deg)
        org = pts + 0.3 * d
        hit = mesh.ray.intersects_any(org, np.tile(d, (len(pts), 1)))
        clear.append(not hit.any())
    # walk from the top down
    best = None
    for e, c in zip(reversed(elevations), reversed(clear)):
        if c:
            best = e
        else:
            break
    return best, dict(zip(elevations, clear))
