# Gridfinity fastener organiser, 5 x 4 starter patch

Standard 42 mm Gridfinity (base profile 0.8/1.8/2.15, stacking-lip profile 0.7/1.8/1.9, 41.5 mm bins, 7 mm height unit; profile values confirmed against kennetek's gridfinity-rebuilt source through the proxy). Not printed or fit-tested: every clearance below is a design value.

## Layout (front row to back row, left to right)
| Row (front to back) | Height | Bin 1 | Bin 2 | Bin 3 | Bin 4 | Bin 5 |
|---|---|---|---|---|---|---|
| M2 | 3u (21 mm) | screws 6 / 8 | 10 / 12 | 16 / 20 | NUT | WASHER |
| M2.5 | 4u (28 mm) | same | same | same | NUT | WASHER |
| M3 | 5u (35 mm) | same | same | same | NUT | WASHER |
| M4 | 6u (42 mm) | same | same | same | NUT | WASHER |

20 cells, all used: 12 two-compartment screw bins (24 size/length combinations) and 8 single-compartment bins, 22 STL and STEP files (baseplate, 20 bins, extension strip). Bin types: **screw bin** (two side-by-side compartments, one length each) and **single bin** (one full-width compartment, nuts and washers kept apart in separate bins, marked by word and by a hex-ring or round-ring icon).
Rows rise by one unit toward the back so every label is visible from above the front of the bench. The row height only affects capacity and visibility; heights are set in `src/layout.json`.

## Handling
- **Read:** each bin has a recessed label deck at the top front with raised FillaPrint text (size line, then lengths under their compartments, or NUT / WASHER). Letters are 5.6 mm cap height (14 x 0.4 mm line width), 0.8 mm strokes, 0.6 mm relief, top 0.3 mm below the wall top so stacked bins do not crush them. The stacking lip is opened across the label.
- **Pick out:** the 24 mm deep window behind the deck is open. A rear scoop (R8, R10 in single bins) lets you drag a part against the ramp and pinch it. Open window per screw compartment is 17.4 mm wide; the largest head is 7 mm.
- **Carry:** each bin is separate; lift it with one finger hooked under the rear edge of the label deck in each compartment (13.2 mm of void under the deck in the 3u bin) and thumbs on the deck. Neighbours are 0.5 mm away on every side and are not disturbed. **This hook grip is a design intent and needs a physical test** (see below). Bins have no lid.
- **Stack:** any bin sits on any other (same footprint). The foot seats 0.2 mm below the wall top on the lip edge; stacked bins cover the lower one, so use stacking for rarely used spares.

## Capacity (estimated, 0.35 / 0.40 solid fraction for screws and washers / nuts, filled to 3 mm below the wall top)
Every screw compartment holds at least 20 pieces of its length (smallest: M4x20 about 21; M2 6 mm about 78). Nut and washer bins hold several hundred (30 needed), so they are much larger than necessary; the cell is the unit. Per-compartment numbers: `out/bin_meta.json`.

## Files
- `src/gridfinity_fasteners.py`: parametric build; `src/layout.json`: sizes, lengths, heights; `src/checks.py` (CAD interference, stacking, label fit) and `src/checks_mesh.py` (STL checks, run with the physics Python).
- `out/stl`, `out/step`: one file per part (`baseplate_5x4`, 20 bins, plus `baseplate_ext_5x1`, a plain strip that tiles against the main plate).
- `out/assembly.json`: part files and assembled 4x4 transforms (mm, no rotation). Baseplate origin is the plate centre at its underside; bins sit with their foot underside on the pocket floor (z = 1.5).
- `out/checks.json`: measured results. `out/bin_meta.json`: per-bin capacity and label data.

## Measured checks (all passed)
All 21 STLs are binary and watertight. Assembled bin versus baseplate and bin versus bin: 0.0 mm3 overlap. Stacked bins (3 combinations) seated 0.2 mm below the wall top: 0.0 mm3 overlap; 0.5 mm lower: about 150-180 mm3, so the seat is real. Label cap height 5.6 mm, stem 0.8 mm, widest ink half-width 17.7 mm inside an 18.0 mm limit, lengths in a pair at least 3.3 mm apart.

## Extending
Append a row to `src/layout.json` (M5 data already present in `fasteners`), run the script: a new row of bins is produced and the baseplate grows to 5 x 5; or print `baseplate_ext_5x1` and add the row beside the existing plate. Further lengths: add them to the row's `lengths` (pairs fill each bin; an odd leftover becomes a single-compartment bin).

## Limitations and fit tests needed
1. Foot-to-pocket and foot-to-lip clearance is 0.2 mm per side; test one bin in the plate and one stacked, and adjust `clr` in the script if tight or loose on your printer.
2. The stacking lip is 3.9 mm tall, not the 4.4 mm of the reference profile, to keep a printable 0.65 mm top edge. Its upper part is only about 0.65 mm thick; and the front lip is cut open across the label.
3. Label text: the font is scaled for a 0.4 mm line width (cap 5.6 mm). Slice at 0.4 mm lines so each stroke is two beads, and check that the 0.6 mm raised letters print cleanly; the deck bridge (about 18 x 16 mm, 2 mm thick) and the 45-degree underhang below the lip need to bridge without support.
4. Rear-row labels are visible from about 50 degrees elevation or steeper (computed from the 7 mm row step and lip height). A flat patch with equal row heights would hide rear labels.
5. The hook-under-the-deck lift and the fingertip pick of M2 washers (0.3 mm thick) are untested; a thin washer may still need a fingernail.
6. Packing fractions are estimates. Screw dimensions are ISO nominal (socket head, ISO 4032 nuts, ISO 7089 washers); real stock varies.
7. The baseplate is 210 x 168 x 6.25 mm and needs a bed of that size (the strip tile allows splitting). Its pocket ridge is 0.2 mm wide, and there are no magnet or screw holes in plate or bins. The tallest bin top is 47.4 mm above the plate underside.
