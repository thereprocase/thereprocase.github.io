"""Mesh-level checks on the exported binary STLs (run with the physics python: trimesh/numpy/shapely)."""
import json, os, trimesh
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); OUT = ROOT + "/out"
asm = json.load(open(f"{OUT}/assembly.json")); meta = json.load(open(f"{OUT}/bin_meta.json"))
res = {"stl": {}, "letter_area_at_Hminus0p5_mm2": {}}; fails = []
for p in asm["parts"]:
    f = f"{OUT}/{p['file_stl']}"; m = trimesh.load(f)
    nt = int.from_bytes(open(f, "rb").read(84)[80:84], "little")
    binary = os.path.getsize(f) == 84 + 50*nt
    res["stl"][p["id"]] = dict(watertight=bool(m.is_watertight), winding_ok=bool(m.is_winding_consistent), binary=binary,
        volume_mm3=round(float(m.volume), 1), bbox_mm=[round(float(x), 3) for x in m.extents], triangles=nt)
    if not (m.is_watertight and binary and m.volume > 0): fails.append("mesh " + p["id"])
for n, mt in meta.items():
    m = trimesh.load(f"{OUT}/stl/{n}.stl"); H = mt["H"]
    import numpy as np
    xs = np.arange(-18.5, 18.5, 0.1); ys = np.arange(-19.0, mt["deck_rear"] - 0.3, 0.1)
    X, Y = np.meshgrid(xs, ys); o = np.c_[X.ravel(), Y.ravel(), np.full(X.size, H + 2.0)]
    loc, ri, _ = m.ray.intersects_location(o, np.tile([0, 0, -1.0], (len(o), 1)), multiple_hits=False)
    z = np.full(len(o), np.nan); z[ri] = loc[:, 2]
    letter = np.isclose(z, H - 0.3, atol=0.03); deck = np.isclose(z, H - 0.9, atol=0.03)
    res["letter_area_at_Hminus0p5_mm2"][n] = dict(letter_top_z_minus_H=round(float(np.nanmax(z[letter | deck]) - H), 3), letter_mm2=round(float(letter.sum())*0.01, 1), deck_mm2=round(float(deck.sum())*0.01, 1))
    if letter.sum()*0.01 < 20: fails.append("no label " + n)
res["failures"] = fails; res["passed"] = not fails
json.dump(res, open(f"{OUT}/checks_mesh.json", "w"), indent=1); print(json.dumps(res, indent=0)[:1500])
