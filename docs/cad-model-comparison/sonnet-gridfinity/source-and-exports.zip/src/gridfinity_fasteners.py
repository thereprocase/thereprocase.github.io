"""Parametric Gridfinity fastener organiser (build123d).
Run:  python src/gridfinity_fasteners.py [--layout src/layout.json] [--out out]
Frames: baseplate origin = plate centre, z=0 plate underside.  Bin origin = bin centre, z=0 foot underside.
Row 0 is the front (user side, -y); column 0 is left (-x).
"""
import json, math, os, sys, argparse
from build123d import *

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT = os.path.join(ROOT, "assets/fillaprint/Fillaprint-Regular.ttf")

# ---------------- parameters (mm) ----------------
P = dict(
    pitch=42.0, bin_w=41.5, r_out=3.75, unit=7.0,
    foot=(0.8, 1.8, 2.15),            # Gridfinity base profile: 45deg / vertical / 45deg
    lip=(0.7, 1.8, 1.9),              # Gridfinity stacking lip profile
    lip_h=3.9,                        # lip truncated from 4.4 to keep a printable 0.65 mm top edge
    clr=0.2,                          # per-side clearance of pocket and lip profile around the foot
    plate_floor=1.5, pocket_cap_w=41.8,
    wall=1.2, floor_z=5.0, divider=1.2, divider_drop=0.5,
    line_w=0.4,                       # extrusion width the FillaPrint label is scaled for
    label_h=0.6, label_sink=0.9,      # raised letters 0.6 mm, deck recessed 0.8 mm below wall top
    deck_t=2.0, line_gap=1.6, label_front=2.0, label_rear=1.4,
    scoop_s=8.0, scoop_n=10.0, notch_w=35.0,
    fill_margin=3.0,
)
FOOT_H = sum(P["foot"])               # 4.75
CAP = 14 * P["line_w"]                # cap height of FillaPrint = 14 x line width
FONT_SIZE = CAP / 0.7                 # em size (cap height is 0.7 em in this font)

def rr(w, l, r, z0, h, taper=0.0):
    """rounded-rect prism from z0 up by h; taper>0 shrinks (deg), <0 grows."""
    if abs(taper) < 1e-9:
        s = extrude(RectangleRounded(w, l, r), amount=h)
    else:
        s = extrude(RectangleRounded(w, l, r), amount=h, taper=taper)
    return s.moved(Location((0, 0, z0)))

def grow_stack(z0, w, l, r, steps):
    """steps: list of (height, kind) kind 'g' grow 45deg, 's' straight. Returns fused solid, final (w,l,r,z)."""
    solid = None; z = z0
    for h, k in steps:
        s = rr(w, l, r, z, h, -45 if k == "g" else 0)
        solid = s if solid is None else solid + s
        z += h
        if k == "g": w += 2*h; l += 2*h; r += h
    return solid, (w, l, r, z)

def foot_solid(w=41.5, l=41.5):
    a, b, c = P["foot"]
    w0 = w - 2*(a + c); l0 = l - 2*(a + c); r0 = P["r_out"] - a - c
    s, _ = grow_stack(0, w0, l0, r0, [(a, "g"), (b, "s"), (c, "g")])
    return s

def pocket_cutter(z0, top_extra=0.5):
    """negative of the foot (baseplate pocket) offset by clr per side, grown to pocket_cap_w."""
    a, b, c = P["foot"]; k = P["clr"]
    w0 = P["bin_w"] - 2*(a + c) + 2*k; r0 = P["r_out"] - a - c + k
    slope = (P["pocket_cap_w"] - (w0 + 2*a)) / 2
    s, (w, l, r, z) = grow_stack(z0, w0, w0, r0, [(a, "g"), (b, "s"), (slope, "g"), (top_extra + (FOOT_H - a - b - slope), "s")])
    return s

def lip_cutter(zH):
    """stacking-lip inner profile: foot profile + clr, rising from the wall top zH."""
    a, b, c = P["lip"]; fa, fb, fc = P["foot"]; k = P["clr"]
    w0 = P["bin_w"] - 2*(fa + fc) + 2*k; r0 = P["r_out"] - fa - fc + k
    s, _ = grow_stack(zH, w0, w0, r0, [(fa, "g"), (fb, "s"), (P["lip_h"] - fa - fb, "g")])
    return s, w0

# ---------------- text ----------------
def text_solid(txt, cx, y_base, z0, anchor="c"):
    """FillaPrint text, baseline at y_base, horizontally centred (or left-aligned) on cx. Raised label_h from z0."""
    t = Text(txt, font_size=FONT_SIZE, font_path=FONT)
    bb = t.bounding_box()
    dx = (cx - (bb.min.X + bb.max.X)/2) if anchor == "c" else (cx - bb.min.X)
    t = t.moved(Location((dx, y_base - bb.min.Y, 0)))
    sol = extrude(t, amount=P["label_h"] + 0.1).moved(Location((0, 0, z0 - 0.1)))
    return sol

def icon_solid(kind, cx, cy, z0):
    h = P["label_h"] + 0.1
    if kind == "nut":     # hexagon ring
        outer = extrude(RegularPolygon(3.0, 6), amount=h)
        hole = extrude(Circle(1.5), amount=h)
        s = outer - hole
    else:                 # round washer ring
        s = extrude(Circle(3.0), amount=h) - extrude(Circle(1.4), amount=h)
    return s.moved(Location((cx, cy, z0 - 0.1)))

# ---------------- bin ----------------
def build_bin(spec):
    """spec: dict(size, units, kind in screw|nut|washer, lengths=[...])"""
    H = spec["units"] * P["unit"]
    W = P["bin_w"]; wall = P["wall"]; fz = P["floor_z"]
    inner = W - 2*wall                                  # 39.1
    body = foot_solid() + rr(W, W, P["r_out"], FOOT_H, H + P["lip_h"] - FOOT_H)
    # cavity: straight, 45deg underhang to the lip seat, then lip profile
    ch = (inner - (W - 2*(sum(P["foot"][:1]) + P["foot"][2]) + 2*P["clr"])) / 2   # underhang height
    cav = rr(inner, inner, P["r_out"] - wall, fz, H - ch - fz)
    cav += rr(inner, inner, P["r_out"] - wall, H - ch, ch, +45)
    lipc, lip_w0 = lip_cutter(H)
    body = body - cav - lipc
    y0 = -W/2                                           # front outer face
    # compartments
    single = len(spec["lengths"]) == 1 or spec["kind"] != "screw"
    comp_w = [inner] if single else [(inner - P["divider"])/2]*2
    comp_x = [0.0] if single else [-(comp_w[0] + P["divider"])/2, (comp_w[0] + P["divider"])/2]
    if not single:
        body += Pos(0, 0, 0) * Box(P["divider"], inner + 0.2, H - P["divider_drop"] - fz + 0.2,
                                   align=(Align.CENTER, Align.CENTER, Align.MIN)).moved(Location((0, 0, fz - 0.2)))
    # rear scoop(s)
    R = P["scoop_n"] if single else P["scoop_s"]
    for cw, cx in zip(comp_w, comp_x):
        blk = Box(cw, R, R, align=(Align.CENTER, Align.MAX, Align.MIN)).moved(Location((cx, inner/2, fz - 0.1)))
        cyl = Pos(cx, inner/2 - R, fz + R - 0.1) * (Rot(0, 90, 0) * Cylinder(R, cw + 1))
        body += (blk - cyl)
    # label deck
    deck_top = H - P["label_sink"]
    ytop1 = y0 + P["label_front"] + CAP + P["line_gap"] + CAP          # top of line-1 glyphs
    deck_rear = ytop1 + P["label_rear"]
    deck = Box(inner + 0.4, deck_rear - (y0 + 0.4), P["deck_t"], align=(Align.CENTER, Align.MIN, Align.MAX)
               ).moved(Location((0, y0 + 0.4, deck_top)))
    body += deck
    # open the stacking lip across the label so the text is visible from the front
    body -= Box(P["notch_w"], 6.0, 6.0, align=(Align.CENTER, Align.MIN, Align.MIN)).moved(Location((0, y0 - 0.5, H)))
    # text
    b2 = y0 + P["label_front"]; b1 = b2 + CAP + P["line_gap"]
    z0 = deck_top
    sz = spec["size"]
    labels = []
    if spec["kind"] == "screw":
        labels.append((f"{sz} SCREW", 0.0, b1, "c"))
        if single:
            labels.append((f'{spec["lengths"][0]}mm', 0.0, b2, "c"))
        else:
            for L, cx in zip(spec["lengths"], comp_x):
                labels.append((f"{L}mm", cx * 0.96, b2, "c"))
    else:
        word = "NUT" if spec["kind"] == "nut" else "WASHER"
        labels.append((sz, -17.0, b1, "l"))
        labels.append((word, 0.0, b2, "c"))
        body += icon_solid(spec["kind"], 13.8, b1 + CAP/2, z0)
    for txt, cx, yb, al in labels:
        body += text_solid(txt, cx, yb, z0, al)
    return body, dict(H=H, comp_w=comp_w, deck_rear=deck_rear, labels=[l[0] for l in labels], single=single)

# ---------------- baseplate ----------------
def build_plate(ncols, nrows, name="plate"):
    pitch = P["pitch"]; ph = P["plate_floor"] + FOOT_H
    plate = Box(ncols*pitch, nrows*pitch, ph, align=(Align.CENTER, Align.CENTER, Align.MIN))
    cutter = pocket_cutter(P["plate_floor"])
    for i in range(ncols):
        for j in range(nrows):
            plate -= cutter.moved(Location(((i-(ncols-1)/2)*pitch, (j-(nrows-1)/2)*pitch, 0)))
    return plate

# ---------------- fastener volumes / capacity ----------------
def piece_volume(f, kind, L=None):
    if kind == "screw": return math.pi/4*f["d"]**2*L + math.pi/4*f["head_d"]**2*f["head_k"]
    if kind == "nut":   return (math.sqrt(3)/2*f["nut_af"]**2 - math.pi/4*f["d"]**2)*f["nut_m"]
    return math.pi/4*(f["w_od"]**2 - f["w_id"]**2)*f["w_t"]
PACK = {"screw": 0.35, "nut": 0.40, "washer": 0.35}      # estimated loose-pile solid fraction

def capacity(spec, info, f):
    H = info["H"]; hf = H - P["fill_margin"] - P["floor_z"]
    inner = P["bin_w"] - 2*P["wall"]; R = P["scoop_n"] if info["single"] else P["scoop_s"]
    out = []
    for k, cw in enumerate(info["comp_w"]):
        V = cw*inner*hf - (1 - math.pi/4)*R*R*cw
        L = spec["lengths"][k] if spec["kind"] == "screw" else None
        v = piece_volume(f, spec["kind"], L)
        out.append(dict(compartment_mm=[round(cw, 2), round(inner, 2)], usable_volume_mm3=round(V), piece_mm3=round(v, 1),
                        est_count=int(V*PACK[spec["kind"]]/v), item=(f'{L}mm' if L else spec["kind"])))
    return out

def bins_from_layout(lay):
    bins = []
    for j, row in enumerate(lay["rows"]):
        cell = 0
        Ls = row["lengths"]
        for a in range(0, len(Ls), 2):
            bins.append(dict(size=row["size"], units=row["units"], kind="screw", lengths=Ls[a:a+2], row=j, col=cell)); cell += 1
        for kind in ("nut", "washer"):
            bins.append(dict(size=row["size"], units=row["units"], kind=kind, lengths=[], row=j, col=cell)); cell += 1
        row["_cells"] = cell
    return bins

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--layout", default=os.path.join(ROOT, "src/layout.json"))
    ap.add_argument("--out", default=os.path.join(ROOT, "out"))
    a = ap.parse_args()
    lay = json.load(open(a.layout)); bins = bins_from_layout(lay)
    ncols = max(r["_cells"] for r in lay["rows"]); nrows = len(lay["rows"])
    os.makedirs(a.out + "/stl", exist_ok=True); os.makedirs(a.out + "/step", exist_ok=True)
    parts = []; meta = {}
    def save(name, shape):
        export_step(shape, f"{a.out}/step/{name}.step")
        export_stl(shape, f"{a.out}/stl/{name}.stl", tolerance=0.01, angular_tolerance=0.1)
    plate = build_plate(ncols, nrows); save("baseplate_%dx%d" % (ncols, nrows), plate)
    ph = P["plate_floor"] + FOOT_H
    parts.append(dict(id="baseplate", file_stl=f"stl/baseplate_{ncols}x{nrows}.stl", file_step=f"step/baseplate_{ncols}x{nrows}.step",
                      translation_mm=[0, 0, 0], rotation_deg=[0, 0, 0]))
    save("baseplate_ext_%dx1" % ncols, build_plate(ncols, 1))
    for b in bins:
        shape, info = build_bin(b)
        tag = b["kind"] if b["kind"] != "screw" else "screw_" + "_".join(map(str, b["lengths"]))
        name = f'bin_{b["size"].replace(".", "p")}_{tag}'
        save(name, shape)
        cx = (b["col"] - (ncols-1)/2) * P["pitch"]; cy = (b["row"] - (nrows-1)/2) * P["pitch"]
        parts.append(dict(id=name, file_stl=f"stl/{name}.stl", file_step=f"step/{name}.step",
                          translation_mm=[cx, cy, P["plate_floor"]], rotation_deg=[0, 0, 0], cell=[b["col"], b["row"]]))
        meta[name] = dict(info, capacity=capacity(b, info, lay["fasteners"][b["size"]]), spec=b)
        print("built", name, flush=True)
    def mat(t): return [[1,0,0,t[0]],[0,1,0,t[1]],[0,0,1,t[2]],[0,0,0,1]]
    for p in parts: p["matrix_4x4"] = mat(p["translation_mm"])
    json.dump(dict(units="mm", frame="x right (col 0 left), y back (row 0 front = -y), z up; baseplate origin = plate centre at z=0 underside; bin origin = bin centre at foot underside",
                   parts=parts), open(a.out + "/assembly.json", "w"), indent=1)
    json.dump(meta, open(a.out + "/bin_meta.json", "w"), indent=1)
    json.dump(dict(P={k: v for k, v in P.items()}, cap_height=CAP, font_size=FONT_SIZE), open(a.out + "/params_used.json", "w"), indent=1)

if __name__ == "__main__":
    main()
