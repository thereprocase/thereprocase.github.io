import json, os, sys, math
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
from build123d import import_step, Location, Pos
import gridfinity_fasteners as g
OUT = os.path.join(ROOT, "out")
asm = json.load(open(f"{OUT}/assembly.json")); meta = json.load(open(f"{OUT}/bin_meta.json"))
res = {"stl": {}, "interference": {}, "stack": {}, "labels": {}, "clear_space": {}, "capacity": {}}
fails = []
def chk(cond, msg):
    if not cond: fails.append(msg)
    return bool(cond)
# 2 assembled interference (STEP, OCC booleans)
plate = import_step(f"{OUT}/{[p for p in asm['parts'] if p['id']=='baseplate'][0]['file_step']}")
bins = {}
for p in asm["parts"]:
    if p["id"] == "baseplate": continue
    s = import_step(f"{OUT}/{p['file_step']}").moved(Location(tuple(p["translation_mm"])))
    bins[p["id"]] = s
    r_ = s & plate; v = r_.volume if r_ else 0.0
    res["interference"][p["id"] + "_vs_plate_mm3"] = round(v, 4)
    chk(v < 0.01, f"bin/plate interference {p['id']}")
ids = list(bins)
worst = 0
for i, a in enumerate(ids):
    ba = bins[a].bounding_box()
    for b in ids[i+1:]:
        bb = bins[b].bounding_box()
        if ba.max.X < bb.min.X or bb.max.X < ba.min.X or ba.max.Y < bb.min.Y or bb.max.Y < ba.min.Y: continue
        r_ = bins[a] & bins[b]; worst = max(worst, r_.volume if r_ else 0.0)
res["interference"]["max_bin_vs_bin_mm3"] = round(worst, 4); chk(worst < 0.01, "bin/bin interference")
gap = min(abs(ba_.min.X - bb_.max.X) for ba_, bb_ in [(bins[ids[0]].bounding_box(), bins[ids[5]].bounding_box())]) if False else None
res["neighbour_gap_mm"] = round(g.P["pitch"] - g.P["bin_w"], 3)
# 3 stacking: every bin type on a 3u and a 6u bin
for up, lo in [("bin_M3_screw_6_8", "bin_M2_screw_6_8"), ("bin_M4_washer", "bin_M4_washer"), ("bin_M2_nut", "bin_M4_screw_16_20")]:
    lo_s = import_step(f"{OUT}/step/{lo}.step"); up_s = import_step(f"{OUT}/step/{up}.step")
    H = meta[lo]["H"]
    seat = H - g.P["clr"]   # foot slope meets the lip edge 0.2 mm below the wall top
    r_ = up_s.moved(Location((0, 0, seat))) & lo_s; v = r_.volume if r_ else 0.0
    r2 = up_s.moved(Location((0, 0, seat - 0.5))) & lo_s; v2 = r2.volume if r2 else 0.0
    # also with 1.0 mm lateral shift in x to show the lip does not bind or collide at the stated clearance
    res["stack"][f"{up}_on_{lo}"] = dict(overlap_at_seated_height_mm3=round(v, 4), seated_height_above_wall_top_mm=-g.P["clr"], overlap_if_0p5mm_lower_mm3=round(v2, 2))
    chk(v < 0.01, f"stack {up} on {lo}")
# lip inner vs foot horizontal clearance
res["stack"]["horizontal_clearance_foot_to_lip_mm"] = g.P["clr"]
# 4 labels: font minimum and fit
H_ = g.Text("H", font_size=g.FONT_SIZE, font_path=g.FONT).bounding_box()
I_ = g.Text("|", font_size=g.FONT_SIZE, font_path=g.FONT).bounding_box()
res["labels"]["cap_height_mm"] = round(H_.size.Y, 3); res["labels"]["cap_min_required_mm"] = g.CAP
res["labels"]["stem_width_mm"] = round(I_.size.X, 3)
res["labels"]["relief_mm"] = g.P["label_h"]
chk(H_.size.Y >= g.CAP - 0.01, "cap height")
lim = 18.0; maxx = 0
for name, mt in meta.items():
    H = mt["H"]; sp = mt["spec"]; inner = 39.1
    # reproduce label positions
    y0 = -20.75; b2 = y0 + g.P["label_front"]; b1 = b2 + g.CAP + g.P["line_gap"]
    comp_x = [0.0] if mt["single"] else [-(18.95 + 1.2)/2, (18.95 + 1.2)/2]
    items = []
    if sp["kind"] == "screw":
        items.append((f"{sp['size']} SCREW", 0.0, b1, "c"))
        for L, cx in zip(sp["lengths"], comp_x): items.append((f"{L}mm", cx*0.96, b2, "c"))
    else:
        items.append((sp["size"], -17.0, b1, "l")); items.append(("NUT" if sp["kind"] == "nut" else "WASHER", 0.0, b2, "c"))
    xs = []
    for txt, cx, yb, al in items:
        t = g.text_solid(txt, cx, yb, 0, al).bounding_box()
        xs += [t.min.X, t.max.X]
        chk(t.max.Y <= mt["deck_rear"] - 0.9, f"label y {name} {txt}")
    if sp["kind"] != "screw": xs.append(13.8 + 3.0)
    mx = max(abs(x) for x in xs); maxx = max(maxx, mx)
    if len(items) == 3:   # two lengths must not overlap
        a = g.text_solid(items[1][0], items[1][1], 0, 0).bounding_box(); b = g.text_solid(items[2][0], items[2][1], 0, 0).bounding_box()
        res["labels"].setdefault("pair_gap_mm", {})[name] = round(b.min.X - a.max.X, 2); chk(b.min.X - a.max.X > 1.5, f"label overlap {name}")
    chk(mx <= lim, f"label width {name} {mx:.2f}")
    # label top vs wall top
res["labels"]["max_ink_half_width_mm"] = round(maxx, 2); res["labels"]["ink_half_width_limit_mm"] = lim
res["labels"]["label_top_below_wall_top_mm"] = g.P["label_sink"] - g.P["label_h"]
# 5 clear spaces / finger access
inner = 39.1
cs = dict(inner_cavity_mm=[39.1, 39.1], lip_opening_mm=g.P["bin_w"] - 2*(sum(g.P["foot"][:1]) + g.P["foot"][2]) + 2*g.P["clr"])
cs["open_window_depth_y_mm"] = {n: round(inner/2 + 20.75 - 20.75 + 19.55 - 0 - (m['deck_rear'] + 0) - 0, 2) for n, m in list(meta.items())[:1]}
dw = 19.55 - meta["bin_M3_screw_6_8"]["deck_rear"]
cs["open_window_depth_y_mm"] = round(dw, 2)
cs["screw_compartment_open_width_each_mm"] = round((cs["lip_opening_mm"] - g.P["divider"])/2, 2)
cs["screw_compartment_full_width_each_mm"] = 18.95
cs["under_deck_height_3u_mm"] = round(3*7 - 2.8 - g.P["floor_z"], 2)
cs["longest_screw_vs_compartment_length_mm"] = [20, 39.1]
cs["largest_head_dia_vs_narrow_compartment"] = [7.0, cs["screw_compartment_open_width_each_mm"]]
res["clear_space"] = cs
chk(cs["screw_compartment_open_width_each_mm"] > 7.0 + 8, "finger width")
for n, m in meta.items(): res["capacity"][n] = m["capacity"]
res["failures"] = fails; res["passed"] = not fails
json.dump(res, open(f"{OUT}/checks_cad.json", "w"), indent=1)
print(json.dumps({k: res[k] for k in ("interference", "stack", "labels", "clear_space", "failures", "passed")}, indent=1))
