"""Mesh checks on delivered binary STLs + assembly.json writer. Run with physics python."""
import json, os, struct, numpy as np, trimesh
R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
res = json.load(open(os.path.join(R, "checks_cad.json")))
LID_TOP = 17.8
for n in ("base", "lid"):
    p = os.path.join(R, "parts", f"{n}.stl")
    raw = open(p, "rb").read(); nt = struct.unpack("<I", raw[80:84])[0]
    m = trimesh.load(p)
    res[f"stl_{n}"] = {"binary_size_matches": len(raw) == 84 + 50 * nt, "triangles": nt, "watertight": bool(m.is_watertight),
        "winding_consistent": bool(m.is_winding_consistent), "volume_mm3": round(float(m.volume), 1),
        "extents_mm": [round(float(v), 2) for v in m.extents], "min_z": round(float(m.bounds[0][2]), 3)}
# assembled lid from print-pose mesh via the declared transform; check against base with ray/volume-free test
M = np.array([[1,0,0,0],[0,-1,0,0],[0,0,-1,LID_TOP],[0,0,0,1]], float)
lid = trimesh.load(os.path.join(R, "parts", "lid.stl")); lid.apply_transform(M)
base = trimesh.load(os.path.join(R, "parts", "base.stl"))
res["assembled_bounds_mm"] = {"base": base.bounds.round(2).tolist(), "lid": lid.bounds.round(2).tolist()}
# sample lid vertices inside base?
inside = base.contains(lid.vertices[::3])
res["lid_vertices_inside_base_solid"] = int(inside.sum())
json.dump(res, open(os.path.join(R, "checks.json"), "w"), indent=1)
asm = {"units": "mm", "frame": "x length, y width, z up; base bottom z=0; centred in x,y",
 "parts": [
  {"name": "base", "file": "parts/base.stl", "step": "parts/base.step", "transform": [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]},
  {"name": "lid", "file": "parts/lid.stl", "step": "parts/lid.step",
   "note": "files are in print pose (top face on bed, z=0..12.4); transform rotates 180 deg about X then lifts to z=17.8",
   "transform": M.tolist()}],
 "transform_convention": "4x4 row-major, applied to column vectors [x,y,z,1] of the part file coordinates"}
json.dump(asm, open(os.path.join(R, "assembly.json"), "w"), indent=1)
print(json.dumps({k: v for k, v in res.items() if k.startswith(("stl","assembled","lid_v"))}, indent=1))
