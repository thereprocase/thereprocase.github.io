"""Parametric two-DIMM (DDR4, heatspreader) mailer. build123d. Units: mm.
Run: python src/build.py
Assembled frame: x = module length, y = width, z up, base bottom at z=0, origin centred in x/y.
"""
import json, os
from build123d import *

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "parts")
os.makedirs(OUT, exist_ok=True)
FONT = os.path.join(ROOT, "assets/fillaprint/Fillaprint-Regular.ttf")

# ---------------- parameters ----------------
# supported module envelope (see README)
MOD_L_MAX = 134.5       # 133.35 nominal + heatspreader overhang
MOD_H_MAX = 45.0        # PCB + heatsink height (Trident Z class)
MOD_T_MAX = 10.0        # PCB + both spreaders (+clips)
BAG_PAD_T = 3.0         # depth allowance above the thickest module for bag + paper/foam

POCKET_L = 138.0        # 134.5 + 3.5 for bag fold / padding
POCKET_W = 47.0         # 45 + 2 for bag
POCKET_D = MOD_T_MAX + BAG_PAD_T   # 13
DIV = 3.0               # divider between pockets
WALL_Y = 3.0            # long walls
WALL_X = 3.0            # short walls
FLOOR = 2.4
CEIL = 2.4
LID_WALL = 2.0
GAP = 0.25              # lid/base radial clearance
PLINTH_H = 5.0          # base lower band, flush with lid outside
RIM_GAP = 0.4           # skirt rim to plinth shelf

# contact-edge keep-out (gold fingers face the outer long walls)
RELIEF_W = 10.0; RELIEF_D = 1.2; RELIEF_L = 132.0
SLOT_D = 1.2; SLOT_Z0 = 1.5; SLOT_Z1 = 8.0; SLOT_L = 136.0   # recess in outer wall, z above floor top

# detents
BUMP_H = 0.7; BUMP_L = 36.0; BUMP_X = 32.0
GROOVE_D = 0.5

# tabs
TAB_W = 40.0; TAB_P = 9.0; BASE_TAB_T = 3.0

# labels: Fillaprint size 9 -> cap 6.3 mm, em 9, stroke 0.9 mm = 2 x 0.45 mm beads.
# font minimum on a 0.4 nozzle (w=0.4): size 8 -> cap 5.6 mm, stroke 0.8 mm.
TXT = 9.0; TXT_DEPTH = 0.6

# derived
BASE_L = POCKET_L + 2 * WALL_X                  # 144
BASE_W = 2 * POCKET_W + DIV + 2 * WALL_Y        # 103
BASE_H = FLOOR + POCKET_D                       # 15.4
OFF = GAP + LID_WALL                            # 2.25
LID_L = BASE_L + 2 * OFF
LID_W = BASE_W + 2 * OFF
LID_TOP = BASE_H + CEIL                         # 17.8
SKIRT_BOT = PLINTH_H + RIM_GAP                  # 5.4
ZC = (SKIRT_BOT + BASE_H) / 2                   # detent height

def rrect_solid(l, w, z0, z1, r):
    s = extrude(RectangleRounded(l, w, r), amount=z1 - z0)
    return s.moved(Location((0, 0, z0)))

def bar(x0, x1, y0, y1, z0, z1):
    return Pos((x0 + x1) / 2, (y0 + y1) / 2, z0) * Box(x1 - x0, y1 - y0, z1 - z0, align=(Align.CENTER, Align.CENTER, Align.MIN))

def prism_yz(pts, xc, length):
    """polygon given as (y,z) points, extruded along x, centred on xc."""
    with BuildSketch(Plane.YZ) as sk:
        Polygon(*pts, align=None)
    p = extrude(sk.sketch, amount=length / 2, both=True)
    return p.moved(Location((xc, 0, 0)))

def mirror_y(p):
    return mirror(p, Plane.XZ)

def label(txt, x, y, z_top, rot=0):
    t = Text(txt, TXT, font_path=FONT, align=(Align.CENTER, Align.CENTER))
    t = Rot(0, 0, rot) * t
    s = extrude(t, amount=TXT_DEPTH + 0.2)
    return Pos(x, y, z_top - TXT_DEPTH) * s

# ---------------- base ----------------
def build_base():
    b = rrect_solid(BASE_L + 2 * OFF, BASE_W + 2 * OFF, 0, PLINTH_H, 5.25)
    b += rrect_solid(BASE_L, BASE_W, PLINTH_H - 0.01, BASE_H, 3.0)
    # tabs (thumb/finger grips), bottom level
    for sx in (-1, 1):
        x_in = sx * (LID_L / 2 - 2)
        x_out = sx * (LID_L / 2 + TAB_P)
        tab = bar(min(x_in, x_out), max(x_in, x_out), -TAB_W / 2, TAB_W / 2, 0, BASE_TAB_T)
        b += tab
    # pockets
    py = POCKET_W / 2 + DIV / 2
    for sy in (-1, 1):
        pk = rrect_solid(POCKET_L, POCKET_W, FLOOR, BASE_H + 1, 1.5)
        b -= Pos(0, sy * py, 0) * pk
        # contact-edge relief channel in floor beside outer long wall
        y_out = sy * (py + POCKET_W / 2)           # inner face of outer wall
        y_in = y_out - sy * RELIEF_W
        b -= bar(-RELIEF_L / 2, RELIEF_L / 2, min(y_out, y_in), max(y_out, y_in), FLOOR - RELIEF_D, FLOOR + 0.01)
        # recess in outer wall so the PCB edge itself touches nothing
        y_w = y_out + sy * SLOT_D
        b -= bar(-SLOT_L / 2, SLOT_L / 2, min(y_out - sy * 0.01, y_w), max(y_out - sy * 0.01, y_w), FLOOR + SLOT_Z0, FLOOR + SLOT_Z1)
    # finger scoop in divider (leaves a 4 mm rib so a module cannot slide to the other pocket)
    scoop = Pos(0, 0, FLOOR + 4.0) * Box(46, DIV + 0.2, POCKET_D, align=(Align.CENTER, Align.CENTER, Align.MIN))
    b -= scoop
    # detent bumps on long outer walls
    yw = BASE_W / 2
    pts = [(yw - 0.2, ZC - 1.7), (yw, ZC - 1.7), (yw + BUMP_H, ZC - 0.6), (yw + BUMP_H, ZC + 0.6), (yw, ZC + 1.7), (yw - 0.2, ZC + 1.7)]
    for xc in (-BUMP_X, BUMP_X):
        bump = prism_yz(pts, xc, BUMP_L)
        b += bump
        b += mirror_y(bump)
    # labels engraved in pocket floors: module slot number and contact side
    for sy, n in ((-1, "1"), (1, "2")):
        yl = sy * (py + POCKET_W / 2 - RELIEF_W - 6.5)      # on plateau just inboard of relief
        b -= label(f"{n}  GOLD EDGE", 0, yl, FLOOR)
    return b

# ---------------- lid (built in assembled pose) ----------------
def build_lid():
    l = rrect_solid(LID_L, LID_W, SKIRT_BOT, LID_TOP, 5.25)
    l -= rrect_solid(BASE_L + 2 * GAP, BASE_W + 2 * GAP, SKIRT_BOT - 1, BASE_H, 3.25)
    for sx in (-1, 1):
        x0 = sx * (LID_L / 2 - 3); x1 = sx * (LID_L / 2 + TAB_P)
        l += bar(min(x0, x1), max(x0, x1), -TAB_W / 2, TAB_W / 2, BASE_H, LID_TOP)
    yi = BASE_W / 2 + GAP
    gl = BUMP_L + 2.0
    pts = [(yi - 0.1, ZC - 2.0), (yi, ZC - 2.0), (yi + GROOVE_D, ZC - 1.0), (yi + GROOVE_D, ZC + 1.0), (yi, ZC + 2.0), (yi - 0.1, ZC + 2.0)]
    for xc in (-BUMP_X, BUMP_X):
        g = prism_yz(pts, xc, gl)
        l -= g
        l -= mirror_y(g)
    # labels engraved in top face
    l -= label("DDR4 DIMM PAIR", 0, 14, LID_TOP)
    l -= label("UP TO 45 X 10 MM", 0, 0, LID_TOP)
    l -= label("LIFT TABS TO OPEN", 0, -14, LID_TOP)
    return l

if __name__ == "__main__":
    base = build_base()
    lid_asm = build_lid()
    # print pose: top face on the bed. assembled = M @ print, M = [[1,0,0,0],[0,-1,0,0],[0,0,-1,LID_TOP]]
    lid_print = (Pos(0, 0, LID_TOP) * Rot(180, 0, 0)) * lid_asm
    for name, p in (("base", base), ("lid", lid_print)):
        export_step(p, os.path.join(OUT, f"{name}.step"))
        export_stl(p, os.path.join(OUT, f"{name}.stl"), tolerance=0.01, angular_tolerance=0.1)
        print(name, p.volume, p.bounding_box().size, len(p.solids()))
