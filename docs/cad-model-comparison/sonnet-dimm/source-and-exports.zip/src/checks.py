"""Measured checks. Run with kraken-cad python (uses build.py geometry) after build.py."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build import *
R = {}
base = build_base(); lid = build_lid()
R["base_solids"] = len(base.solids()); R["lid_solids"] = len(lid.solids())
R["lid_base_overlap_mm3"] = round((base & lid).volume, 4)

# module envelope models: PCB + spreaders, lying flat, contact edge toward outer wall (worst-case shifted into wall recess)
def dimm(L, H, T, spread_from=3.0):
    pcb = Box(L - 0.9, H, 1.27, align=(Align.CENTER, Align.MIN, Align.CENTER))
    sp_t = (T - 1.27) / 2
    sp = Box(L, H - spread_from, sp_t, align=(Align.CENTER, Align.MIN, Align.MIN))
    m = pcb + Pos(0, spread_from, 0.635) * sp + Pos(0, spread_from, -0.635 - sp_t) * sp
    return m
def fingers(L):  # gold-finger band, both faces, 3 mm tall from edge, 128 long, +0.15 each face for plating
    return Box(128, 3.0, 1.27 + 0.3, align=(Align.CENTER, Align.MIN, Align.CENTER))
py = POCKET_W / 2 + DIV / 2
cases = {"Vengeance LPX class 133.35x34x7.5": (133.35, 34, 7.5),
         "Ripjaws V class 133.5x42x8": (133.5, 42, 8.0),
         "Trident Z RGB class 134.5x45x10": (134.5, 45, 10.0),
         "thin-limit 133.35x31.25x6.5": (133.35, 31.25, 6.5)}
R["cases"] = {}
for k, (L, H, T) in cases.items():
    out = {}
    for sy in (-1, 1):
        # worst placement 1: module pushed against outer wall (edge into recess), other: pushed to divider
        for tag, edge_off in (("edge_in_recess", SLOT_D), ("edge_at_wall_plane", 0.0), ("pushed_to_divider", None)):
            y_wall = sy * (py + POCKET_W / 2)
            if edge_off is None:
                y_edge = sy * (py - POCKET_W / 2) + sy * (H)   # top edge on divider face (edge at far side)
            else:
                y_edge = y_wall + sy * edge_off
            m = dimm(L, H, T); f = fingers(L)
            if sy == 1:
                m = Rot(0, 0, 180) * m; f = Rot(0, 0, 180) * f   # +y pockets: edge at +y -> flip so edge is at y=0, body toward -y
            else:
                pass
            # module frame: edge at y=0 and body toward +y; for sy=+1 body toward -y after rotation
            dz = FLOOR + T / 2
            m = Pos(0, y_edge, dz) * m; f = Pos(0, y_edge, dz) * f
            # module spreaders lie on floor: spreader bottom z = dz-T/2 = FLOOR
            out[f"{'+' if sy>0 else '-'}y {tag}"] = {
                "module_vs_base_mm3": round((m & base).volume, 3),
                "fingers_vs_base_mm3": round((f & base).volume, 3),
                "module_vs_lid_mm3": round((m & lid).volume, 3),
                "module_inside_pocket_z_clear_mm": round(LID_TOP - CEIL - (dz + T / 2), 2)}
    R["cases"][k] = out
R["pocket_mm"] = [POCKET_L, POCKET_W, POCKET_D]
R["outer_closed_mm"] = [LID_L + 2 * TAB_P, LID_W, LID_TOP]
R["outer_body_mm_without_tabs"] = [LID_L, LID_W, LID_TOP]
R["divider_rib_above_floor_mm"] = 4.0
R["detent_deflection_mm"] = round(BUMP_H - GAP, 2)
R["detent_tip_slack_in_groove_mm"] = round(GAP + GROOVE_D - BUMP_H, 2)
R["label_cap_height_mm"] = TXT * 0.7; R["label_stroke_mm"] = TXT / 10.0
R["label_font_min_cap_mm_0.4nozzle"] = 5.6
for nm, t in (("DDR4 DIMM PAIR", 0), ("UP TO 45 X 10 MM", 0), ("LIFT TABS TO OPEN", 0), ("2  GOLD EDGE", 0)):
    bb = Text(nm, TXT, font_path=FONT).bounding_box(); R[f"text_width_{nm}"] = round(bb.size.X, 1)
json.dump(R, open(os.path.join(ROOT, "checks_cad.json"), "w"), indent=1)
print(json.dumps(R, indent=1))
