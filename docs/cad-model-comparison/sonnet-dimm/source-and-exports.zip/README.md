# DDR4 DIMM pair mailer (two heatspreader modules)

Two printed parts, no hardware: `parts/base` (two pockets) and `parts/lid` (telescoping cover). Each module lies flat in its own pocket, in its ESD bag with paper or foam. The closed mailer goes inside your outer cardboard box.

Closed size: 148.5 x 107.5 x 17.8 mm, or 166.5 mm long including the two grip tabs. Solid volume is 110 cm3, about 137 g if printed 100% solid in PLA. Real mass depends on infill.

## How it works
- **Modules lie flat**, heatspreader face down, gold edge toward the outer long wall. Nothing stands on or presses the contacts. In the contact zone the floor is lowered 1.2 mm over a 10 mm band, and the wall has a 1.2 mm recess (z 1.5-8 mm above the floor) that the bare PCB edge can sit in. Checked in CAD: with the module's finger band pushed fully into the recess, nothing touches it.
- **Pockets** are 138 x 47 x 13 mm. The 13 mm depth is the 10 mm thickest module plus 3 mm for bag and padding. Thinner modules have more room, so use thicker padding. The lid underside is 3 mm above a 10 mm module with no padding.
- **Lid retention**: the lid skirt slides over the base's upper wall with 0.25 mm clearance per side. Two 0.7 mm detent bumps per long wall of the base (36 mm long, ramped on both sides) click into matching grooves in the lid skirt. Opening or closing flexes the lid's long walls 0.45 mm. The lid ceiling rests on the base rim, which is the stop for pushing down.
- **Opening**: pinch the lid tab (top) and base tab (bottom) at either end, 40 mm wide and 9 mm proud, and pull apart. The lid peels off the detents progressively.
- **Removing a stick**: the divider between the pockets has a 46 mm scoop. Reach in, pinch the top edge of the module, which faces the divider, and tip it out. A 4 mm rib stays at the scoop so a module cannot slide into the other pocket.
- **Labels** (engraved 0.6 mm, Fillaprint, size 9): lid "DDR4 DIMM PAIR / UP TO 45 X 10 MM / LIFT TABS TO OPEN"; pocket floors "1 GOLD EDGE" and "2 GOLD EDGE". Size 9 gives 6.3 mm cap height and a 0.9 mm stroke, which is two 0.45 mm beads. The font's minimum on a 0.4 mm nozzle is size 8 (5.6 mm cap, 0.8 mm stroke); no label is below that. Widths are 40-62 mm, all within their faces.

## Supported envelope
| Class | Examples (approximate, from memory, not re-verified on the web) | H x T mm |
|---|---|---|
| Low profile | Corsair Vengeance LPX, HyperX/Kingston Fury DDR4 | ~34 x 7-7.5 |
| Mid | Crucial Ballistix, Kingston Fury Beast, G.Skill Ripjaws V | ~35-42 x 7.5-8.5 |
| Tall | G.Skill Trident Z / Z RGB | ~44 x up to ~10 |

Envelope: length up to 134.5 mm (nominal 133.35 mm), **height 31-45 mm**, **thickness up to 10 mm** including heatspreader clips. **Not supported**: Corsair Vengeance RGB Pro (~51 mm), Dominator Platinum (~55 mm) and RGB light-bar modules taller than 45 mm. Taller modules need `POCKET_W` raised in `src/build.py`; they cannot be mailed in this box as is. These vendor dimensions are recalled approximations. Measure your own sticks against the envelope above before relying on them.

## Measured checks (see `checks.json`)
- Both parts are single watertight solids. The STLs are binary and winding-consistent.
- Lid and base overlap by 0 mm3 in assembly. No lid vertices lie inside the base solid. A positive control (module sunk into the floor) did register overlap, so the zeros are meaningful.
- Four module models (34, 42 and 45 mm tall plus a thin 31 mm one, 6.5-10 mm thick) in either pocket, in three positions each (edge in the recess, at the wall plane, pushed to the divider): 0 mm3 overlap with base or lid, and 0 mm3 between the gold-finger band and any printed surface.
- Closed ceiling clearance above the thickest module is 3.0 mm; for a 6.5 mm module with no padding it is 6.5 mm.

## Print
PLA or PETG, 0.4 mm nozzle, 0.2 mm layers, 3 perimeters, no supports. Base prints floor down. The lid is exported in print pose (top face on the bed), and `assembly.json` carries the transform back to assembled pose (rotate 180 degrees about X, lift to z = 17.8). Press the lid straight down. Adjust `GAP`, `BUMP_H` and `GROOVE_D` if your printer's clearances differ.

## Not verified. Needs a physical test
- Detent click and release force, and whether the bumps survive repeated use. The lid's long walls are 2 mm thick, and PETG is more forgiving than PLA. 0.25 mm clearance depends on your printer.
- Whether the lid stays closed under mail vibration. It relies on the detents plus the outer box. There is no positive lock.
- Fit of real modules: heatspreader lengths, clips and RGB bars vary. The numbers above are not from datasheets.
- Fit of bag and padding in the 3 mm allowance, and how snug a thinner module is. The pocket is wider and longer than a stick, so padding does the holding.
- Whether the grip tabs and scoop feel comfortable. The scoop is about 46 mm.
- Mass and printing time have not been checked in a slicer.
- Fillaprint legibility at 0.6 mm engraving depth has not been confirmed on a real print.

## Files
`src/build.py` is the parametric source. `src/checks.py` and `src/mesh_checks.py` produce `checks.json`. `parts/` holds STEP and binary STL per part. `assembly.json` lists the parts and their transforms. Font licence: `assets/fillaprint/OFL.txt`.
