# DDR4 DIMM ×2 mailer (sliding-lid tray)

A small reusable printed mailer for two desktop DDR4 modules with ordinary heatspreaders.
The modules lie flat, each in its own pocket, inside a shielding bag with a little paper or
foam on top. A plate lid slides lengthwise in grooves and clicks onto a centre detent.
The whole thing goes inside an outer cardboard box; it is not a stand-alone shipping box.

Outer size, closed: **150 × 106 × 18.7 mm**. Two printed parts, no hardware.

## Supported module envelope

Design envelope per pocket: **module ≤ 140 long × 45 tall × 8.5 thick (mm), heatspreader included**,
inside a 4×6" (100×150 mm) or 9×18 cm shielding bag folded around the module.

| Module | L × T × H (mm) | Fits | Source |
|---|---|---|---|
| Kingston FURY Beast DDR4 | 133.35 × 7.2 × 34 | yes | Kingston datasheet KF432C16BB1_16 |
| Kingston FURY Renegade DDR4 | 133.35 × 8.3 × 42.2 | yes | Kingston datasheet KF436C16RB_8 |
| Corsair Vengeance LPX | 135 × 6.64 × 33.53 | yes | Corsair support "RAM Memory Module Dimensions" |
| Corsair Vengeance RGB RS | 135 × 7 × 45 | yes (at the limit) | same |
| Corsair Vengeance RGB Pro SL / RGB RT | 138.3 × 7.5 × 44.8 | yes | same |
| Crucial Ballistix (non-RGB) | ≈133.35 × ~7 × 39.17 | yes | Crucial spec, TechPowerUp measured 39.25 |
| G.Skill Ripjaws V / Flare X | 42 / 40 tall | yes | G.Skill FAQ "How tall are the memory modules" |
| G.Skill Trident Z, Z RGB, Z Neo, Z Royal | 44 tall (44.55 measured) | yes | G.Skill FAQ, TechPowerUp |
| TeamGroup T-Force Vulcan Z | 140 × 7 × 32 | yes (sets the length limit) | TeamGroup spec sheet |
| Corsair Vengeance LED / RGB Pro | 49 / 51 tall | **no** | Corsair support table |
| Corsair Dominator Platinum (RGB) | 55 / 56 tall | **no** | Corsair support table |
| G.Skill Trident Z RGB DC | 59 tall | **no** | G.Skill FAQ |

45 mm covers every plain and most mid-height RGB heatspreader; going to 51 mm for the
Vengeance RGB Pro would add 12 mm to the width for one family, and the 55 mm+ Dominator class
is out of scope by the brief. Bare 31.25 mm JEDEC modules fit too (more padding needed).

Pocket: 143 × 48 × 11.5 mm. That is +3 mm on length (bag end fold), +3 mm on height (bag folded
behind the module), +3 mm on thickness (padding layer between module and lid).

## How it works

**Orientation.** Modules lie on their heatspreader faces. The gold-finger edge faces the
**centre rib**, so the contacts sit in the middle of the box, away from the outer walls.
Along each rib side the floor has an 8 mm wide × 1.2 mm deep relief groove, so even a
bare module (which lies on its chips) cannot rest on its contacts. A heatspreader module's
bare contact strip floats (T − 1.2)/2 above the floor: 3.65 mm for an 8.5 mm module,
2.7 mm for a 6.64 mm Vengeance LPX, and 1.2 mm more over the groove. The lid never touches the module: 3 mm is left above the 8.5 mm
envelope for the padding, which is what stops rattle.

**Lid retention.** The lid is a 2.4 mm plate that slides along the length in a 2.7 mm tall,
1.5 mm deep groove cut into both long walls and the closed end wall. Once in, it cannot be
lifted anywhere along its length; it can only slide. The entrance end wall is low (its top
is level with the lid underside) and carries a triangular detent ridge 0.8 mm tall, 10 mm
long across the centre. The lid underside has a matching 1.0 mm deep dimple at its leading
end. When closing, the plate rides over the ridge (the plate bows about 0.8 mm at its
middle; a 2.4 mm PLA/PETG plate 101 mm wide does this with a few newtons) and drops onto
it with a click. The closed-end groove is the closing stop. The outer cardboard box is the
second line of defence; even with a weak detent the lid cannot slide out inside a box.
A thumb bar 32 mm from the leading edge gives a push surface for opening (push toward the
arrow) and for closing. The bar is set back so the leading strip of the plate stays
flexible enough to pass the ridge.

**Getting the sticks out.** Each pocket floor has a 30 × 20 mm thumb slot under the centre
of the module (under the heatspreader, 15 mm clear of the contact strip). Slide the lid off,
push up from below with a thumb, then take the module by its ends or its top edge. Nothing
has to be pried out and nothing touches the contacts.

**Loading.** Bag each module, fold the bag excess behind it and tape, lay it in with the
contacts toward the centre rib (floor says `CONTACTS ↓` / `CONTACTS ↑`), add a strip of
foam or folded paper on top so it is flush with or below the pocket rim (do not let it
stand proud, the lid must slide over it), slide the lid in chamfered end first until it
clicks, then put the tray in an outer box.

## Labels (Fillaprint)

Font: `assets/fillaprint/Fillaprint-Regular.ttf` (OFL). The font's rule: cap height = 14 ×
line width, em = 20 × line width, strokes and gaps = 2 × line width. Everything is set at
**em 10 mm → 7.0 mm capitals, 1.0 mm strokes and gaps** (w = 0.5 mm), above the 5.88 mm
minimum for a 0.42 mm line. Cap height and the 1.0 mm bar glyph were measured on the
generated outlines. Slice the text at 0.5 mm line width (or leave 0.42, Arachne fills it).

- Lid top, raised 0.6 mm: `DDR4 DIMM ×2`, `OPEN →` (arrow points to the sliding-out end).
- Pocket floors, debossed 0.6 mm: `CONTACTS ↓` / `CONTACTS ↑` (arrow toward the rib),
  `MAX 140×45×8.5` in the +Y pocket.
- Underside, debossed 0.6 mm: `MAX 140×45×8.5 mm`.

## Printing

- Base: open side up, no supports. The 1.5 mm groove roof is a short flat overhang that
  prints fine; keep it in mind if you use a very hot/fast profile.
- Lid: label side up, no supports. The dimple and the end chamfers are on the bed side.
- 0.4 mm nozzle, 0.2 mm layers, 3–4 perimeters. PETG is nicer for the detent long term;
  PLA is fine.
- Fit parameters at the top of `cad/dimm_mailer.py`: `LID_SIDE_CLR` (0.25 per side),
  `LID_VERT_CLR` (0.3), `BUMP_H` (0.8), `DIMPLE_D` (1.0). If the lid is tight, raise the
  side clearance to 0.35; if the click is too weak, raise `BUMP_H` to 1.0.

## Files

- `cad/dimm_mailer.py` parametric source (build123d). Run with the kraken-cad venv; writes `out/` and `assembly.json`.
- `out/base.step`, `out/base.stl`, `out/lid.step`, `out/lid.stl` the two printed parts (binary STL).
- `out/module_envelope_A/B.step|.stl` reference 140×45×8.5 modules (heatspreader body + PCB with a 5 mm bare contact strip), for checking only.
- `out/assembly_closed.step` all of the above, lid closed.
- `assembly.json` part files and 4×4 transforms (mm) in the base frame; lid transform is the closed position.
- `checks/measure.py` mesh-level checks (trimesh); `checks/checks.json` the results; `checks/cad_report.json` numbers from the CAD run.

## What was verified (see checks/checks.json)

- Both printed parts are watertight, valid solids.
- Measured on the STLs: groove-to-groove width vs lid width, groove height vs lid thickness,
  lid captured 1.0+ mm each side under the lip, wall left outside the groove 2.0 mm, floor
  under the relief groove 1.8 mm.
- Reference modules 0.5 mm from the rib (one bag fold): no penetration into base or lid,
  contact strip underside 4.84 mm above the relief groove floor (ray-cast), 3.0 mm free
  above the module for padding, 4.0 mm between the two modules' contact edges.
- Lid slid from closed to fully out in steps: no clash with the base except the detent
  ridge lifting the plate by ≤0.8 mm, as intended.
- Font: cap height 7.0 mm and 1.0 mm strokes measured on the generated geometry.

## What still needs a physical test

- **Detent feel.** The click force depends on printer, material and how much the plate
  bows. The geometry is deliberately mild (0.8 mm ridge, 14° ramps). Expect a light,
  positive click; tune `BUMP_H`.
- **Sliding fit.** 0.25 mm per side and 0.3 mm vertical suits a well-calibrated printer.
  A first print tells you whether to loosen it.
- **Bag bulk.** A 4×6" bag folded around a 45 mm tall module should fit the 48 mm pocket;
  a bag folded sloppily, or a 5×8" bag, will not. Trim or fold neatly.
- **The groove roof overhang** (1.5 mm) and the raised letters: check the first print for
  sagging or stringing between letters.

## Limitations

- Not a crush-proof shipping box on its own; it relies on the outer carton and the
  padding you add. The thumb slots are open holes in the floor (the bag covers the module).
- Modules taller than 45 mm or longer than 140 mm (RGB Pro, Dominator, DC) do not fit.
- The lid can be inserted dimple-end first by mistake; it still closes but will not click.
  The chamfered corners and the `OPEN →` arrow show the right way round.
