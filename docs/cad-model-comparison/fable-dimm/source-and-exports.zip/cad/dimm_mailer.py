"""
DDR4 DIMM x2 mailer -- parametric build123d model.

Two heatspreader DIMMs lie flat, each in its own pocket, inside shielding bags with a
little padding. A plate lid slides lengthwise in grooves cut into the long walls and the
closed end wall; it is held closed by a centre detent bump on the low entrance wall that
seats in a dimple under the lid. Modules are lifted out through a thumb slot in each pocket floor.

Coordinate frame (base): X = length (0 at closed end, L_OUT at the entrance end),
Y = width (0 at the centre rib), Z = up (0 at the underside).
Lid is modelled in its own frame: X 0..LID_L (X = LID_L is the leading/entrance edge),
Y centred, Z 0..LID_T. Its closed-position transform is written to assembly.json.

Run:  python cad/dimm_mailer.py
"""
from __future__ import annotations
import json, math, os, sys
from build123d import *  # noqa: F401,F403

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "out")
FONT = os.path.join(ROOT, "assets", "fillaprint", "Fillaprint-Regular.ttf")
os.makedirs(OUT, exist_ok=True)

# ----------------------------------------------------------------------------- envelope
# Supported module (heatspreader included): length x thickness x height.
MOD_L, MOD_T, MOD_H = 140.0, 8.5, 45.0
# Pocket = module + bag folds + "a little paper or foam".
POCKET_L = 143.0          # +3.0 on length (bag end fold, square module corners vs pocket fillets)
POCKET_W = 48.0           # +3.0 on module height (bag folded over the back of the module)
POCKET_D = 11.5           # +3.0 on module thickness for the padding layer above the module

# ----------------------------------------------------------------------------- walls
FLOOR_T = 3.0             # floor
RIB_W = 3.0               # centre rib between pockets; contacts face this rib
WALL_T = 3.5              # long walls and closed end wall (groove is cut 1.5 into them)
END_T = 3.5               # both end walls
GROOVE_D = 1.5            # groove depth into the walls (lid edge engagement)
LID_T = 2.4               # lid plate
LID_VERT_CLR = 0.3        # groove height - lid thickness
LID_SIDE_CLR = 0.25       # per side, lid width vs groove-to-groove width
LID_END_GAP = 0.3         # lid far end vs closed-end groove bottom
LIP_T = 1.5               # wall material above the groove
RIB_DROP = 0.3            # rib top sits this much below the lid underside (no drag, supports lid under crush)

GROOVE_H = LID_T + LID_VERT_CLR
Z_RIM = FLOOR_T + POCKET_D                     # groove bottom = lid underside = pocket rim
H_OUT = Z_RIM + GROOVE_H + LIP_T               # outer height of the base
W_IN = 2 * POCKET_W + RIB_W                    # interior width between long walls
W_OUT = W_IN + 2 * WALL_T
L_OUT = POCKET_L + 2 * END_T
W_GROOVE = W_IN + 2 * GROOVE_D                 # groove-to-groove width
LID_W = W_GROOVE - 2 * LID_SIDE_CLR
LID_X0 = END_T - GROOVE_D + LID_END_GAP        # base-frame X of the lid far end when closed
LID_L = L_OUT - LID_X0                         # lid is flush with the entrance face when closed
LID_Z0 = Z_RIM                                 # lid underside when closed

# ----------------------------------------------------------------------------- features
CONTACT_GROOVE_W = 8.0    # relief groove under the gold-finger edge (beside the rib)
CONTACT_GROOVE_D = 1.2
PUSH_SLOT_L, PUSH_SLOT_W = 30.0, 20.0   # thumb slot through each pocket floor (stadium)
POCKET_CORNER_R = 1.5
OUTER_CORNER_R = 4.0
BUMP_H = 0.8              # detent ridge on the entrance wall top
BUMP_LEN = 10.0           # ridge length across Y
DIMPLE_D = 1.0            # recess under the lid that the ridge seats in
DIMPLE_CLR = 0.2          # per side, dimple footprint vs ridge footprint
BAR_L, BAR_W, BAR_H = 56.0, 4.0, 1.6   # thumb bar on the lid
BAR_SETBACK = 32.0        # from the leading edge (keeps the leading plate strip free to flex over the ridge)
LID_END_CHAMFER = 0.8     # underside chamfer at both lid ends (rides over the ridge)
LID_PLAN_CHAMFER = 2.0    # plan chamfer at the far-end corners (insertion)

# ----------------------------------------------------------------------------- labels
LINE_W = 0.5              # Fillaprint sizing: cap height = 14 w, em = 20 w, stroke = 2 w
FONT_EM = 20 * LINE_W     # 10.0 mm em -> 7.0 mm capitals, 1.0 mm strokes/gaps
LABEL_RAISE = 0.6         # raised text on the lid
LABEL_CUT = 0.6           # debossed text in the pocket floors and the underside

def text_sketch(s: str, em: float = FONT_EM):
    return Text(s, font_size=em, font_path=FONT, align=(Align.CENTER, Align.CENTER))

def text_part(s: str, height: float, em: float = FONT_EM):
    return extrude(text_sketch(s, em), amount=height)

# ============================================================================= BASE
base = Pos(L_OUT / 2, 0, H_OUT / 2) * Box(L_OUT, W_OUT, H_OUT)
base = fillet(base.edges().filter_by(Axis.Z), OUTER_CORNER_R)
# comfort chamfers on the outer top and bottom edges (done before any cuts so the edge selection is clean)
base = chamfer(base.edges().group_by(Axis.Z)[-1], 0.8)
base = chamfer(base.edges().group_by(Axis.Z)[0], 0.5)

# pockets
pocket_centres = []
for sgn in (+1, -1):
    yc = sgn * (RIB_W / 2 + POCKET_W / 2)
    xc = END_T + POCKET_L / 2
    pocket_centres.append((xc, yc))
    pk = Pos(xc, yc, FLOOR_T + 50) * Box(POCKET_L, POCKET_W, 100)
    pk = fillet(pk.edges().filter_by(Axis.Z), POCKET_CORNER_R)
    base -= pk

# lid groove band: from the closed-end groove bottom out through the entrance face
groove_x0 = END_T - GROOVE_D
base -= Pos((groove_x0 + L_OUT) / 2, 0, Z_RIM + GROOVE_H / 2) * Box(L_OUT - groove_x0, W_GROOVE, GROOVE_H)

# entrance wall is low (lid slides over it); only the outer parts of the long walls stay full height
base -= Pos(L_OUT - END_T / 2, 0, (Z_RIM + H_OUT + 5) / 2) * Box(END_T + 1.0, W_GROOVE, H_OUT + 5 - Z_RIM)
# centre rib dropped below the lid underside
base -= Pos(END_T + POCKET_L / 2, 0, (Z_RIM - RIB_DROP + H_OUT) / 2) * Box(POCKET_L, RIB_W + 0.01, H_OUT - Z_RIM + RIB_DROP)

# contact relief grooves along the rib side of each pocket floor
for xc, yc in pocket_centres:
    sgn = 1 if yc > 0 else -1
    yg = sgn * (RIB_W / 2 + CONTACT_GROOVE_W / 2)
    base -= Pos(xc, yg, FLOOR_T - CONTACT_GROOVE_D / 2) * Box(POCKET_L - 2 * POCKET_CORNER_R, CONTACT_GROOVE_W, CONTACT_GROOVE_D)

# push-up thumb slots through each floor
for xc, yc in pocket_centres:
    slot = extrude(SlotOverall(PUSH_SLOT_L, PUSH_SLOT_W), amount=FLOOR_T + 2)
    base -= Pos(xc, yc, -1) * slot

# detent ridge on the entrance wall top (triangular prism, ramps on both sides)
ridge_prof = Polygon((-END_T / 2, 0), (END_T / 2, 0), (0, BUMP_H), align=None)
ridge = extrude(Plane.XZ * ridge_prof, amount=BUMP_LEN / 2, both=True)
base += Pos(L_OUT - END_T / 2, 0, Z_RIM) * ridge

# floor labels (debossed). Positions keep clear of the thumb slot (x within +-15 of the pocket centre, y 15.5..35.5)
for xc, yc in pocket_centres:
    sgn = 1 if yc > 0 else -1
    arrow = "\u2193" if sgn > 0 else "\u2191"           # points toward the rib = where the gold fingers go
    y_lab = sgn * (RIB_W / 2 + CONTACT_GROOVE_W + 2.0 + 0.5 * (14 * LINE_W))   # just outboard of the relief groove
    base -= Pos(xc + 40.0, y_lab, FLOOR_T) * text_part(f"CONTACTS {arrow}", -LABEL_CUT)
    if sgn > 0:   # envelope reminder in the outer band of the +Y pocket
        base -= Pos(xc, sgn * (RIB_W / 2 + POCKET_W - 7.0), FLOOR_T) * text_part("MAX 140\u00d745\u00d78.5", -LABEL_CUT)

# underside label (debossed into the bottom face), in the outer band of the -Y pocket floor: no slot or groove there
under = Rot(180, 0, 0) * text_part("MAX 140\u00d745\u00d78.5 mm", LABEL_CUT)   # faces -Z, cut extends up into the floor
base -= Pos(L_OUT / 2, -(RIB_W / 2 + POCKET_W - 7.0), LABEL_CUT) * under   # text body occupies z 0..LABEL_CUT

# ============================================================================= LID
lid = Pos(LID_L / 2, 0, LID_T / 2) * Box(LID_L, LID_W, LID_T)
# plan chamfer on the far-end corners (enters the grooves first)
far_vert = [e for e in lid.edges().filter_by(Axis.Z) if e.center().X < 1e-3]
lid = chamfer(far_vert, LID_PLAN_CHAMFER)
# underside chamfer at both ends so the plate rides up over the detent ridge
end_bottom = [e for e in lid.edges().filter_by(Axis.Y) if e.center().Z < 1e-3 and (e.center().X < 1e-3 or abs(e.center().X - LID_L) < 1e-3)]
lid = chamfer(end_bottom, LID_END_CHAMFER)

# detent dimple under the leading end: footprint = ridge footprint + clearance
ridge_cx_base = L_OUT - END_T / 2
dimple_x = ridge_cx_base - LID_X0
dimple = Pos(dimple_x, 0, DIMPLE_D / 2 - 0.001) * Box(END_T + 2 * DIMPLE_CLR, BUMP_LEN + 2 * DIMPLE_CLR, DIMPLE_D + 0.002)
lid -= dimple

# thumb bar
bar = extrude(SlotOverall(BAR_L, BAR_W), amount=BAR_H)
bar = Rot(0, 0, 90) * bar  # long axis along Y
lid += Pos(LID_L - BAR_SETBACK, 0, LID_T) * bar

# lid labels (raised)
LINE_PITCH = 28 * LINE_W   # 14 mm baseline pitch from the font's guidance
lid += Pos(58.0, +LINE_PITCH / 2, LID_T) * text_part("DDR4 DIMM ×2", LABEL_RAISE)
lid += Pos(58.0, -LINE_PITCH / 2, LID_T) * text_part("OPEN →", LABEL_RAISE)

# ============================================================================= reference module envelopes (not printed)
# Heatspreader body (full thickness) + PCB with the bare contact strip (CONTACT_STRIP tall) toward the rib.
PCB_T, PCB_L, CONTACT_STRIP = 1.2, 133.35, 5.0
MODULE_RIB_GAP = 0.5
modules = []
for xc, yc in pocket_centres:
    sgn = 1 if yc > 0 else -1
    # near-worst case: contact edge 0.5 mm (one bag fold) from the rib wall
    y_edge = sgn * (RIB_W / 2 + MODULE_RIB_GAP)                 # contact edge Y
    y_hs_c = y_edge + sgn * (CONTACT_STRIP + (MOD_H - CONTACT_STRIP) / 2)
    hs = Pos(xc, y_hs_c, FLOOR_T + MOD_T / 2) * Box(MOD_L, MOD_H - CONTACT_STRIP, MOD_T)
    pcb = Pos(xc, y_edge + sgn * MOD_H / 2, FLOOR_T + MOD_T / 2) * Box(PCB_L, MOD_H, PCB_T)
    modules.append(hs + pcb)

# ============================================================================= checks in CAD space
def bb(p):
    b = p.bounding_box(); return (b.min.X, b.min.Y, b.min.Z, b.max.X, b.max.Y, b.max.Z)

cap = text_sketch("H").bounding_box()
cap_h = cap.max.Y - cap.min.Y
stroke = text_sketch("I").bounding_box()
stroke_w = stroke.max.X - stroke.min.X
cad_report = {
    "outer_base_mm": [L_OUT, W_OUT, H_OUT],
    "lid_mm": [LID_L, LID_W, LID_T],
    "pocket_mm": [POCKET_L, POCKET_W, POCKET_D],
    "module_envelope_mm": [MOD_L, MOD_H, MOD_T],
    "groove": {"height": GROOVE_H, "depth": GROOVE_D, "width_between": W_GROOVE},
    "lid_clearances": {"vertical": LID_VERT_CLR, "per_side": LID_SIDE_CLR, "end_gap": LID_END_GAP},
    "lid_closed_transform_xyz": [LID_X0, 0.0, LID_Z0],
    "font": {"em_mm": FONT_EM, "cap_height_measured_mm": round(cap_h, 3), "I_stroke_width_measured_mm": round(stroke_w, 3),
             "min_for_0.42_line_cap_mm": 14 * 0.42, "label_raise_mm": LABEL_RAISE, "label_cut_mm": LABEL_CUT},
    "volumes_mm3": {"base": round(base.volume, 1), "lid": round(lid.volume, 1)},
    "base_bbox": bb(base), "lid_bbox": bb(lid),
    "valid": {"base": base.is_valid, "lid": lid.is_valid},
}
print(json.dumps(cad_report, indent=1))

# ============================================================================= export
export_step(base, os.path.join(OUT, "base.step"))
export_step(lid, os.path.join(OUT, "lid.step"))
export_stl(base, os.path.join(OUT, "base.stl"), tolerance=0.01, angular_tolerance=0.1)
export_stl(lid, os.path.join(OUT, "lid.stl"), tolerance=0.01, angular_tolerance=0.1)
for i, m in enumerate(modules):
    export_step(m, os.path.join(OUT, f"module_envelope_{'AB'[i]}.step"))
    export_stl(m, os.path.join(OUT, f"module_envelope_{'AB'[i]}.stl"), tolerance=0.01, angular_tolerance=0.1)

# closed assembly (lid placed) as one STEP for convenience
lid_placed = Pos(LID_X0, 0, LID_Z0) * lid
asm = Compound(children=[base, lid_placed] + modules)
export_step(asm, os.path.join(OUT, "assembly_closed.step"))

def T(x, y, z):
    return [[1, 0, 0, x], [0, 1, 0, y], [0, 0, 1, z], [0, 0, 0, 1]]

assembly = {
    "units": "mm",
    "frame": "base frame: X along length (0 = closed end, +X toward the open/entrance end), Y across width (0 = centre rib), Z up (0 = underside). Column-vector 4x4 transforms, applied to each part's own file coordinates.",
    "state": "closed: lid slid fully in, detent seated. Lid opens by sliding +X.",
    "parts": [
        {"name": "base", "files": ["out/base.step", "out/base.stl"], "print": True, "transform": T(0, 0, 0)},
        {"name": "lid", "files": ["out/lid.step", "out/lid.stl"], "print": True, "transform": T(LID_X0, 0, LID_Z0),
         "motion": {"type": "prismatic", "axis": [1, 0, 0], "open_travel_mm": LID_L}},
        {"name": "module_envelope_A", "files": ["out/module_envelope_A.step", "out/module_envelope_A.stl"], "print": False,
         "note": "reference 140x45x8.5 mm heatspreader DIMM, contact edge 0.5 mm from the rib (+Y pocket)", "transform": T(0, 0, 0)},
        {"name": "module_envelope_B", "files": ["out/module_envelope_B.step", "out/module_envelope_B.stl"], "print": False,
         "note": "reference 140x45x8.5 mm heatspreader DIMM, contact edge 0.5 mm from the rib (-Y pocket)", "transform": T(0, 0, 0)},
    ],
    "assembly_step": "out/assembly_closed.step",
}
with open(os.path.join(ROOT, "assembly.json"), "w") as f:
    json.dump(assembly, f, indent=1)
with open(os.path.join(ROOT, "checks", "cad_report.json"), "w") as f:
    json.dump(cad_report, f, indent=1)
print("exported to", OUT)
