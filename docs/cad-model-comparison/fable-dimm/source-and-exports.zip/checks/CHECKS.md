# Measured checks (from checks/checks.json, produced by checks/measure.py on the exported STLs)

| Check | Measured | Result |
|---|---|---|
| Parts watertight (base, lid, 2 reference modules) | all true | pass |
| Groove-to-groove width vs lid width | 102.0 vs 101.5 mm (0.25 mm per side) | pass |
| Groove height vs lid plate | 2.7 vs 2.4 mm (0.3 mm vertical) | pass |
| Lid captured under the lip, each side | 1.25 mm | pass |
| Wall left outside the groove | 2.0 mm | pass |
| Floor under the contact relief groove / elsewhere | 1.8 / 3.0 mm | pass |
| Reference modules (140×45×8.5) inside the closed box | 0 points penetrate base or lid | pass |
| Padding room above an 8.5 mm module | 3.0 mm | pass |
| Contact-strip underside above the relief groove floor (ray cast, 400 rays each) | 4.84 mm | pass |
| Gap between the two modules' contact edges across the rib | 4.0 mm | pass |
| Lid slid 0 → 140 mm in 8 steps, penetration into base away from the detent ridge | 0 points | pass |
| Penetration at the ridge (plate lift while sliding) | 0.64–0.71 mm sampled (ridge peak 0.8) | pass, intended |
| Fillaprint capital height on the lid mesh | 7.0 mm (min 5.88 at a 0.42 line) | pass |
| Raised label height / debossed depth | 0.6 / 0.6 mm | pass |

Not measurable here: detent click force, real sliding friction, print tolerance. See README "What still needs a physical test".
