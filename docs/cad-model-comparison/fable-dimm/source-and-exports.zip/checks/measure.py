"""Mesh-level verification of the exported parts (trimesh/numpy). Run with the physics venv.
Writes checks/checks.json and prints a summary. Independent of the CAD kernel: everything is measured on the STLs."""
import json, os, sys, time
import numpy as np, trimesh

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "out")
asm = json.load(open(os.path.join(ROOT, "assembly.json")))
P = {p["name"]: p for p in asm["parts"]}

def load(name):
    m = trimesh.load(os.path.join(ROOT, P[name]["files"][1]), force="mesh")
    T = np.array(P[name]["transform"], float)
    m.apply_transform(T)
    return m

base, lid, modA, modB = load("base"), load("lid"), load("module_envelope_A"), load("module_envelope_B")
lid_local = trimesh.load(os.path.join(OUT, "lid.stl"), force="mesh")
R = {"parts": {}, "fits": {}, "clearances": {}, "slide": {}, "labels": {}, "pass": {}}
for n, m in [("base", base), ("lid", lid), ("module_envelope_A", modA), ("module_envelope_B", modB)]:
    R["parts"][n] = {"watertight": bool(m.is_watertight), "volume_mm3": round(float(m.volume), 1),
                     "bbox_min": [round(float(v), 3) for v in m.bounds[0]], "bbox_max": [round(float(v), 3) for v in m.bounds[1]],
                     "faces": int(len(m.faces))}

def section_pts(m, origin, normal):
    s = m.section(plane_origin=origin, plane_normal=normal)
    return np.asarray(s.vertices) if s is not None else np.zeros((0, 3))

# --- groove geometry measured on the base mesh by ray casting (robust against triangulation)
def hits(m, origin, direction):
    loc, _, _ = m.ray.intersects_location([origin], [direction], multiple_hits=True)
    d = np.linalg.norm(loc - np.asarray(origin), axis=1); return np.sort(d)
def material_runs(m, origin, direction):
    """distances along the ray at which the ray enters/leaves material, as (enter, leave) pairs"""
    d = hits(m, origin, direction); return [(d[i], d[i + 1]) for i in range(0, len(d) - 1, 2)]
# +Y ray through the long wall at mid-groove height: groove inner face -> outer face
runs = material_runs(base, [75, 0, 15.85], [0, 1, 0]); wall = runs[-1]; groove_inner = 2 * wall[0]; wall_outside_groove = wall[1] - wall[0]
runs = material_runs(base, [75, 0, 18.2], [0, 1, 0]); lip_inner = 2 * runs[-1][0]
# +Z ray inside the groove's y band: material (wall) ends at the groove bottom, resumes at the groove top
runs = material_runs(base, [75, 50.3, -1], [0, 0, 1]); groove_z0, groove_z1 = runs[0][1] - 1, runs[1][0] - 1
runs = material_runs(base, [75, 5.0, -1], [0, 0, 1]); floor_under_relief = runs[0][1] - runs[0][0]
runs = material_runs(base, [30, 30.0, -1], [0, 0, 1]); floor_full = runs[0][1] - runs[0][0]
runs = material_runs(lid_local, [60, 48, -1], [0, 0, 1]); lid_t = runs[0][1] - runs[0][0]
runs = material_runs(lid_local, [60, 0, -1], [0, 0, 1]); lid_t_mid = runs[0][1] - runs[0][0]
loc, _, _ = lid_local.ray.intersects_location([[60, -60, 1.2]], [[0, 1, 0]], multiple_hits=True); yy = np.sort(loc[:, 1]); lid_w = yy[-1] - yy[0]
R["fits"] = {"groove_width_between_mm": round(float(groove_inner), 3), "lid_width_mm": round(float(lid_w), 3),
             "lid_side_clearance_each_mm": round(float(groove_inner - lid_w) / 2, 3),
             "groove_height_mm": round(float(groove_z1 - groove_z0), 3), "lid_plate_thickness_mm": round(float(lid_t), 3),
             "lid_vertical_clearance_mm": round(float(groove_z1 - groove_z0 - lid_t), 3),
             "opening_above_groove_mm": round(float(lip_inner), 3), "lid_captured_each_side_mm": round(float(lid_w - lip_inner) / 2, 3),
             "wall_outside_groove_mm": round(float(wall_outside_groove), 3), "floor_under_relief_groove_mm": round(float(floor_under_relief), 3),
             "floor_full_mm": round(float(floor_full), 3), "lid_thickness_at_centre_mm": round(float(lid_t_mid), 3),
             "groove_bottom_z": round(float(groove_z0), 3), "groove_top_z": round(float(groove_z1), 3)}

# --- module envelopes inside the closed box: no intersection, clearance to base and lid
def surf_pts(m, n, seed=0):
    pts, _ = trimesh.sample.sample_surface(m, n, seed=seed); return np.asarray(pts)
def inside_count(container, pts):
    # points more than 0.02 mm inside the container (a module resting on the floor has points exactly on the surface)
    return int((trimesh.proximity.signed_distance(container, pts) > 0.02).sum())
for name, mod in [("A", modA), ("B", modB)]:
    pts = np.vstack([surf_pts(mod, 6000), mod.vertices])
    d_base = trimesh.proximity.closest_point(base, pts)[1]
    d_lid = trimesh.proximity.closest_point(lid, pts)[1]
    # contact strip: PCB underside within 5 mm of the contact edge (edge = |y| = 1.5, PCB bottom z = 3 + (8.5-1.2)/2)
    sgn = 1 if mod.centroid[1] > 0 else -1
    y_edge = 1.5 + 0.5   # rib half width + bag gap (see MODULE_RIB_GAP in the CAD)
    xs = np.linspace(mod.bounds[0][0] + 1, mod.bounds[1][0] - 1, 40); ys = sgn * np.linspace(y_edge + 0.05, y_edge + 5.0, 10)
    X, Y = np.meshgrid(xs, ys); strip = np.column_stack([X.ravel(), Y.ravel(), np.full(X.size, 3.0 + (8.5 - 1.2) / 2 - 0.01)])
    loc, ray_i, _ = base.ray.intersects_location(strip, np.tile([0, 0, -1.0], (len(strip), 1)), multiple_hits=False)
    drop = strip[ray_i, 2] - loc[:, 2]
    d_strip = drop   # vertical clearance under the bare contact strip (PCB underside) to the floor/relief groove
    R["clearances"][f"module_{name}"] = {
        "points_inside_base": inside_count(base, pts), "points_inside_lid": inside_count(lid, pts),
        "min_dist_to_base_mm": round(float(d_base.min()), 3), "min_dist_to_lid_mm": round(float(d_lid.min()), 3),
        "contact_strip_min_drop_to_floor_mm": round(float(d_strip.min()), 3), "contact_strip_rays": int(len(d_strip)),
        "module_top_z": round(float(mod.bounds[1][2]), 3), "lid_underside_z": round(float(lid.bounds[0][2]), 3)}
# modules do not touch each other
dAB = trimesh.proximity.closest_point(modB, surf_pts(modA, 2000))[1]; R["clearances"]["module_A_to_B_mm"] = round(float(dAB.min()), 3)

# --- lid slide: translate the lid along +X from closed (t=0) to removed (t=LID_L); measure penetration into the base
gx = np.arange(0.25, lid_local.bounds[1][0], 0.5); gy_fine = np.arange(-8, 8.01, 0.5); gy_coarse = np.arange(-50.5, 50.51, 2.5)
GX, GY = np.meshgrid(gx, gy_fine); u1 = np.column_stack([GX.ravel(), GY.ravel(), np.zeros(GX.size)])         # dense under the ridge track
GX, GY = np.meshgrid(np.arange(0.5, lid_local.bounds[1][0], 2.0), gy_coarse); u2 = np.column_stack([GX.ravel(), GY.ravel(), np.zeros(GX.size)])
under = np.vstack([u1, u2])                                                                                   # lid underside sample (local)
edge_pts = surf_pts(lid_local, 20000, seed=1); edge_pts = edge_pts[np.abs(edge_pts[:, 1]) > 48.0][:2500]     # side edge region
T0 = np.array(P["lid"]["transform"], float)
slide = []
t0 = time.time()
for t in [0.0, 1.0, 1.75, 2.5, 5.0, 30.0, 80.0, 140.0]:
    pts = under @ T0[:3, :3].T + T0[:3, 3] + np.array([t, 0, 0])
    e = edge_pts @ T0[:3, :3].T + T0[:3, 3] + np.array([t, 0, 0])
    allp = np.vstack([pts, e])
    sd = trimesh.proximity.signed_distance(base, allp)     # >0 inside the base
    inside = sd > 1e-3
    pen = float(sd.max())
    where = allp[np.argmax(sd)] if inside.any() else None
    off_rib = inside & (np.abs(allp[:, 1]) > 6.0)      # anything inside away from the detent ridge is a real clash
    slide.append({"t_mm": t, "max_penetration_mm": round(pen, 3), "n_inside": int(inside.sum()),
                  "n_inside_away_from_ridge": int(off_rib.sum()),
                  "at": [round(float(x), 2) for x in where] if where is not None else None})
R["slide"] = {"positions": slide, "note": "penetration >0 only at the detent ridge (|y|<=5) is expected: that is the ridge lifting the plate; max should be <= ridge height 0.8 mm",
              "seconds": round(time.time() - t0, 1)}

# --- labels: raised height on the lid, debossed depth on the floor, cap height from a glyph section
lz = lid_local.vertices[:, 2]; R["labels"]["lid_max_z_mm"] = round(float(lz.max()), 3)
R["labels"]["lid_label_top_z_mm"] = round(float(np.unique(np.round(lz, 2))[np.searchsorted(np.unique(np.round(lz, 2)), 2.5)]), 3)
# cap height: section the lid at z=2.7 (through the raised letters) and measure the Y extent of the "DDR4 DIMM" line's D glyph region
v = section_pts(lid_local, [0, 0, 2.7], [0, 0, 1]); v = v[(v[:, 1] > 0) & (v[:, 0] > 30) & (v[:, 0] < 40)]
R["labels"]["cap_height_from_mesh_mm"] = round(float(v[:, 1].max() - v[:, 1].min()), 3)
fz = base.vertices[:, 2]; R["labels"]["floor_label_depth_mm"] = round(float(3.0 - fz[(fz > 2.2) & (fz < 2.95)].min()), 3) if ((fz > 2.2) & (fz < 2.95)).any() else None
R["labels"]["font_rule"] = "Fillaprint: cap = 14 w, em = 20 w; used em 10 mm -> cap 7.0 mm, stroke 1.0 mm (w = 0.5). Minimum at a 0.42 mm line is cap 5.88 mm."

# --- pass/fail
f = R["fits"]; c = R["clearances"]
R["pass"] = {
    "all_parts_watertight": all(p["watertight"] for p in R["parts"].values()),
    "lid_slides_in_groove": 0.15 <= f["lid_side_clearance_each_mm"] <= 0.4 and 0.2 <= f["lid_vertical_clearance_mm"] <= 0.5,
    "lid_captured_by_lip": f["lid_captured_each_side_mm"] >= 1.0,
    "modules_no_intersection": all(c[k]["points_inside_base"] == 0 and c[k]["points_inside_lid"] == 0 for k in ("module_A", "module_B")),
    "contact_strip_never_touches": all(c[k]["contact_strip_min_drop_to_floor_mm"] >= 1.5 and c[k]["contact_strip_rays"] >= 390 for k in ("module_A", "module_B")),
    "padding_room_above_module_mm": round(min(c[k]["min_dist_to_lid_mm"] for k in ("module_A", "module_B")), 3),
    "slide_clash_free_except_ridge": all(s["n_inside_away_from_ridge"] == 0 and s["max_penetration_mm"] <= 0.85 for s in slide),
    "labels_at_or_above_font_minimum": R["labels"]["cap_height_from_mesh_mm"] >= 5.88,
}
json.dump(R, open(os.path.join(ROOT, "checks", "checks.json"), "w"), indent=1)
print(json.dumps(R, indent=1))
