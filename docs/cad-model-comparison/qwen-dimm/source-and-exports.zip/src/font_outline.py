"""Fillaprint-Regular.ttf -> glyph outline polygons (pure fontTools + numpy).

Returns contours as numpy point arrays in font units (1000 units/em, y up,
origin at the glyph's left side bearing on the baseline). Advances and
kerning are returned in the same units.
"""
import numpy as np
from fontTools.ttLib import TTFont
from fontTools.pens.recordingPen import RecordingPen

FONT_PATH = "assets/fillaprint/Fillaprint-Regular.ttf"
EM_UNITS = 1000
CAP_UNITS = 700  # OS/2 sCapHeight
X_HEIGHT_UNITS = 500  # OS/2 sxHeight

_font = None
_cmap = None
_glyf = None
_hmtx = None
_kern = {}


def _ensure():
    global _font, _cmap, _glyf, _hmtx, _kern
    if _font is None:
        _font = TTFont(FONT_PATH)
        _cmap = _font.getBestCmap()
        _glyf = _font["glyf"]
        _hmtx = _font["hmtx"]
        if "kern" in _font:
            for table in _font["kern"].kernTables:
                if hasattr(table, "kernPairs"):      # kern subtable format 1/2
                    for (left_gid, right_gid), val in table.kernPairs.items():
                        _kern[(left_gid, right_gid)] = val
                else:                                 # format 0: subtables of pairs
                    for sub in getattr(table, "kernTable", []):
                        for pair in getattr(sub, "pairs", []):
                            _kern[(pair.left, pair.right)] = pair.value


def char_gid(ch):
    _ensure()
    return _cmap.get(ord(ch))


def advance(ch):
    """Advance width in font units (0 for missing/space fallbacks)."""
    _ensure()
    gid = _cmap.get(ord(ch))
    if gid is None:
        return 0.0
    return float(_hmtx[gid][0])


def kern(ch_a, ch_b):
    _ensure()
    ga, gb = _cmap.get(ord(ch_a)), _cmap.get(ord(ch_b))
    if ga is None or gb is None:
        return 0.0
    return float(_kern.get((ga, gb), 0.0))


def glyph_contours(ch):
    """List of contours (each an (N,2) float array in font units)."""
    _ensure()
    gid = _cmap.get(ord(ch))
    if gid is None:
        return []
    pen = RecordingPen()
    _glyf[gid].draw(pen, _glyf)
    contours, cur = [], None
    for op, args in pen.value:
        if op == "moveTo":
            if cur is not None:
                contours.append(cur)
            cur = [args[0]]
        elif op == "lineTo":
            cur.append(args[0])
        elif op == "qCurveTo":
            cur.extend([args[0]] + list(args[1:]))
        elif op == "closePath":
            if cur is not None:
                contours.append(cur)
                cur = None
    if cur is not None:
        contours.append(cur)
    return [np.array(c, dtype=float) for c in contours if len(c) > 2]


def string_width(text, kerning=True):
    w = 0.0
    prev = None
    for ch in text:
        w += advance(ch)
        if prev is not None and kerning:
            w += kern(prev, ch)
        prev = ch
    return w
