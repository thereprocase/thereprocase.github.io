#!/usr/bin/env python
"""Parametric CAD: two-up DDR4 UDIMM mailer (tray + snap-fit lid).

Build (CAD venv):  python src/dimm_mailer.py
Outputs:           out/tray.step out/tray.stl
                   out/lid.step  out/lid.stl
                   out/assembly.step   (lid in closed, snap-engaged position)
                   assembly.json

Coordinate system (assembled, tray is the reference part):
  +x along the sticks' long axis (133.35 mm), +y across, +z up.
  Tray pocket floor at z = 0; pocket opening / wall tops at z = POCKET_D.
  Lid is modelled in its own local frame (plate underside at z = 0) and is
  assembled with a +z translation of LID_LIFT (= POCKET_D).

Both parts print flat and support-free:
  tray: pocket openings up.
  lid:  plate down (engraved label against the bed), snap tabs up.
"""
import json
import os

from build123d import (
    Align,
    BuildPart,
    BuildSketch,
    Box,
    Compound,
    Location,
    Rectangle,
    TextAlign,
    Text,
    fillet,
    extrude,
    export_step,
    export_stl,
)

from font_outline import CAP_UNITS, EM_UNITS, string_width

# --------------------------------------------------------------------------
# Design parameters (mm)
# --------------------------------------------------------------------------
MOD_L = 133.35            # JEDEC UDIMM length
MOD_W = 38.6              # JEDEC UDIMM width
H_MOD_MIN = 9.0           # supported module height, board bottom to spreader top
H_MOD_MAX = 16.0

BAG_THK = 1.5             # shielding-bag bulge added to package width/height
BAG_END = 4.5             # bag fold allowance per end

ENV_L = MOD_L + 2 * BAG_END            # 142.35
ENV_W = MOD_W + 2 * BAG_THK + 2.0      # 43.6
ENV_H = H_MOD_MAX + BAG_THK + 0.5      # 18.0

# tray
POCKET_L = 146.0
POCKET_W = 45.0
POCKET_D = 19.0
DIV_W = 6.0               # partition between pockets
WALL = 3.0
FLOOR = 5.0
TRAY_L = 2 * WALL + POCKET_L               # 152
TRAY_W = 2 * WALL + 2 * POCKET_W + DIV_W   # 102
R_OUT = 5.0
R_POC = 3.0

# snap fit (per corner tab)
TAB_W = 12.0
TAB_T = 1.5
TAB_D = 12.0
GAP = 0.3                 # clearance tab face <-> tray outer wall face
CAPTURE = 0.3             # bulge overlap past the inner wall face (engagement)
BULGE_W = 10.0
BULGE_H = 2.0
BULGE_Z = 10.0            # bulge centre height, global (closed)
WIN_W = BULGE_W + 0.5
WIN_H = BULGE_H + 0.6
TAB_X = 61.0              # tab centre, from centreline
GUSSET_D = 0.9
GUSSET_H = 4.0
DIMP_W = 6.0
DIMP_H = 6.0
DIMP_D = 0.5
TAB_ROOT = 0.25      # tab root overlap into the plate (robust fuse, invisible)
BULGE_ROOT = 0.3     # bulge overlap into the tab inner face
GUSSET_ROOT = 0.2    # gusset overlap into the tab outer face

# lid
PLATE_T = 3.0
PLATE_L = TRAY_L + 2 * (GAP + TAB_T)       # 155.6
PLATE_W = TRAY_W + 2 * (GAP + TAB_T)       # 105.6
PLATE_R = 6.0
NOTCH_W = 8.0             # corner finger notches in the plate
NOTCH_DEPTH = 6.8
LID_LIFT = POCKET_D       # assembled translation of the lid

# label (engraved into the lid top face)
FONT_PATH = "assets/fillaprint/Fillaprint-Regular.ttf"
LABEL1 = "2× DDR4"
LABEL2 = "FRAGILE"
CAP1 = 10.0
CAP2 = 7.5
ENGRAVE = 0.4
BASE1 = 5.0               # baselines (lid-local y)
BASE2 = -15.0

# geometry anchors
SIDE_IN = TRAY_W / 2 - WALL   # 48: side-wall inner face
SIDE_OUT = SIDE_IN + WALL                                                  # 51


def _rounded_slab(length, width, radius, z0, height):
    with BuildPart() as p:
        with BuildSketch() as sk:
            Rectangle(length, width)
            fillet(sk.vertices(), radius)
        extrude(amount=height)
    return p.part.locate(Location((0, 0, z0)))


def _text_solid(text, cap_mm, baseline_y, z0, height):
    """Extruded glyphs centred on x=0, baseline at y=baseline_y, from z0 up.

    Uses the real TTF via build123d Text (font_path); placement is corrected
    from the measured bounding box so the baseline lands exactly.
    """
    em = cap_mm * EM_UNITS / CAP_UNITS
    with BuildPart() as p:
        with BuildSketch() as sk:
            Text(
                txt=text,
                font_size=em,
                font_path=FONT_PATH,
                text_align=(TextAlign.CENTER, TextAlign.CENTER),
            )
        extrude(amount=height)
    solid = p.part
    bb = solid.bounding_box()
    dy = baseline_y - bb.min.Y
    dx = -(bb.min.X + bb.max.X) / 2
    return solid.locate(Location((dx, dy, z0)))


def build_tray():
    slab = _rounded_slab(TRAY_L, TRAY_W, R_OUT, -FLOOR, FLOOR + POCKET_D)

    pockets = []
    for yc in (-(DIV_W / 2 + POCKET_W / 2), DIV_W / 2 + POCKET_W / 2):   # ±25.5 pocket centres
        pk = _rounded_slab(POCKET_L, POCKET_W, R_POC, 0.0, POCKET_D + 0.05)
        pockets.append(pk.locate(Location((0, yc, 0))))

    windows = []
    for sx in (-1, 1):
        for sy in (-1, 1):
            win = Box(
                WIN_W,
                WALL + 0.6,
                WIN_H,
                align=Align.CENTER,
            ).locate(Location((sx * TAB_X, sy * (SIDE_IN + WALL / 2), BULGE_Z)))
            windows.append(win)

    return slab.cut(Compound(pockets + windows))


def build_lid():
    plate = _rounded_slab(PLATE_L, PLATE_W, PLATE_R, 0.0, PLATE_T)

    cuts, unions = [], []
    for sx in (-1, 1):
        for sy in (-1, 1):
            # corner finger notch (opens under the plate edge)
            notch = Box(
                NOTCH_W + 2.0,
                NOTCH_DEPTH + 2.0,
                PLATE_T + 0.4,
                align=Align.CENTER,
            ).locate(
                Location(
                    (
                        sx * (PLATE_L / 2 - NOTCH_W / 2),
                        sy * (PLATE_W / 2 - NOTCH_DEPTH / 2),
                        PLATE_T / 2,
                    )
                )
            )
            cuts.append(notch)

            # snap tab: hangs below the plate, outside the tray wall
            tab = Box(
                TAB_W,
                TAB_T,
                TAB_D,
                align=Align.CENTER,
            ).locate(
                Location((sx * TAB_X, sy * (SIDE_OUT + GAP + TAB_T / 2), -(TAB_D - TAB_ROOT) / 2))
            )
            unions.append(tab)

            # root gusset on the tab's OUTER face (reinforces the flex root)
            gus = Box(
                TAB_W,
                GUSSET_D,
                GUSSET_H,
                align=Align.CENTER,
            ).locate(
                Location(
                    (
                        sx * TAB_X,
                        sy * (SIDE_OUT + GAP + TAB_T - GUSSET_ROOT + GUSSET_D / 2),
                        -GUSSET_H / 2,
                    )
                )
            )
            unions.append(gus)

            # snap bulge on the tab's inner face: from BULGE_ROOT into the tab
            # (y = SIDE_OUT + GAP + BULGE_ROOT) inward through the wall to a tip
            # CAPTURE past the inner face (y = SIDE_IN - CAPTURE)
            bulge = Box(
                BULGE_W,
                (SIDE_OUT + GAP + BULGE_ROOT) - (SIDE_IN - CAPTURE),
                BULGE_H,
                align=Align.CENTER,
            ).locate(
                Location(
                    (
                        sx * TAB_X,
                        sy * ((SIDE_IN - CAPTURE + SIDE_OUT + GAP + BULGE_ROOT) / 2),
                        -(LID_LIFT - BULGE_Z),
                    )
                )
            )
            unions.append(bulge)

            # thumb dimple on the tab outer face, below the gusset
            dimp = Box(
                DIMP_W,
                DIMP_D + 0.3,
                DIMP_H,
                align=Align.CENTER,
            ).locate(
                Location(
                    (
                        sx * TAB_X,
                        sy * (SIDE_OUT + GAP + TAB_T - 0.05),
                        -(LID_LIFT - BULGE_Z),
                    )
                )
            )
            cuts.append(dimp)

    # fuse and cut sequentially: a single multi-tool boolean dropped thin
    # tab-plate overlaps on this OCCT build
    lid = plate
    for s in unions:
        lid = lid.fuse(s)
    for c in cuts:
        lid = lid.cut(c)

    for text, cap, base in ((LABEL1, CAP1, BASE1), (LABEL2, CAP2, BASE2)):
        engrave = _text_solid(text, cap, base, PLATE_T - ENGRAVE, ENGRAVE + 0.1)
        lid = lid.cut(engrave)
    return lid


def main():
    os.makedirs("out", exist_ok=True)

    tray = build_tray()
    lid = build_lid()

    export_step(tray, "out/tray.step")
    export_stl(tray, "out/tray.stl")
    export_step(lid, "out/lid.step")
    export_stl(lid, "out/lid.stl")

    lid_closed = lid.locate(Location((0, 0, LID_LIFT)))
    export_step(Compound([tray, lid_closed]), "out/assembly.step")

    assembly = {
        "units": "mm",
        "frame": "tray pocket floor at z=0; +x along stick long axis, +y across, +z up",
        "parts": [
            {
                "id": "tray",
                "file_stl": "out/tray.stl",
                "file_step": "out/tray.step",
                "assembled_transform": {
                    "translation": [0.0, 0.0, 0.0],
                    "rotation_deg": [0.0, 0.0, 0.0],
                },
                "note": "base; pockets open upward, snap windows in the side walls",
            },
            {
                "id": "lid",
                "file_stl": "out/lid.stl",
                "file_step": "out/lid.step",
                "assembled_transform": {
                    "translation": [0.0, 0.0, float(LID_LIFT)],
                    "rotation_deg": [0.0, 0.0, 0.0],
                },
                "note": (
                    "modelled plate-underside-down (z 0..3 local); closed position "
                    "adds z=19; four snap tabs engaged in the tray wall windows"
                ),
            },
        ],
        "references": [
            {
                "id": "bagged_dimm_a",
                "geometry": "box (L x W x H)",
                "size": [ENV_L, ENV_W, ENV_H],
                "transform": {
                    "translation": [0.0, 25.5, 0.0],
                    "rotation_deg": [0.0, 0.0, 0.0],
                },
                "note": "bagged module in pocket A (envelope, not a part)",
            },
            {
                "id": "bagged_dimm_b",
                "geometry": "box (L x W x H)",
                "size": [ENV_L, ENV_W, ENV_H],
                "transform": {
                    "translation": [0.0, -25.5, 0.0],
                    "rotation_deg": [0.0, 0.0, 0.0],
                },
                "note": "bagged module in pocket B",
            },
            {
                "id": "gold_contacts_a",
                "geometry": "box (L x W x H)",
                "size": [MOD_L, 3.4, 2.0],
                "transform": {
                    "translation": [0.0, 45.6, 1.0],
                    "rotation_deg": [0.0, 0.0, 0.0],
                },
                "note": (
                    "edge-connector band (1.9 mm PCB edge + bag) at the +y edge of "
                    "module A, which lies flat, spreader up, connector on the "
                    "pocket's inner-wall side; nothing may intersect this box"
                ),
            },
            {
                "id": "gold_contacts_b",
                "geometry": "box (L x W x H)",
                "size": [MOD_L, 3.4, 2.0],
                "transform": {
                    "translation": [0.0, -45.6, 1.0],
                    "rotation_deg": [0.0, 0.0, 0.0],
                },
                "note": "edge-connector band (1.9 mm PCB edge + bag), module B, -y side",
            },
        ],
    }
    with open("assembly.json", "w") as fh:
        json.dump(assembly, fh, indent=2)

    bb_t = tray.bounding_box()
    bb_l = lid.bounding_box()
    print("tray bbox  : x %.2f..%.2f  y %.2f..%.2f  z %.2f..%.2f"
          % (bb_t.min.X, bb_t.max.X, bb_t.min.Y, bb_t.max.Y, bb_t.min.Z, bb_t.max.Z))
    print("lid bbox   : x %.2f..%.2f  y %.2f..%.2f  z %.2f..%.2f"
          % (bb_l.min.X, bb_l.max.X, bb_l.min.Y, bb_l.max.Y, bb_l.min.Z, bb_l.max.Z))
    print("volumes mm3: tray %.1f  lid %.1f" % (tray.volume, lid.volume))
    print("solid counts: tray %d  lid %d (1 = single connected solid)"
          % (len(tray.solids()), len(lid.solids())))
    print("label widths: %r = %.1f mm, %r = %.1f mm"
          % (LABEL1, string_width(LABEL1) * CAP1 / CAP_UNITS,
             LABEL2, string_width(LABEL2) * CAP2 / CAP_UNITS))
    print("OK")


if __name__ == "__main__":
    main()
