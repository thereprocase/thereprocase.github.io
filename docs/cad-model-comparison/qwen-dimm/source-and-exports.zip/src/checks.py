#!/usr/bin/env python
"""Measured functional checks for the DDR4 mailer (trimesh / manifold3d).

Run (mesh venv):  python src/checks.py

Checks, in the closed assembled state (lid translated +19.0 mm in z, per
assembly.json):
  1. per part: watertight, winding, single body, volume, bounding box
  2. tray ∩ lid interference: expected 4 bulge zones, ~24 mm3 total
  3. bagged-module envelope boxes (2 x 142.35 x 43.6 x 18.0 at y=±25.5)
     vs tray and closed lid: expected zero intersection
  4. gold-contact guard boxes (133.35 x 3.4 x 2.0 at y=±45.6, z 0..2)
     vs tray and closed lid: expected zero intersection
  5. lid engraving present (recess floor at z=2.60 lid-local)
  6. analytic snap-fit force per tab (cantilever, PLA)
"""
import sys

import numpy as np
import trimesh

LID_LIFT = 19.0
results = []


def check(name, ok, detail=""):
    results.append((name, ok, detail))
    print("%-58s %s  %s" % (name, "PASS" if ok else "FAIL", detail))


def load(path):
    m = trimesh.load(path)
    return m.geometry if hasattr(m, "geometry") else m


def boolean_op(op, a, b):
    """Boolean op with engine fallback."""
    for eng in ("manifold", "blender", None):
        try:
            if eng is None:
                return getattr(a, op)(b)
            return getattr(a, op)(b, engine=eng)
        except Exception:
            continue
    raise RuntimeError("no boolean engine available for %s" % op)


def box(l, w, h, tx, ty, tz):
    b = trimesh.creation.box(extents=[l, w, h])
    b.apply_translation((tx, ty, tz))
    return b


def main():
    tray = load("out/tray.stl")
    lid = load("out/lid.stl")

    # 1. per-part sanity -------------------------------------------------
    for name, m in (("tray", tray), ("lid", lid)):
        bodies = m.split(only_watertight=True)
        bb = m.bounds
        check(
            "%s watertight" % name,
            m.is_watertight,
            "bodies=%d winding=%s vol=%.1f mm3" % (len(bodies), m.is_winding_consistent, m.volume),
        )
        check(
            "%s single connected body" % name,
            len(bodies) == 1,
            "n=%d" % len(bodies),
        )
        print("      %s bbox: x %.2f..%.2f  y %.2f..%.2f  z %.2f..%.2f"
              % (name, bb[0][0], bb[1][0], bb[0][1], bb[1][1], bb[0][2], bb[1][2]))

    # lid in closed position
    lid_closed = lid.copy()
    lid_closed.apply_translation((0.0, 0.0, LID_LIFT))

    # 2. closed-state interference ---------------------------------------
    inter = boolean_op("intersection", tray, lid_closed)
    vol = inter.volume if inter is not None else float("nan")
    if vol < 0:
        inter.fix_normals()
        vol = abs(vol)
    pieces = inter.split(only_watertight=False) if vol > 0.05 else []
    check(
        "closed-state interference = 4 snap zones, ~24 mm3",
        abs(vol - 24.0) < 2.0 and len(pieces) == 4,
        "vol=%.2f mm3  zones=%d (each %s mm3)"
        % (vol, len(pieces),
           ", ".join("%.2f" % p.volume for p in pieces) if pieces else "-"),
    )

    # 3. bagged-module envelopes -----------------------------------------
    env = [box(142.35, 43.6, 18.0, 0.0, s * 25.5, 9.0) for s in (-1, 1)]
    for tag, other in (("tray", tray), ("closed lid", lid_closed)):
        worst = 0.0
        for i, e in enumerate(env):
            iv = boolean_op("intersection", other, e)
            worst = max(worst, iv.volume if iv is not None else float("nan"))
        check("envelope A/B vs %s: no intersection" % tag, worst < 0.5,
              "max intersection vol=%.4f mm3" % worst)

    # 4. gold-contact guard boxes ----------------------------------------
    guard = [box(133.35, 3.4, 2.0, 0.0, s * 45.6, 1.0) for s in (-1, 1)]
    for tag, other in (("tray", tray), ("closed lid", lid_closed)):
        worst = 0.0
        for g in guard:
            iv = boolean_op("intersection", other, g)
            worst = max(worst, iv.volume if iv is not None else float("nan"))
        check("connector guard A/B vs %s: no intersection" % tag, worst < 0.5,
              "max intersection vol=%.4f mm3" % worst)

    # 5. engraving present on lid top face -------------------------------
    z = lid.vertices[:, 2]
    frac = float(np.mean(np.abs(z - 2.60) < 0.05))
    check("label engraving floor at z=2.60 (0.4 mm deep)", frac > 0.01,
          "vertex fraction near 2.60 = %.3f" % frac)

    # 6. analytic snap force per tab -------------------------------------
    E = 2400.0      # MPa, PLA
    w = 12.0        # tab width, mm
    t = 1.5         # tab thickness, mm
    L = 9.0         # cantilever length plate underside -> bulge centre, mm
    delta = 0.3     # designed capture, mm
    k = E * w * t ** 3 / (12.0 * L ** 3)   # N/mm
    F = k * delta
    check("snap retention force (analytic)", F > 1.0,
          "k=%.2f N/mm  F=%.2f N per tab, %.1f N total x4; "
          "sustained flex stress ~ %.1f MPa (PLA yield ~ 40-60 MPa)"
          % (k, F, 4 * F, F * L * (t / 2) / (w * t ** 3 / 12.0)))

    print()
    n_fail = sum(1 for _, ok, _ in results if not ok)
    print("SUMMARY: %d/%d checks passed" % (len(results) - n_fail, len(results)))
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
