# Two-Up DDR4 UDIMM Mailer

A compact, reusable, hardware-free mailer for two desktop DDR4 RAM sticks
with ordinary (low-to-mid profile) heatsinks. Each stick goes into its own
shielding bag, then into its own pocket; the snap-fit lid is pressed on.
Designed for FDM printing (PLA); both parts print support-free.

## Files
- `src/dimm_mailer.py` — parametric CAD (build123d); run it to regenerate everything
- `src/font_outline.py` — Fillaprint glyph/advance/kerning utilities
- `src/checks.py` — measured functional checks (trimesh + manifold3d)
- `out/tray.step`, `out/tray.stl` — base tray
- `out/lid.step`, `out/lid.stl` — snap lid, modelled in its local frame (plate underside z=0)
- `out/assembly.step` — closed assembly (lid engaged)
- `assembly.json` — part files, actual assembled transforms (mm), reference boxes

## Supported envelope (with real examples)
- JEDEC DDR4 UDIMM: 133.35 mm long, 38.6 mm wide, 288-pin edge connector
  (verified against the Wikipedia DDR4 page via the permitted proxy).
- Supported module height (board bottom to heatsink top): **9–16 mm**.
  This covers ordinary desktop heatsinks: low-profile kits such as the
  Corsair Vengeance LPX, Kingston Fury Beast and G.Skill Aegis class
  (per-product heights are nominal, from vendor pages). JEDEC slot
  heights — 1U: 31.25 mm, VLP: 18.75 mm — are independent corroborating
  bounds. RGB tower heatsinks (typically 25–32 mm) are deliberately out
  of scope; the mailer stays compact.
- Bagged envelope: 142.35 × 43.6 × 18.0 mm (1.5 mm bag bulge per side,
  4.5 mm fold per end, 0.5 mm height allowance).
- Pocket: 146 × 45 × 19 mm → fit: 1.8 mm per end, 0.7 mm per side,
  1.0 mm on top. Deliberate play so paper/foam shims absorb rattle
  without the lid binding.

## Lid mechanism
Four cantilever snap tabs (12 wide × 1.5 thick × 12 long) at the corners,
each with a bulge that snaps 0.3 mm past the tray wall's inner face
through a 10.5 × 2.6 mm window in the wall. Measured closed-state
interference: **24.0 mm³ total (6.0 per corner)** — the only designed
interference in the assembly.
Analytic retention: k = E·w·t³/(12·L³) = 11.1 N/mm (PLA E = 2.4 GPa,
L = 9 mm) → ~3.3 N per tab, ~13 N total at full 0.3 mm deflection;
root bending stress ~6.7 MPa at sustained deflection — well below PLA
yield. Corner finger notches in the plate lift it once tabs release;
thumb dimples on the tabs' outer faces aid pressing.

## Loading and opening
1. Bag each stick in its own shielding bag.
2. Seat each in a pocket, spreader up.
3. Optional: small paper/foam shims in the free play to stop rattle.
4. Lay the lid on with tabs over the windows; press the corners down
   until all four bulges snap past the wall's inner face.
To open: press the two tabs on one edge (use the dimples) until they
flex past their windows, then lift the plate at the corner notches.

## Labels (FillaPrint)
"2× DDR4" — cap 10.0 mm, width 41.2 mm; "FRAGILE" — cap 7.5 mm,
width 32.7 mm; engraved 0.4 mm into the lid's top face.
The font's own minimum printable size (nameID 10): cap height ≥
14 × slicer line width → 5.88 mm at a 0.42 mm line. Measured glyph
strokes are ≈2 line widths and counters ≈1 line width, so both labels
sit comfortably above the minimum and stay readable.

## Printing
- Tray: pockets up, no supports.
- Lid: plate down (label face prints as an upward groove; tabs stand
  vertical), no supports.
- Tolerance: the 0.3 mm capture and 0.3 mm tab-to-wall gap assume
  ~±0.2 mm FDM accuracy. A tight print makes the snap firmer; a loose
  print may rattle. Verify on a test print.

## Measured verification (`src/checks.py`)
Both parts: watertight, consistent winding, single connected body
(tray 121,853.8 mm³; lid 49,555.5 mm³). Closed-state tray∩lid
intersection: exactly 24.00 mm³ in the four corner zones. Bagged-module
envelope and connector guard boxes: zero intersection with tray and
closed lid — nothing presses on the gold contacts. Label engraving
verified on the lid mesh (recess floor at z = 2.60 lid-local).

## Still needs a physical test
- Snap retention over time: PLA creep/fatigue under sustained 0.3 mm
  deflection (~6.7 MPa root stress). Safe analytically, unproven.
- Real shielding-bag fit — bag bulk is modelled, not measured.
- Print-tolerance effects on the 0.3 mm capture and overall feel.
- Label readability once printed (infill inside the 0.4 mm recess).
- Opening feel — dimple leverage on the tabs.
