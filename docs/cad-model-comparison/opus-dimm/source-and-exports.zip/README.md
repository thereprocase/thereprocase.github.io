# DIMM mailer: reusable two-module DDR4 case

Two printed parts, a **tray** and a **lid**. The case holds two desktop DDR4 UDIMMs with heatspreaders, each one bagged, lying flat side by side. Closed size is **153.7 × 110 × 19.2 mm**, so it fits a small padded carton. There's no hardware. The lid closes with a hinge tongue at one end and a printed snap latch at the other.

## Files
| File | What |
|---|---|
| `src/dimm_mailer.py` | Parametric build123d model. All dimensions are in the `P` dataclass. Run it to regenerate `out/` and `assembly.json`. |
| `src/check_fit.py` | Exact B-rep functional checks. Writes `checks/fit_checks.json`. |
| `src/check_mesh.py` | STL checks: watertight, overhangs, assembled collisions. Writes `checks/mesh_checks.json`. |
| `checks/label_checks.txt` | Measured label cap heights and positions. |
| `out/tray.step/.stl` | Tray, in print orientation (open side up), which is also its assembled pose. |
| `out/lid.step/.stl` | Lid, in print orientation (top face on the bed). |
| `out/lid_label_inlay.step/.stl` | Optional: text bodies that fill the 0.6 mm lid deboss, for multi-material printing. |
| `out/ref_module_envelopes.*` | Not printed. The two largest supported bagged modules, for clearance checks. |
| `assembly.json` | Each part file with its 4×4 transform (mm) from file pose to assembled pose, plus all parameters. |

Assembled frame: origin at the tray's bottom centre, Z up. The hinge end is −X and the latch end is +X.

## Supported envelope (and why)
Each module may be up to **137 mm long, 45 mm tall (contact edge to heatspreader top) and 8.5 mm thick**, plus a shielding bag (0.3 mm per side allowed). The heatspreader's lower edge must sit at least ~4.5 mm above the contact edge. Real heatspreadered DIMMs are built that way.

| Module | Height (published nominal) | Fits | Foam headspace |
|---|---|---|---|
| Kingston FURY Beast DDR4 | 34.1 | yes | 5.6 mm |
| Corsair Vengeance LPX | 34 | yes | 5.2 mm |
| TeamGroup T-Force Vulcan Z | 32 | yes | 5.2 mm |
| Crucial Ballistix DDR4 | ~39 | yes | 4.7 mm |
| G.Skill Ripjaws V | 42 | yes | 4.6 mm |
| Kingston FURY Beast RGB DDR4 | ~42 | yes | 4.6 mm |
| G.Skill Trident Z / Z RGB | 44 | yes | 4.2 mm |
| Corsair Vengeance RGB Pro | 51 | **no** (deliberately excluded) | – |
| Corsair Dominator Platinum RGB | 55 | **no** (deliberately excluded) | – |

Heights above 45 mm belong to a few tall RGB and "tower" kits. Covering them would add about 20 mm to the case width for a small share of modules. Note: the search and spec pages couldn't be fetched through the provided proxy. The heights above are well-known published values, and the thicknesses (6.6–8 mm) are estimates. **Measure your own modules: height ≤ 45 mm and thickness ≤ 8.5 mm.** A bare module without a heatspreader isn't supported, because its PCB would sit on the stop rail (the check flags this).

## How it works
**Pockets.** Each module lies flat on four floor rails. The heatspreader's top edge goes toward the outer wall and the gold edge toward the centre. A low **heatspreader stop** (1.6 mm high, at 9.5 mm from the centre line) catches the heatspreader's lower edge if the module slides inward. The thinner PCB passes over the stop, so the gold zone always floats above it. Checked at both ends of travel (against the outer wall, and slid onto the stop): for every supported module, the bare gold zone stays **≥ 1.37 mm** from any plastic. Nothing presses on the contacts. The ends of the pocket touch only the PCB's short edges.

**Lid retention.**
- *Hinge end (−X):* two tongues on the lid sit in two windows in the tray end wall. They hold the lid down at that end. The windows are 24 mm wide, which keeps them printable as bridges.
- *Latch end (+X):* a slot through the lid plate leaves an 84 mm spring beam (2.4 × 2.4 mm). It bends in the plane of the print layers, the strong direction. A hook hangs from the beam, and its square lip catches under a ledge on the tray wall with 0.9 mm engagement. Lowering the lid flexes the beam 0.9 mm and it clicks in. Bending strain is about 0.4 %, well under PETG/PLA yield. Upward foam pressure twists the hook *inward*, so the catch tightens under load rather than slipping.
- *Location:* the lid's side skirts locate it across the box. End rims locate it lengthwise and hold the tray wall between the rim and the hook.
- *Stiffness:* the side skirts and a centre rib make the lid a stiff channel. Estimated sag is about 0.18 mm per 10 N of foam load.

**Closing:** hold the lid tilted slightly (anything up to 16° works), push the tongues into the windows, lower the latch end and press until it clicks.
**Opening:** put a fingertip under the pull flange at the latch end and lift. The off-centre pull twists the hook out of its catch. Raise that end, slide the lid ~3 mm toward the latch end to free the tongues, and lift it off.
**Getting the sticks out:** each long wall has a 28 mm finger notch. Under the notch the outer rail is cut away, which leaves a 2.4 mm gap under the module's top edge. Slip a fingertip under the bag edge, tip the module up, and lift it by the heatspreader.

## Packing
1. Put each module in its own shielding bag and fold the open end under.
2. Lay it with the heatspreader top toward the outer wall and the gold edge toward the centre. The floor labels show this.
3. Short modules (~34 mm) have up to ~13 mm of play across the pocket. Either position is safe for the contacts. To stop rattle, push the module inward to the stop and fill the gap at the outer wall with folded paper.
4. Lay a **5–6 mm soft foam strip (~135 × 35 mm)** over the heatspreader area of each module, not over the gold edge. Folded paper also works. Headspace is 3.7–5.6 mm, so the foam is lightly compressed.
5. Close the lid and ship the case inside an outer cardboard box with some padding.

## Labels
Font: Fillaprint Regular (OFL, see `assets/fillaprint/OFL.txt`). Every label has a cap height of **≥ 6.0 mm**; the main lid title is 9.0 mm. Fillaprint's guidance is 14 × line width, which is 5.88 mm at 0.42 mm lines. Measured values are in `checks/label_checks.txt`.
- Lid: "DDR4 DIMM ×2", "ANTI-STATIC BAGS INSIDE", "HANDLE BY EDGES", plus "↓ PULL TAB OUT, LIFT ↓" and "HINGE END" set to read from each end.
- Floor: "GOLD EDGE TOWARD CENTRE" and "HEATSPREADER TOP TO WALL", with arrows, between the rails.

All labels are debossed 0.6 mm. To print them in two colours, either change filament for the first 3 layers of the lid, or use `lid_label_inlay` as a second body. Floor labels are single-colour.

## Printing notes (not sliced here)
- PETG is preferred for the latch beam; PLA should work. Use 0.4 mm nozzle, 0.2 mm layers, at least 3 walls. No supports needed.
- Unsupported features:
  - **Tray:** the 1.2 mm ledge underside and two 24 mm window bridges.
  - **Lid:** the 2 mm tongue undersides, the 1.2 mm hook lip, and the small bridges over the debossed letters.

## Measured checks (summary)
- Closed lid vs tray: 0 interference, both on the B-rep and on the exported meshes. The largest bagged envelopes intersect neither part.
- Hinge path: the lid can tilt 0–16° about the wall edge with no interference, and the tongues slide in from 4 mm out at 16° with no interference. Once the tongues are out, the lid clears at any tilt up to 45°.
- All printed STLs are watertight and sit flat at z = 0.
- Volumes: tray 52.2 cm³, lid 46.7 cm³ (about 120 g PETG total at 100 % infill; real use is less).

## Needs a physical test
- **How the latch feels.** The force, the click, and whether lifting the flange alone releases it depend on hook twist and print quality. The modelled bending force is only ~1.6 N (PETG). If it feels too loose, raise `beam_w` to 2.8 or shorten `slot_half_len`.
- **Tongue/window fit** (0.3 mm above the tongue, 0.25 mm rim clearance) on your printer.
- **Real module dimensions**, especially thickness and how far the heatspreader lower edge sits above the contacts (≥ 4.5 mm assumed).
- **Foam choice.** A stiff PE foam pushes much harder than the soft PU assumed here.
- **Drop behaviour** inside the outer carton.
