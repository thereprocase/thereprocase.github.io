"""Functional checks on the exact B-rep (labels omitted for speed: they are
0.6 mm debosses on the lid top and pocket floors and cannot affect fit).
Writes checks/fit_checks.json.
"""
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dimm_mailer as dm  # noqa: E402
from build123d import Axis, Location, Pos, Rot  # noqa: E402

p = dm.p
p.labels = False
ROOT = dm.ROOT
out = {}

tray, _ = dm.build_tray()
lid, _ = dm.build_lid(hook=True)
lid_nohook, _ = dm.build_lid(hook=False)


def vol(a, b):
    try:
        i = a & b
        return sum(s.volume for s in i.solids()) if i is not None else 0.0
    except Exception as e:  # noqa
        return float("nan")


# --- 1. closed assembly interference --------------------------------------
out["closed_lid_tray_interference_mm3"] = round(vol(lid, tray), 4)
out["closed_lid_tray_min_gap_mm"] = round(lid.distance_to(tray), 3)

# --- 2. real module examples (published nominal heights; thickness estimates)
MODULES = {
    # name: (length, height, thickness)
    "JEDEC bare DDR4 UDIMM (ref)": (133.35, 31.25, 4.0),
    "Corsair Vengeance LPX": (133.35, 34.0, 7.0),
    "Kingston FURY Beast DDR4": (133.35, 34.1, 6.6),
    "TeamGroup T-Force Vulcan Z": (133.35, 32.0, 7.0),
    "Crucial Ballistix DDR4": (133.35, 39.2, 7.5),
    "G.Skill Ripjaws V": (133.35, 42.0, 7.6),
    "Kingston FURY Beast RGB DDR4": (133.35, 42.2, 7.6),
    "G.Skill Trident Z / Trident Z RGB": (133.35, 44.0, 8.0),
    "Design envelope max": (p.mod_L, p.mod_H, p.mod_T),
    "Corsair Vengeance RGB Pro (excluded)": (133.35, 51.0, 8.0),
    "Corsair Dominator Platinum RGB (excluded)": (133.35, 55.0, 8.0),
}
lid_under = p.wall_top
res = {}
for name, (L, Hm, T) in MODULES.items():
    r = {"L": L, "H": Hm, "T": T}
    ok = True
    for pos in ("against_outer_wall", "slid_to_stop"):
        for side in (1, -1):
            env, gold = dm.module_body(L, Hm, T, side=side, slide_out=(pos == "against_outer_wall"))
            it = vol(env, tray) + vol(env, lid)
            ok &= it < 1e-3
            if side == 1:
                r[f"{pos}_interference_mm3"] = round(it, 3)
                r[f"{pos}_gold_to_tray_mm"] = round(gold.distance_to(tray), 2)
                r[f"{pos}_gold_to_lid_mm"] = round(gold.distance_to(lid), 2)
    r["headspace_for_foam_mm"] = round(lid_under - (p.sup_z + T + p.bag_T), 2)
    r["fits"] = bool(ok and Hm + 0.6 <= p.pocket_W and L + 2 <= p.pocket_L)
    r["Y_travel_between_stop_and_wall_mm"] = round((p.in_Y / 2 - p.stop_y) - (Hm - 5.0) - p.bag_T, 2)
    res[name] = r
out["modules"] = res

# --- 3. hinge motion (hook excluded; its snap is checked in section 4) --------
# The lid plate rests on the -X wall top; tilting the latch end up pivots it on
# the wall's outer top edge. Closing path checked: lid tilted by A, shifted +X by
# dx (tongues out), slid -X to dx=0 (tongues enter windows), then lowered to 0.
xo, zo = -p.out_X / 2, p.wall_top


def pose(a, dx):
    return Pos(dx, 0, 0) * Pos(xo, 0, zo) * Rot(0, -a, 0) * Pos(-xo, 0, -zo) * lid_nohook


swing = [(a, round(vol(pose(a, 0), tray), 3)) for a in (0, 2, 4, 6, 8, 10, 12, 14, 16, 20)]
out["hinge_rotation_about_wall_outer_edge_deg_vs_interference_mm3"] = swing
free = [a for a, v in swing if v < 1e-3]
a_max = 0
for a, v in swing:
    if v < 1e-3:
        a_max = a
    else:
        break
out["hinge_max_free_tilt_deg"] = a_max
A = a_max
slide = [(dx, round(vol(pose(A, dx), tray), 3)) for dx in (4, 3, 2, 1, 0.5, 0)]
out["insertion_slide_at_tilt"] = {"tilt_deg": A, "dx_mm_vs_interference_mm3": slide}
lift = [(a, round(vol(pose(a, 3.0), tray), 3)) for a in (A, 12, 20, 30, 45)]
out["withdrawn_dx3_tilt_deg_vs_interference_mm3"] = lift
# lid lift play at hinge end when closed (tongue top to window top)
# --- 4. latch geometry -----------------------------------------------------
x_lip = p.x_wall_out + p.hook_gap
engage = p.x_ledge - x_lip
defl = engage  # lip must clear ledge nose while closing / opening
L_beam = 2 * p.slot_half_len
b = p.beam_w
h = p.lid_t
E_petg, E_pla = 2000.0, 3300.0
eps = 12 * defl * b / L_beam ** 2  # fixed-fixed, centre load
I = h * b ** 3 / 12
F = 192 * E_petg * I * defl / L_beam ** 3
out["latch"] = {
    "catch_engagement_mm": round(engage, 2),
    "lip_clear_of_wall_mm": round(x_lip - p.x_wall_out, 2),
    "hook_clear_of_ledge_nose_mm": round(p.x_hook_in - p.x_ledge, 2),
    "vertical_slack_lip_below_ledge_mm": p.hook_slack,
    "beam_free_length_mm": L_beam,
    "beam_section_mm": [b, h],
    "required_beam_deflection_mm": round(defl, 2),
    "beam_peak_strain_pct_bending_only": round(100 * eps, 2),
    "beam_force_N_PETG_bending_only": round(F, 2),
    "beam_force_N_PLA_bending_only": round(F * E_pla / E_petg, 2),
    "note": "beam bending only; hook twist adds compliance (lowers force & strain). PETG yield ~4 %, PLA ~2.5 %.",
}
# --- 5. tongue / window -----------------------------------------------------
out["hinge_tongue"] = {
    "tongue_penetration_into_wall_mm": round(p.tongue_out - p.rim_gap, 2),
    "wall_thickness_mm": p.wall,
    "tongue_top_to_window_top_mm": round(p.window_top - p.tongue_top, 2),
    "tongue_bottom_to_window_bottom_mm": round(p.tongue_top - p.tongue_t - p.window_bot, 2),
    "lid_x_play_total_mm": round(2 * p.rim_gap, 2),
    "min_tongue_engagement_mm": round(p.tongue_out - p.rim_gap - 2 * p.rim_gap, 2),
}
# --- 5b. lid bending under foam pressure (simply supported hinge-to-latch) ---
rects = [  # (width_y, height_z, z_centre) about lid underside z'=0
    (2 * p.lid_y, p.lid_t, p.lid_t / 2),
    (2 * p.skirt_t, p.skirt_drop, -p.skirt_drop / 2),
    (p.lid_rib_w, p.lid_rib_drop, -p.lid_rib_drop / 2),
]
A_ = sum(b_ * h_ for b_, h_, _ in rects)
zc_ = sum(b_ * h_ * z_ for b_, h_, z_ in rects) / A_
I_ = sum(b_ * h_ ** 3 / 12 + b_ * h_ * (z_ - zc_) ** 2 for b_, h_, z_ in rects)
span = p.out_X
out["lid_stiffness"] = {
    "section_I_mm4": round(I_, 0),
    "span_mm": span,
    "midspan_deflection_mm_per_10N_uniform_PETG": round(5 * 10 * span ** 3 / (384 * 2000 * I_), 3),
    "note": "10 N total ~ two 135x35 mm soft PU foam strips compressed ~30 %; real foams vary 2-5x",
}
# --- 6. finger access ---------------------------------------------------------
out["finger_access"] = {
    "notch_width_mm": p.notch_w,
    "notch_bottom_z_mm": p.sup_z,
    "module_underside_z_mm": p.sup_z,
    "scoop_gap_under_module_edge_mm": p.plateau_h,
    "scoop_width_x_depth_mm": [p.scoop_w, p.scoop_d],
}
out["overall_mm"] = {
    "tray": [p.out_X, p.out_Y, p.wall_top],
    "closed_bbox": [round(v, 2) for v in (tray.fuse(lid)).bounding_box().size],
}
os.makedirs(os.path.join(ROOT, "checks"), exist_ok=True)
with open(os.path.join(ROOT, "checks", "fit_checks.json"), "w") as f:
    json.dump(out, f, indent=1)
print(json.dumps(out, indent=1))
