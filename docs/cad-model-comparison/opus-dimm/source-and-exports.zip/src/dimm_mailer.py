"""Two-DIMM reusable mailer: parametric build123d model.

Coordinate frame (assembled, mm): X = module length, Y = across the box,
Z = up, origin at tray bottom centre. Hinge (tongue) end is -X, latch end is +X.
Run:  python src/dimm_mailer.py
"""
from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass, asdict

from build123d import (
    Align, Axis, Box, Compound, Cylinder, Location, Mode, Plane, Pos, Rot,
    Solid, Text, export_step, export_stl, extrude, Polygon, fillet, chamfer,
    BuildSketch, BuildPart, Rectangle, RectangleRounded, add, Sketch,
)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT = os.path.join(ROOT, "assets", "fillaprint", "Fillaprint-Regular.ttf")
OUT = os.path.join(ROOT, "out")


@dataclass
class P:
    # ---- supported module envelope (bare module, heatspreader included) ----
    mod_L: float = 137.0     # length incl. heatspreader overhang (PCB is 133.35)
    mod_H: float = 45.0      # height above contact edge (Trident Z / Ripjaws V class)
    mod_T: float = 8.5       # thickness across heatspreaders
    bag_T: float = 0.6       # shielding bag, two layers + fold allowance (thickness)
    # ---- tray ----
    pocket_L: float = 142.0  # module + bag end folds
    pocket_W: float = 49.0   # module height + bag + 2-3 mm
    rib_W: float = 3.0       # centre divider
    wall: float = 2.4
    floor: float = 1.6
    plateau_h: float = 2.4   # support-rail height (finger gap under module edge)
    rail_w: float = 2.4
    rail_y: tuple = (14.0, 24.5, 35.0, 45.5)   # |y| of rail centres
    label_gaps: tuple = (19.25, 29.75)           # |y| of label centres (between rails)
    stop_y: float = 9.5      # |y| of heatspreader-stop face
    stop_t: float = 1.6
    stop_h: float = 1.6      # height above rail tops; PCB underside is >= 2.7 above
    wall_top: float = 16.8   # tray wall top = lid underside
    rib_drop: float = 6.0     # tray centre rib top below wall top
    corner_r: float = 4.0
    # finger access
    notch_w: float = 28.0
    notch_r: float = 8.0
    scoop_w: float = 26.0
    scoop_d: float = 7.0
    # ---- lid ----
    lid_t: float = 2.4
    skirt_t: float = 1.8
    skirt_gap: float = 0.3
    skirt_drop: float = 8.0        # side-skirt depth below lid underside
    rim_t: float = 1.6
    rim_gap: float = 0.25
    rim_depth: float = 3.0
    lid_rib_w: float = 2.4
    lid_rib_drop: float = 5.5      # lid centre rib depth below lid underside
    # hinge tongues (-X end): two tongues through two windows
    tongue_y0: float = 6.25
    tongue_y1: float = 29.75
    tongue_out: float = 2.0        # protrusion past rim outer face
    tongue_top: float = -0.3 - 1.6 # z' (lid frame, 0 = lid underside)
    tongue_t: float = 1.8          # at the tip
    tongue_drop: float = 0.7       # top slope, tip to root
    window_top: float = -1.6       # z' of window top (wall strip above is 1.6)
    window_bot: float = -5.0
    window_y0: float = 6.0
    window_y1: float = 30.0
    # latch (+X end)
    ledge_out: float = 1.2
    ledge_drop: float = 7.0        # catch face depth below wall top
    ledge_face_h: float = 0.6
    ledge_half_w: float = 13.0
    hook_gap: float = 0.3
    hook_t: float = 2.4
    hook_half_w: float = 12.0
    hook_lip_h: float = 1.8
    hook_slack: float = 0.2
    hook_drop: float = 11.0        # hook foot depth below wall top
    flange_out: float = 3.0
    beam_w: float = 2.4
    slot_w: float = 1.3
    slot_half_len: float = 42.0
    # labels
    deboss: float = 0.6
    cap_main: float = 9.0
    cap_small: float = 6.0          # >= 14 x 0.42 mm = 5.88 mm (Fillaprint min)

    labels: bool = True

    # ---- derived ----
    @property
    def rib_top(self):
        return self.wall_top - self.rib_drop

    @property
    def skirt_bottom(self):
        return self.wall_top - self.skirt_drop

    @property
    def lid_rib_bottom(self):
        return self.wall_top - self.lid_rib_drop

    @property
    def ledge_under_z(self):
        return self.wall_top - self.ledge_drop

    @property
    def hook_bottom_z(self):
        return self.wall_top - self.hook_drop

    @property
    def in_X(self):
        return self.pocket_L

    @property
    def in_Y(self):
        return 2 * self.pocket_W + self.rib_W

    @property
    def out_X(self):
        return self.in_X + 2 * self.wall

    @property
    def out_Y(self):
        return self.in_Y + 2 * self.wall

    @property
    def sup_z(self):
        return self.floor + self.plateau_h

    @property
    def lid_y(self):
        return self.out_Y / 2 + self.skirt_gap + self.skirt_t

    @property
    def x_wall_out(self):
        return self.out_X / 2

    @property
    def x_ledge(self):
        return self.out_X / 2 + self.ledge_out

    @property
    def x_hook_in(self):
        return self.x_ledge + self.hook_gap

    @property
    def x_hook_out(self):
        return self.x_hook_in + self.hook_t

    @property
    def lid_x_max(self):
        return self.x_hook_out


p = P()


def box(x0, x1, y0, y1, z0, z1):
    return Pos((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2) * Box(x1 - x0, y1 - y0, z1 - z0)


def rounded_prism(lx, ly, r, z0, z1, cx=0.0, cy=0.0):
    with BuildSketch(Plane.XY.offset(z0)) as s:
        RectangleRounded(lx, ly, r)
    return Pos(cx, cy, 0) * extrude(s.sketch, z1 - z0)


def text_solid(txt, cap, depth, x, y, z_top, rot=0.0, mirror=False):
    """Text cut-tool/inlay: from z_top-depth to z_top+0.01, centred at (x,y)."""
    fs = cap / 0.7  # Fillaprint: cap height = 14w, em = 20w
    with BuildSketch() as sk:
        Text(txt, font_size=fs, font_path=FONT, align=(Align.CENTER, Align.CENTER))
    sk_s = sk.sketch
    if mirror:
        sk_s = sk_s.mirror(Plane.YZ)
    solid = extrude(sk_s, depth)
    return Pos(x, y, z_top - depth) * Rot(0, 0, rot) * solid


# ------------------------------------------------------------------- TRAY
def build_tray():
    H = p.wall_top
    t = rounded_prism(p.out_X, p.out_Y, p.corner_r, 0, H)
    # cavity
    t -= rounded_prism(p.in_X, p.in_Y, max(p.corner_r - p.wall, 0.8), p.floor, H + 1)
    # centre rib
    t += box(-p.in_X / 2, p.in_X / 2, -p.rib_W / 2, p.rib_W / 2, p.floor - 0.01, p.rib_top)
    # support rails: heatspreader rests on these; PCB face sits >= (T-1.27)/2 above them
    x_r = p.in_X / 2 - 0.01
    for sgn in (1, -1):
        for yc in p.rail_y:
            ys = sorted([sgn * (yc - p.rail_w / 2), sgn * (yc + p.rail_w / 2)])
            t += box(-x_r, x_r, ys[0], ys[1], p.floor - 0.01, p.sup_z)
        # heatspreader stop: low wall that catches the heatspreader's lower edge
        # while the thinner PCB (with the gold contacts) passes over it
        ys = sorted([sgn * (p.stop_y - p.stop_t), sgn * p.stop_y])
        t += box(-x_r, x_r, ys[0], ys[1], p.floor - 0.01, p.sup_z + p.stop_h)
    # finger notches in the long walls; outer rail removed under the notch (scoop)
    for sgn in (1, -1):
        yc = sgn * (p.out_Y / 2 - p.wall / 2)
        a = p.notch_w / 2 - p.notch_r
        notch = box(-p.notch_w / 2, p.notch_w / 2, -3, 3, p.sup_z + p.notch_r, H + 2)
        notch += box(-a, a, -3, 3, p.sup_z, H + 2)
        for xc in (-a, a):
            notch += Pos(xc, 0, p.sup_z + p.notch_r) * Rot(90, 0, 0) * Cylinder(p.notch_r, 6)
        t -= Pos(0, yc, 0) * notch
        y_w = sgn * p.in_Y / 2
        ys = sorted([y_w, y_w - sgn * p.scoop_d])
        t -= box(-p.scoop_w / 2, p.scoop_w / 2, ys[0], ys[1], p.floor, p.sup_z + 0.5)
    # hinge windows in the -X end wall
    zt = H + p.window_top
    zb = H + p.window_bot
    for s in (1, -1):
        ys = sorted([s * p.window_y0, s * p.window_y1])
        t -= box(-p.out_X / 2 - 1, -p.in_X / 2 + 0.01, ys[0], ys[1], zb, zt)
    # latch ledge on +X end wall outer face (ramp on top, square catch below)
    x0 = p.x_wall_out - 0.01
    prof = Polygon(
        (0, p.ledge_under_z),
        (p.ledge_out + 0.01, p.ledge_under_z),
        (p.ledge_out + 0.01, p.ledge_under_z + p.ledge_face_h),
        (0, p.ledge_under_z + p.ledge_face_h + p.ledge_out + 0.01),
        align=None,
    )
    led = extrude(Plane.XZ * prof, p.ledge_half_w, both=True)
    t += Pos(x0, 0, 0) * led
    # small chamfer at bottom edge against elephant foot
    try:
        t = chamfer(t.edges().group_by(Axis.Z)[0], 0.5)
    except Exception:
        pass
    # floor labels (debossed between rails); arrows point the way in plan view
    labels = []
    for sgn in ((1, -1) if p.labels else ()):
        to_rib = "\u2193" if sgn > 0 else "\u2191"
        to_wall = "\u2191" if sgn > 0 else "\u2193"
        g = p.label_gaps
        labels.append(text_solid(f"{to_rib} GOLD EDGE TOWARD CENTRE {to_rib}", p.cap_small, p.deboss, 0,
                                 sgn * g[0], p.floor + 0.001))
        labels.append(text_solid(f"{to_wall} HEATSPREADER TOP TO WALL {to_wall}", p.cap_small, p.deboss, 0,
                                 sgn * g[1], p.floor + 0.001))
    # outer -X end face label: hinge side
    if p.labels:
        for L in labels:
            t -= L
    return t, labels


# -------------------------------------------------------------------- LID
def build_lid(hook=True):
    """Lid in assembled position: underside at z = wall_top."""
    H = p.wall_top
    Ht = H + p.lid_t
    x_min = -p.out_X / 2
    x_max = p.lid_x_max
    ly = p.lid_y
    # plate: rounded rectangle spanning x_min..x_max
    plate = rounded_prism(x_max - x_min, 2 * ly, p.corner_r + p.skirt_gap + p.skirt_t, H, Ht,
                          cx=(x_min + x_max) / 2)
    lid = plate
    # side skirts outside the long walls
    for s in (1, -1):
        y_in = s * (p.out_Y / 2 + p.skirt_gap)
        y_out = s * ly
        sk = box(x_min + p.corner_r + 2, p.x_wall_out - p.corner_r - 2, min(y_in, y_out), max(y_in, y_out),
                 p.skirt_bottom, H + 0.01)
        lid += sk
    # inner end rims
    xr_in = p.in_X / 2 - p.rim_gap
    ry = p.in_Y / 2 - 1.5
    lid += box(-xr_in, -xr_in + p.rim_t, -ry, ry, H - p.rim_depth, H + 0.01)
    lid += box(xr_in - p.rim_t, xr_in, -ry, ry, H - p.rim_depth, H + 0.01)
    # hinge tongues: deepen rim locally and add tongues
    tz0 = H + p.tongue_top - p.tongue_t
    tz1 = H + p.tongue_top
    for s in (1, -1):
        ys = sorted([s * p.tongue_y0, s * p.tongue_y1])
        lid += box(-xr_in, -xr_in + p.rim_t, ys[0], ys[1], tz0, H + 0.01)
        # tongue top slopes down toward the root so the lid can tilt further
        # about the wall's outer edge before the tongue meets the window top
        xt, xroot = -xr_in - p.tongue_out, -xr_in + 0.01
        prof = Polygon((xt, tz0), (xroot, tz0), (xroot, tz1 - p.tongue_drop), (xt, tz1), align=None)
        lid += Pos(0, (ys[0] + ys[1]) / 2, 0) * extrude(Plane.XZ * prof, (ys[1] - ys[0]) / 2, both=True)
    # centre stiffening rib (bears on tray rib only if lid is pushed down)
    lid += box(-xr_in + p.rim_t - 0.01, xr_in - p.rim_t + 0.01, -p.lid_rib_w / 2, p.lid_rib_w / 2,
               p.lid_rib_bottom, H + 0.01)
    # latch: slot through plate makes a fixed-fixed spring beam; hook hangs from it
    xs0 = p.x_hook_in - p.slot_w
    lid -= box(xs0, p.x_hook_in, -p.slot_half_len, p.slot_half_len, H - 1, Ht + 1)
    if not hook:
        return lid, []
    # hook body
    lip_top = p.ledge_under_z - p.hook_slack
    lid += box(p.x_hook_in, p.x_hook_out, -p.hook_half_w, p.hook_half_w, p.hook_bottom_z, H + 0.01)
    # hook lip (square catch on top, 45 deg lead-in below)
    x_lip = p.x_wall_out + p.hook_gap
    prof = Polygon(
        (p.x_hook_in + 0.01, lip_top),
        (x_lip, lip_top),
        (x_lip, lip_top - 0.6),
        (p.x_hook_in + 0.01, lip_top - 0.6 - (p.x_hook_in - x_lip)),
        align=None,
    )
    lid += extrude(Plane.XZ * prof, p.hook_half_w, both=True)
    # pull flange at hook foot: lift it with a fingertip; the offset load twists
    # the hook outward, freeing the lip from the ledge
    fl = Polygon((p.x_hook_out - 0.01, p.hook_bottom_z), (p.x_hook_out + p.flange_out, p.hook_bottom_z),
                 (p.x_hook_out + p.flange_out, p.hook_bottom_z + 1.6),
                 (p.x_hook_out - 0.01, p.hook_bottom_z + 1.6 + p.flange_out), align=None)
    lid += extrude(Plane.XZ * fl, p.hook_half_w, both=True)
    # labels on the lid top (debossed; same solids exported as optional inlay)
    labels = [] if not p.labels else [
        text_solid("DDR4 DIMM ×2", p.cap_main, p.deboss, -4, 18, Ht + 0.001),
        text_solid("ANTI-STATIC BAGS INSIDE", p.cap_small, p.deboss, -4, 0, Ht + 0.001),
        text_solid("HANDLE BY EDGES", p.cap_small, p.deboss, -4, -13, Ht + 0.001),
        text_solid("\u2193 PULL TAB OUT, LIFT \u2193", p.cap_small, p.deboss, p.x_wall_out - 7.5, 0, Ht + 0.001, rot=90),
        text_solid("HINGE END", p.cap_small, p.deboss, -p.out_X / 2 + 7.5, 0, Ht + 0.001, rot=-90),
    ]
    if p.labels:
        for L in labels:
            lid -= L
    return lid, labels


def module_body(L, Hm, T, pcb=1.27, c=5.0, side=1, slide_out=True):
    """Representative bagged module lying flat in pocket `side` (+1 / -1).

    L, Hm, T: length, height (contact edge to heatspreader top), thickness.
    c: PCB exposed below the heatspreader (contact edge to heatspreader lower edge).
    slide_out=True: top edge against the outer wall; False: slid inward until the
    heatspreader edge meets the stop (worst case for the contact edge).
    Returns (bagged_envelope, gold_zone_bare)."""
    bt = p.bag_T / 2
    z0 = p.sup_z
    if slide_out:
        y_top = side * (p.in_Y / 2 - bt)
    else:
        y_top = side * (p.stop_y + bt + (Hm - c))
    y_hs = y_top - side * (Hm - c)      # heatspreader lower edge
    y_edge = y_top - side * Hm          # contact edge
    hs = box(-L / 2 - bt, L / 2 + bt, min(y_top + side * bt, y_hs - side * bt),
             max(y_top + side * bt, y_hs - side * bt), z0, z0 + T + 2 * bt)
    zc = z0 + bt + T / 2
    pcb_b = box(-133.35 / 2 - bt, 133.35 / 2 + bt, min(y_hs, y_edge - side * bt), max(y_hs, y_edge - side * bt),
                zc - pcb / 2 - bt, zc + pcb / 2 + bt)
    env = hs.fuse(pcb_b)
    g1 = y_edge + side * min(5.0, c)
    gold = box(-133.35 / 2 + 2, 133.35 / 2 - 2, min(y_edge, g1), max(y_edge, g1), zc - pcb / 2, zc + pcb / 2)
    return env, gold


def main():
    os.makedirs(OUT, exist_ok=True)
    tray, tray_labels = build_tray()
    lid, lid_labels = build_lid()
    inlay = lid_labels[0].fuse(*lid_labels[1:])

    # Print orientations
    Ht = p.wall_top + p.lid_t
    lid_print_loc = Location((0, 0, Ht), (180, 0, 0))  # flip about X, top face on bed
    lid_print = lid_print_loc * lid
    inlay_print = lid_print_loc * inlay

    parts = {
        "tray": (tray, Location()),
        "lid": (lid_print, lid_print_loc.inverse()),
        "lid_label_inlay": (inlay_print, lid_print_loc.inverse()),
    }
    manifest = {"units": "mm", "frame": "assembled: origin tray bottom centre, +Z up, hinge end -X, latch end +X",
                "parts": []}
    for name, (shape, to_asm) in parts.items():
        export_step(shape, os.path.join(OUT, f"{name}.step"))
        export_stl(shape, os.path.join(OUT, f"{name}.stl"), tolerance=0.02, angular_tolerance=0.2, ascii_format=False)
        m = (tuple(to_asm.position), tuple(to_asm.orientation))
        # 4x4 matrix
        T = to_asm.wrapped.Transformation()
        mat = [[T.Value(r, c) for c in range(1, 5)] for r in range(1, 4)] + [[0, 0, 0, 1]]
        manifest["parts"].append({
            "name": name,
            "step": f"out/{name}.step",
            "stl": f"out/{name}.stl",
            "files_are_in": "print orientation" if name != "tray" else "print orientation (= assembled)",
            "transform_file_to_assembled": {"matrix_4x4_row_major": [[round(v, 6) for v in row] for row in mat],
                                            "translation_mm": [round(v, 4) for v in m[0]],
                                            "rotation_xyz_deg": [round(v, 4) for v in m[1]]},
            "printed": True,
            "note": {"tray": "print as shown, open side up",
                     "lid": "print top face down; optional 2-colour: swap filament for first 3 layers or use inlay body",
                     "lid_label_inlay": "optional: same-position text bodies filling the 0.6 mm lid deboss for multi-material"}[name],
        })
    # reference module envelopes (not printed) in assembled frame
    refs = []
    for side in (1, -1):
        env, gold = module_body(p.mod_L, p.mod_H, p.mod_T, side=side)
        refs.append(env)
    ref = refs[0].fuse(refs[1])
    export_step(ref, os.path.join(OUT, "ref_module_envelopes.step"))
    export_stl(ref, os.path.join(OUT, "ref_module_envelopes.stl"), tolerance=0.02, ascii_format=False)
    manifest["parts"].append({"name": "ref_module_envelopes", "step": "out/ref_module_envelopes.step",
                              "stl": "out/ref_module_envelopes.stl", "printed": False,
                              "files_are_in": "assembled frame",
                              "transform_file_to_assembled": {"matrix_4x4_row_major": [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]],
                                                              "translation_mm": [0, 0, 0], "rotation_xyz_deg": [0, 0, 0]},
                              "note": "largest supported bagged module (137 x 45 x 8.5 mm + bag) x2, for clearance checks only"})
    manifest["parameters"] = asdict(p)
    with open(os.path.join(ROOT, "assembly.json"), "w") as f:
        json.dump(manifest, f, indent=2)
    return tray, lid, inlay


if __name__ == "__main__":
    main()
    print("ok")
