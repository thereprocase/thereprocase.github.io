"""Mesh-level checks on exported STLs (physics venv: trimesh/numpy).
Watertightness, volumes, print-orientation bed contact, unsupported overhang
area, label cap heights. Writes checks/mesh_checks.json."""
import json, os, sys
import numpy as np
import trimesh

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
asm = json.load(open(os.path.join(ROOT, "assembly.json")))
out = {}
meshes = {}
for part in asm["parts"]:
    m = trimesh.load(os.path.join(ROOT, part["stl"]))
    meshes[part["name"]] = (m, np.array(part["transform_file_to_assembled"]["matrix_4x4_row_major"]))
    r = {"watertight": bool(m.is_watertight), "volume_cm3": round(m.volume / 1000, 2),
         "bbox_mm": [round(v, 2) for v in m.extents], "triangles": len(m.faces)}
    if part.get("printed"):
        zmin = m.bounds[0][2]
        r["min_z_print"] = round(zmin, 3)
        n = m.face_normals; a = m.area_faces; c = m.triangles_center
        down = n[:, 2] < -np.cos(np.radians(45)) - 1e-6   # steeper than 45 deg from vertical
        on_bed = c[:, 2] < zmin + 0.05
        ov = down & ~on_bed
        r["bed_contact_area_mm2"] = round(a[down & on_bed].sum(), 1)
        r["overhang_gt45_area_mm2"] = round(a[ov].sum(), 1)
        # cluster overhang faces by height to identify features
        if ov.any():
            zs = np.round(c[ov, 2], 1)
            feats = {}
            for z, ar, cc in zip(zs, a[ov], c[ov]):
                k = float(z)
                f = feats.setdefault(k, {"area": 0.0, "xmin": 1e9, "xmax": -1e9, "ymin": 1e9, "ymax": -1e9})
                f["area"] += ar; f["xmin"] = min(f["xmin"], cc[0]); f["xmax"] = max(f["xmax"], cc[0])
                f["ymin"] = min(f["ymin"], cc[1]); f["ymax"] = max(f["ymax"], cc[1])
            r["overhang_by_height"] = {f"z={k}": {kk: round(vv, 1) for kk, vv in v.items()}
                                       for k, v in sorted(feats.items()) if v["area"] > 0.5}
    out[part["name"]] = r

# assembled collision check (mesh): lid vs tray, envelopes vs both
def T(name):
    m, M = meshes[name]
    mm = m.copy(); mm.apply_transform(M); return mm
tray, lid, env = T("tray"), T("lid"), T("ref_module_envelopes")
out["assembled_bbox_mm"] = [round(v, 2) for v in trimesh.util.concatenate([tray, lid]).extents]
try:
    out["assembled_lid_tray_intersection_cm3"] = round(tray.intersection(lid).volume / 1000, 4)
    out["envelope_tray_intersection_cm3"] = round(env.intersection(tray).volume / 1000, 4)
    out["envelope_lid_intersection_cm3"] = round(env.intersection(lid).volume / 1000, 4)
except Exception as e:
    out["mesh_boolean"] = f"unavailable: {e}"
json.dump(out, open(os.path.join(ROOT, "checks", "mesh_checks.json"), "w"), indent=1)
print(json.dumps(out, indent=1))
