"""
Mesh checks on the exported binary STLs and assembly.json.  trimesh runtime:
    python src/check_mesh.py
Writes out/checks_mesh.json.
"""
import json
import struct
from pathlib import Path

import numpy as np
import trimesh

ROOT = Path(__file__).resolve().parents[1]
asm = json.loads((ROOT / "assembly.json").read_text())
rep = json.loads((ROOT / "out" / "build_report.json").read_text())
cad_vol = {}
for b in rep["bins"]:
    cad_vol[f"{b['name']}_body"] = b["body_volume_mm3"]
    cad_vol[f"{b['name']}_label"] = b["label_volume_mm3"]

res = {"parts": [], "problems": []}


def is_binary_stl(path):
    data = path.read_bytes()
    if len(data) < 84:
        return False
    n = struct.unpack("<I", data[80:84])[0]
    return len(data) == 84 + 50 * n


meshes = {}
all_stl = sorted((ROOT / "out" / "stl").glob("*.stl"))
for f in all_stl:
    m = trimesh.load_mesh(f)
    name = f.stem.removeprefix("bin_")
    rec = {"file": f"out/stl/{f.name}", "binary": is_binary_stl(f), "triangles": int(len(m.faces)),
           "watertight": bool(m.is_watertight), "winding_consistent": bool(m.is_winding_consistent),
           "volume_mm3": round(float(m.volume), 1), "bodies": len(m.split(only_watertight=False)),
           "bbox_mm": [round(float(v), 3) for v in m.extents]}
    if name in cad_vol:
        rec["cad_volume_mm3"] = cad_vol[name]
        rec["mesh_vs_cad_pct"] = round(100 * (m.volume - cad_vol[name]) / cad_vol[name], 3)
    if not (rec["binary"] and rec["watertight"] and rec["winding_consistent"] and m.volume > 0):
        res["problems"].append(f"{f.name}: mesh not clean")
    if name.endswith("_body") and rec["bodies"] != 1:
        res["problems"].append(f"{f.name}: {rec['bodies']} bodies")
    res["parts"].append(rec)
    meshes[f"out/stl/{f.name}"] = m

# ---------------------------------------------------------------- assembly
placed = []
for part in asm["parts"]:
    m = meshes[part["stl"]].copy()
    m.apply_transform(np.array(part["transform"], dtype=float))
    placed.append((part, m))
plate = [m for p, m in placed if p["role"] == "baseplate"][0]
pb = plate.bounds
bins = [(p, m) for p, m in placed if p["role"] == "bin body"]
labels = [(p, m) for p, m in placed if p["role"].startswith("label")]
asm_rec = {"plate_extent_mm": [round(float(v), 2) for v in plate.extents],
           "bins": len(bins), "label_inlays": len(labels)}
# all bins inside the plate footprint, sitting on the plate floor
inside = all((m.bounds[0][:2] >= pb[0][:2] - 1e-6).all() and (m.bounds[1][:2] <= pb[1][:2] + 1e-6).all() for _, m in bins)
asm_rec["bins_within_plate_footprint"] = bool(inside)
asm_rec["bin_bottom_z_values"] = sorted({round(float(m.bounds[0][2]), 3) for _, m in bins})
# pairwise bounding-box gaps between bins
gaps = []
for i in range(len(bins)):
    for j in range(i + 1, len(bins)):
        a, b = bins[i][1].bounds, bins[j][1].bounds
        sep = np.maximum(a[0] - b[1], b[0] - a[1])[:2]
        if (sep > -1e-6).any():
            gaps.append(float(sep.max()))
        else:
            res["problems"].append(f"overlap {bins[i][0]['name']} / {bins[j][0]['name']}")
asm_rec["min_bbox_gap_between_bins_mm"] = round(min(g for g in gaps if g > -1e-6 and g < 5), 3)
# cell coverage of bins (sample the cell centres)
cover = {}
for p_, m in bins:
    for c in p_["cells"]:
        cover[tuple(c)] = cover.get(tuple(c), 0) + 1
asm_rec["cells_covered"] = len(cover)
asm_rec["all_20_cells_once"] = len(cover) == 20 and set(cover.values()) == {1}
# label inlays sit inside their bin's footprint and flush with the label plane
flush = []
for p_, m in labels:
    body = [bm for bp, bm in bins if bp["bin"] == p_["bin"]][0]
    flush.append(float(m.bounds[1][2]))
    lo_ok = (m.bounds[0][:2] >= body.bounds[0][:2]).all() and (m.bounds[1][:2] <= body.bounds[1][:2]).all()
    if not lo_ok:
        res["problems"].append(f"label outside body footprint: {p_['name']}")
    # the inlay must not occupy the body's material: points slightly inside the inlay are outside the body
    pts = m.sample(400, return_index=False) if hasattr(m, "sample") else m.vertices
    inward = pts - 0.02 * m.face_normals[m.nearest.on_surface(pts)[2]]
    inside_body = body.contains(inward)
    if inside_body.mean() > 0.02:
        res["problems"].append(f"label overlaps body: {p_['name']} ({inside_body.mean():.2%})")
asm_rec["label_top_z_values"] = sorted({round(z, 3) for z in flush})
total = sum(m.volume for _, m in placed)
asm_rec["total_plastic_cm3_solid"] = round(total / 1000, 1)
res["assembly"] = asm_rec
res["all_clean"] = not res["problems"]
(ROOT / "out" / "checks_mesh.json").write_text(json.dumps(res, indent=1))
print(json.dumps({k: v for k, v in res.items() if k != "parts"}, indent=1))
print("parts checked:", len(res["parts"]))
