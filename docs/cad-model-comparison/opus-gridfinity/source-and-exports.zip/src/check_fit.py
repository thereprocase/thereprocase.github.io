"""
Exact (B-rep) functional checks for the fastener organizer.  build123d runtime.
Writes out/checks_fit.json.  Run after src/fastener_grid.py.

Checks:
  socket fit   : a seated bin vs. the baseplate socket walls (lateral clearance, no interference)
  neighbours   : two bins in adjacent cells
  stacking     : seat height of a bin on another bin's lip, clearance from the upper feet to the lower
                 bin's dividers / label shelf / inlay
  labels       : capital height vs. Fillaprint minimum, ink kept inside the visible shelf area,
                 clear distance between label items
  access       : top opening of every compartment and reach depth
  spill        : tilt at which a (conservative) heap surface would reach the divider/label plane
  layout       : every grid cell occupied exactly once
"""
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import build123d as bd  # noqa: E402
import fastener_grid as G  # noqa: E402

p = G.PR
OUT = G.OUT
res = {}


def dist(a, b):
    return a.distance_to(b)


def ivol(a, b):
    x = a & b
    return 0.0 if x is None else sum(s.volume for s in x.solids()) if hasattr(x, "solids") else x.volume


specs = {s.name: s for s in G.starter_layout(p)}
for s in specs.values():
    G.choose_floor(s, p)

# ---------------------------------------------------------------- socket fit
split = specs["M3_6-8"]
single = specs["M4_16"]
tray = specs["SORT_1x2"]
b_split, ink_split = G.build_bin(split, p)
b_tray, _ = G.build_bin(tray, p)
frame = G.build_baseplate(2, 2, p)                         # floor present
frame_nofloor = G.build_baseplate(2, 2, p, floor=0.0) .moved(bd.Location((0, 0, p.plate_floor)))
seated = bd.Pos(21, 21, p.plate_floor) * b_split
lat = dist(seated, frame_nofloor)
res["socket_fit"] = {
    "bin_on_plate_floor_z": p.plate_floor,
    "interference_mm3": round(ivol(seated, frame), 5),
    "min_lateral_clearance_normal_mm": round(lat, 3),
    "expected": "0.25 mm horizontal on the vertical band (0.18 mm normal to the 45-deg faces), 0.35 mm at the chamfers",
    "bin_top_of_base_above_plate_top_mm": round(G.FOOT_H - G.SOCKET_H, 3),
}
seated_tray = bd.Pos(21, 42, p.plate_floor) * b_tray
res["socket_fit"]["tray_1x2_interference_mm3"] = round(ivol(seated_tray, frame), 5)
res["socket_fit"]["tray_1x2_min_lateral_clearance_mm"] = round(dist(seated_tray, frame_nofloor), 3)

# ---------------------------------------------------------------- neighbours
nb = bd.Pos(63, 21, p.plate_floor) * b_split
res["neighbours"] = {"gap_between_adjacent_bins_mm": round(dist(seated, nb), 3)}

# ---------------------------------------------------------------- stacking
lower = b_split
upper_src, _ = G.build_bin(single, p)
lo, hi = p.z_body - 2.0, p.z_body + 1.0
for _ in range(22):
    mid = (lo + hi) / 2
    v = ivol(bd.Pos(0, 0, mid) * upper_src, lower)
    lo, hi = (mid, hi) if v > 1e-3 else (lo, mid)
seat = hi
upper = bd.Pos(0, 0, seat) * upper_src
foot_zone = bd.Pos(0, 0, 0) * bd.extrude(bd.RectangleRounded(41.5 - 2 * G.LIP_TIP - 0.01, 41.5 - 2 * G.LIP_TIP - 0.01, 1.15),
                                          amount=p.z_body + 10)
inner_feats = lower & foot_zone          # dividers, label shelf, inlay (the lip tip lies outside this zone)
inner_feats_ink = (lower + ink_split) & foot_zone
res["stacking"] = {
    "seat_z_of_upper_foot_bottom": round(seat, 3),
    "analytic_seat": round(p.z_body + 4.4 - G.FOOT_H, 3),
    "seat_minus_lower_z_body": round(seat - p.z_body, 3),
    "clearance_upper_feet_to_lower_dividers_and_label_mm": round(dist(upper, inner_feats_ink), 3),
    "lower_label_top_z": p.z_label,
    "note": "stacked bins rest on the lower bin's stacking lip; the lower label is hidden while stacked",
}

# ---------------------------------------------------------------- labels
w42, w45 = 0.42, 0.45
lab = {"cap_height_mm": p.cap, "font_size_em_mm": p.em,
       "fillaprint_min_cap_for_w0.42": round(14 * w42, 3), "fillaprint_min_cap_for_w0.45": round(14 * w45, 3)}
h = G.text_face("H", p).bounding_box().size.Y
m4 = G.text_face("M4×16", p).bounding_box().size.Y
lab["measured_H_outline_height_mm"] = round(h, 3)
lab["measured_M4x16_outline_height_mm"] = round(m4, 3)
lab["meets_minimum_for_w<=0.45"] = h >= 14 * w45 - 1e-6
per_bin = []
worst_gap = 1e9
for s in specs.values():
    faces = G.label_geometry(s, p)
    hx, hy = G.interior(s, p)
    ys = hy - G.shelf_depth(s.n_lines, p)
    xs = [f.bounding_box() for f in faces]
    xmin = min(b.min.X for b in xs); xmax = max(b.max.X for b in xs)
    ymin = min(b.min.Y for b in xs); ymax = max(b.max.Y for b in xs)
    gaps = []
    for i in range(len(faces)):
        for j in range(i + 1, len(faces)):
            gaps.append(faces[i].distance_to(faces[j]))
    g = min(gaps) if gaps else None
    if g is not None:
        worst_gap = min(worst_gap, g)
    per_bin.append({
        "bin": s.name, "text": " / ".join(it.content or it.kind for it in s.label),
        "ink_x": [round(xmin, 2), round(xmax, 2)], "ink_y": [round(ymin, 2), round(ymax, 2)],
        "shelf_front_y": round(ys, 2),
        "margin_to_shelf_front": round(ymin - ys, 2),
        "margin_to_lip_shadow_rear": round((hy - (G.LIP_TIP - p.wall)) - ymax, 2),
        "margin_to_lip_shadow_side": round((G.interior(s, p)[0] - (G.LIP_TIP - p.wall)) - max(abs(xmin), abs(xmax)), 2),
        "min_gap_between_items": None if g is None else round(g, 2),
    })
lab["per_bin"] = per_bin
lab["min_gap_between_label_items_mm"] = round(worst_gap, 3)
lab["required_min_gap_2w"] = 2 * p.line_w
res["labels"] = lab

# ---------------------------------------------------------------- access
acc = []
for s in specs.values():
    hx, hy = G.interior(s, p)
    over = G.LIP_TIP - p.wall
    ys = hy - G.shelf_depth(s.n_lines, p)
    for c in s.compartments:
        x0 = max(c.x0, -hx + over); x1 = min(c.x1, hx - over)
        oy = ys - (-hy + over)
        acc.append({"bin": s.name, "contents": c.contents, "opening_x_mm": round(x1 - x0, 2),
                    "opening_y_mm": round(oy, 2), "reach_lip_top_to_floor_mm": round(p.z_body + G.LIP_TOP - G.floor_z(s, p), 2),
                    "floor_z": G.floor_z(s, p)})
res["access"] = {"compartments": acc,
                 "min_opening_x": min(a["opening_x_mm"] for a in acc),
                 "min_opening_y": min(a["opening_y_mm"] for a in acc),
                 "max_reach": max(a["reach_lip_top_to_floor_mm"] for a in acc)}

# ---------------------------------------------------------------- spill / capacity summary from the build report
rep = json.loads((OUT / "build_report.json").read_text())
spill = []
for b in rep["bins"]:
    for c in b["compartments"]:
        if "heap_top_z_conservative" not in c:
            continue
        half_w = (c["x1"] - c["x0"]) / 2
        fb = c["freeboard_to_divider_mm"]
        # rim = stacking-lip inner tip (z_body) at the outer wall, measured over the full compartment
        # width from the far side; divider = label/divider plane over half the compartment width.
        fb_rim = p.z_body - c["heap_top_z_conservative"]
        row = {"bin": b["name"], "contents": c["contents"], "fill_conservative": c["fill_conservative"],
               "fill_typical": c["fill_typical"], "freeboard_to_divider_mm": fb,
               "tilt_deg_heap_level_reaches_rim": round(math.degrees(math.atan(fb_rim / half_w)), 1)}
        if b["type"] == "SPLIT-2":
            row["tilt_deg_heap_level_reaches_divider_top"] = round(math.degrees(math.atan(fb / half_w)), 1)
        spill.append(row)
res["capacity_and_spill"] = {
    "model": "flat heap surface (liquid-like) - pessimistic; loose screws/nuts have an angle of repose and do not "
             "level like a liquid. Demand = 20 screws / 30 nuts / 30 washers divided by an assumed solid fraction "
             "(screw 0.33/0.40, nut 0.45/0.55, washer 0.40/0.50 conservative/typical).",
    "rows": spill,
    "max_fill_conservative": max(r["fill_conservative"] for r in spill),
    "min_tilt_to_divider_deg_split_bins": min(r["tilt_deg_heap_level_reaches_divider_top"] for r in spill
                                             if "tilt_deg_heap_level_reaches_divider_top" in r),
    "min_tilt_to_rim_deg": min(r["tilt_deg_heap_level_reaches_rim"] for r in spill)}

# ---------------------------------------------------------------- layout occupancy
cells = {}
for s in specs.values():
    for a in range(s.nx):
        for b in range(s.ny):
            cells.setdefault((s.cell[0] + a, s.cell[1] + b), []).append(s.name)
res["layout"] = {"cells_used": len(cells), "grid": [5, 4],
                 "all_cells_once": len(cells) == 20 and all(len(v) == 1 for v in cells.values()),
                 "map_front_row_first": [[cells[(i, j)][0] for i in range(5)] for j in range(4)]}

(OUT / "checks_fit.json").write_text(json.dumps(res, indent=1))
print(json.dumps({k: (v if k not in ("labels", "access", "capacity_and_spill") else
                      {kk: vv for kk, vv in v.items() if kk not in ("per_bin", "compartments", "rows")})
                  for k, v in res.items()}, indent=1))
