"""
Parametric Gridfinity fastener organizer (M2 / M2.5 / M3 / M4 socket-head screws, hex nuts, flat washers).

Run with the build123d runtime:
    python src/fastener_grid.py            # build all parts + checks
    python src/fastener_grid.py --only M3_6-8   # one bin

All dimensions in millimetres.  Every part is modelled in its own local frame:
    bins:      XY centred on the bin footprint, z = 0 at the bottom of the feet
    baseplate: XY origin at the front-left outer corner, z = 0 at the underside
assembly.json gives the transform of each part into the assembled 5 x 4 layout.

Interfaces (Gridfinity, as published in kennetek/gridfinity-rebuilt-openscad src/core/standard.scad,
which follows Zack Freedman's specification):
    grid pitch 42, bin footprint 41.5 (0.25 gap per side), outer corner radius 3.75
    bin foot profile, from the bottom: 0.8 @45deg, 1.8 vertical, 2.15 @45deg  (4.75 total)
    baseplate socket, from the bottom: 0.7 @45deg, 1.8 vertical, 2.15 @45deg (4.65 total), top 42 r4
    stacking lip, from the top inner tip: 0.7 @45deg, 1.8 vertical, 1.9 @45deg (4.4 total)
    height unit 7
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import dataclass, field
from pathlib import Path

import build123d as bd

ROOT = Path(__file__).resolve().parents[1]
FONT = ROOT / "assets" / "fillaprint" / "Fillaprint-Regular.ttf"
OUT = ROOT / "out"

# ----------------------------------------------------------------------------------------------
# Gridfinity interface constants
# ----------------------------------------------------------------------------------------------
PITCH = 42.0
BIN_CLEAR = 0.5                      # total gap between neighbouring bins
BIN_R = 3.75                         # outer corner radius of a bin
U = 7.0                              # height unit
FOOT_H = 4.75
# (z, inset from the 41.5 outline) for one bin foot
FOOT_SECTIONS = [(0.0, 2.95), (0.8, 2.15), (2.6, 2.15), (4.75, 0.0)]
PLATE_R = 4.0
SOCKET_H = 4.65
# (z above plate floor, inset from the 42 cell outline) for one baseplate socket
SOCKET_SECTIONS = [(0.0, 2.85), (0.7, 2.15), (2.5, 2.15), (4.65, 0.0), (5.65, -1.0)]
LIP_TIP = 2.6                        # stacking-lip inner tip, inset from the outer wall
LIP_CUT = 0.4                        # lip top truncated 0.4 below the knife edge (0.4 flat); seat unaffected
# lip void (z relative to top of body, inset from outer outline); support below the tip at 45 deg
LIP_TOP = 4.4 - LIP_CUT


# ----------------------------------------------------------------------------------------------
# Design parameters
# ----------------------------------------------------------------------------------------------
@dataclass
class P:
    wall: float = 1.2                # bin outer wall
    divider: float = 1.2             # compartment divider
    height_u: int = 4                # bin body height in units (28 mm) + stacking lip
    floor_t: float = 1.0             # floor above the foot top (z = 4.75)
    shallow_raise: float = 6.0       # floor raise for the "shallow" variant (tiny parts)
    label_drop: float = 1.0          # label/divider top below the body top (stacked feet clear it)
    shelf_t: float = 1.6             # label shelf thickness at its front edge
    nose: float = 1.5                # horizontal finger-hook under the label front edge
    r_side: float = 3.0              # floor-to-wall fillet across the compartment
    r_scoop: float = 10.0            # front scoop radius (clamped to 0.6 x depth)
    # Fillaprint sizing: w = extrusion line width used for the label layers
    line_w: float = 0.45
    inlay: float = 0.8               # label inlay depth (4 layers @ 0.2)
    plate_floor: float = 2.0         # solid floor under the baseplate sockets

    @property
    def cap(self):   # capital height = 14 w (font minimum at reference size)
        return 14 * self.line_w

    @property
    def em(self):    # build123d font_size is the em = 20 w
        return 20 * self.line_w

    @property
    def line_pitch(self):  # 18 w: caps/digits only (no accents/descenders) -> 4 w clear between lines
        return 18 * self.line_w

    @property
    def margin(self):      # 2 w: minimum body-colour band around inlaid ink
        return 2 * self.line_w

    @property
    def z_body(self):
        return self.height_u * U

    @property
    def z_label(self):
        return self.z_body - self.label_drop


PR = P()


# ----------------------------------------------------------------------------------------------
# Fastener data (nominal, ISO 4762 / ISO 4032 / ISO 7089) and bulk-volume model
# ----------------------------------------------------------------------------------------------
SHCS = {  # d, head dia dk, head height k, hex socket s
    "M2": (2.0, 3.8, 2.0, 1.5),
    "M2.5": (2.5, 4.5, 2.5, 2.0),
    "M3": (3.0, 5.5, 3.0, 2.5),
    "M4": (4.0, 7.0, 4.0, 3.0),
}
NUT = {"M2": (4.0, 1.6), "M2.5": (5.0, 2.0), "M3": (5.5, 2.4), "M4": (7.0, 3.2)}           # s, m
WASHER = {"M2": (2.2, 5.0, 0.3), "M2.5": (2.7, 6.0, 0.5), "M3": (3.2, 7.0, 0.5), "M4": (4.3, 9.0, 0.8)}
# solid fraction of a loose heap: (conservative, typical).  Assumptions, not measurements.
PHI = {"screw": (0.33, 0.40), "nut": (0.45, 0.55), "washer": (0.40, 0.50)}
COUNT = {"screw": 20, "nut": 30, "washer": 30}


def solid_volume(kind, size, length=None):
    if kind == "screw":
        d, dk, k, s = SHCS[size]
        head = math.pi * (dk / 2) ** 2 * k - (3 * math.sqrt(3) / 2) * (s / math.sqrt(3)) ** 2 * (k * 0.6)
        return head + math.pi * (d / 2) ** 2 * length
    if kind == "nut":
        s, m = NUT[size]
        d = SHCS[size][0]
        return (math.sqrt(3) / 2 * s * s - math.pi * (d / 2) ** 2) * m
    if kind == "washer":
        d1, d2, h = WASHER[size]
        return math.pi / 4 * (d2 * d2 - d1 * d1) * h
    raise ValueError(kind)


def bulk_demand(kind, size, length=None):
    """(conservative, typical) heap volume in mm^3 for the target count."""
    v = solid_volume(kind, size, length) * COUNT[kind]
    lo, hi = PHI[kind]
    return v / lo, v / hi


# ----------------------------------------------------------------------------------------------
# Geometry helpers
# ----------------------------------------------------------------------------------------------
def rr(wx, wy, r, z, cx=0.0, cy=0.0):
    return bd.Pos(cx, cy, z) * bd.RectangleRounded(wx, wy, max(r, 0.05))


def loft_stack(wx, wy, r, sections, cx=0.0, cy=0.0, z0=0.0):
    """Ruled loft through rounded-rectangle sections given as (z, inset)."""
    secs = [rr(wx - 2 * i, wy - 2 * i, r - i, z0 + z, cx, cy) for z, i in sections]
    return bd.loft(secs, ruled=True)


def poly_face(pts):
    w = bd.Wire.make_polygon([bd.Vector(*p) for p in pts], close=True)
    return bd.Face(w)


def fillet_face_at(face, targets, radius):
    """2D-fillet the vertices of a planar face nearest the given global points."""
    verts = []
    for t in targets:
        tv = bd.Vector(*t)
        verts.append(min(face.vertices(), key=lambda v: (bd.Vector(v) - tv).length))
    return face.fillet_2d(radius, verts)


# ----------------------------------------------------------------------------------------------
# Labels
# ----------------------------------------------------------------------------------------------
@dataclass
class LabelItem:
    kind: str          # "text" | "nut" | "washer"
    content: str
    x: float           # centre x
    line: int          # 0 = rear line


def text_face(s, p=PR):
    return bd.Text(s, font_size=p.em, font_path=str(FONT), align=(bd.Align.CENTER, bd.Align.MIN))


def icon_face(kind, p=PR):
    c = p.cap
    if kind == "nut":   # hexagon, flats top/bottom, across flats = cap height, round hole
        R = c / 2 / math.cos(math.radians(30))
        pts = [(R * math.cos(math.radians(a)), R * math.sin(math.radians(a))) for a in range(0, 360, 60)]
        f = bd.Sketch() + bd.Polygon(*pts, align=None)
        f = f - bd.Circle(c / 4)               # hole dia = cap/2 -> ink >= 3.5 w at the flats
    else:               # washer: plain ring, OD = cap, ID = 0.57 cap -> ink 3 w
        f = bd.Sketch() + bd.Circle(c / 2) - bd.Circle(c * 0.285)
    return bd.Pos(0, c / 2) * f              # sit on the baseline like a capital


def item_width(it, p=PR):
    if it.kind == "text":
        bb = text_face(it.content, p).bounding_box()
        return bb.size.X
    return p.cap * (2 / math.sqrt(3)) if it.kind == "nut" else p.cap


def label_rows(n_lines, p=PR):
    return n_lines


def shelf_depth(n_lines, p=PR):
    """Label shelf depth measured from the inner face of the back wall."""
    over = LIP_TIP - p.wall
    return over + p.margin + n_lines * p.cap + (n_lines - 1) * (p.line_pitch - p.cap) + p.margin


# ----------------------------------------------------------------------------------------------
# Bin model
# ----------------------------------------------------------------------------------------------
@dataclass
class Compartment:
    x0: float
    x1: float
    contents: dict        # {"kind":..., "size":..., "length":...}


@dataclass
class BinSpec:
    name: str
    btype: str                       # SPLIT-2 | SINGLE | TRAY
    cell: tuple                      # (i, j) of the front-left cell in the baseplate grid
    nx: int
    ny: int
    compartments: list
    label: list
    n_lines: int
    floor_raise: float = 0.0
    note: str = ""

    @property
    def sx(self):
        return PITCH * self.nx - BIN_CLEAR

    @property
    def sy(self):
        return PITCH * self.ny - BIN_CLEAR


def interior(spec, p=PR):
    return spec.sx / 2 - p.wall, spec.sy / 2 - p.wall   # half sizes of the interior


def floor_z(spec, p=PR):
    return FOOT_H + p.floor_t + spec.floor_raise


def pocket_solid(spec, comp, p=PR):
    """Material removed for one compartment (below the label/divider plane, plus headroom)."""
    hx, hy = interior(spec, p)
    yf, yb = -hy, hy
    zf = floor_z(spec, p)
    zl = p.z_label
    ztop = p.z_body + 1.0
    ys = yb - shelf_depth(spec.n_lines, p)
    zg0 = zl - p.shelf_t
    yn = ys + p.nose
    zgb = zg0 - (yb - yn)            # gusset (45 deg) meets the back wall here
    if zgb > zf + 1.0:
        back = [(yb, zf), (yb, zgb), (yn, zg0), (ys, zg0)]
        corner_pts = [(yb, zf)]
    else:
        ym = yn + (zg0 - zf)
        back = [(ym, zf), (yn, zg0), (ys, zg0)]
        corner_pts = [(ym, zf)]
    pts2d = [(yf, ztop), (yf, zf)] + back + [(ys, ztop)]
    # YZ profile -> global (x=0, Y=u, Z=v)
    f = poly_face([(0, u, v) for u, v in pts2d])
    depth = zl - zf
    rs = min(p.r_scoop, 0.6 * depth)
    f = fillet_face_at(f, [(0, yf, zf)], rs)
    f = fillet_face_at(f, [(0, u, v) for u, v in corner_pts], 3.0)
    xc = (comp.x0 + comp.x1) / 2
    yz = bd.Pos(xc, 0, 0) * bd.extrude(f, amount=(comp.x1 - comp.x0) / 2, both=True)
    # XZ profile: floor-to-side fillets
    g = poly_face([(comp.x0, 0, ztop), (comp.x0, 0, zf), (comp.x1, 0, zf), (comp.x1, 0, ztop)])
    g = fillet_face_at(g, [(comp.x0, 0, zf), (comp.x1, 0, zf)], min(p.r_side, (comp.x1 - comp.x0) / 3))
    xz = bd.extrude(g, amount=hy + 1, both=True)
    return yz & xz


def lip_ring(spec, p=PR):
    zb = p.z_body
    outer = bd.Pos(0, 0, zb - 2.0) * bd.extrude(bd.RectangleRounded(spec.sx, spec.sy, BIN_R), amount=2.0 + LIP_TOP)
    over = LIP_TIP - p.wall
    secs = [(-2.6, p.wall), (-2.0, p.wall), (-2.0 + over, LIP_TIP), (0.0, LIP_TIP), (0.7, LIP_TIP - 0.7),
            (2.5, LIP_TIP - 0.7), (4.4, 0.0)]
    # truncate: continue 45deg profile slightly past the top so the cut is clean
    secs[-1] = (LIP_TOP + 0.3, LIP_CUT - 0.3)
    void = loft_stack(spec.sx, spec.sy, BIN_R, secs, z0=zb)
    return outer - void


def label_geometry(spec, p=PR):
    """Faces of all label items placed in bin coordinates at z = z_label (flat)."""
    hx, hy = interior(spec, p)
    over = LIP_TIP - p.wall
    base0 = hy - over - p.margin - p.cap
    faces = []
    for it in spec.label:
        base = base0 - it.line * p.line_pitch
        if it.kind == "text":
            f = text_face(it.content, p)
        else:
            f = icon_face(it.kind, p)
        faces.append(bd.Pos(it.x, base, 0) * f)
    return faces


def build_bin(spec, p=PR):
    hx, hy = interior(spec, p)
    # feet
    feet = []
    for a in range(spec.nx):
        for b in range(spec.ny):
            cx = (a - (spec.nx - 1) / 2) * PITCH
            cy = (b - (spec.ny - 1) / 2) * PITCH
            feet.append(loft_stack(PITCH - BIN_CLEAR, PITCH - BIN_CLEAR, BIN_R, FOOT_SECTIONS, cx, cy))
    body = bd.Pos(0, 0, FOOT_H) * bd.extrude(bd.RectangleRounded(spec.sx, spec.sy, BIN_R), amount=p.z_body - FOOT_H)
    for ft in feet:
        body = body + ft
    for comp in spec.compartments:
        body = body - pocket_solid(spec, comp, p)
    slab = bd.Pos(0, 0, p.z_label) * bd.extrude(
        bd.RectangleRounded(2 * hx, 2 * hy, BIN_R - p.wall), amount=p.z_body - p.z_label + 6)
    body = body - slab
    body = body + lip_ring(spec, p)
    # label inlay: cut the pocket in the shelf and build the matching inlay solid
    ink = None
    for f in label_geometry(spec, p):
        s = bd.Pos(0, 0, p.z_label - p.inlay) * bd.extrude(f, amount=p.inlay)
        ink = s if ink is None else ink + s
    body = body - ink
    body = body.solids()[0] if len(body.solids()) == 1 else body
    return body, ink


# ----------------------------------------------------------------------------------------------
# Baseplate
# ----------------------------------------------------------------------------------------------
def build_baseplate(nx, ny, p=PR, floor=None):
    fl = p.plate_floor if floor is None else floor
    W, D = nx * PITCH, ny * PITCH
    plate = bd.Pos(W / 2, D / 2, 0) * bd.extrude(bd.RectangleRounded(W, D, PLATE_R), amount=fl + SOCKET_H)
    for i in range(nx):
        for j in range(ny):
            plate = plate - loft_stack(PITCH, PITCH, PLATE_R, SOCKET_SECTIONS,
                                       cx=(i + 0.5) * PITCH, cy=(j + 0.5) * PITCH, z0=fl)
    if fl <= 0:
        plate = plate - bd.Pos(W / 2, D / 2, -1) * bd.Box(W + 2, D + 2, 2)
    return plate


# ----------------------------------------------------------------------------------------------
# Starter assortment (5 x 4 grid).  Rows = thread size (front M2 -> back M4); columns = what.
# ----------------------------------------------------------------------------------------------
def _half_x(p=PR):
    hx = (PITCH - BIN_CLEAR) / 2 - p.wall
    return hx, p.divider / 2


def text_limit(p=PR):
    """Max |x| of label ink: 2 w inside the flat part of the shelf (the lip support rises 1.0 from the
    wall at label height) and therefore also inside the lip opening."""
    hx = (PITCH - BIN_CLEAR) / 2 - p.wall
    return hx - 1.0 - p.margin


def place_pair(left, right, p=PR, gap_min=None):
    """Centre two label items over the two compartments, nudged inward/outward to stay legal."""
    hx, hd = _half_x(p)
    lim = text_limit(p)
    gap_min = 1.0 if gap_min is None else gap_min   # ink >= 0.5 from the divider centreline
    cl, cr = -(hx + hd) / 2, (hx + hd) / 2
    out = []
    for it, c in ((left, cl), (right, cr)):
        w = item_width(it, p)
        x = c
        if abs(x) + w / 2 > lim:
            x = math.copysign(lim - w / 2, c)
        if abs(x) - w / 2 < gap_min / 2:
            x = math.copysign(gap_min / 2 + w / 2, c)
        it.x = x
        out.append(it)
    return out


def split_spec(name, cell, size, a, b, kinds=("screw", "screw"), p=PR):
    hx, hd = _half_x(p)
    comps = [Compartment(-hx, -hd, {}), Compartment(hd, hx, {})]
    if kinds == ("nut", "washer"):
        comps[0].contents = {"kind": "nut", "size": size}
        comps[1].contents = {"kind": "washer", "size": size}
        lim = text_limit(p)
        icw = p.cap * (2 / math.sqrt(3))
        line0 = [LabelItem("nut", "", -(lim - icw / 2), 0), LabelItem("text", size, 0, 0),
                 LabelItem("washer", "", lim - p.cap / 2, 0)]
        line1 = place_pair(LabelItem("text", "NUT", 0, 1), LabelItem("text", "WSHR", 0, 1), p)
        btype, note = "SPLIT-2", f"{size} hex nuts (left) / {size} flat washers (right)"
    else:
        comps[0].contents = {"kind": "screw", "size": size, "length": a}
        comps[1].contents = {"kind": "screw", "size": size, "length": b}
        line0 = [LabelItem("text", size, 0, 0)]
        line1 = place_pair(LabelItem("text", f"×{a}", 0, 1), LabelItem("text", f"×{b}", 0, 1), p)
        btype, note = "SPLIT-2", f"{size}x{a} (left) / {size}x{b} (right) socket-head screws"
    return BinSpec(name, btype, cell, 1, 1, comps, line0 + line1, 2, note=note)


def single_spec(name, cell, size, length, p=PR):
    hx, _ = _half_x(p)
    comps = [Compartment(-hx, hx, {"kind": "screw", "size": size, "length": length})]
    lab = [LabelItem("text", f"{size}×{length}", 0, 0)]
    return BinSpec(name, "SINGLE", cell, 1, 1, comps, lab, 1, note=f"{size}x{length} socket-head screws")


def tray_spec(name, cell, p=PR):
    hx, _ = _half_x(p)
    comps = [Compartment(-hx, hx, {"kind": "sort"})]
    lab = [LabelItem("text", "SORT", 0, 0)]
    return BinSpec(name, "TRAY", cell, 1, 2, comps, lab, 1,
                   note="1x2 unsorted/returns tray: leftovers from a project go here until sorted")


def starter_layout(p=PR):
    S = []
    rows = {0: "M2", 1: "M2.5", 2: "M3", 3: "M4"}
    for j, size in rows.items():
        S.append(split_spec(f"{size}_NUT-WSHR", (0, j), size, None, None, ("nut", "washer"), p))
    for j, size in ((0, "M2"), (1, "M2.5")):
        for i, (a, b) in enumerate(((6, 8), (10, 12), (16, 20)), start=1):
            S.append(split_spec(f"{size}_{a}-{b}", (i, j), size, a, b, p=p))
    for i, (a, b) in enumerate(((6, 8), (10, 12)), start=1):
        S.append(split_spec(f"M3_{a}-{b}", (i, 2), "M3", a, b, p=p))
    S.append(single_spec("M3_16", (3, 2), "M3", 16, p))
    S.append(single_spec("M3_20", (4, 2), "M3", 20, p))
    for i, L in enumerate((8, 10, 12, 16), start=1):
        S.append(single_spec(f"M4_{L}", (i, 3), "M4", L, p))
    S.append(tray_spec("SORT_1x2", (4, 0), p))
    return S


# ----------------------------------------------------------------------------------------------
# Capacity / floor variant selection
# ----------------------------------------------------------------------------------------------
def usable_volume(spec, comp, p=PR):
    """Compartment volume below the divider/label plane (where the contents can sit)."""
    pk = pocket_solid(spec, comp, p)
    hx, hy = interior(spec, p)
    clip = bd.Box(4 * hx, 4 * hy, p.z_label, align=(bd.Align.CENTER, bd.Align.CENTER, bd.Align.MIN))
    return (pk & clip).volume


def demand(comp):
    c = comp.contents
    if c.get("kind") in ("screw", "nut", "washer"):
        return bulk_demand(c["kind"], c["size"], c.get("length"))
    return None


def choose_floor(spec, p=PR, max_fill=0.5):
    """Use the shallow floor when every compartment stays <= max_fill full (conservative heap)."""
    if spec.btype == "TRAY":
        return 0.0
    spec.floor_raise = p.shallow_raise
    ok = all(demand(c) is None or demand(c)[0] <= max_fill * usable_volume(spec, c, p) for c in spec.compartments)
    spec.floor_raise = p.shallow_raise if ok else 0.0
    return spec.floor_raise


def fill_height(spec, comp, vol, p=PR):
    """Heap height (flat-surface approximation) for a given volume, by bisection on the real pocket."""
    pk = pocket_solid(spec, comp, p)
    hx, hy = interior(spec, p)
    lo, hi = floor_z(spec, p), p.z_label
    for _ in range(18):
        mid = (lo + hi) / 2
        v = (pk & bd.Box(4 * hx, 4 * hy, mid, align=(bd.Align.CENTER, bd.Align.CENTER, bd.Align.MIN))).volume
        lo, hi = (mid, hi) if v < vol else (lo, mid)
    return (lo + hi) / 2


# ----------------------------------------------------------------------------------------------
# Export
# ----------------------------------------------------------------------------------------------
def export(shape, stem, step_children=None):
    stl = OUT / "stl" / f"{stem}.stl"
    bd.export_stl(shape, str(stl), tolerance=0.01, angular_tolerance=0.15, ascii_format=False)
    return stl


def bin_transform(spec, p=PR):
    x = (spec.cell[0] + spec.nx / 2) * PITCH
    y = (spec.cell[1] + spec.ny / 2) * PITCH
    return [[1, 0, 0, round(x, 4)], [0, 1, 0, round(y, 4)], [0, 0, 1, p.plate_floor], [0, 0, 0, 1]]


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default=None)
    args = ap.parse_args(argv)
    (OUT / "stl").mkdir(parents=True, exist_ok=True)
    (OUT / "step").mkdir(parents=True, exist_ok=True)
    p = PR
    specs = starter_layout(p)
    if args.only:
        specs = [s for s in specs if s.name == args.only]
    assembly = {"units": "mm", "frame": "baseplate front-left outer corner at origin, +X right, +Y away "
                "from the user (rear), +Z up; bins seated on the plate floor",
                "transform_convention": "4x4 row-major, part-local -> assembly, translation in mm",
                "grid_pitch": PITCH, "parts": []}
    report = {"params": {k: getattr(p, k) for k in p.__dataclass_fields__},
              "derived": {"cap_height": p.cap, "em_font_size": p.em, "line_pitch": p.line_pitch,
                          "z_body": p.z_body, "z_label_and_divider_top": p.z_label,
                          "lip_top": p.z_body + LIP_TOP}, "bins": []}
    if not args.only:
        for nx, ny, nm in ((5, 4, "baseplate_5x4"), (5, 1, "baseplate_5x1_extension")):
            bp = build_baseplate(nx, ny, p)
            bp.label = nm
            export(bp, nm)
            bd.export_step(bp, str(OUT / "step" / f"{nm}.step"))
            if nm == "baseplate_5x4":
                assembly["parts"].append({"name": nm, "role": "baseplate", "stl": f"out/stl/{nm}.stl",
                                          "step": f"out/step/{nm}.step", "color": "#5a5f66",
                                          "transform": [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]})
            else:
                assembly["optional_parts"] = [{"name": nm, "role": "extension baseplate row (not placed)",
                                               "stl": f"out/stl/{nm}.stl", "step": f"out/step/{nm}.step",
                                               "suggested_transform": [[1, 0, 0, 0], [0, 1, 0, 168.0],
                                                                       [0, 0, 1, 0], [0, 0, 0, 1]]}]
            print("built", nm, flush=True)
    for s in specs:
        choose_floor(s, p)
        body, ink = build_bin(s, p)
        body.label, ink.label = f"{s.name}_body", f"{s.name}_label"
        stem = f"bin_{s.name}"
        export(body, stem + "_body")
        export(ink, stem + "_label")
        bd.export_step(bd.Compound(children=[body, ink], label=stem), str(OUT / "step" / f"{stem}.step"))
        T = bin_transform(s, p)
        for part, role, col in ((body, "bin body", "#2b2d31"), (ink, "label inlay (2nd colour)", "#f2f2f2")):
            assembly["parts"].append({"name": part.label, "role": role, "bin": s.name, "type": s.btype,
                                      "cells": [[s.cell[0] + a, s.cell[1] + b] for a in range(s.nx) for b in range(s.ny)],
                                      "stl": f"out/stl/bin_{part.label}.stl", "step": f"out/step/{stem}.step",
                                      "color": col, "transform": T})
        rec = {"name": s.name, "type": s.btype, "cell": s.cell, "size_cells": [s.nx, s.ny], "note": s.note,
               "floor_z": floor_z(s, p), "floor_raise": s.floor_raise,
               "label": [{"kind": it.kind, "text": it.content, "x": round(it.x, 2), "line": it.line} for it in s.label],
               "body_volume_mm3": round(body.volume, 1), "label_volume_mm3": round(ink.volume, 1),
               "compartments": []}
        for c in s.compartments:
            uv = usable_volume(s, c, p)
            d = demand(c)
            cr = {"x0": round(c.x0, 2), "x1": round(c.x1, 2), "contents": c.contents, "usable_mm3": round(uv, 0)}
            if d:
                cr["demand_mm3_conservative"] = round(d[0], 0)
                cr["demand_mm3_typical"] = round(d[1], 0)
                cr["fill_conservative"] = round(d[0] / uv, 3)
                cr["fill_typical"] = round(d[1] / uv, 3)
                zf = fill_height(s, c, d[0], p)
                cr["heap_top_z_conservative"] = round(zf, 2)
                cr["freeboard_to_divider_mm"] = round(p.z_label - zf, 2)
            rec["compartments"].append(cr)
        report["bins"].append(rec)
        print("built", s.name, s.btype, "floor+%.0f" % s.floor_raise, flush=True)
    if not args.only:
        (ROOT / "assembly.json").write_text(json.dumps(assembly, indent=1))
        (OUT / "build_report.json").write_text(json.dumps(report, indent=1))


if __name__ == "__main__":
    main()
