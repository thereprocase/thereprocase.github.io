# Gridfinity fastener organizer

A 42 mm [Gridfinity](https://www.gridfinity.systems/) organizer for hobby machine
fasteners: M2 / M2.5 / M3 / M4 socket-head screws (lengths 6–20 mm), matching plain
hex nuts, and flat washers. One base (a 5×4 grid patch) plus twenty labelled bins,
built as a few reusable bin types. Original geometry; the 42 mm module interface
follows the public Gridfinity spec.

## What fits where (starter assortment, 20 compartments)

Each bin holds a single size. Screws are grouped so a size stays together; nuts and
washers get their own bins. A bin of this size (39.1 mm wide × 16 mm deep open cavity)
comfortably holds ~20 short screws or ~30 nuts/washers in a single open compartment —
no fiddly little holes.

| Row | Contents (left → right) |
|-----|--------------------------|
| 0 (front) | M2×6, M2.5×8, M2.5×10, M3×6, M3×8 |
| 1       | M3×10, M3×12, M3×16, M3×20, M4×8 |
| 2       | M4×10, M4×16, M4×20, nut M3, nut M4 |
| 3 (back) | nut M2, nut M2.5, washer M2.5, washer M3, washer M4 |

Three blank templates (`template_screw/nut/washer`) are exported unlabelled so you can
drop in a size that isn't in the starter set (e.g. M5, or an M3×14) by re-running the
generator with that entry in `ASSORTMENT`.

## The interface (all dimensions in mm)

Standard 42 mm module. Each bin drops a funnel **foot** into a matching base **pocket**,
held by a positive fit with 0.25 mm radial clearance — the bin lifts straight out and
can't tilt out sideways.

| | foot | pocket | clearance/side |
|---|---|---|---|
| base of foot (z 0.00) | 35.6 | 36.1 | 0.25 |
| grip shoulder (z 0.80–2.60) | 37.2 | 37.7 | 0.25 |
| foot top, seats at base top (z 4.75) | 41.5 | 42.0 | 0.25 |

- Base: 5×4 = 210 × 168 × 6.25 (1.5 mm floor + 4.75 mm pockets). Four M3 corner holes.
- Bin: 41.5 × 41.5 footprint, 1.2 mm walls, 39.1 × 39.1 × 16 open cavity (finger-accessible).
- Bin sits with the foot bottom on the base floor; its rim is 20.75 mm above the foot
  bottom (26.0 mm above the base floor once seated).

## Files

| Path | Contents |
|---|---|
| `src/gridfinity_fasteners.py` | Parametric build (build123d). The single source of truth. |
| `src/validate_meshes.py` | trimesh sanity checks on the exported STLs. |
| `out/*.step`, `out/*.stl` | STEP + binary STL per part (base, 20 bins, 3 templates). |
| `out/assembly.json` | Part files + assembled transforms in mm (base at origin, each bin centred in its cell, foot bottom at the base floor, no rotation). |
| `out/checks.txt` | Measured checks (interface clearance, seated overlap, dimensions, label caps). |
| `assets/fillaprint/Fillaprint-Regular.ttf` | The label font (SIL OFL 1.1). |

## Regenerate

```sh
python  -I src/gridfinity_fasteners.py   # geometry -> out/
python    -I src/validate_meshes.py         # STL sanity
```

## How to use it

- **Seat a bin:** drop it into its pocket. The 0.25 mm clearance lets it seat cleanly
  and resist being knocked sideways; a straight pull lifts it out.
- **Finger access:** the open 39 mm cavity and 16 mm depth reach straight in — you can
  pull a single washer or short screw from a full bin without dumping it.
- **Lift to a project:** take one bin (or the whole base) off the tray. The foot keeps
  each bin upright in its pocket, so moving one bin does not spill the neighbours.
- **Read the size:** every bin has a raised two-line FillaPrint label on the front face —
  thread size on top, length (screws) or `NUT` / `WAS` below — so the nut vs washer and
  the length are obvious at a glance. Capital height is 6.0 mm (thread) / 5.88 mm
  (secondary), both at or above the font's minimum (14 w = 5.88 mm, w = 0.42 mm).

## Verification (measured)

- Foot/pocket radial clearance is 0.25 mm at every section; a seated bin overlaps the
  base by **0.0000 mm³** (boolean intersection).
- All 24 exported meshes are watertight (trimesh).
- Labeled bin is a single bonded solid; the relief protrudes 0.4 mm (kept under the
  0.5 mm module gap so it never hits the bin in the row in front) and sits within the
  20.75 mm wall height.

## Limitations (stated plainly)

- **Bins do not stack on one another.** The full-cell foot flares to the module width
  (41.5 mm) at its top, which is wider than the 39.1 mm cavity, so a plain open cavity
  cannot nest a second bin (measured interference 14.17 mm³). Real Gridfinity bins use a
  contoured **top lip** for this; it is not modelled here, so bins are single-level and
  the **base is the stackable/extension unit** — add more 42 mm patches to grow the
  organizer.
- **Back-row labels read at an angle.** All labels face the front of the base. The front
  row is directly visible; rows 2–4 are readable by looking down at the tray from the
  front (the rows are 42 mm apart), not straight-on.
- **Label relief is 0.4 mm** — enough to read by sight and stay permanent, but shallow
  (it must fit the 0.5 mm gap between adjacent bins).
- **Not physically fit-tested.** These are CAD checks (clearance, watertightness,
  boolean overlap). Printing behaviour — seat feel, any residual print swelling against
  the 0.25 mm clearance, label legibility at 0.4 mm relief — still needs a physical
  fit test on your printer.
