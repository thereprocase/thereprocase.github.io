#!/usr/bin/env python3
"""Validate the exported binary STLs with trimesh (printability sanity checks).

Run:
    python -I src/validate_meshes.py

For every out/*.stl: watertightness, enclosed volume, extents, and the per-part
bounding box. Reports the base and a representative bin so the Gridfinity
footprint (41.5 mm) and the seated height can be cross-checked against the
STEP source.
"""
from pathlib import Path

import trimesh

OUT = Path(__file__).resolve().parent.parent / "out"


def load(p: Path):
    m = trimesh.load(str(p))
    if isinstance(m, trimesh.Scene):
        m = trimesh.concatenate(tuple(m.geometry.values()))
    return m


def main():
    rows = []
    for p in sorted(OUT.glob("*.stl")):
        m = load(p)
        rows.append((p.stem, m.is_watertight, m.volume, m.extents))

    print(f"{'part':24} {'watertight':>10} {'volume_mm3':>12}  extents_mm")
    for name, wat, vol, ext in rows:
        print(f"{name:24} {str(wat):>10} {vol:12.1f}  "
              f"{ext[0]:6.2f} x {ext[1]:6.2f} x {ext[2]:6.2f}")

    all_wat = all(r[1] for r in rows)
    base = next(r for r in rows if r[0] == "base_5x4")
    print(f"\n{len(rows)} parts; all watertight: {all_wat}")
    print(f"base_5x4 footprint: {base[3][0]:.2f} x {base[3][1]:.2f} x {base[3][2]:.2f} "
          f"(expect 210 x 168 x 6.25)")
    binrow = next(r for r in rows if r[0] == "screw_M3_10")
    print(f"bin footprint: {binrow[3][0]:.2f} x {binrow[3][1]:.2f} x {binrow[3][2]:.2f} "
          f"(expect 41.5 x 41.5 x 20.75)")


if __name__ == "__main__":
    main()
