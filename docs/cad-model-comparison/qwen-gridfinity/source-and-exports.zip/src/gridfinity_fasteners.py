#!/usr/bin/env python3
"""Parametric Gridfinity organizer for hobby fasteners (screws / hex nuts / washers).

Everything is built in millimetres with build123d and exported as STEP + binary STL.
The interface is the standard 42 mm Gridfinity module: each bin drops a funnel
"foot" into a matching base pocket, held by a positive fit (0.25 mm radial
clearance).  Bins are open-topped (finger accessible) and sit single-level in
the base; the base extends by tiling further 42 mm patches.

Run:
    python -I src/gridfinity_fasteners.py
Reads the font from assets/fillaprint/Fillaprint-Regular.ttf and writes exports to
out/ (STEP + binary STL per part, assembly.json, checks.txt).

Original geometry; the 42 mm interface dimensions follow the public Gridfinity
spec (see README references).
"""

import json
import math
import os

from build123d import (
    Axis,
    BuildPart,
    BuildSketch,
    Circle,
    Rectangle,
    TextAlign,
    Text,
    extrude,
    fillet,
    loft,
    Part,
)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "out")
FONT = os.path.join(ROOT, "assets", "fillaprint", "Fillaprint-Regular.ttf")


# ----------------------------------------------------------------------------
# Gridfinity interface (42 mm module)  --  all values in mm
# ----------------------------------------------------------------------------
GRID = 42.0                 # module pitch
FLOOR = 1.5                 # solid base floor under the pockets
PKT = 4.75                  # pocket / foot depth (standard)
BASE_H = FLOOR + PKT        # 6.25 total base height
CLR = 0.25                  # radial clearance between foot and pocket

# Foot cross-sections: (z_local, width, corner_radius); z=0 at the foot bottom.
FOOT = [
    (0.00, 35.6, 0.8),
    (0.80, 37.2, 1.6),      # grip shoulder
    (2.60, 37.2, 1.6),
    (4.75, 41.5, 3.75),     # foot top (seats at the base top)
]
# Pocket = foot enlarged by 2*CLR (0.5 mm) per dimension, with an over-cut top so
# the opening is clean through the base surface.
POCKET = [(z, w + 2 * CLR, r + CLR) for z, w, r in FOOT] + [(PKT + 0.5, 42.5, 4.5)]

# Bin dimensions
WALL = 1.2
DEPTH = 16.0                # interior depth (floor -> rim)
BIN_TOP = PKT + DEPTH       # 20.75, bin top in bin-local z (foot bottom at 0)
OUTER = GRID - 0.5          # 41.5 bin outer footprint
OUT_R = 3.75
INNER = OUTER - 2 * WALL    # 39.1 interior
IN_R = OUT_R - WALL         # 2.55

# Labels (FillaPrint).  cap = 0.70 * font_size  (measured).
# Font minimum capital height = 14 * w, w = 0.42 mm  ->  5.88 mm.
CAP_MIN = 5.88
CAP_THREAD = 6.0            # >= CAP_MIN
CAP_SEC = 5.88              # == CAP_MIN
LIFT = 0.4                  # visible relief; kept under the 0.5 mm module gap
EMBED = 0.2                 # label is sunk this far into the wall so it bonds


def _fs(cap):
    return cap / 0.70


# ----------------------------------------------------------------------------
# Primitive helpers
# ----------------------------------------------------------------------------
def rr(w, r, z=0.0):
    """Rounded-rectangle sketch of side `w`, corner radius `r`, at height z."""
    with BuildSketch() as s:
        Rectangle(w, w)
        fillet(s.vertices(), r)
    return s.sketch.translate((0, 0, z))


def loft_sq(secs, cx=0.0, cy=0.0):
    """Loft through (z, w, r) square sections -> solid, centred at (cx, cy)."""
    solid = loft(sections=[rr(w, r, z) for z, w, r in secs])
    return solid.translate((cx, cy, 0.0))


def foot_solid(cx=0.0, cy=0.0):
    return loft_sq(FOOT, cx, cy)


def pocket_solid(cx, cy):
    """Base pocket (a cut tool), centred at the cell centre (cx, cy)."""
    return loft_sq(POCKET, cx, cy).translate((0, 0, FLOOR))


# ----------------------------------------------------------------------------
# Base
# ----------------------------------------------------------------------------
def cell_centers(n_col, n_row):
    return [(c * GRID + GRID / 2.0, r * GRID + GRID / 2.0)
            for c in range(n_col) for r in range(n_row)]


def build_base(n_col=5, n_row=4):
    L = n_col * GRID
    W = n_row * GRID
    with BuildPart() as p:
        with BuildSketch() as s:
            Rectangle(L, W)
            fillet(s.vertices(), 4.0)
        extrude(amount=BASE_H)
    base = p.part
    # pockets (cut)
    for cx, cy in cell_centers(n_col, n_row):
        base = base - pocket_solid(cx, cy)
    # corner mounting holes (M3 clearance) through the four corners
    for sx, sy in [(-1, -1), (1, -1), (-1, 1), (1, 1)]:
        hx = sx * (L / 2.0 - 6.0)
        hy = sy * (W / 2.0 - 6.0)
        hole = Part(extrude(_circle(3.2), amount=BASE_H + 2)).translate((hx, hy, -1.0))
        base = base - hole
    return base


def _circle(r):
    with BuildSketch() as s:
        Circle(r)
    return s.sketch


# ----------------------------------------------------------------------------
# Bin
# ----------------------------------------------------------------------------
def bin_shell():
    """Open-topped 1x1 Gridfinity bin (foot + walls + floor). Local z=0 foot bottom."""
    foot = foot_solid()
    walls = extrude(rr(OUTER, OUT_R, PKT), amount=DEPTH)
    cav = extrude(rr(INNER, IN_R, PKT), amount=DEPTH + 2.0)
    return foot + walls - cav


def _line_label(txt, cap, cx=0.0):
    """A single text line as a thin relief solid, standing in XZ and facing -Y.
    Returns (part, width_mm, cap_mm). The relief is centred on the local origin in
    the two in-plane axes (X, Z) so callers can place it by its centre; the relief
    thickness runs in -Y with its embedded back face at y=0.
    """
    fs = _fs(cap)
    with BuildSketch() as s:
        Text(txt, font_size=fs, font_path=FONT,
             text_align=(TextAlign.CENTER, TextAlign.CENTER))
    lab = extrude(s.sketch, amount=LIFT + EMBED)
    # measure width / cap from the sketch
    bb = s.sketch.bounding_box()
    width = bb.max.X - bb.min.X
    capp = bb.max.Y - bb.min.Y
    # rotate so the relief faces -Y and reads upright: (x,y,z)->(x,-z,y). The font's
    # vertical centring is offset from the glyph bbox, so recenter on the solid's own
    # bounding box in the in-plane axes (X, Z); the -Y thickness is left to placement.
    lab = lab.rotate(Axis((0, 0, 0), (1, 0, 0)), 90)
    b2 = lab.bounding_box()
    cx_off = (b2.min.X + b2.max.X) / 2.0
    cz_off = (b2.min.Z + b2.max.Z) / 2.0
    lab = lab.translate((-cx_off, 0.0, -cz_off))
    lab = lab.translate((cx, 0.0, 0.0))
    return lab, width, capp


def apply_label(body, thread, second, kind):
    """Add two raised FillaPrint lines on the front face (y = -OUTER/2)."""
    face_y = -OUTER / 2.0
    # vertical placement: secondary below, thread above, block centred in the wall
    wall_lo, wall_hi = PKT, BIN_TOP
    gap = 1.6
    block = CAP_THREAD + gap + CAP_SEC
    mid = (wall_lo + wall_hi) / 2.0
    c_thread = mid + block / 2.0 - CAP_THREAD / 2.0
    c_sec = mid - block / 2.0 + CAP_SEC / 2.0
    # each line is centred (bbox centred on local origin); translate to target centre
    l1, w1, ch1 = _line_label(thread, CAP_THREAD)
    l2, w2, ch2 = _line_label(second, CAP_SEC)
    # the line is centred on its bbox centre in local z; place at c_*, sunk
    # EMBED into the wall so the relief bonds to the bin (visible depth = LIFT)
    l1 = l1.translate((0, face_y + EMBED, c_thread))
    l2 = l2.translate((0, face_y + EMBED, c_sec))
    body = body + l1 + l2
    return body, w1, ch1, w2, ch2


# ----------------------------------------------------------------------------
# Assortment (starter layout for the 5x4 base)
# ----------------------------------------------------------------------------
# (kind, thread, length, col, row)  col 0..4 (x), row 0..3 (y, front=0)
ASSORTMENT = [
    # row 0 (front): short screws
    ("screw", "M2",   6,  0, 0),
    ("screw", "M2.5", 8,  1, 0),
    ("screw", "M2.5", 10, 2, 0),
    ("screw", "M3",   6,  3, 0),
    ("screw", "M3",   8,  4, 0),
    # row 1: more screws
    ("screw", "M3",   10, 0, 1),
    ("screw", "M3",   12, 1, 1),
    ("screw", "M3",   16, 2, 1),
    ("screw", "M3",   20, 3, 1),
    ("screw", "M4",   8,  4, 1),
    # row 2: long screws + start of nuts
    ("screw", "M4",   10, 0, 2),
    ("screw", "M4",   16, 1, 2),
    ("screw", "M4",   20, 2, 2),
    ("nut",   "M3",   None, 3, 2),
    ("nut",   "M4",   None, 4, 2),
    # row 3 (back): nuts + washers
    ("nut",    "M2",   None, 0, 3),
    ("nut",    "M2.5", None, 1, 3),
    ("washer", "M2.5", None, 2, 3),
    ("washer", "M3",   None, 3, 3),
    ("washer", "M4",   None, 4, 3),
]


def label_parts(kind, thread, length):
    second = str(length) if kind == "screw" else ("NUT" if kind == "nut" else "WAS")
    return thread, second


def slug(kind, thread, length):
    return f"{kind}_{thread}_{(length if length else kind)}"


def make_bin(kind, thread, length):
    body = bin_shell()
    th, sec = label_parts(kind, thread, length)
    body, w1, ch1, w2, ch2 = apply_label(body, th, sec, kind)
    return body, dict(thread_w=w1, thread_cap=ch1, sec_w=w2, sec_cap=ch2)


# ----------------------------------------------------------------------------
# Checks
# ----------------------------------------------------------------------------
def run_checks():
    rep = []
    # 1) foot clears pocket (radial) - compare widths at each section
    rep.append("Interface widths (foot / pocket, radial clearance should be 0.25):")
    for (z, wf, rf), (zp, wp, rp) in zip(FOOT, POCKET[: len(FOOT)]):
        rep.append(f"  z={z:5.2f}  foot={wf:5.2f}  pocket={wp:5.2f}  gap/side={ (wp-wf)/2.0:.3f}")

    # 2) interference test: seat a bin foot into a pocket (no boolean overlap)
    base = build_base(5, 4)
    cx, cy = cell_centers(5, 4)[0]
    seated = foot_solid().translate((cx, cy, FLOOR))
    inter = base & seated
    rep.append(f"Foot/pocket overlap volume when seated (expect ~0): {inter.volume:.4f} mm^3")

    # 3) bin internal dimensions
    b = bin_shell()
    bb = b.bounding_box()
    rep.append(f"Bin outer: {bb.max.X-bb.min.X:.2f} x {bb.max.Y-bb.min.Y:.2f}, "
               f"top z={bb.max.Z:.2f} (foot bottom z=0)")
    rep.append(f"Interior: {INNER:.2f} x {INNER:.2f} x {DEPTH:.2f}  (finger-accessible open top)")

    # 4) label cap heights >= font minimum
    th, sec = label_parts("screw", "M3", 10)
    _, _, ch1, _, ch2 = _dummy_caps()
    rep.append(f"Label caps: thread={CAP_THREAD:.2f} mm, secondary={CAP_SEC:.2f} mm, "
               f"font minimum={CAP_MIN:.2f} mm  (both >= min: "
               f"{CAP_THREAD>=CAP_MIN and CAP_SEC>=CAP_MIN})")

    # 5) stacking: a second bin nested into the open cavity of a first bin.
    # The full-cell foot flares to 41.5 mm at its top, wider than the 39.1 mm
    # cavity, so a plain open cavity cannot nest a second bin. The standard
    # Gridfinity top lip provides bin-on-bin stacking and is not modelled here,
    # so bins are single-level and the base is the stackable/extension unit.
    lower = bin_shell()
    upper = foot_solid().translate((0, 0, PKT))
    clash = lower & upper
    rep.append(f"Bin-on-bin nest (foot into open cavity) overlap: {clash.volume:.4f} mm^3 "
               f"(>0 => bins are single-level; the base, not the bins, stacks/extends)")

    # 6) front label relief: protrudes from the face and stays one bonded solid
    labbin, _ = make_bin("screw", "M3", 10)
    lbb = labbin.bounding_box()
    face = -OUTER / 2.0
    protr = face - lbb.min.Y
    rep.append(f"Front label relief: bin min.y={lbb.min.Y:.3f} (face {face:.3f}), "
               f"protrusion={protr:.3f} mm (want ~{LIFT}); solids={len(labbin.solids())} (want 1)")

    return "\n".join(rep)


def _dummy_caps():
    l1, w1, ch1 = _line_label("M3", CAP_THREAD)
    l2, w2, ch2 = _line_label("10", CAP_SEC)
    return (w1, ch1, w2, ch2, 0)


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
def main():
    os.makedirs(OUT, exist_ok=True)

    # base
    base = build_base(5, 4)
    export(base, "base_5x4")

    # bins
    parts = [{"name": "base_5x4", "file": "base_5x4.stl", "step": "base_5x4.step",
              "kind": "base", "x": 0.0, "y": 0.0, "z": 0.0, "col": None, "row": None}]
    report = []
    for (kind, thread, length, col, row) in ASSORTMENT:
        body, meta = make_bin(kind, thread, length)
        nm = slug(kind, thread, length)
        export(body, nm)
        # seated transform: cell centre, foot bottom at the base floor (z=FLOOR)
        parts.append({
            "name": nm, "file": nm + ".stl", "step": nm + ".step",
            "kind": kind, "thread": thread, "length_mm": length,
            "col": col, "row": row,
            "x": col * GRID + GRID / 2.0,
            "y": row * GRID + GRID / 2.0,
            "z": FLOOR,
            "rotation_deg": [0, 0, 0],
            "label": {"line1": thread, "line2":
                      (str(length) if kind == "screw" else ("NUT" if kind == "nut" else "WAS")),
                      "cap1_mm": round(CAP_THREAD, 2), "cap2_mm": round(CAP_SEC, 2)},
            "metrics": {k: round(v, 3) for k, v in meta.items()},
        })
        report.append(f"{nm}: thread-w={meta['thread_w']:.2f} thread-cap={meta['thread_cap']:.2f} "
                      f"sec-w={meta['sec_w']:.2f} sec-cap={meta['sec_cap']:.2f}")

    # templates (blank, unlabeled) for future sizes
    for kind in ("screw", "nut", "washer"):
        b = bin_shell()
        export(b, f"template_{kind}")

    with open(os.path.join(OUT, "assembly.json"), "w") as f:
        json.dump({
            "units": "mm",
            "grid_pitch_mm": GRID,
            "base": {"cols": 5, "rows": 4, "size_mm": [5 * GRID, 4 * GRID, BASE_H]},
            "note": "Bin local frame: x/y centred on the cell, z=0 at the foot bottom. "
                    "Seated bins sit with the foot bottom at z=FLOOR inside the base floor.",
            "parts": parts,
        }, f, indent=1)

    checks = run_checks()
    with open(os.path.join(OUT, "checks.txt"), "w") as f:
        f.write(checks + "\n\n" + "Label metrics:\n" + "\n".join(report) + "\n")
    print(checks)
    print("\nLabel metrics:")
    print("\n".join(report))
    print(f"\nWrote {len(parts)+3} parts (+3 templates) to {OUT}")


def export(part, name):
    from build123d import export_step as _es, export_stl as _estl
    _es(part, os.path.join(OUT, name + ".step"))
    _estl(part, os.path.join(OUT, name + ".stl"))


if __name__ == "__main__":
    main()
