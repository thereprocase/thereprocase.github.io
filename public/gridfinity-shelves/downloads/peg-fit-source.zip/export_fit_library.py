from pathlib import Path
import sys,json,hashlib
sys.path.append('/app/freecad/lib')
import FreeCAD as A,Part,MeshPart
R=Path(__file__).parent;SNAP=R/'bench/source/gallery_current_mounts_v1/station_snapshot';sys.path.insert(0,str(SNAP/'source/solder_v12'));import common as K
V=A.Vector;FACE=.15

def region(z0,z1):return Part.makeBox(100,60+FACE,z1-z0,V(-50,-60,z0))
def component(receiver,upper):
 s=receiver.common(region(-10,15) if upper else region(-40,-10))
 if not upper:s.translate(V(0,0,25.4))
 s=s.fuse(Part.makeCylinder((6.72 if upper else 7.62)/2,2,V(0,FACE,.12),V(0,1,0))).removeSplitter()
 assert s.isValid() and len(s.Solids)==1
 return s

def meshed(shape):
 mesh=MeshPart.meshFromShape(Shape=shape,LinearDeflection=.005,AngularDeflection=.087,Relative=False)
 pts,tri=mesh.Topology
 return {'vertices':[[p.x,p.y,p.z] for p in pts],'triangles':[list(t) for t in tri]}
def key(v):return f'{v:.2f}'
def savepart(shape,name):
 path=R/'native';path.mkdir(exist_ok=True);shape.exportStep(str(path/(name+'.step')))
 reread=Part.read(str(path/(name+'.step')));delta=shape.cut(reread).Volume+reread.cut(shape).Volume;assert delta<1e-5
 return {'volume':shape.Volume,'roundtripDifference':delta}

original_ribs=K.G.side_ribs
full,info=K.receiver(1,1,'upright')
nominal={name:component(full,top) for name,top in [('upper',True),('lower',False)]}
reference={name:meshed(s) for name,s in nominal.items()}
# The browser adds the two simple crush-rib prisms, so preserve the analytic cores separately.
K.G.side_ribs=lambda *a,**kw:([],0)
lib={'schema':1,'face':FACE,'pitch':25.4,'upper':{},'lower':{},'reference':reference,'native_checks':{},'rib':{'baseX':2.2,'rootHalf':1.6,'crestHalf':.4,'leadStartX':2.5,'upperDiametral':.5,'lowerDiametral':.3,'lowerRearY':FACE-K.G.BOARD+.2}}
for n in range(-4,5):
 delta=n*.05;K.TOP['clamp_mm']=round(.49+delta,4);s,_=K.receiver(1,1,'upright');upper=component(s,True)
 fitpath=K.G.fit_file(K.TOP['clamp_mm']);_,fitinfo=K.P._build(fitpath.read_bytes());rear=max(fitinfo['elbow_center_y_mm'],FACE-K.G.BOARD)+.3
 lib['upper'][key(delta)]={**meshed(upper),'ribRearY':rear,'clamp':K.TOP['clamp_mm']}
 lib['native_checks']['upper'+key(delta)]=savepart(upper,'upper-core-'+key(delta))
 print('upper',key(delta),'PASS',flush=True)
K.TOP['clamp_mm']=.49
for n in range(-3,5):
 delta=n*.05;K.HOOP['arm_mm']=round(.8+delta,4);s,_=K.receiver(1,1,'upright');lower=component(s,False)
 lib['lower'][key(delta)]={**meshed(lower),'arm':K.HOOP['arm_mm']}
 lib['native_checks']['lower'+key(delta)]=savepart(lower,'lower-core-'+key(delta))
 print('lower',key(delta),'PASS',flush=True)
K.HOOP['arm_mm']=.8
lib['source_hashes']={str(p.relative_to(SNAP)):hashlib.sha256(p.read_bytes()).hexdigest() for p in SNAP.rglob('*') if p.is_file() and p.suffix in ['.py','.scad','.step'] and 'reviews' not in p.parts}
(R/'fit-inputs.json').write_text(json.dumps(lib,separators=(',',':'))+'\n')
print('Library exported',flush=True)
