# Gridfinity shelf and peg-fit source

Run `bench/source/gridfinity_generator_v1/generate.py output --config recipe.json`
in FreeCAD Python to create STEP, FCStd and STL files. Add `--coupon` for the
small hook-and-hoop pair. Recipes downloaded from the browser include all three
fit settings. Without a recipe the original zero-adjustment fit is used.

`peg_clearance`: per-side crush-rib clearance, -0.15 to +0.15 mm.
`hook_grip`: added upper-hook clamp, -0.20 to +0.20 mm.
`hoop_firmness`: added lower-hoop wall thickness, -0.15 to +0.20 mm.
All three use 0.05 mm steps. Hole pitch remains 25.4 mm.

The frozen peg construction comes from thereprocase/peg's PF02 #9 / PF07 #5
source. Changes apply only during the selected generation call. The canonical
reference files remain unchanged.

Run `export_fit_library.py` in FreeCAD Python to rebuild the browser peg library and its native STEP checks.
