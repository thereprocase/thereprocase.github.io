"""Generate P02 watertight printable STL, editable STEP and viewer meshes."""
from pathlib import Path
import json
import cadquery as cq
import trimesh
import numpy as np
import design as d

OUT=Path('output'); OUT.mkdir(exist_ok=True)

def annulus(outer, inner, z, height):
    return cq.Workplane('XY').workplane(offset=z).circle(outer).circle(inner).extrude(height)

def build():
    base=annulus(d.BASE_R,d.RIM_IN,0,d.SEAT_Z)
    base=base.union(annulus(d.BASE_R,d.RIM_OUT+.25,d.SEAT_Z,3))
    base=base.union(cq.Workplane('XY').circle(10).extrude(d.STOP_Z))
    for angle in (30,150,270):
        spoke=cq.Workplane('XY').center(20,0).rect(30,5).extrude(2)
        base=base.union(spoke.rotate((0,0,0),(0,0,1),angle))
    cradle=cq.Workplane('XY').circle(d.CUP_R).extrude(d.CUP_H)
    sphere=cq.Workplane('XY').sphere(d.BALL_D/2+d.BALL_CLEARANCE).translate((0,0,d.CUP_FLOOR+d.BALL_D/2+d.BALL_CLEARANCE))
    cradle=cradle.cut(sphere)
    cradle=cradle.union(annulus(d.RIM_OUT,d.RIM_IN,0,d.RIB_H))
    for i in range(6):
        rib=cq.Workplane('XY').polyline(d.outline(i).tolist()).close().extrude(d.RIB_H)
        cradle=cradle.union(rib)
    return base,cradle

def main():
    base,cradle=build()
    stats={}
    for name,part in [('base',base),('cradle',cradle)]:
        assert part.val().isValid(), name
        assert len(part.solids().vals())==1, name
        cq.exporters.export(part,str(OUT/f'{name}.step'))
        cq.exporters.export(part,str(OUT/f'{name}.stl'),tolerance=.04,angularTolerance=.08)
        mesh=trimesh.load_mesh(OUT/f'{name}.stl')
        # OCCT can emit zero-area triangles at the spherical pole.
        mesh.update_faces(mesh.nondegenerate_faces())
        mesh.update_faces(mesh.unique_faces())
        mesh.remove_unreferenced_vertices()
        mesh.export(OUT/f'{name}.stl')
        assert mesh.is_watertight and mesh.is_winding_consistent and mesh.volume>0, name
        assert len(mesh.split())==1, name
        assert abs(mesh.bounds[0,2])<1e-5
        stats[name]=dict(bounds_mm=mesh.bounds.tolist(),volume_mm3=float(mesh.volume),
                         triangles=len(mesh.faces),watertight=bool(mesh.is_watertight),
                         mass_g_at_1_22=float(mesh.volume*.00122))
        mesh.export(OUT/f'{name}.glb')
    installed=cradle.translate((0,0,d.SEAT_Z))
    assert base.intersect(installed).val().Volume()<1e-6
    # Analytical contact clearance is checked separately; no undeformed collision.
    assembly=cq.Assembly(name='P02_squash_ball_foot')
    assembly.add(base,name='base',color=cq.Color(.32,.37,.43))
    assembly.add(installed,name='cradle',color=cq.Color(.0,.62,.68))
    assembly.export(str(OUT/'assembly.step'))
    stats['assembly']=dict(diameter_mm=d.BASE_R*2,height_mm=d.SEAT_Z+d.CUP_H,
        cup_depth_mm=d.BALL_D/3,unloaded_stop_gap_mm=d.SEAT_Z-d.STOP_Z,
        ball_bottom_above_table_mm=d.SEAT_Z+d.CUP_FLOOR,
        seat_z_mm=d.SEAT_Z,rib_height_mm=d.RIB_H,ball_diameter_mm=d.BALL_D,
        ball_center_z_mm=d.SEAT_Z+d.CUP_FLOOR+d.BALL_D/2,
        radial_socket_clearance_mm=.25)
    (OUT/'geometry.json').write_text(json.dumps(stats,indent=2))
    print(json.dumps(stats,indent=2))

if __name__=='__main__': main()
