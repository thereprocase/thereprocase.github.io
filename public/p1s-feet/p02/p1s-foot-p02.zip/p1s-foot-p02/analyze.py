"""Linear curved-beam estimate: vertical translation + two bending/twist rotations.

Timoshenko bending and Saint-Venant rectangular torsion, isotropic TPU.
Rigid cup/rim, six clamped curved ribs. No ball, contact, creep, hyperelasticity
or layer anisotropy. Units N, mm, MPa. This is NOT a solid-element FEA.
"""
import json
from pathlib import Path
import numpy as np
import design as d

def rib_stiffness(points, width, height, E, nu=.49):
    n = len(points)
    K = np.zeros((3*n, 3*n))
    G = E/(2*(1+nu))
    A, I = width*height, width*height**3/12
    a,b = max(width,height), min(width,height)
    J = a*b**3*(1/3-.21*b/a*(1-b**4/(12*a**4)))
    elements=[]
    for i,(p,q) in enumerate(zip(points[:-1],points[1:])):
        L = np.linalg.norm(q-p)
        tx,ty = (q-p)/L
        # local coordinates [w, rotation about tangent, rotation about normal]
        R=np.array([[1,0,0],[0,tx,ty],[0,-ty,tx]])
        T=np.zeros((6,6)); T[:3,:3]=R; T[3:,3:]=R
        phi=12*E*I/((5/6)*G*A*L**2)
        B=E*I/(L**3*(1+phi))*np.array([
            [12,-6*L,-12,-6*L],
            [-6*L,(4+phi)*L**2,6*L,(2-phi)*L**2],
            [-12,6*L,12,6*L],
            [-6*L,(2-phi)*L**2,6*L,(4+phi)*L**2]])
        k=np.zeros((6,6)); ids=[0,2,3,5]; k[np.ix_(ids,ids)]=B
        k[np.ix_([1,4],[1,4])]=G*J/L*np.array([[1,-1],[-1,1]])
        ix=np.arange(3*i,3*i+6)
        K[np.ix_(ix,ix)]+=T.T@k@T
        elements.append((ix,T,k))
    u=np.zeros(3*n); u[0]=1
    free=np.arange(3,3*n-3)
    u[free]=np.linalg.solve(K[np.ix_(free,free)],-K[free,0])
    reaction=K@u
    # Nominal bending strain, excludes fillet concentrations and torsional strain.
    max_strain=0
    max_twist=0
    for ix,T,k in elements:
        force=k@T@u[ix]
        max_strain=max(max_strain, max(abs(force[2]),abs(force[5]))*height/(2*E*I))
        max_twist=max(max_twist,abs(force[1]))
    return dict(k=float(reaction[0]),length=float(np.linalg.norm(np.diff(points,axis=0),axis=1).sum()),
                bending_strain_per_mm=float(max_strain), torque_per_mm=float(max_twist),
                equilibrium_error=float(abs(reaction[0]+reaction[-3])))

def solve(segments=80,height=d.RIB_H,E=d.E_REF):
    ribs=[rib_stiffness(d.centerline(i,segments),d.RIB_W,height,E,d.NU) for i in range(6)]
    return sum(x['k'] for x in ribs),ribs

def main():
    # Exact straight fixed-guided Timoshenko reference verifies signs and shear.
    L,b,h,E=30.,4.,6.,9.8
    result=rib_stiffness(np.column_stack((np.linspace(0,L,30),np.zeros(30))),b,h,E)
    I=b*h**3/12; G=E/(2*1.49)
    exact=1/(L**3/(12*E*I)+L/((5/6)*G*b*h))
    assert abs(result['k']/exact-1)<1e-8
    k,ribs=solve()
    refined,_=solve(160)
    assert abs(refined/k-1)<.005
    assert max(r['equilibrium_error'] for r in ribs)<1e-7
    cases=[]
    for mass in (12.95,20.):
        for modulus in (5.,7.4,9.8,15.,26.):
            for imbalance in (1.,1.3):
                force=mass*9.80665/4*imbalance
                stiffness=k*modulus/d.E_REF
                sag=force/stiffness
                # Whole printer on four identical foot springs; excludes squash balls.
                frequency=(4*stiffness*1000/mass)**.5/(2*np.pi)
                cases.append(dict(mass_kg=mass,E_MPa=modulus,load_factor=imbalance,
                    force_N=force,stiffness_N_mm=stiffness,sag_mm=sag,
                    stop_clearance_mm=d.SEAT_Z-d.STOP_Z-sag,
                    clearance_at_1_5_sag_mm=d.SEAT_Z-d.STOP_Z-1.5*sag,
                    foot_only_frequency_Hz=frequency,
                    nominal_max_bending_strain=sag*max(r['bending_strain_per_mm'] for r in ribs)))
    report=dict(revision='P02',method=__doc__,rib_width_mm=d.RIB_W,rib_height_mm=d.RIB_H,
                E_reference_MPa=d.E_REF,k_reference_N_mm=k,ribs=ribs,cases=cases,
                convergence_relative=abs(refined/k-1),straight_beam_reference_error=abs(result['k']/exact-1),
                unloaded_stop_gap_mm=d.SEAT_Z-d.STOP_Z)
    Path('analysis.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))

if __name__=='__main__': main()
