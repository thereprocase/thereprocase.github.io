"""Shared dimensions, mm. Revision P02: two support-free TPU parts."""
import numpy as np

BALL_D = 40.0
BALL_CLEARANCE = 0.25  # radial
CUP_R = 21.5
CUP_FLOOR = 2.0
CUP_H = CUP_FLOOR + BALL_D / 3
RIM_IN = 34.5
RIM_OUT = 38.0
BASE_R = 40.0
SEAT_Z = 17.0
STOP_Z = 5.0
RIB_W = 4.0
RIB_H = 8.8
SWEEPS = [20.0, 20.0, 20.0]
E_REF = 9.8
NU = 0.49

def centerline(index, segments=40):
    t = np.linspace(0, 1, segments + 1)
    r = CUP_R + (RIM_IN - CUP_R) * t
    a = np.deg2rad(index * 60 + SWEEPS[index % 3] * (3*t*t - 2*t*t*t))
    return np.column_stack((r*np.cos(a), r*np.sin(a)))

def outline(index, segments=60):
    p = centerline(index, segments)
    # Extend into cup and outer rim; FE clamps at their nominal boundaries.
    p = np.vstack((p[0] - 1.5*(p[1]-p[0])/np.linalg.norm(p[1]-p[0]), p,
                   p[-1] + 1.5*(p[-1]-p[-2])/np.linalg.norm(p[-1]-p[-2])))
    tangent = np.gradient(p, axis=0)
    tangent /= np.linalg.norm(tangent, axis=1)[:, None]
    normal = np.column_stack((-tangent[:,1], tangent[:,0]))
    return np.vstack((p + RIB_W/2*normal, (p - RIB_W/2*normal)[::-1]))
