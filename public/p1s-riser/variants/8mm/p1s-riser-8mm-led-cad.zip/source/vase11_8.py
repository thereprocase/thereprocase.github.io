"""Exact back-surface vase blank with shallow scissor witness grooves."""
from pathlib import Path
from build123d import *
import math,numpy as np,json
R=Path(__file__).parent;D=R/'draft-11-8mm'
path=[]
for x in np.linspace(33.6,0,16):path.append((x,-16,0,1,math.radians(25)*min(1,x/32)))
for deg in np.linspace(-90,-180,49)[1:]:
 a=math.radians(deg);path.append((16*math.cos(a),16*math.sin(a),-math.cos(a),-math.sin(a),0))
for y in np.linspace(0,33.6,16)[1:]:path.append((-16,y,1,0,math.radians(25)*min(1,y/32)))
def wire(z,inset=0):
 pts=[]
 for i,(x,y,nx,ny,a) in enumerate(path):
  if i==0:x-=inset
  if i==len(path)-1:y-=inset
  # Match the assembly back surface k=3.2 exactly; z offset is 12 mm.
  q=(z-6+math.sin(a)*3.2)/math.cos(a)
  groove=max(max(0,1-abs(q-edge)/.3) for edge in [-4.7,5.6])*.15
  v=(3.2+inset+groove)/math.cos(a)+(z-6)*math.tan(a)
  pts.append((x+nx*v-.07,y+ny*v-.07,z))
 for i,(x,y,nx,ny,a) in reversed(list(enumerate(path))):
  if i==0:x-=inset
  if i==len(path)-1:y-=inset
  v=(11.5-inset)/math.cos(a)+(z-6)*math.tan(a)
  pts.append((x+nx*v-.07,y+ny*v-.07,z))
 return Wire.make_polygon(pts,close=True)
zs=np.linspace(0,12.4,63)
blank=Solid.make_loft([wire(z) for z in zs],ruled=True)
assert blank.is_valid and len(blank.solids())==1
name='vase-corner-diffuser'
export_step(blank,D/'parts'/(name+'.step'));export_stl(blank,D/'parts'/(name+'.stl'),tolerance=.06)
v,t=blank.tessellate(.06,.1);np.savez_compressed(D/'meshes'/(name+'.npz'),v=np.array([tuple(p) for p in v]),t=np.array(t))
# Preview is an ideal horizontal 0.6 mm wall, matching vase extrusion convention.
inner=Solid.make_loft([wire(z,.6) for z in zs],ruled=True)
shell=blank-inner
v,t=shell.tessellate(.06,.1);np.savez_compressed(D/'meshes/vase-corner-shell-preview.npz',v=np.array([tuple(p) for p in v]),t=np.array(t))
checks=[dict(z=float(z),closed_wires=len(section(blank,section_by=Plane.XY.offset(z)).wires())) for z in [.1,1,3,5,7,9,10.9]]
(D/'corner-vase-checks.json').write_text(json.dumps(dict(height_mm=12.4,wall_width_mm=.6,normal_thickness_mm=[.6*math.cos(math.radians(25)),.6],trim='Shallow 0.15 mm witness grooves at the two finished edges; snip returns, then trim along grooves. Physical trimming trial still needed.',sections=checks),indent=2))
print('vase corner ready',flush=True)
