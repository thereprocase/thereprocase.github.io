from pathlib import Path
from build123d import *
import json,numpy as np,math,concurrent.futures,multiprocessing
from twist_lock import turn,AXIS_Q
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
R=Path(__file__).parent;D=R/'draft-11-10mm-tall'
def init():
 global frames,diffs,m,peg
 frames=[import_step(D/'parts'/(n+'.step')) for n in ['front','right','back','left','front-left','front-right','rear-right','rear-left']]
 diffs={f.stem.removeprefix('diffuser-'):import_step(f) for f in (D/'parts').glob('diffuser-*.step') if not f.stem.endswith('-flat')}
 m=json.loads((D/'retention.json').read_text());peg=import_step(D/'parts/retaining-peg.step')
def nearby(a,b):
 aa=a.bounding_box();bb=b.bounding_box();return all(tuple(aa.min)[i]<tuple(bb.max)[i]+.001 and tuple(aa.max)[i]>tuple(bb.min)[i]-.001 for i in range(3))
def overlap(a,obs):return sum(abs(Compound(BRepAlgoAPI_Common(a.wrapped,b.wrapped).Shape()).volume) for b in obs if nearby(a,b))
def check_diff(name):
 s=diffs[name];n=m['insertion_vectors'][name];corner=not name.endswith(('-a','-b'))
 obs=frames+[v for k,v in diffs.items() if k!=name and (not corner or not k.endswith(('-a','-b')))]
 path=[(4,.5),(2,.5),(1,.3),(.5,.3),(.3,.3),(.2,.1),(.2,0),(0,0)] if not corner else [(4,.5),(2,.5),(1,.5),(.5,.5),(.3,.5),(.2,.3),(.2,.1),(.2,0),(.1,0),(0,0)]
 samples=[tuple(a+(b-a)*t for a,b in zip(path[i],path[i+1])) for i in range(len(path)-1) for t in [0,.25,.5,.75]]+[path[-1]]
 rows=[dict(inward_mm=x,lift_mm=z,overlap_mm3=overlap(Pos(n[0]*x,n[1]*x,z)*s,obs)) for x,z in samples]
 return dict(name=name,positions=rows)
def check_peg(rec):
 pl=Plane(origin=rec['origin'],x_dir=(*rec['tangent'],0),z_dir=rec['normal']);rows=[]
 for a,w in [(a,0) for a in range(0,91,15)]+[(90,4),(90,8)]:
  s=pl.location*(Pos(0,0,w)*turn(peg,a));rows.append(dict(angle=a,withdrawal=w,frame_overlap_mm3=overlap(s,frames),diffuser_overlap_mm3=overlap(s,list(diffs.values()))))
 return dict(name=rec['name'],states=rows,locked_withdrawal_interference_mm3=overlap(pl.location*(Pos(0,0,.8)*peg),frames))

# Generate the same actual CAD section used by the detail viewer.
init();rec=m['pegs'][0];pl=Plane(origin=rec['origin'],x_dir=(*rec['tangent'],0),z_dir=rec['normal']);clip=Pos(rec['origin'][0],-178,9)*Box(7,32,24,align=(Align.MIN,)*3)
shapes={'retention-frame':Compound(children=[s&clip for s in frames if getattr(s&clip,'volume',0)>1e-5]),'retention-diffuser':diffs['front-a']&clip,'retention-peg':(pl.location*peg)&clip}
for n,s in shapes.items():
 v,t=s.tessellate(.05,.1);np.savez_compressed(D/'meshes'/(n+'.npz'),v=np.array([tuple(p) for p in v]),t=np.array(t))
print('validation complete',flush=True)