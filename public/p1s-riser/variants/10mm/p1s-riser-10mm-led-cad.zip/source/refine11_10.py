from build123d import *
from pathlib import Path
import numpy as np,json
R=Path(__file__).parent;D=R/'draft-11-10mm'
def mesh(n,s):
 v,t=s.tessellate(.12,.15);np.savez_compressed(D/'meshes'/(n+'.npz'),v=np.array([tuple(p) for p in v]),t=np.array(t))
for n in ['front','right','back','left','front-left','front-right','rear-right','rear-left']:
 s=import_step(D/'parts'/(n+'.step'))
 cut=s & (Pos(0,0,-1)*Box(500,500,19,align=(Align.CENTER,Align.CENTER,Align.MIN)))
 mesh('light-cut-'+n,cut)
# Vase blanks are solid mandrel geometry: slicer spiralizes the perimeter.
# The two long faces are harvested after printing by cutting the round returns.
for name,L in [('front-back',125.85),('sides',109.85),('coupon',45)]:
 # Nominal 0.45 mm bead: physical straight harvested length is near the straight span.
 sk=SlotOverall(L+10,10)
 s=extrude(sk,amount=12.3)
 export_step(s,D/'parts'/('vase-diffuser-'+name+'.step'))
 export_stl(s,D/'parts'/('vase-diffuser-'+name+'.stl'))
 mesh('vase-diffuser-'+name,s)
 # Illustrated resulting sleeve, shell inset approximates one extrusion width.
 sleeve=s-extrude(SlotOverall(L+8.8,8.8),amount=16)
 mesh('vase-sleeve-'+name,sleeve)

print('light cuts and straight previews ready')
