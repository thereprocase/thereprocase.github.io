from pathlib import Path
from build123d import *
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
import json
from twist_lock import turn
D=Path(__file__).parent/'draft-11-10mm';names=['front','back','left','right','front-left','front-right','rear-left','rear-right'];fs=[import_step(D/'parts'/(n+'.step')) for n in names];p=import_step(D/'parts/retaining-peg.step');rows=[]
def overlap(q):
 b=q.bounding_box();out=0
 for s in fs:
  a=s.bounding_box()
  if all(tuple(a.min)[i]<tuple(b.max)[i] and tuple(a.max)[i]>tuple(b.min)[i] for i in range(3)):out+=abs(Compound(BRepAlgoAPI_Common(s.wrapped,q.wrapped).Shape()).volume)
 return out
for r in json.loads((D/'retention.json').read_text())['pegs']:
 pl=Plane(origin=r['origin'],x_dir=(*r['tangent'],0),z_dir=r['normal']);locked=overlap(pl.location*(Pos(0,0,3)*p));unlocked=overlap(pl.location*(Pos(0,0,3)*turn(p,90)));rows.append(dict(name=r['name'],locked_3mm_withdrawal_overlap_mm3=locked,unlocked_3mm_overlap_mm3=unlocked));print(r['name'],locked,unlocked,flush=True)
(D/'lock-checks.json').write_text(json.dumps(dict(note='Retention check at 3 mm withdrawal; existing axial free play is not a clamp-force test.',pegs=rows),indent=2));assert all(r['locked_3mm_withdrawal_overlap_mm3']>0 and r['unlocked_3mm_overlap_mm3']<1e-5 for r in rows)
