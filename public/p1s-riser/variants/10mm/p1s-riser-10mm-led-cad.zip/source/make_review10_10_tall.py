from pathlib import Path
import json,subprocess,shutil,zipfile,os
R=Path(__file__).parent;D=R/'draft-11-10mm-tall';W=R/'site-dfm11-10mm';W.mkdir(exist_ok=True)
S=Path('/home/repro/.codex/skills/render');py='/home/repro/venvs/kraken-cad/bin/python'
rot=[[1,0,0,0],[0,0,-1,0],[0,1,0,0],[0,0,0,1]]
names=['front','right','back','left','front-left','front-right','rear-right','rear-left']
def part(n,c=(.36,.64,.69),shift=(0,0,0),alpha=1):
 m=[r[:] for r in rot];m[0][3]=shift[0];m[1][3]=-shift[2];m[2][3]=shift[1]
 return dict(mesh=str(D/'meshes'/(n+'.npz')),color=c,transform=m,alpha=alpha)
white=(.94,.93,.86);orange=(.98,.63,.28)
diffs=['diffuser-'+s+'-'+a for s in ['front','right','back','left'] for a in ['a','b']]+['diffuser-'+n for n in ['front-right','rear-right','rear-left','front-left']]
pegnames=['retaining-peg-'+str(i) for i in range(1,25)]
scenes={
'assembly':dict(title='P1S USB light riser',subtitle='Draft 11 · 10 mm LED · eight-piece CA assembly',caption='Teal: frame and diffuser rails · ivory: removable diffusers · orange: removable pegs and rear cable plug',parts=[part(n) for n in names]+[part(n,white) for n in diffs]+[part('rear-cable-plug',orange)]+[part(n,orange) for n in pegnames],camera=dict(yaw=-.9,pitch=.8,zoom=.9)),
'lighting':dict(title='Continuous light route',subtitle='Frame cut away at Z20 mm · LED tape shown gold',caption='The tape twists upright through each rounded corner. Rear start/end gap sits beside the cable exit.',parts=[part('light-cut-'+n) for n in names]+[part('led-route',(1,.82,.3))],camera=dict(yaw=-.9,pitch=.8,zoom=.9)),
'exploded':dict(title='Frame and removable inserts',subtitle='Parts separated for assembly review',caption='Frame pieces move outward; diffusers are lifted 38 mm. These are display positions.',parts=[],camera=dict(yaw=-.9,pitch=.9,zoom=.9)),
'section':dict(title='Riser section',subtitle='Front-right quadrant removed from a CAD display copy',caption='The cut reveals the solid lower frame, narrow diffuser rails and glass support. Original part geometry is unchanged.',parts=[part('section-'+n) for n in names if (D/'meshes'/('section-'+n+'.npz')).exists()],camera=dict(yaw=.85,pitch=.55,zoom=.85)),
}
scenes['vase']=dict(title='Vase-printed diffuser blanks',subtitle='Left: twisted corner sleeve · right: straight coupon',caption='Ideal 0.6 mm horizontal walls shown. Corner trim grooves mark the finished edges. All vase blanks have been sliced.',parts=[part('vase-corner-shell-preview',white),part('vase-sleeve-coupon',orange,(75,0,0))],camera=dict(yaw=-.85,pitch=.7,zoom=.85))
scenes['retention']=dict(title='Quarter-turn diffuser keeper',subtitle='Section through the locked keeper and diffuser seat',caption='Ivory: taller diffuser against the sloped roof seat, held by the raised cam. Gold LED tape sits behind it; the upper edge overlaps the sloped roof seat.',parts=[part('retention-frame'),part('retention-led',(1,.82,.3)),part('retention-peg',orange),part('retention-diffuser',white)],camera=dict(yaw=.7,pitch=.45,zoom=.85))
scenes['section']['parts'] += [part('section-led-route',(1,.82,.3))]+[part('section-'+n,orange) for n in pegnames if (D/'meshes'/('section-'+n+'.npz')).exists()]+[part('section-'+n,white,alpha=.32) for n in diffs if (D/'meshes'/('section-'+n+'.npz')).exists()]
scenes['section']['caption']='Real quarter cutaway: teal frame, gold LED strip, orange keepers, translucent ivory diffusers. Frame prints upright as installed.'
for n in names:
 x=-24 if 'left' in n else 24 if 'right' in n else 0;y=-24 if 'front' in n else 24 if ('rear' in n or n=='back') else 0
 scenes['exploded']['parts'].append(part(n,shift=(x,y,0)))
scenes['exploded']['parts'] += [part(n,white,(0,0,38)) for n in diffs]+[part('rear-cable-plug',orange,(0,35,0))]
scenes['clearance']=dict(title='Reserved LED clearance',subtitle='Gold volumes are CAD checkers, not printed parts',caption='Continuous 10.2 mm wide clearance envelope, including twist transitions and rounded corners. Teal frame shown transparent.',parts=[part(n,alpha=.18) for n in names]+[part('led-clearance-negative',(1,.82,.3),alpha=.85)],camera=dict(yaw=-1.05,pitch=.87,zoom=.8))
for n,scene in scenes.items():
 if os.environ.get("ONLY_VIEW") and n!=os.environ["ONLY_VIEW"]:continue
 f=D/'review'/(n+'.json');f.write_text(json.dumps(scene,indent=2))
 subprocess.run([py,str(S/'scripts/prepare.py'),str(f),str(W/n)],check=True)
 packed=W/n/'scene.json';ps=json.loads(packed.read_text())
 for a,b in zip(ps['parts'],scene['parts']):a['alpha']=b.get('alpha',1)
 packed.write_text(json.dumps(ps,indent=2))
 # Smaller text in embedded/mobile views; keep rendering/shader recipe intact.
 h=W/n/'index.html';txt=h.read_text().replace('cam.dist*.0022','cam.dist*.0004').replace('</style>','@media(max-width:800px){header{top:14px;left:16px;right:16px}h1{font-size:22px}p{font-size:13px}footer{left:16px;right:16px;bottom:12px;font-size:12px}}</style>');txt=txt.replace('start().catch', (R/'orbit.js').read_text()+'\nstart().catch');txt=txt.replace('for(const m of models){','for(const m of models){ const translucent=(m.info.alpha??1)<1;if(translucent){gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);}')
 txt=txt.replace('gl.enable(gl.CULL_FACE);gl.cullFace(gl.FRONT);','if(!translucent){gl.enable(gl.CULL_FACE);gl.cullFace(gl.FRONT);').replace('gl.disable(gl.CULL_FACE);bind(celProg,m);','} gl.disable(gl.CULL_FACE);bind(celProg,m);').replace('gl.uniform1f(U(celProg,"alpha"),1);','gl.uniform1f(U(celProg,"alpha"),m.info.alpha??1);').replace('gl.drawElements(gl.LINES,m.nEdge,gl.UNSIGNED_INT,0);','gl.drawElements(gl.LINES,m.nEdge,gl.UNSIGNED_INT,0);gl.depthMask(true);gl.disable(gl.BLEND);')
 h.write_text(txt)
 subprocess.run(['node',str(S/'scripts/capture.mjs'),str(W/n),str(W/(n+'.png'))],check=True)
shutil.copy(D/'assembly.step',W/'p1s-riser-10mm-led-assembly.step');shutil.copy(D/'checks.json',W/'checks.json');shutil.copy(R/'overlap09.py',W/'build_draft.py');shutil.copy(R/'REFERENCE-ATTRIBUTION.txt',W/'REFERENCE-ATTRIBUTION.txt')
with zipfile.ZipFile(W/'p1s-riser-10mm-led-cad.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in (D/'parts').iterdir():z.write(f,'parts/'+f.name)
 for f in [R/'overlap09.py',R/'corner_vase.py',R/'refine_review.py',R/'REFERENCE-ATTRIBUTION.txt',D/'checks.json',D/'vase-diffuser-notes.txt',D/'corner-vase-checks.json']:z.write(f,f.name)
print('review assets ready')
