from pathlib import Path
from build123d import *
import numpy as np,json
R=Path(__file__).parent;D=R/'draft-11-12mm-tall'
def mesh(n,s):
 v,t=s.tessellate(.12,.15);np.savez_compressed(D/'meshes'/(n+'.npz'),v=np.array([tuple(a) for a in v]),t=np.array(t))
cut=Pos(0,-210,-1)*Box(210,210,40,align=(Align.MIN,Align.MIN,Align.MIN))
for f in (D/'meshes').glob('section-*.npz'):f.unlink()
names=['front','right','back','left','front-left','front-right','rear-right','rear-left'];frames={n:import_step(D/'parts'/(n+'.step')) for n in names};checks=[]
shapes=dict(frames)
shapes.update({f.stem:import_step(f) for f in (D/'parts').glob('diffuser-*.step') if not f.stem.endswith('-flat')})
shapes['rear-cable-plug']=import_step(D/'parts/rear-cable-plug.step')
for n,s in shapes.items():
 checks.append(dict(name=n,valid=s.is_valid,solids=len(s.solids()),volume_mm3=s.volume,bbox_mm=list(s.bounding_box().size)))
 sh=s-cut
 if getattr(sh,'volume',0)>1e-5:mesh('section-'+n,sh)
peg=import_step(D/'parts/retaining-peg.step')
assembled=list(shapes.values())
for rec in json.loads((D/'retention.json').read_text())['pegs']:
 t=rec['tangent'];pl=Plane(origin=rec['origin'],x_dir=(t[0],t[1],0),z_dir=rec['normal']);assembled.append(pl.location*peg);sh=pl.location*peg-cut
 if getattr(sh,'volume',0)>1e-5:mesh('section-'+rec['name'],sh)
f=np.load(D/'meshes/led-route.npz');vs=f['v'];ts=f['t'];led=[]
for i in range(0,len(ts),8):
 ids=sorted(set(int(j) for tri in ts[i:i+8] for j in tri))
 if len(ids)!=8:continue
 s=Solid.make_loft([Wire.make_polygon([tuple(vs[j]) for j in ids[:4]],close=True),Wire.make_polygon([tuple(vs[j]) for j in ids[4:]],close=True)],ruled=True)
 led.append(s)
mesh('section-led-route',Compound(children=led)-cut)
collisions=[]
for i,a in enumerate(names):
 for b in names[i+1:]:
  vol=getattr(frames[a]&frames[b],'volume',0)
  if vol>1e-4:collisions.append(dict(a=a,b=b,overlap_mm3=vol))
report=dict(parts=checks,frame_overlap=collisions,min_z=min(s.bounding_box().min.Z for s in frames.values()),basis='384 x 352 glass, R24 rear; 17.5 mm seat band',stage='Draft 11: 12 mm strip, 30-degree lower rail supports and matching diffusers',pending=['Physical keeper and trimmed diffuser fit','Support removal and printed PETG fit','Strip thickness, minimum bend radius, cut marks and connector fit'])
(D/'checks.json').write_text(json.dumps(report,indent=2));print('Final CAD checks and actual cutaways ready',flush=True)

export_step(Compound(children=assembled),D/'assembly.step')
