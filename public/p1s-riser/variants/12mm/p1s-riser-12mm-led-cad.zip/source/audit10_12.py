from pathlib import Path
from build123d import *
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
import json,numpy as np
D=Path(__file__).parent/'draft-11-12mm'
def vol(a,b):
 op=BRepAlgoAPI_Common(a.wrapped,b.wrapped);return abs(Compound(op.Shape()).volume)
def nearby(a,b):
 return all(a[0][i]<b[1][i] and a[1][i]>b[0][i] for i in range(3))
def bounds(s):
 b=s.bounding_box();return tuple(b.min),tuple(b.max)
names=['front','right','back','left','front-left','front-right','rear-right','rear-left','rear-cable-plug']
obs={n:import_step(D/'parts'/(n+'.step')) for n in names}
obs.update({f.stem:import_step(f) for f in (D/'parts').glob('diffuser-*.step') if not f.stem.endswith('-flat')})
p=import_step(D/'parts/retaining-peg.step')
for r in json.loads((D/'retention.json').read_text())['pegs']:
 obs[r['name']]=Plane(origin=r['origin'],x_dir=(*r['tangent'],0),z_dir=r['normal']).location*p
bs={n:bounds(s) for n,s in obs.items()};hits=[];total=0
f=np.load(D/'meshes/led-route.npz');vs=f['v'];ts=f['t']
for i in range(0,len(ts),8):
 ids=sorted(set(int(j) for tri in ts[i:i+8] for j in tri))
 if len(ids)!=8:continue
 s=Solid.make_loft([Wire.make_polygon([tuple(vs[j]) for j in ids[:4]],close=True),Wire.make_polygon([tuple(vs[j]) for j in ids[4:]],close=True)],ruled=True);b=bounds(s);total+=1
 for n,o in obs.items():
  if nearby(b,bs[n]):
   v=vol(s,o)
   if v>1e-5:hits.append(dict(segment=i//8,part=n,overlap_mm3=v))
 if total%50==0:print(total,'segments',len(hits),'collisions',flush=True)
(D/'led-route-audit.json').write_text(json.dumps(dict(route_segments=total,checked_parts=list(obs),intersections=hits,nominal_tape_width_mm=12,nominal_tape_thickness_mm=.8),indent=2))
print('DONE',total,len(hits),flush=True)
assert not hits
