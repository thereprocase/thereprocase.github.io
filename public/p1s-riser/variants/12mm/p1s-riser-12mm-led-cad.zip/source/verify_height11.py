from pathlib import Path
from build123d import *
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
import json,sys,numpy as np
from twist_lock import turn
R=Path(__file__).parent;w=int(sys.argv[1]);dz=w-8;D=R/f'draft-11-{w}mm-tall';B=R/f'draft-11-{w}mm'
# The complete pre-height motion check must finish before reuse.
# Source motion reports are copied again at publication after the source run finishes.
for name in ['retention-checks.json','lock-checks.json','led-route-audit.json']:
 data=json.loads((B/name).read_text());data['height_transform_note']=f'Optical assembly translated rigidly +{dz} mm; added base stays below all moving parts. See height-checks.json.';(D/name).write_text(json.dumps(data,indent=2))
frames={n:import_step(D/'parts'/(n+'.step')) for n in ['front','right','back','left','front-left','front-right','rear-right','rear-left']}
obs=dict(frames);obs['rear-cable-plug']=import_step(D/'parts/rear-cable-plug.step');obs.update({f.stem:import_step(f) for f in (D/'parts').glob('diffuser-*.step') if not f.stem.endswith('-flat')})
peg=import_step(D/'parts/retaining-peg.step')
for r in json.loads((D/'retention.json').read_text())['pegs']:obs[r['name']]=Plane(origin=r['origin'],x_dir=(*r['tangent'],0),z_dir=r['normal']).location*peg
rotated=[]
for r in json.loads((D/'retention.json').read_text())['pegs']:
 pl=Plane(origin=r['origin'],x_dir=(*r['tangent'],0),z_dir=r['normal'])
 rotated.extend((pl.location*turn(peg,a)).bounding_box().min.Z for a in range(0,91,5))
moving_min=min(min(rotated),min(s.bounding_box().min.Z for n,s in obs.items() if n.startswith(('diffuser-','retaining-peg-'))));assert moving_min>dz+.03
for n,s in frames.items():
 c=s&(Pos(0,0,-1)*Box(500,500,19+dz,align=(Align.CENTER,Align.CENTER,Align.MIN)));v,t=c.tessellate(.12,.15);np.savez_compressed(D/'meshes'/('light-cut-'+n+'.npz'),v=np.array([tuple(p) for p in v]),t=np.array(t))
def nearby(a,b):
 aa=a.bounding_box();bb=b.bounding_box();return all(tuple(aa.min)[i]<tuple(bb.max)[i] and tuple(aa.max)[i]>tuple(bb.min)[i] for i in range(3))
results={}
for file in ['led-clearance-negative','rear-cable-passage-negative','corner-entry-relief-negative']:
 tools=list(import_step(D/'clearance'/(file+'.step')).solids());hits=[]
 for n,s in obs.items():
  if file.startswith('corner-entry') and n not in frames:continue
  if file.startswith('rear') and (n=='rear-cable-plug' or n.startswith('diffuser-')):continue
  volume=sum(abs(Compound(BRepAlgoAPI_Common(s.wrapped,c.wrapped).Shape()).volume) for c in tools if nearby(s,c))
  if volume>1e-5:hits.append(dict(part=n,overlap_mm3=volume))
 results[file]=hits
 print(w,file,'intersections',len(hits),flush=True)
 assert not hits,hits
# Bounds prove the floor extension cannot intersect the lifted/inward diffuser
# paths or keeper rotations/withdrawals (all are well above the new base).
(D/'height-checks.json').write_text(json.dumps(dict(translation_mm=dz,base_extension_max_z_mm=dz+.03,lowest_installed_moving_part_z_mm=moving_min,negative_intersections=results),indent=2))
print(w,'height checks pass',flush=True)
