"""Quarter-turn keeper in local coordinates X=along strip, Y=-strip height, Z=outward.
Frame prints in world Z, not this local coordinate system.
"""
from build123d import *
AXIS_Q=8.0

def box(x,y,z,dx,dy,dz):return Pos(x,y,z)*Box(dx,dy,dz,align=(Align.MIN,Align.MIN,Align.MIN))
def lb(u,q,k,du,dq,dk):return box(u,-q-dq,k,du,dq,dk)
def turn(s,degrees):return Pos(0,-AXIS_Q,0)*Rot(Z=degrees)*Pos(0,AXIS_Q,0)*s

def components():
 stem=Pos(0,-AXIS_Q,-2)*Cylinder(1.6,4.8,align=(Align.CENTER,Align.CENTER,Align.MIN))
 lug=lb(-1.4,4.8,-1.6,2.8,2,1.4)
 shoulder=Pos(0,-AXIS_Q,2.8)*Cylinder(2,1.25,align=(Align.CENTER,Align.CENTER,Align.MIN))
 handle=lb(-2,3.7,4.05,4,5.8,1.2)
 handle=fillet(handle.edges().filter_by(Axis.Z),.5)
 peg=(stem+lug+shoulder+handle)&box(-1.4,-20,-5,2.8,30,15)
 boss=lb(-4,4.2,-5,8,8.3,7.8)
 # Open upper/back well: no hidden annular ceiling to support or clean out.
 well=lb(-3.6,4.2,-3.8,7.2,20,4.0)
 # Central peaked bore plus one side key entry, both have peaked roofs.
 def opening(points):
  w=Wire.make_polygon([(x,-AXIS_Q-q,.1) for x,q in points],close=True)
  return Solid.extrude(Face(w),(0,0,2.9))
 bore=opening([(-1.8,-.7),(-1.4,-1.4),(0,-1.9),(1.4,-1.4),(1.8,-.7),(1.8,.7),(1.4,1.4),(0,3.1),(-1.4,1.4),(-1.8,.7)])
 key=opening([(-3.4,-1.6),(-1.2,-1.6),(-1.2,1.6),(-2.3,2.9),(-3.4,1.6)])
 stop=lb(1.5,4.2,-1.8,2.1,1.8,2.0)
 void=well+bore+key
 socket=(boss-void)+stop
 return peg,boss,void,stop,socket

if __name__=='__main__':
 import json
 peg,boss,void,stop,socket=components()
 rows=[]
 for a in [0,15,30,45,60,75,90]:
  s=turn(peg,a);rows.append(dict(angle=a,collision=getattr(s&socket,'volume',0)))
 travel=[]
 for k in [0,.4,.8,2,4,7]:travel.append(dict(outward=k,collision=getattr((Pos(0,0,k)*turn(peg,90))&socket,'volume',0)))
 report=dict(valid=peg.is_valid and socket.is_valid,solids=[len(peg.solids()),len(socket.solids())],rotation=rows,unlocked_withdrawal=travel,locked_withdrawal_collision=getattr((Pos(0,0,.8)*peg)&socket,'volume',0),stop_collision=getattr(turn(peg,-10)&socket,'volume',0),centre_of_mass=list(peg.center(CenterOf.MASS)))
 print(json.dumps(report,indent=2))
