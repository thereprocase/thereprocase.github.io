from pathlib import Path
from build123d import *
import numpy as np,json,subprocess
R=Path(__file__).parent;D=R/'draft-11-12mm-tall';W=R/'site-dfm11-12mm';S=Path('/home/repro/.codex/skills/render');py='/home/repro/venvs/kraken-cad/bin/python'
def outline(w,d,r):
 x=w/2;y=d/2
 return Face(Wire([Edge.make_line((-x,-y),(x,-y)),Edge.make_line((x,-y),(x,y-r)),Edge.make_circle(r,Plane(origin=(x-r,y-r,0)),0,90),Edge.make_line((x-r,y),(-x+r,y)),Edge.make_circle(r,Plane(origin=(-x+r,y-r,0)),90,180),Edge.make_line((-x,y-r),(-x,-y))]))
def prism(w,d,r,z,h):return Pos(0,0,z)*extrude(outline(w,d,r),amount=h)
def mesh(n,s):
 v,t=s.tessellate(.12,.15);np.savez_compressed(D/'meshes'/(n+'.npz'),v=np.array([tuple(p) for p in v]),t=np.array(t))
# Reference envelope only: cropped upper body and seat, not detailed P1S CAD.
body=prism(394,362,29,-80,80)-prism(349,317,6.5,-81,82)
glass=prism(384,352,24,34,3)
border=glass-prism(349,317,6.5,33,5)
clear=glass&prism(349,317,6.5,33,5)
cut=Pos(0,-210,-81)*Box(210,210,140,align=(Align.MIN,Align.MIN,Align.MIN))
for n,s in [('mock-body',body),('mock-glass-border',border),('mock-glass-clear',clear)]:
 mesh(n,s);mesh(n+'-section',s-cut)
rot=[[1,0,0,0],[0,0,-1,0],[0,1,0,0],[0,0,0,1]]
def part(n,c,alpha=1):return dict(mesh=str(D/'meshes'/(n+'.npz')),color=c,transform=rot,alpha=alpha)
names=['front','right','back','left','front-left','front-right','rear-right','rear-left']
teal=[.36,.64,.69];dark=[.25,.28,.29]
for mode in ['installed','installed-section']:
 section=mode.endswith('section');suffix='-section' if section else ''
 parts=[part('mock-body'+suffix,dark)]+[part(('section-' if section else '')+n,teal) for n in names if (D/'meshes'/((('section-' if section else '')+n)+'.npz')).exists()]+[part('mock-glass-border'+suffix,[.12,.14,.15]),part('mock-glass-clear'+suffix,[.68,.86,.91],.22)]
 if not section:
  accessories=[part(f.stem,[.94,.93,.86]) for f in sorted((D/'meshes').glob('diffuser-*.npz')) if not f.stem.endswith('-flat')]+[part('retaining-peg-'+str(i),[.98,.63,.28]) for i in range(1,25)]
  parts=parts[:-1]+accessories+parts[-1:]
 if section:
  parts=parts[:-1]+[part('section-led-route',[1,.82,.3])]+[part(f.stem,[.98,.63,.28]) for f in sorted((D/'meshes').glob('section-retaining-peg-*.npz'))]+[part(f.stem,[.94,.93,.86],.32) for f in sorted((D/'meshes').glob('section-diffuser-*.npz'))]+parts[-1:]
 scene=dict(title='Glass and printer reference' if not section else 'Glass seat and diffuser rails',subtitle='Simplified upper printer body · glass thickness assumed 3 mm',caption='Teal: riser · ivory: diffuser · orange: keepers · gold: LED behind diffuser · blue: glass at Z30.',parts=parts,camera=dict(yaw=.85 if section else -.9,pitch=.55 if section else .8,zoom=.9))
 f=D/'review'/(mode+'.json');f.write_text(json.dumps(scene,indent=2));out=W/mode
 subprocess.run([py,str(S/'scripts/prepare.py'),str(f),str(out)],check=True)
 p=out/'scene.json';ss=json.loads(p.read_text())
 for a,b in zip(ss['parts'],parts):a['alpha']=b['alpha']
 p.write_text(json.dumps(ss,indent=2))
 p=out/'index.html';h=p.read_text().replace('cam.dist*.0022','cam.dist*.0004')
 # Opaque geometry first, glass last; transparent reference does not write depth.
 h=h.replace('for(const m of models){','for(const m of models){\n const translucent=(m.info.alpha??1)<1; if(translucent){gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);}')
 h=h.replace('gl.enable(gl.CULL_FACE);gl.cullFace(gl.FRONT);','if(!translucent){gl.enable(gl.CULL_FACE);gl.cullFace(gl.FRONT);').replace('gl.disable(gl.CULL_FACE);bind(celProg,m);','}\n gl.disable(gl.CULL_FACE);bind(celProg,m);').replace('gl.uniform1f(U(celProg,"alpha"),1);','gl.uniform1f(U(celProg,"alpha"),m.info.alpha??1);')
 h=h.replace('gl.drawElements(gl.LINES,m.nEdge,gl.UNSIGNED_INT,0);','gl.drawElements(gl.LINES,m.nEdge,gl.UNSIGNED_INT,0);gl.depthMask(true);gl.disable(gl.BLEND);')
 h=h.replace('start().catch',(R/'orbit.js').read_text()+'\nstart().catch')
 p.write_text(h);subprocess.run(['node',str(S/'scripts/capture.mjs'),str(out),str(W/(mode+'.png'))],check=True)
(W/'reference-mocks.json').write_text(json.dumps({'glass_mm':[384,352,3],'glass_thickness':'3 mm assumed for visualization','glass_underside_z':34,'diffuser_shade_lip_projection_mm':1.0,'retainer_top_z':36.5,'body':'Simplified cropped upper enclosure, 394 x 362 x 80 mm; not measured printer geometry','purpose':'Seat/height reference only; not an interference certification'},indent=2))
print('reference views ready')
