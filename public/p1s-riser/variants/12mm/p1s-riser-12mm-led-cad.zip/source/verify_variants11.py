from pathlib import Path
import sys,subprocess,os,json
R=Path(__file__).parent;w=int(sys.argv[1]);py='/home/repro/venvs/kraken-cad/bin/python';env=dict(os.environ,OPENBLAS_NUM_THREADS='1');steps=[]
for base in ['negative10','audit10','validate10','lock10','finalize10','detail_led10']:
 with (R/f'{base}-11-{w}.log').open('w') as log:subprocess.run([py,str(R/f'{base}_{w}.py')],stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
 steps.append(base);(R/f'verify11-{w}.json').write_text(json.dumps(steps));print(w,base,'pass',flush=True)
