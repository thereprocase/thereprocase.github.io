let drag=null;const pointers=new Map();let pinch=0;let pan=false;let midpoint=null;
cv.addEventListener('contextmenu',e=>e.preventDefault());
function panView(dx,dy){
 const z=eyeBasis(),right=[-Math.sin(cam.yaw),0,Math.cos(cam.yaw)];
 const up=[z[1]*right[2]-z[2]*right[1],z[2]*right[0]-z[0]*right[2],z[0]*right[1]-z[1]*right[0]];
 const scale=2*cam.dist*Math.tan(.3)/cv.clientHeight;
 cam.target=cam.target.map((v,i)=>v+(-dx*right[i]+dy*up[i])*scale);
}
function rebaseGesture(){
 const a=[...pointers.values()];drag=a.length===1?a[0]:null;
 midpoint=a.length===2?[(a[0][0]+a[1][0])/2,(a[0][1]+a[1][1])/2]:null;
 pinch=a.length===2?Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1]):0;
}
cv.addEventListener('pointerdown',e=>{pan=e.button===2;pointers.set(e.pointerId,[e.clientX,e.clientY]);cv.setPointerCapture(e.pointerId);rebaseGesture();});
cv.addEventListener('pointermove',e=>{
 if(!pointers.has(e.pointerId))return;
 pointers.set(e.pointerId,[e.clientX,e.clientY]);
 if(pointers.size===2){
  const a=[...pointers.values()],m=[(a[0][0]+a[1][0])/2,(a[0][1]+a[1][1])/2];
  const d=Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1]);
  if(midpoint)panView(m[0]-midpoint[0],m[1]-midpoint[1]);
  if(d>0&&pinch>0)cam.dist*=pinch/d;
 }else if(pointers.size===1&&drag){
  if(pan)panView(e.clientX-drag[0],e.clientY-drag[1]);
  else{cam.yaw-=(e.clientX-drag[0])*.006;cam.pitch=Math.max(-1.45,Math.min(1.45,cam.pitch+(e.clientY-drag[1])*.006));}
 }
 rebaseGesture();
});
for(const ev of ['pointerup','pointercancel','lostpointercapture'])cv.addEventListener(ev,e=>{pointers.delete(e.pointerId);rebaseGesture();});
cv.addEventListener('wheel',e=>{e.preventDefault();cam.dist*=Math.exp(e.deltaY*.001);},{passive:false});
cv.addEventListener('dblclick',()=>{cam.yaw=scene.camera?.yaw??-1.05;cam.pitch=scene.camera?.pitch??.87;home();cam.dist*=scene.camera?.zoom??.8;});
