from pathlib import Path
from build123d import *
import numpy as np,json
D=Path(__file__).parent/'draft-11-12mm-tall';rec=json.loads((D/'retention.json').read_text())['pegs'][0]
clip=Pos(rec['origin'][0],-178,9)*Box(7,32,26,align=(Align.MIN,)*3)
f=np.load(D/'meshes/led-route.npz');vs=f['v'];ts=f['t'];pieces=[]
for i in range(0,len(ts),8):
 ids=sorted(set(int(j) for tri in ts[i:i+8] for j in tri))
 if len(ids)!=8:continue
 pts=vs[ids]
 if pts[:,0].max()<rec['origin'][0]-7 or pts[:,0].min()>rec['origin'][0]+7 or pts[:,1].min()>-146:continue
 s=Solid.make_loft([Wire.make_polygon([tuple(vs[j]) for j in ids[:4]],close=True),Wire.make_polygon([tuple(vs[j]) for j in ids[4:]],close=True)],ruled=True)&clip
 if getattr(s,'volume',0)>1e-5:pieces.append(s)
s=pieces[0].fuse(*pieces[1:]) if len(pieces)>1 else pieces[0]
v,t=s.tessellate(.05,.1);np.savez_compressed(D/'meshes/retention-led.npz',v=np.array([tuple(p) for p in v]),t=np.array(t))
