from pathlib import Path
from build123d import *
import json,math,numpy as np
R=Path(__file__).parent;D=R/'draft-11-12mm'
def box(x,y,z,dx,dy,dz):return Pos(x,y,z)*Box(dx,dy,dz,align=(Align.MIN,)*3)
def nearby(a,b):
 aa=a.bounding_box();bb=b.bounding_box();return all(tuple(aa.min)[i]<tuple(bb.max)[i] and tuple(aa.max)[i]>tuple(bb.min)[i] for i in range(3))
def save(n,s):
 assert s.is_valid and len(s.solids())==1,(n,[(x.volume,list(x.center())) for x in s.solids()])
 export_step(s,D/'parts'/(n+'.step'));export_stl(s,D/'parts'/(n+'.stl'),tolerance=.06,angular_tolerance=.1)
 v,t=s.tessellate(.06,.1);np.savez_compressed(D/'meshes'/(n+'.npz'),v=np.array([tuple(p) for p in v]),t=np.array(t))
cutters=[]
for name,p,t,n,L in [('front',(-160,-160),(1,0),(0,1),320),('right',(176,-144),(0,1),(-1,0),288),('back',(160,160),(-1,0),(0,-1),320),('left',(-176,144),(0,-1),(1,0),288)]:
 stations=sorted(set([0,8,16,24,32,L-32,L-24,L-16,L-8,L]))
 wires=[]
 for u in stations:
  a=math.radians(25)*min(1,u/32,(L-u)/32)
  pts=[(p[0]+t[0]*u+n[0]*(math.sin(a)*q+math.cos(a)*k),p[1]+t[1]*u+n[1]*(math.sin(a)*q+math.cos(a)*k),18+math.cos(a)*q-math.sin(a)*k) for q,k in [(-8.25,-.05),(4.25,-.05),(4.25,1.25),(-8.25,1.25)]]
  wires.append(Wire.make_polygon(pts,close=True))
 for a,b in zip(wires,wires[1:]):cutters.append(Solid.make_loft([a,b],ruled=True))
for cx,cy,sx,sy in [(160,-144,1,-1),(160,144,1,1),(-160,144,-1,1),(-160,-144,-1,-1)]:
 ring=Pos(cx,cy,9.75)*(Cylinder(16.05,12.5,align=(Align.CENTER,Align.CENTER,Align.MIN))-Cylinder(14.75,12.5,align=(Align.CENTER,Align.CENTER,Align.MIN)))
 cutters.append(ring&box(cx if sx>0 else cx-17,cy if sy>0 else cy-17,9,17,17,14))
report=[]
for n in ['front','right','back','left','front-left','front-right','rear-right','rear-left']:
 s=import_step(D/'parts'/(n+'.step'));old=s.volume
 s=s.cut(*[c for c in cutters if nearby(s,c)])
 solids=sorted(s.solids(),key=lambda a:a.volume,reverse=True)
 assert all(a.volume<.05 for a in solids[1:]),(n,[a.volume for a in solids])
 s=solids[0]
 save(n,s);report.append(dict(name=n,removed_mm3=old-s.volume));print(n,'channel removed',old-s.volume,flush=True)
s=import_step(D/'parts/front.step')&box(-116,-190,0,24,60,35);save('fit-coupon-keeper',s)
(D/'channel-changes.json').write_text(json.dumps(report,indent=2))
