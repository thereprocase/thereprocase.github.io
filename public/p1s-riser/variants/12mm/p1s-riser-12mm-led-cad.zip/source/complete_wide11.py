from pathlib import Path
import sys,time,json,subprocess,os
R=Path(__file__).parent;w=int(sys.argv[1]);env=dict(os.environ,OPENBLAS_NUM_THREADS='1',TMPDIR=str(R/'render-tmp'));py='/home/repro/venvs/kraken-cad/bin/python'
start=time.time()
while not (R/f'draft-11-{w}mm-tall/entry-relief.json').exists() or json.loads((R/f'verify11-{w}.json').read_text())[-1]!='detail_led10':
 assert time.time()-start<1800;time.sleep(5)
for script,args in [('recheck_entry11.py',[str(w)]),(f'finalize10_{w}_tall.py',[]),('verify_height11.py',[str(w)]),(f'make_review10_{w}_tall.py',[]),(f'add_reference10_{w}_tall.py',[])]:
 with (R/f'wide11-{w}-{script}.log').open('w') as log:subprocess.run([py,str(R/script),*args],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(w,script,'complete',flush=True)
# Only corners changed after the previous full slice matrix.
sys.path.insert(0,str(R/'dfm-08'));from slice_audit import plate
assert plate(f'11-{w}mm-corners',R/f'draft-11-{w}mm-tall/parts',[('front-left',65,65,0),('front-right',175,65,0),('rear-left',65,175,0),('rear-right',175,175,0)],True)==0
(R/f'wide11-{w}-ready.json').write_text(json.dumps(dict(width=w,complete=True)))
