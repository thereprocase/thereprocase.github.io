"""Width variants: fixed upper tape edge and fittings, widened downward.
Lower rail support ramps: 30 degrees from vertical (60 above print bed).
"""
from pathlib import Path
from build123d import *
import math,numpy as np,json,shutil,sys
R=Path(__file__).parent;B=R/'draft-10';width=int(sys.argv[1]);delta=width-8;D=R/f'draft-11-{width}mm'
assert width in (8,10,12)
shutil.copytree(B,D,dirs_exist_ok=True)
def box(x,y,z,dx,dy,dz):return Pos(x,y,z)*Box(dx,dy,dz,align=(Align.MIN,)*3)
def save(n,s):
 assert s.is_valid and len(s.solids())==1,(n,s.is_valid,len(s.solids()))
 export_step(s,D/'parts'/(n+'.step'));export_stl(s,D/'parts'/(n+'.stl'),tolerance=.06,angular_tolerance=.1)
 v,t=s.tessellate(.06,.1);np.savez_compressed(D/'meshes'/(n+'.npz'),v=np.array([tuple(p) for p in v]),t=np.array(t))
def nearby(a,b):
 aa=a.bounding_box();bb=b.bounding_box();return all(tuple(aa.min)[i]<tuple(bb.max)[i] and tuple(aa.max)[i]>tuple(bb.min)[i] for i in range(3))
sides=[('front',(-160,-160),(1,0),(0,1),320),('right',(176,-144),(0,1),(-1,0),288),('back',(160,160),(-1,0),(0,-1),320),('left',(-176,144),(0,-1),(1,0),288)]
def angle(u,L):return math.radians(25)*min(1,max(0,u/32),max(0,(L-u)/32))
def ribbon(path,q0,q1,k0,k1,shift=(0,0)):
 wires=[]
 for p,t,n,u,a in path:
  pts=[(p[0]+t[0]*u+n[0]*(math.sin(a)*q+math.cos(a)*k)+shift[0],p[1]+t[1]*u+n[1]*(math.sin(a)*q+math.cos(a)*k)+shift[1],18+math.cos(a)*q-math.sin(a)*k) for q,k in [(q0,k0),(q1,k0),(q1,k1),(q0,k1)]]
  wires.append(Wire.make_polygon(pts,close=True))
 return Solid.make_loft(wires,ruled=True)
paths=[]
for name,p,t,n,L in sides:
 for suffix,lo,hi in [('a',34,L/2-.15),('b',L/2+.15,L-34)]:paths.append((name+'-'+suffix,[(p,t,n,lo,math.radians(25)),(p,t,n,hi,math.radians(25))],(0,0)))
for cname,ia,ib,cx,cy,start,end in [('front-right',0,1,160,-144,-90,0),('rear-right',1,2,160,144,0,90),('rear-left',2,3,-160,144,90,180),('front-left',3,0,-160,-144,180,270)]:
 path=[]
 for idx,last in [(ia,True),(ib,False)]:
  _,p,t,n,L=sides[idx]
  if last:
   for u in np.linspace(L-33.6,L,10):path.append((p,t,n,u,angle(u,L)))
   for deg in np.linspace(start,end,25)[1:-1]:
    a=math.radians(deg);path.append(((cx+16*math.cos(a),cy+16*math.sin(a)),(-math.sin(a),math.cos(a)),(-math.cos(a),-math.sin(a)),0,0))
  else:
   for u in np.linspace(0,33.6,10):path.append((p,t,n,u,angle(u,L)))
 paths.append((cname,path,(.07 if cx>0 else -.07,.07 if cy>0 else -.07)))
adds=[];clears=[];slots=[]
for name,path,shift in paths:
 if delta:
  save('diffuser-'+name,ribbon(path,-4.7-delta,5.6,3.2,3.8,shift))
  if name.endswith(('-a','-b')):save('diffuser-'+name+'-flat',box(0,0,0,125.85 if name.startswith(('front','back')) else 109.85,10.3+delta,.6))
  # Remove the old lower lip and open the wider light mouth. Rear mounting
  # surface stays at k=0; all added support stays behind/below the new seat.
  clears.append(ribbon(path,-4.25-delta,-4.24,-.05,9,shift))
  adds.append(ribbon(path,-6.2-delta,-4.25-delta,-2,5.2,shift))
 slots.append(ribbon(path,-5-delta,-4.24-delta,2.8,4.2,shift))
 wires=[]
 for p,t,n,u,a in path:
  q=-6.2-delta;sn=math.sin(a);cs=math.cos(a)
  bv=sn*q-2*cs;bz=18+cs*q+2*sn;fv=sn*q+5.2*cs;fz=18+cs*q-5.2*sn
  rv=min(bv,-3);rz=fz-math.sqrt(3)*(fv-rv)
  pts=[(p[0]+t[0]*u+n[0]*v+shift[0],p[1]+t[1]*u+n[1]*v+shift[1],z) for v,z in [(bv,bz),(fv,fz),(rv,rz)]]
  wires.append(Wire.make_polygon(pts,close=True))
 adds.append(Solid.make_loft(wires,ruled=True))
regions=[('front',(-117,-200,234,99)),('right',(117,-101,83,202)),('back',(-117,101,234,99)),('left',(-200,-101,83,202)),('front-left',(-200,-200,83,99)),('front-right',(117,-200,83,99)),('rear-right',(117,101,83,99)),('rear-left',(-200,101,83,99))]
for name,(x,y,w,h) in regions:
 s=import_step(B/'parts'/(name+'.step'));clip=box(x,y,0,w,h,35)
 local=[c for c in clears if nearby(s,c)]
 if local:s=s.cut(*local)
 for a in adds:
  if nearby(clip,a):
   b=a&clip
   if getattr(b,'volume',0)>1e-5:s=s+b
 local=[c for c in slots if nearby(s,c)]
 if local:s=s.cut(*local)
 # Same connector passage, already reserved by Draft 10.
 if name=='back':s=s-box(70,141,10.5,18,39,10)
 save(name,s);print(width,name,'ready',flush=True)
save('fit-coupon-keeper',import_step(D/'parts/front.step')&box(-116,-190,0,24,60,35))
save('fit-coupon-diffuser',box(0,0,0,23.6,10.3+delta,.6))
# Expand actual tape mesh downward in each local ruled cross-section.
f=np.load(B/'meshes/led-route.npz');v=f['v'].copy();t=f['t']
for i in range(0,len(v),4):
 direction=(v[i+1]-v[i])/8
 v[i]-=delta*direction;v[i+3]-=delta*direction
np.savez_compressed(D/'meshes/led-route.npz',v=v,t=t)
m=json.loads((D/'design-parameters.json').read_text());m.update(revision='11',led_width_mm=width,diffuser_height_mm=10.3+delta,dfm_ramp_degrees_from_vertical=30,dfm_ramp_degrees_from_bed=60);m['led_clearance_checker']['width_mm']=width+.2;(D/'design-parameters.json').write_text(json.dumps(m,indent=2))
m=json.loads((D/'retention.json').read_text());m['diffuser_height_mm']=10.3+delta;(D/'retention.json').write_text(json.dumps(m,indent=2))
print(width,'geometry ready',flush=True)
