from pathlib import Path
R=Path(__file__).parent
for w in (8,10,12):
 d=w-8;D=f'draft-11-{w}mm';folder=R/f'work11-{w}mm';folder.mkdir(exist_ok=True)
 # Scripts stay at project root so their paths and imports resolve consistently.
 for base in ['negative10','audit10','validate10','lock10','finalize10','detail10','detail_led10','make_review10','add_reference10']:
  s=(R/(base+'.py')).read_text().replace("D=R/'draft-10'",f"D=R/'{D}'").replace("/'draft-10'",f"/'{D}'").replace("'site-dfm10'",f"'site-dfm11-{w}mm'")
  s=s.replace("draft-10-assembly.step",f"p1s-riser-{w}mm-led-assembly.step").replace("draft-10-cad.zip",f"p1s-riser-{w}mm-led-cad.zip").replace('Draft 10',f'Draft 11 · {w} mm LED')
  if base=='negative10':
   s=s.replace('(-4.1,.05)',f'({-4.1-d},.05)').replace('(-4.1,1.15)',f'({-4.1-d},1.15)').replace('13.9',str(13.9-d)).replace('15.95,8.2',f'15.95,{8.2+d}').replace('14.85,8.2',f'14.85,{8.2+d}').replace('13,17,17,10',f'{9 if w==12 else 11 if w==10 else 13},17,17,{10+d}')
   s=s.replace('width_mm=8.2',f'width_mm={w+.2}').replace('nominal_tape_width_mm=8,',f'nominal_tape_width_mm={w},').replace('8.2 mm width',f'{w+.2} mm width').replace('8 x 0.8',f'{w} x 0.8')
  if base=='audit10':s=s.replace('nominal_tape_width_mm=8,',f'nominal_tape_width_mm={w},')
  if base=='make_review10':s=s.replace('8.2 mm wide',f'{w+.2} mm wide')
  (R/f'{base}_{w}.py').write_text(s)
 s=(R/'vase09.py').read_text().replace("/'draft-09'",f"/'{D}'").replace('z-6',f'z-{6+d}').replace('[-4.7,5.6]',f'[{-4.7-d},5.6]').replace('12.4',str(12.4+d)).replace('63)',f'{63+5*d})')
 (R/f'vase11_{w}.py').write_text(s)
 s=(R/'refine_review09.py').read_text().replace("/'draft-09'",f"/'{D}'").replace('amount=10.3',f'amount={10.3+d}').replace('amount=12)',f'amount={14+d})')
 (R/f'refine11_{w}.py').write_text(s)
