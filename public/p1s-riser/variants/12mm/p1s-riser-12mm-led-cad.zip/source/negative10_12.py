from pathlib import Path
from build123d import *
import json,math,numpy as np
R=Path(__file__).parent;D=R/'draft-11-12mm'
def box(x,y,z,dx,dy,dz):return Pos(x,y,z)*Box(dx,dy,dz,align=(Align.MIN,)*3)
def nearby(a,b):
 aa=a.bounding_box();bb=b.bounding_box();return all(tuple(aa.min)[i]<tuple(bb.max)[i] and tuple(aa.max)[i]>tuple(bb.min)[i] for i in range(3))
def save(n,s):
 assert s.is_valid and len(s.solids())==1,(n,len(s.solids()))
 export_step(s,D/'parts'/(n+'.step'));export_stl(s,D/'parts'/(n+'.stl'),tolerance=.06,angular_tolerance=.1)
 v,t=s.tessellate(.06,.1);np.savez_compressed(D/'meshes'/(n+'.npz'),v=np.array([tuple(p) for p in v]),t=np.array(t))
cutters=[]
for name,p,t,n,L in [('front',(-160,-160),(1,0),(0,1),320),('right',(176,-144),(0,1),(-1,0),288),('back',(160,160),(-1,0),(0,-1),320),('left',(-176,144),(0,-1),(1,0),288)]:
 stations=sorted(set([0,8,16,24,32,L-32,L-24,L-16,L-8,L]))
 wires=[]
 for u in stations:
  a=math.radians(25)*min(1,u/32,(L-u)/32)
  pts=[(p[0]+t[0]*u+n[0]*(math.sin(a)*q+math.cos(a)*k),p[1]+t[1]*u+n[1]*(math.sin(a)*q+math.cos(a)*k),18+math.cos(a)*q-math.sin(a)*k) for q,k in [(-8.1,.05),(4.1,.05),(4.1,1.15),(-8.1,1.15)]]
  wires.append(Wire.make_polygon(pts,close=True))
 for a,b in zip(wires,wires[1:]):cutters.append(Solid.make_loft([a,b],ruled=True))
for cx,cy,sx,sy in [(160,-144,1,-1),(160,144,1,1),(-160,144,-1,1),(-160,-144,-1,-1)]:
 ring=Pos(cx,cy,9.9)*(Cylinder(15.95,12.2,align=(Align.CENTER,Align.CENTER,Align.MIN))-Cylinder(14.85,12.2,align=(Align.CENTER,Align.CENTER,Align.MIN)))
 cutters.append(ring&box(cx if sx>0 else cx-17,cy if sy>0 else cy-17,9,17,17,14))

from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
C=D/'clearance';C.mkdir(exist_ok=True)
negative=Compound(children=cutters)
assert all(s.is_valid for s in cutters)
export_step(negative,C/'led-clearance-negative.step')
v,t=negative.tessellate(.08,.12);np.savez_compressed(D/'meshes/led-clearance-negative.npz',v=np.array([tuple(p) for p in v]),t=np.array(t))
frames={n:import_step(D/'parts'/(n+'.step')) for n in ['front','right','back','left','front-left','front-right','rear-right','rear-left','rear-cable-plug']}
frames.update({f.stem:import_step(f) for f in (D/'parts').glob('diffuser-*.step') if not f.stem.endswith('-flat')})
p=import_step(D/'parts/retaining-peg.step')
for r in json.loads((D/'retention.json').read_text())['pegs']:
 frames[r['name']]=Plane(origin=r['origin'],x_dir=(*r['tangent'],0),z_dir=r['normal']).location*p
hits=[]
for name,s in frames.items():
 volume=0
 for c in cutters:
  if nearby(s,c):volume+=abs(Compound(BRepAlgoAPI_Common(s.wrapped,c.wrapped).Shape()).volume)
 print(name,volume,flush=True)
 if volume>1e-5:hits.append(dict(part=name,overlap_mm3=volume))
# Preserve the full cable passage as a second physical keep-out. Plug is
# intentionally excluded: it is removed to pass the connector.
cable=box(70,141,10.5,18,39,10)
export_step(cable,C/'rear-cable-passage-negative.step')
cablehits=[]
for name,s in frames.items():
 if name=='rear-cable-plug' or name.startswith('diffuser-') or not nearby(s,cable):continue
 volume=abs(Compound(BRepAlgoAPI_Common(s.wrapped,cable.wrapped).Shape()).volume)
 if volume>1e-5:cablehits.append(dict(part=name,overlap_mm3=volume))
report=dict(led=dict(width_mm=12.2,normal_range_mm=[.05,1.15],nominal_tape_width_mm=12,nominal_tape_normal_range_mm=[.1,.9],checked_parts=list(frames),intersections=hits),cable=dict(size_mm=[18,39,10],plug_and_diffusers_removed=True,intersections=cablehits))
(C/'checks.json').write_text(json.dumps(report,indent=2))
(C/'README.txt').write_text('Reference keep-out solids, not printed parts. All coordinates are assembly coordinates in mm. LED negative reserves 12.2 mm width and k=0.05..1.15 mm off the mounting face, versus provisional 12 x 0.8 mm tape at k=0.1..0.9. The rear gap remains reserved for the tape ends. Rear cable negative is checked before fitting diffusers and removable plug. Regenerate and run negative10.py after frame edits; any intersection above 0.00001 mm3 fails. Individual adjacent checker solids overlap at joins; they represent a union.\n')
assert not hits and not cablehits,(hits,cablehits)
