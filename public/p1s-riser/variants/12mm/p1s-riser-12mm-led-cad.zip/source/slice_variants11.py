from pathlib import Path
import sys,json
R=Path(__file__).parent;sys.path.insert(0,str(R/'dfm-08'));from slice_audit import plate
w=int(sys.argv[1]);source=R/(f'draft-11-{w}mm-tall' if w>8 else 'draft-11-8mm')/'parts'
for which,items in [('sides',[('front',128,45,0),('back',128,95,0),('left',128,145,90),('right',128,195,90)]),('corners',[('front-left',65,65,0),('front-right',175,65,0),('rear-left',65,175,0),('rear-right',175,175,0)]),('coupon',[('fit-coupon-keeper',128,128,0)])]:
 assert plate(f'11-{w}mm-'+which,source,items,True)==0
vase=json.loads((R/'dfm-08/09-vase-corner-diffuser/process.json').read_text())
for n in ['vase-corner-diffuser','vase-diffuser-front-back','vase-diffuser-sides','vase-diffuser-coupon']:
 assert plate(f'11-{w}mm-'+n,source,[(n,128,128,0)],False,vase)==0
# Eight straight flat pieces plus the fit coupon are packed in two rows.
items=[]
for i,n in enumerate(['front-a','front-b','back-a','back-b','left-a','left-b','right-a','right-b']):items.append(('diffuser-'+n+'-flat',65 if i%2==0 else 191,40+(i//2)*35,0))
items.append(('fit-coupon-diffuser',128,200,0))
assert plate(f'11-{w}mm-flat-diffusers',source,items)==0
