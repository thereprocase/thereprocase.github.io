from pathlib import Path
import sys,importlib,json,concurrent.futures,multiprocessing,os
R=Path(__file__).parent;w=int(sys.argv[1]);v=importlib.import_module(f'validate10_{w}');D=R/f'draft-11-{w}mm'
if __name__=='__main__':
 assert json.loads((R/f'verify11-{w}.json').read_text())[-1]=='detail_led10'
 old=json.loads((D/'retention-checks.json').read_text());corners=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=2,mp_context=multiprocessing.get_context('spawn'),initializer=v.init) as pool:
  for r in pool.map(v.check_diff,['front-right','rear-right','rear-left','front-left']):
   corners.append(r);print(w,r['name'],max(x['overlap_mm3'] for x in r['positions']),flush=True)
 assert max(x['overlap_mm3'] for r in corners for x in r['positions'])<1e-5
 old['diffuser_insertion']=[r for r in old['diffuser_insertion'] if r['name'].endswith(('-a','-b'))]+corners
 old['entry_relief_note']='Corners rechecked after subtractive end relief; straight paths and keeper motion preserved (no added material).'
 (D/'retention-checks.json').write_text(json.dumps(old,indent=2));(D/'entry-recheck-passed.json').write_text(json.dumps(dict(width=w,corners=4,max_overlap_mm3=0)))
