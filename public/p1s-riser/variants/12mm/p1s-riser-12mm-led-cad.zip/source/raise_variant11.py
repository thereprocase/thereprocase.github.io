"""Raise the wider optical assembly, extending the original seating walls below it.
This is a rigid translation of the checked optical geometry, not scaling.
"""
from pathlib import Path
from build123d import *
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
import json,numpy as np,sys,shutil
R=Path(__file__).parent;w=int(sys.argv[1]);dz=w-8;B=R/f'draft-11-{w}mm';D=R/f'draft-11-{w}mm-tall'
assert w in [10,12]
shutil.copytree(B,D,dirs_exist_ok=True)
names=['front','right','back','left','front-left','front-right','rear-right','rear-left']
def box(x,y,z,dx,dy,dz):return Pos(x,y,z)*Box(dx,dy,dz,align=(Align.MIN,)*3)
def save(n,s):
 assert s.is_valid and len(s.solids())==1,(n,len(s.solids()))
 export_step(s,D/'parts'/(n+'.step'));export_stl(s,D/'parts'/(n+'.stl'),tolerance=.06,angular_tolerance=.1)
 v,t=s.tessellate(.06,.1);np.savez_compressed(D/'meshes'/(n+'.npz'),v=np.array([tuple(p) for p in v]),t=np.array(t))
frames={};report=[]
for n in names:
 old=import_step(B/'parts'/(n+'.step'))
 profile=Pos(0,0,-.02)*section(old,section_by=Plane.XY.offset(.02))
 extension=extrude(profile,amount=dz+.03)
 s=Pos(0,0,dz)*old+extension
 save(n,s);frames[n]=s;report.append(dict(name=n,base_extension_mm=dz,min_z=s.bounding_box().min.Z,max_z=s.bounding_box().max.Z));print(w,n,'raised',flush=True)
for f in (B/'parts').glob('diffuser-*.step'):
 if not f.stem.endswith('-flat'):save(f.stem,Pos(0,0,dz)*import_step(f))
plug=Pos(0,0,dz)*import_step(B/'parts/rear-cable-plug.step');save('rear-cable-plug',plug)
# Print-oriented plug/keepers and all diffuser blanks are unchanged.
save('fit-coupon-keeper',frames['front']&box(-116,-190,0,24,60,35+dz))
save('fit-coupon-joint-side',frames['front']&box(100,-180,0,17,14,13+dz))
save('fit-coupon-joint-corner',frames['front-right']&box(108.9,-180,0,25,14,13+dz))
m=json.loads((D/'retention.json').read_text());peg=import_step(D/'parts/retaining-peg.step')
for rec in m['pegs']:
 rec['origin'][2]+=dz;s=Plane(origin=rec['origin'],x_dir=(*rec['tangent'],0),z_dir=rec['normal']).location*peg
 v,t=s.tessellate(.06,.1);np.savez_compressed(D/'meshes'/(rec['name']+'.npz'),v=np.array([tuple(p) for p in v]),t=np.array(t))
(D/'retention.json').write_text(json.dumps(m,indent=2))
f=np.load(B/'meshes/led-route.npz');v=f['v'].copy();v[:,2]+=dz;np.savez_compressed(D/'meshes/led-route.npz',v=v,t=f['t'])
for f in (B/'clearance').glob('*.step'):export_step(Pos(0,0,dz)*import_step(f),D/'clearance'/f.name)
f=np.load(B/'meshes/led-clearance-negative.npz');v=f['v'].copy();v[:,2]+=dz;np.savez_compressed(D/'meshes/led-clearance-negative.npz',v=v,t=f['t'])
p=json.loads((D/'design-parameters.json').read_text());p.update(glass_seat_z_mm=30+dz,glass_lip_top_mm=32.5+dz,rear_tunnel_bottom_z_mm=10.5+dz,additional_height_mm=dz);(D/'design-parameters.json').write_text(json.dumps(p,indent=2))
(D/'height-changes.json').write_text(json.dumps(dict(translation_mm=dz,frames=report,method='Rigidly translate optical and upper seating assembly; extend original base profiles to Z0.'),indent=2))
print(w,'height adjusted',flush=True)
