from pathlib import Path
from build123d import *
import sys,math,numpy as np,json
R=Path(__file__).parent;w=int(sys.argv[1]);delta=w-8
assert w in [10,12]
# Each corner's two straight ends need room for the 4 mm inward approach.
sides=[((-160,-160),(1,0),(0,1),320),((176,-144),(0,1),(-1,0),288),((160,160),(-1,0),(0,-1),320),((-176,144),(0,-1),(1,0),288)]
tools=[]
for name,ia,ib,sx,sy in [('front-right',0,1,1,-1),('rear-right',1,2,1,1),('rear-left',2,3,-1,1),('front-left',3,0,-1,-1)]:
 for idx,last in [(ia,True),(ib,False)]:
  p,t,n,L=sides[idx];lo,hi=(L-38.2,L-33.5) if last else (33.5,38.2);a=math.radians(25);wires=[]
  for band in [[(-4.25-delta,-.05),(-4.24,-.05),(-4.24,9),(-4.25-delta,9)], [(-5-delta,2.8),(-4.24-delta,2.8),(-4.24-delta,4.2),(-5-delta,4.2)]]:
   wires=[]
   for u in [lo,hi]:
    pts=[(p[0]+t[0]*u+n[0]*(math.sin(a)*q+math.cos(a)*k)+sx*.07,p[1]+t[1]*u+n[1]*(math.sin(a)*q+math.cos(a)*k)+sy*.07,18+math.cos(a)*q-math.sin(a)*k) for q,k in band]
    wires.append(Wire.make_polygon(pts,close=True))
   tools.append((name,Solid.make_loft(wires,ruled=True)))

for tall in [False,True]:
 D=R/(f'draft-11-{w}mm'+('-tall' if tall else ''));dz=delta if tall else 0;records=[]
 for name in ['front-left','front-right','rear-left','rear-right']:
  s=import_step(D/'parts'/(name+'.step'));old=s.volume;s=s.cut(*[Pos(0,0,dz)*c for n,c in tools if n==name]);solids=sorted(s.solids(),key=lambda p:p.volume,reverse=True)
  assert all(x.volume<1 for x in solids[1:]),(name,[x.volume for x in solids]);s=solids[0];assert s.is_valid
  export_step(s,D/'parts'/(name+'.step'));export_stl(s,D/'parts'/(name+'.stl'),tolerance=.06,angular_tolerance=.1);v,t=s.tessellate(.06,.1);np.savez_compressed(D/'meshes'/(name+'.npz'),v=np.array([tuple(p) for p in v]),t=np.array(t))
  records.append(dict(name=name,removed_mm3=old-s.volume));print(w,tall,name,old-s.volume,flush=True)
 export_step(Compound(children=[Pos(0,0,dz)*c for _,c in tools]),D/'clearance/corner-entry-relief-negative.step')
 (D/'entry-relief.json').write_text(json.dumps(dict(extension_past_diffuser_end_mm=4.6,frame_changes=records),indent=2))
