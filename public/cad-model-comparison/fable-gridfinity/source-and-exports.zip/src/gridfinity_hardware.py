#!/usr/bin/env python
"""
Gridfinity hardware organizer (M2 .. M4 screws, nuts, washers) - parametric build123d source.

Run with the kraken-cad runtime:
    python src/gridfinity_hardware.py [--out DIR] [--quick]

Produces, per part: STEP + binary STL, plus assembly.json and checks/checks_cad.json.

Coordinate conventions
  * Every part has its own local origin: X/Y at the footprint centre, Z=0 at the lowest
    face (bin foot bottom, baseplate underside).  The viewer stands at -Y and looks
    towards +Y; label faces point up and towards -Y.
  * Units: millimetres.

Gridfinity numbers come from the public specification (gridfinity.xyz) and were
cross-checked against gridfinity-rebuilt-openscad standard.scad:
  bin foot profile (bottom up)      0.8 chamfer / 1.8 vertical / 2.15 chamfer, top 41.5 mm, R3.75
  baseplate pocket (top down)       2.15 chamfer / 1.8 vertical / 0.7 chamfer, top 42.0 mm, R4
  stacking lip (top down)           1.9 chamfer / 1.8 vertical / 0.7 chamfer  (4.4 tall)
  height unit                       7 mm;  grid pitch 42 mm;  bin footprint 42n - 0.5
"""
from __future__ import annotations
import argparse, json, math, os, sys, time
from dataclasses import dataclass, field
from build123d import *

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
FONT = os.path.join(ROOT, "assets", "fillaprint", "Fillaprint-Regular.ttf")

# ----------------------------------------------------------------------------- parameters
PITCH = 42.0                 # grid pitch
CELL_TOP = 41.5              # width of one bin cell at the top of the foot profile
U = 7.0                      # Gridfinity height unit
FOOT_CH_BOT, FOOT_V, FOOT_CH_TOP = 0.8, 1.8, 2.15
FOOT_H = FOOT_CH_BOT + FOOT_V + FOOT_CH_TOP          # 4.75
R_FOOT_TOP = 3.75
LIP_CH_TOP, LIP_V, LIP_CH_BOT = 1.9, 1.8, 0.7
LIP_H = LIP_CH_TOP + LIP_V + LIP_CH_BOT              # 4.4
LIP_SUPPORT_V = 1.2          # vertical run under the lip tip before the 45 deg support chamfer
LIP_TOP_FLAT = 0.3           # knife edge of the spec lip truncated to a 0.3 mm flat (printable)

WALL = 1.2                   # outer wall (3 perimeters at 0.4-0.42)
DIVIDER = 1.2
FLOOR_ABOVE_FOOT = 1.25      # floor top = FOOT_H + this  (= 6.0)
FLOOR_Z = FOOT_H + FLOOR_ABOVE_FOOT
CEILING_CLEAR = 1.0          # interior features stop this far below the 7u plane (stacked bin foot sits 0.35 below it)

# label / font (Fillaprint two-bead rule: cap height = 14 w, em = 20 w, stroke = 2 w)
LINE_WIDTH = 0.45            # extrusion line width the text is designed for (>= what most 0.4 mm profiles use)
FONT_EM = 20 * LINE_WIDTH    # 9.0 mm  (build123d font_size is the em; measured H = 6.30 mm)
CAP_H = 14 * LINE_WIDTH      # 6.3 mm
LINE_PITCH = 20 * LINE_WIDTH # 9.0 mm baseline pitch for unaccented caps/digits (font docs allow 20 w for such labels)
LABEL_MARGIN = 1.2           # face margin above/below the text block (>= 2 w)
LABEL_ANGLE = 45.0           # label face angle from horizontal, rising towards the back
TAB_T = 2.0                  # label tab thickness measured normal to the face
TEXT_DEPTH = 0.6             # debossed text depth (normal to the face)
MAGNETS = False              # optional 6.5 x 2.4 magnet pockets in the feet
MAGNET_D, MAGNET_H, MAGNET_OFF = 6.5, 2.4, 13.0

# baseplate
PLATE_T = 6.0
POCKET_TOP = 41.9            # 42.0 in the spec; 0.05 flat per side keeps the inter-cell ridge printable
POCKET_CH_TOP = POCKET_TOP/2 - (CELL_TOP/2 - FOOT_CH_TOP + 0.25)   # 2.1  -> vertical section 37.7 wide
POCKET_V, POCKET_CH_BOT = 1.8, 0.7
POCKET_EXTRA = 0.05          # straight run under the bottom chamfer so the pocket is 4.65 deep like the spec
POCKET_DEPTH = POCKET_CH_TOP + POCKET_V + POCKET_CH_BOT + POCKET_EXTRA  # 4.65 ; bins rest on the pocket floor, see README
R_POCKET_TOP = R_FOOT_TOP + 0.25 - 0.05
PLATE_CORNER_R = 4.0

# starter layout (5 x 4 cells, bins are 1 wide x 2 deep, columns = diameter)
GRID_X, GRID_Y = 5, 4


@dataclass
class BinSpec:
    name: str
    labels: list                       # one entry per compartment, front to back; entry = str or [line1, line2]
    units: int = 4                     # height units (7 mm each) to the lip tip plane
    scoop_r: float = 7.0
    cells_x: int = 1
    cells_y: int = 2
    col: int = 0                       # placement on the plate (column 0..4, row 0 = front)
    row: int = 0


def _lab(d, lengths):
    return [f"M{d}×{l}" for l in lengths]        # "M3×10"

BINS = [
    BinSpec("bin_M2_short",   _lab("2",   [6, 8, 10]),  col=0, row=0),
    BinSpec("bin_M2_nut_washer",   [["M2", "WASHER"], ["M2", "NUT"]],   scoop_r=8.0, col=0, row=1),
    BinSpec("bin_M2.5_short", _lab("2.5", [6, 8, 10]),  col=1, row=0),
    BinSpec("bin_M2.5_long",  _lab("2.5", [12, 16, 20]), col=1, row=1),
    BinSpec("bin_M3_short",   _lab("3",   [6, 8, 10]),  col=2, row=0),
    BinSpec("bin_M3_long",    _lab("3",   [12, 16, 20]), col=2, row=1),
    BinSpec("bin_M4_long",    _lab("4",   [12, 16, 20]), col=3, row=0),
    BinSpec("bin_M4_nut_washer",   [["M4", "WASHER"], ["M4", "NUT"]],   scoop_r=8.0, col=3, row=1),
    BinSpec("bin_M2.5_nut_washer", [["M2.5", "WASHER"], ["M2.5", "NUT"]], scoop_r=8.0, col=4, row=0),
    BinSpec("bin_M3_nut_washer",   [["M3", "WASHER"], ["M3", "NUT"]],   scoop_r=8.0, col=4, row=1),
]


# ----------------------------------------------------------------------------- helpers
def rr_prism(w, l, r, z0, h, taper=0.0):
    """Rounded-rectangle prism from z0 up by h. taper=-45 grows the outline by h per side."""
    with BuildPart() as bp:
        with BuildSketch(Plane.XY.offset(z0)):
            RectangleRounded(w, l, r)
        extrude(amount=h, taper=taper)
    return bp.part


def foot_solid(cx, cy):
    """One Gridfinity foot (bottom at z=0) centred at (cx, cy)."""
    wb = CELL_TOP - 2 * (FOOT_CH_TOP + FOOT_CH_BOT)      # 35.6
    rb = R_FOOT_TOP - FOOT_CH_TOP - FOOT_CH_BOT          # 0.8
    s = rr_prism(wb, wb, rb, 0, FOOT_CH_BOT, taper=-45)
    s += rr_prism(wb + 2*FOOT_CH_BOT, wb + 2*FOOT_CH_BOT, rb + FOOT_CH_BOT, FOOT_CH_BOT, FOOT_V)
    s += rr_prism(CELL_TOP - 2*FOOT_CH_TOP, CELL_TOP - 2*FOOT_CH_TOP, R_FOOT_TOP - FOOT_CH_TOP,
                  FOOT_CH_BOT + FOOT_V, FOOT_CH_TOP, taper=-45)          # ends exactly at 41.5 / z=4.75
    if MAGNETS:
        with BuildPart() as m:
            with Locations(*[(sx*MAGNET_OFF, sy*MAGNET_OFF) for sx in (-1, 1) for sy in (-1, 1)]):
                Cylinder(MAGNET_D/2, MAGNET_H, align=(Align.CENTER, Align.CENTER, Align.MIN))
        s -= m.part
    return s.moved(Location((cx, cy, 0)))


def label_geometry(n_lines):
    """Slope length L of the label face and its horizontal projection P (45 deg)."""
    L = CAP_H + (n_lines - 1) * LINE_PITCH + 2 * LABEL_MARGIN
    a = math.radians(LABEL_ANGLE)
    return L, L * math.cos(a), L * math.sin(a)


def build_bin(spec: BinSpec):
    """Returns (Part, info dict). Local origin: footprint centre, z=0 at foot bottom."""
    n = len(spec.labels)
    n_lines = max(len(l) if isinstance(l, list) else 1 for l in spec.labels)
    ox = spec.cells_x * PITCH - 0.5          # 41.5
    oy = spec.cells_y * PITCH - 0.5          # 83.5
    z_tip = spec.units * U                   # lip inner tip plane (7u)
    z_lip = z_tip + LIP_H                    # nominal lip top (knife edge)
    z_top = z_lip - LIP_TOP_FLAT             # actual top face
    zc = z_tip - CEILING_CLEAR               # interior ceiling for dividers / tabs

    # --- outer body + feet
    body = rr_prism(ox, oy, R_FOOT_TOP, FOOT_H - 0.01, z_top - FOOT_H + 0.01)   # 0.01 overlap with the feet
    for i in range(spec.cells_x):
        for j in range(spec.cells_y):
            cx = (i - (spec.cells_x - 1) / 2) * PITCH
            cy = (j - (spec.cells_y - 1) / 2) * PITCH
            body += foot_solid(cx, cy)

    # --- interior cut: cavity, lip support, lip profile (stacked tapered prisms)
    ix, iy, ir = ox - 2*WALL, oy - 2*WALL, R_FOOT_TOP - WALL
    z_sup = z_tip - LIP_SUPPORT_V - (2.6 - WALL)       # support chamfer starts here (25.4 for 4u)
    cut = rr_prism(ix, iy, ir, FLOOR_Z, z_sup - FLOOR_Z)
    cut += rr_prism(ix, iy, ir, z_sup, 2.6 - WALL, taper=45)                         # shrink to inset 2.6
    ins = 2.6
    cut += rr_prism(ox - 2*ins, oy - 2*ins, R_FOOT_TOP - ins, z_sup + (2.6 - WALL), LIP_SUPPORT_V)
    cut += rr_prism(ox - 2*ins, oy - 2*ins, R_FOOT_TOP - ins, z_tip, LIP_CH_BOT, taper=-45)  # 2.6 -> 1.9
    ins = 2.6 - LIP_CH_BOT
    cut += rr_prism(ox - 2*ins, oy - 2*ins, R_FOOT_TOP - ins, z_tip + LIP_CH_BOT, LIP_V)
    cut += rr_prism(ox - 2*ins, oy - 2*ins, R_FOOT_TOP - ins, z_tip + LIP_CH_BOT + LIP_V,
                    LIP_CH_TOP + 0.5, taper=-45)                                      # 1.9 -> 0 at z_lip (and beyond)
    body -= cut

    # --- compartments: dividers with integral label tabs, scoops, debossed text
    L, P, drop = label_geometry(n_lines)
    y_in0, y_in1 = -oy/2 + WALL, oy/2 - WALL
    c = (iy - (n - 1) * DIVIDER) / n                       # floor length of one compartment
    z_m = zc - drop                                        # mount height of the label face
    t_v = TAB_T / math.cos(math.radians(LABEL_ANGLE))      # vertical thickness at the tab's back edge
    z_u = zc - t_v - P                                     # where the 45 deg underside meets the divider back face
    half_x = ix/2 + 0.3                                    # tabs/dividers overlap 0.3 into the side walls
    comps = []
    adds = None
    cuts = None
    for k in range(n):
        y_front = y_in0 + k * (c + DIVIDER)                 # floor start of compartment k
        y_k = y_front - DIVIDER                             # divider front face (k=0: front wall outer region)
        y_b = y_front + c                                   # back boundary of compartment k
        # divider + tab polygon in (y, z)
        pts = [(y_k, FLOOR_Z - 0.5), (y_k, z_m), (y_k + DIVIDER, z_m), (y_k + DIVIDER + P, zc),
               (y_k + DIVIDER + P, zc - t_v), (y_k + DIVIDER, z_u), (y_k + DIVIDER, FLOOR_Z - 0.5)]
        with BuildPart() as tb:
            with BuildSketch(Plane.YZ):
                Polygon(*pts, align=None)
            extrude(amount=half_x, both=True)
        adds = tb.part if adds is None else adds + tb.part
        # scoop filler at the back of the compartment
        r = spec.scoop_r
        with BuildPart() as sc:
            with BuildSketch(Plane.YZ):
                with Locations(((y_b - r + y_b + 0.5) / 2, (FLOOR_Z - 0.5 + FLOOR_Z + r) / 2)):
                    Rectangle(r + 0.5, r + 0.5)
                with Locations((y_b - r, FLOOR_Z + r)):
                    Circle(r, mode=Mode.SUBTRACT)
            extrude(amount=half_x, both=True)
        adds += sc.part
        # label text, centred on the face
        lines = spec.labels[k] if isinstance(spec.labels[k], list) else [spec.labels[k]]
        a = math.radians(LABEL_ANGLE)
        face_c = Vector(0, y_k + DIVIDER + P/2, (z_m + zc)/2)
        plane = Plane(origin=face_c, x_dir=(1, 0, 0), z_dir=(0, -math.sin(a), math.cos(a)))
        with BuildPart() as tx:
            with BuildSketch(plane):
                for li, line in enumerate(lines):
                    off = ((len(lines) - 1) / 2 - li) * LINE_PITCH
                    with Locations((0, off)):
                        Text(line, font_size=FONT_EM, font_path=FONT, align=(Align.CENTER, Align.CENTER))
            extrude(amount=-TEXT_DEPTH)
        cuts = tx.part if cuts is None else cuts + tx.part
        comps.append({
            "index": k, "label": lines,
            "floor_y_range_local": [round(y_front, 3), round(y_b, 3)],
            "floor_length": round(c, 3), "floor_width": round(ix, 3),
            "open_top_y_range_local": [round(y_k + DIVIDER + P, 3), round(y_b, 3)],
            "open_top_length": round(c - P, 3),
            "open_top_width_at_ceiling": round(ox - 2*2.6, 3),
            "divider_front_face_height_above_floor": round(z_m - FLOOR_Z, 3),
            "scoop_radius": r,
            "label_face_center_local": [0, round(face_c.Y, 3), round(face_c.Z, 3)],
        })
    body += adds
    body -= cuts
    # measure text geometry once (cap height of H at the chosen em)
    with BuildSketch() as hs:
        Text("H", font_size=FONT_EM, font_path=FONT)
    cap = hs.sketch.bounding_box().size.Y

    info = {
        "name": spec.name, "cells": [spec.cells_x, spec.cells_y], "height_units": spec.units,
        "footprint": [ox, oy], "height_total": round(z_top, 3), "lip_tip_z": z_tip,
        "floor_z": FLOOR_Z, "ceiling_z": zc, "interior_full_width_to_z": round(z_sup, 3),
        "stack_seat_offset_z": round(z_lip - FOOT_H, 3),
        "label": {"lines": n_lines, "slope_length": round(L, 3), "projection": round(P, 3),
                  "face_angle_deg": LABEL_ANGLE, "cap_height_measured": round(cap, 3),
                  "em": FONT_EM, "stroke_nominal": 2 * LINE_WIDTH, "deboss_depth": TEXT_DEPTH},
        "compartments": comps,
        "placement": {"col": spec.col, "row": spec.row},
    }
    return body, info


def build_plate(nx, ny):
    """Baseplate with closed floor. Local origin: centre of the underside."""
    W, Lp = nx * PITCH, ny * PITCH
    with BuildPart() as pp:
        with BuildSketch():
            RectangleRounded(W, Lp, PLATE_CORNER_R)
        extrude(amount=PLATE_T)
    plate = pp.part
    # one pocket, built bottom-up, then subtracted at every cell
    z0 = PLATE_T - POCKET_DEPTH
    wv = POCKET_TOP - 2 * POCKET_CH_TOP                  # 37.7
    rv = R_POCKET_TOP - POCKET_CH_TOP
    pocket = rr_prism(wv - 2*POCKET_CH_BOT, wv - 2*POCKET_CH_BOT, rv - POCKET_CH_BOT, z0, POCKET_EXTRA)
    pocket += rr_prism(wv - 2*POCKET_CH_BOT, wv - 2*POCKET_CH_BOT, rv - POCKET_CH_BOT, z0 + POCKET_EXTRA, POCKET_CH_BOT, taper=-45)
    pocket += rr_prism(wv, wv, rv, z0 + POCKET_EXTRA + POCKET_CH_BOT, POCKET_V)
    pocket += rr_prism(wv, wv, rv, z0 + POCKET_EXTRA + POCKET_CH_BOT + POCKET_V, POCKET_CH_TOP + 0.5, taper=-45)
    pts = [((i - (nx - 1)/2) * PITCH, (j - (ny - 1)/2) * PITCH) for i in range(nx) for j in range(ny)]
    with BuildPart() as cp:
        insert(plate)
        with Locations(*pts):
            insert(pocket, mode=Mode.SUBTRACT)
    info = {"name": f"baseplate_{nx}x{ny}", "cells": [nx, ny], "size": [W, Lp, PLATE_T],
            "pocket_depth": POCKET_DEPTH, "pocket_top_width": POCKET_TOP,
            "bin_rest_z": round(PLATE_T - POCKET_DEPTH, 3)}
    return cp.part, info


# ----------------------------------------------------------------------------- checks (CAD level)
def vol(s):
    """Volume of a Shape / ShapeList / Compound (sum of all solids)."""
    if s is None:
        return 0.0
    if isinstance(s, (list, tuple)):
        return float(sum(vol(x) for x in s))
    try:
        sols = s.solids()
    except Exception:
        sols = []
    if sols:
        return float(sum(x.volume for x in sols))
    return float(getattr(s, "volume", 0.0))


def inter_vol(a, b):
    """Common volume of two parts. Raises (does not hide) boolean failures."""
    return vol(a.intersect(b))


def run_checks(plate, bins, placements, out):
    """plate must already be moved to its assembly position; bins are in local frames + placements."""
    ck = {"units": "mm", "checks": []}
    def rec(name, ok, **kw):
        ck["checks"].append({"name": name, "pass": bool(ok), **kw}); print(("PASS " if ok else "FAIL "), name, kw)
    # validity + volumes
    for name, part in [("plate", plate)] + [(b["name"], b["part"]) for b in bins]:
        rec(f"valid_solid:{name}", part.is_valid and len(part.solids()) == 1, volume_mm3=round(vol(part), 1),
            n_solids=len(part.solids()), bbox=[round(v, 3) for v in (part.bounding_box().size.X, part.bounding_box().size.Y, part.bounding_box().size.Z)])
    # fit on plate: no interpenetration at the assembled position; lateral play by shifting
    for b in bins:
        loc = placements[b["name"]]
        moved = b["part"].moved(Location(tuple(loc)))
        iv = inter_vol(moved, plate)
        rec(f"fit_on_plate:{b['name']}", iv < 1e-3, intersection_mm3=round(iv, 4))
    # lateral play of one bin on the plate (shift in +X until the foot chamfers meet the pocket chamfers)
    b0 = bins[0]; loc = placements[b0["name"]]
    play = {}
    for dx in (0.15, 0.25, 0.30, 0.40):
        m = b0["part"].moved(Location((loc[0] + dx, loc[1], loc[2])))
        play[f"{dx:.2f}"] = round(inter_vol(m, plate), 4)
    rec("lateral_play_on_plate", play["0.25"] < 1e-3 and play["0.40"] > 1e-3, intersection_by_x_shift_mm3=play,
        note="free at 0.25 mm, interference at 0.30-0.40 mm: about 0.25-0.3 mm play per side, the standard Gridfinity seating")
    # neighbours do not touch (0.5 mm nominal gap)
    names = [b["name"] for b in bins]
    worst = 0.0
    for i in range(len(bins)):
        for j in range(i + 1, len(bins)):
            li, lj = placements[names[i]], placements[names[j]]
            if abs(li[0] - lj[0]) > PITCH + 1 or abs(li[1] - lj[1]) > 2 * PITCH + 1:
                continue
            iv = inter_vol(bins[i]["part"].moved(Location(tuple(li))), bins[j]["part"].moved(Location(tuple(lj))))
            worst = max(worst, iv)
    rec("neighbour_bins_clear", worst < 1e-3, worst_intersection_mm3=round(worst, 4))
    # stacking: a bin on a bin seats 4.75 below the lip knife-edge plane (surface contact on the lip's upper chamfer)
    lower = bins[4]["part"]; upper = bins[5]["part"]
    seat = bins[4]["info"]["stack_seat_offset_z"]
    stack = {}
    for dz in (0.1, 0.0, -0.15, -0.5):
        stack[f"{dz:.2f}"] = round(inter_vol(upper.moved(Location((0, 0, seat + dz))), lower), 4)
    rec("stacking_seat", stack["0.00"] < 1e-3 and stack["-0.15"] > 1e-3, seat_offset_z=seat, intersection_by_dz_mm3=stack,
        note="0 at the seat and above, interference as soon as the upper bin is pushed lower: the lip chamfer carries it")
    sp = {}
    for d in (0.2, 0.6):
        sp[f"{d:.2f}"] = round(inter_vol(upper.moved(Location((d, 0, seat + d))), lower), 4)
    rec("stacking_lateral_play", sp["0.20"] < 1e-3 and sp["0.60"] > 1e-3, intersection_by_diagonal_shift_mm3=sp,
        note="upper bin moved 0.2 sideways and 0.2 up (riding the 45 deg chamfer) stays clear; 0.6 binds on the vertical sections")
    # finger access: a 16 mm diameter hemispherical-ended fingertip reaches the floor of every compartment through the open top
    def capsule(yc, tilt_deg, r=8.0, L=40.0):
        with BuildPart() as fp:
            Cylinder(r, L, align=(Align.CENTER, Align.CENTER, Align.MIN))
            Sphere(r)
        return fp.part.rotate(Axis.X, tilt_deg).moved(Location((0, yc, FLOOR_Z + r + 0.05)))
    for b in bins:
        detail = []; allok = True
        for cdef in b["info"]["compartments"]:
            y0, y1 = cdef["open_top_y_range_local"]
            found = None
            for tilt in (0, 10, 20):
                for yc in [y0 + 8 + 0.5 * i for i in range(int((y1 - y0 - 16) / 0.5) + 1)]:
                    if inter_vol(capsule(yc, tilt), b["part"]) < 1e-3:
                        found = {"tilt_deg_from_vertical": tilt, "axis_y_local": round(yc, 2)}; break
                if found: break
            allok &= found is not None
            detail.append({"compartment": cdef["index"], "clear_pose": found})
        rec(f"finger16_reaches_floor:{b['name']}", allok, detail=detail,
            note="16 mm fingertip (cylinder with hemispherical tip) at floor level with zero interference; tilt>0 leans the finger towards the user")
    # label cap height vs font minimum
    cap = bins[0]["info"]["label"]["cap_height_measured"]
    rec("label_cap_height_at_least_14w", cap >= 14 * LINE_WIDTH - 0.01, cap_height=cap, line_width=LINE_WIDTH,
        em=FONT_EM, stroke=2 * LINE_WIDTH)
    # geometric clearances derived from the profile numbers (closed form)
    rec("profile_clearances", True,
        foot_vs_pocket_vertical_section_per_side=round((POCKET_TOP - 2*POCKET_CH_TOP - (CELL_TOP - 2*FOOT_CH_TOP)) / 2, 3),
        foot_vs_lip_vertical_section_per_side=round(((CELL_TOP - 2*(2.6 - LIP_CH_BOT)) - (CELL_TOP - 2*FOOT_CH_TOP)) / 2, 3),
        stacked_foot_bottom_below_lip_tip=round(FOOT_H - LIP_H, 3),
        tab_top_below_stacked_foot=round(CEILING_CLEAR - (FOOT_H - LIP_H), 3),
        bin_body_bottom_above_plate_ridge=round(FOOT_H - POCKET_DEPTH, 3))
    with open(out, "w") as f:
        json.dump(ck, f, indent=1)
    return ck


# ----------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=ROOT)
    ap.add_argument("--quick", action="store_true", help="skip the slow boolean checks")
    args = ap.parse_args()
    out = args.out
    for d in ("export/step", "export/stl", "checks"):
        os.makedirs(os.path.join(out, d), exist_ok=True)
    t0 = time.time()

    plate, pinfo = build_plate(GRID_X, GRID_Y)
    ext, einfo = build_plate(1, GRID_Y)
    print(f"plates built {time.time()-t0:.1f}s")
    bins = []
    for spec in BINS:
        part, info = build_bin(spec)
        bins.append({"name": spec.name, "part": part, "info": info})
        print(f"{spec.name}: vol {vol(part):.0f} mm3  {time.time()-t0:.1f}s")

    # placements (assembly frame: plate corner at (0,0,0))
    placements = {}
    W, Lp = GRID_X * PITCH, GRID_Y * PITCH
    for b in bins:
        p = b["info"]["placement"]
        placements[b["name"]] = [PITCH/2 + PITCH * p["col"], PITCH + 2 * PITCH * p["row"], pinfo["bin_rest_z"]]
    plate_loc = [W/2, Lp/2, 0.0]

    # exports
    parts = [("baseplate_5x4", plate, pinfo), ("baseplate_ext_1x4", ext, einfo)] + [(b["name"], b["part"], b["info"]) for b in bins]
    for name, part, info in parts:
        export_step(part, os.path.join(out, "export/step", name + ".step"))
        export_stl(part, os.path.join(out, "export/stl", name + ".stl"), tolerance=0.01, angular_tolerance=0.1)
    print(f"exported {time.time()-t0:.1f}s")

    def tf(t):
        return {"translation_mm": [round(v, 3) for v in t], "rotation_deg_xyz": [0, 0, 0],
                "matrix_4x4_row_major": [[1, 0, 0, round(t[0], 3)], [0, 1, 0, round(t[1], 3)], [0, 0, 1, round(t[2], 3)], [0, 0, 0, 1]]}
    asm = {
        "name": "gridfinity_hardware_starter_5x4", "units": "mm",
        "frame": "assembly origin = baseplate corner (min X, min Y) at the plate underside; +Y is away from the user, labels face -Y/+Z",
        "part_local_origin": "footprint centre, Z=0 at the lowest face",
        "parts": [{"name": "baseplate_5x4", "step": "export/step/baseplate_5x4.step", "stl": "export/stl/baseplate_5x4.stl",
                   "placed": True, "transform": tf(plate_loc), "info": pinfo}] +
                 [{"name": b["name"], "step": f"export/step/{b['name']}.step", "stl": f"export/stl/{b['name']}.stl",
                   "placed": True, "transform": tf(placements[b["name"]]), "info": b["info"]} for b in bins] +
                 [{"name": "baseplate_ext_1x4", "step": "export/step/baseplate_ext_1x4.step", "stl": "export/stl/baseplate_ext_1x4.stl",
                   "placed": False, "note": "optional extension column; butt it against the +X edge of the main plate (translation [231, 84, 0]) when a 6th size is added",
                   "transform": tf([W + PITCH/2, Lp/2, 0.0]), "info": einfo}],
        "parameters": {"pitch": PITCH, "cell_top": CELL_TOP, "wall": WALL, "divider": DIVIDER, "floor_z": FLOOR_Z,
                       "line_width_for_text": LINE_WIDTH, "font_em": FONT_EM, "cap_height": CAP_H, "font": "assets/fillaprint/Fillaprint-Regular.ttf"},
    }
    with open(os.path.join(out, "assembly.json"), "w") as f:
        json.dump(asm, f, indent=1, ensure_ascii=False)
    if not args.quick:
        run_checks(plate.moved(Location(tuple(plate_loc))), bins, placements, os.path.join(out, "checks", "checks_cad.json"))
    print(f"done {time.time()-t0:.1f}s")


if __name__ == "__main__":
    main()
