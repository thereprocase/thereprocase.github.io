#!/usr/bin/env python
"""
Mesh-level checks for the exported STLs (run with the physics runtime):
    python src/check_meshes.py

Writes checks/checks_mesh.json and merges it with checks/checks_cad.json into checks/checks.json.
What is measured (all from the exported meshes, not from the parameters):
  * watertight / consistent winding / single body, volume vs the CAD volume
  * per compartment: ray-cast open-top (the floor area visible from straight above), the
    clear length along the centreline, the usable fill volume below the label-tab underside,
    and the label face: measured cap height of a debossed capital and its stroke width
  * plate: pocket depth and width profile through a cell
"""
import json, math, os, sys
import numpy as np, trimesh

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
asm = json.load(open(os.path.join(ROOT, "assembly.json")))
cad = json.load(open(os.path.join(ROOT, "checks", "checks_cad.json")))
cad_vol = {c["name"].split(":")[1]: c["volume_mm3"] for c in cad["checks"] if c["name"].startswith("valid_solid:")}

out = {"units": "mm", "checks": []}
def rec(name, ok, **kw):
    out["checks"].append({"name": name, "pass": bool(ok), **kw}); print("PASS " if ok else "FAIL ", name, kw)

def hits_down(m, xy, z0=80.0):
    org = np.column_stack([xy, np.full(len(xy), z0)]); d = np.tile([0, 0, -1.0], (len(xy), 1))
    loc, idx, _ = m.ray.intersects_location(org, d, multiple_hits=False)
    z = np.full(len(xy), np.nan); z[idx] = loc[:, 2]
    return z

for p in asm["parts"]:
    name = p["name"]; m = trimesh.load(os.path.join(ROOT, p["stl"]))
    key = "plate" if name == "baseplate_5x4" else name
    v_ok = key in cad_vol and abs(m.volume - cad_vol[key]) / cad_vol[key] < 0.01
    rec(f"mesh:{name}", m.is_watertight and m.is_winding_consistent and m.body_count == 1 and (v_ok or key not in cad_vol),
        watertight=m.is_watertight, winding_consistent=m.is_winding_consistent, bodies=m.body_count,
        faces=len(m.faces), volume_mm3=round(float(m.volume), 1), cad_volume_mm3=cad_vol.get(key),
        bbox_min=np.round(m.bounds[0], 3).tolist(), bbox_max=np.round(m.bounds[1], 3).tolist())
    info = p["info"]
    if name.startswith("bin"):
        floor = info["floor_z"]; ox, oy = info["footprint"]
        # 0.5 mm grid over the whole footprint; a column is "open to the floor" if the first hit from above is the floor
        xs = np.arange(-ox/2 + 0.25, ox/2, 0.5); ys = np.arange(-oy/2 + 0.25, oy/2, 0.5)
        X, Y = np.meshgrid(xs, ys); xy = np.column_stack([X.ravel(), Y.ravel()])
        z = hits_down(m, xy).reshape(Y.shape)
        comps = []
        zcap = info["lip_tip_z"]
        for c in info["compartments"]:
            y0, y1 = c["floor_y_range_local"]; r = c["scoop_radius"]
            sel = (Y >= y0) & (Y <= y1) & (np.abs(X) <= info["footprint"][0]/2 - 1.2)
            flat = sel & (np.abs(z - floor) < 0.05)                 # flat floor seen from straight above
            opened = sel & (z <= floor + r + 0.1)                   # floor or scoop ramp seen from straight above
            ci = np.argmin(np.abs(xs))
            def run_len(mask):
                col = mask[:, ci]; ysel = Y[:, ci][col]
                return float(ysel.max() - ysel.min() + 0.5) if col.any() else 0.0
            open_len, flat_len = run_len(opened), run_len(flat)
            if flat[:, ci].any():
                ysel = Y[:, ci][flat[:, ci]]; ym = (ysel.max() + ysel.min()) / 2
                ri = np.argmin(np.abs(ys - ym)); row = flat[ri, :]; xsel = xs[row]
                clear_w = float(xsel.max() - xsel.min() + 0.5)
            else:
                clear_w = 0.0
            # usable volume: every column over the compartment floor; surface = floor/scoop if visible from
            # above, else the floor under the label tab; top = first surface above (tab underside) or the lip tip plane
            cols = np.column_stack([X[sel], Y[sel]]); zs = np.where(opened[sel], z[sel], floor)
            org = np.column_stack([cols, zs + 0.05]); d = np.tile([0, 0, 1.0], (len(cols), 1))
            loc, idx, _ = m.ray.intersects_location(org, d, multiple_hits=False)
            top = np.full(len(cols), zcap); top[idx] = np.minimum(loc[:, 2], zcap)
            usable = float(np.clip(top - zs, 0, None).sum() * 0.25)
            comps.append({"index": c["index"], "label": c["label"],
                          "open_top_length_centreline": round(open_len, 2), "flat_floor_length_centreline": round(flat_len, 2),
                          "clear_width": round(clear_w, 2), "open_top_area_mm2": round(float(opened.sum() * 0.25), 1),
                          "usable_volume_to_lip_tip_cm3": round(usable / 1000, 1), "expected_open_length": c["open_top_length"]})
        ok = all(abs(cc["open_top_length_centreline"] - cc["expected_open_length"]) < 1.6 and cc["clear_width"] >= 36.0 for cc in comps)
        rec(f"compartments:{name}", ok, compartments=comps,
            criterion="ray-cast open top length (0.5 mm grid, scoop top counted to r+0.1) matches the design value within 1.6 mm and clear width >= 36 mm")
        # label metrics from the mesh: sample the first label face, measure the debossed capital height and stroke width
        c = info["compartments"][-1]; cx, cy, cz = c["label_face_center_local"]; L = info["label"]["slope_length"]
        a = math.radians(info["label"]["face_angle_deg"]); n = np.array([0, -math.sin(a), math.cos(a)]); up = np.array([0, math.cos(a), math.sin(a)])
        us = np.arange(-19, 19.001, 0.05); vs = np.arange(-L/2, L/2 + 1e-9, 0.05)
        U, V = np.meshgrid(us, vs)
        org = np.array([cx, cy, cz]) + U.ravel()[:, None] * np.array([1.0, 0, 0]) + V.ravel()[:, None] * up + 2.0 * n
        d = np.tile(-n, (len(org), 1))
        loc, idx, _ = m.ray.intersects_location(org, d, multiple_hits=False)
        dep = np.full(len(org), np.nan); dep[idx] = np.einsum("ij,j->i", loc - org[idx], -n) - 2.0
        D = dep.reshape(V.shape)
        edge = (np.abs(V) > L/2 - 0.6) | (np.abs(U) > 18.0)      # rays grazing the face edges are not label ink
        ink = (D > 0.3) & (D < 1.5) & ~edge
        rows_with_ink = np.where(ink.any(axis=1))[0]
        bands = [b for b in np.split(rows_with_ink, np.where(np.diff(rows_with_ink) > 1)[0] + 1) if len(b) > 5]
        band_h = [round(float((b.max() - b.min() + 1) * 0.05), 2) for b in bands]
        b = bands[-1]; mid = ink[(b.min() + b.max()) // 2]
        runs = np.diff(np.where(np.diff(np.concatenate([[0], mid.astype(int), [0]])))[0])[::2] * 0.05
        depth_med = float(np.median(D[ink]))
        rec(f"label_metrics:{name}", len(bands) == info["label"]["lines"] and all(abs(h - info["label"]["cap_height_measured"]) < 0.15 for h in band_h)
            and runs.min() >= 2 * asm["parameters"]["line_width_for_text"] - 0.1 and abs(depth_med - info["label"]["deboss_depth"]) < 0.1,
            text_line_heights=band_h, nominal_cap=info["label"]["cap_height_measured"], lines=len(bands),
            min_stroke_run=round(float(runs.min()), 2), stroke_runs_sample=np.round(runs[:12], 2).tolist(),
            deboss_depth_median=round(depth_med, 2), nominal_depth=info["label"]["deboss_depth"])
    elif name == "baseplate_5x4":
        xs = np.arange(-105, -62.9, 0.05); z = hits_down(m, np.column_stack([xs, np.full(len(xs), -63.0)]), 20)
        floor = float(np.nanmin(z)); top = 6.0
        at = lambda zz: xs[np.argmax(z <= zz + 1e-6)]  # first x where the profile is at/below zz
        rec("plate_pocket_profile", abs(top - floor - info["pocket_depth"]) < 0.06,
            pocket_depth=round(top - floor, 3), top_width=round(float(2 * (-84 - at(top - 0.001))), 2),
            vertical_section_width=round(float(2 * (-84 - at(top - 2.1 - 0.9))), 2), floor_width=round(float(2 * (-84 - at(floor + 0.01))), 2))

json.dump(out, open(os.path.join(ROOT, "checks", "checks_mesh.json"), "w"), indent=1, ensure_ascii=False)
merged = {"units": "mm", "cad_checks": cad["checks"], "mesh_checks": out["checks"],
          "all_pass": all(c["pass"] for c in cad["checks"] + out["checks"])}
json.dump(merged, open(os.path.join(ROOT, "checks", "checks.json"), "w"), indent=1, ensure_ascii=False)
print("ALL PASS" if merged["all_pass"] else "SOME CHECKS FAILED")
