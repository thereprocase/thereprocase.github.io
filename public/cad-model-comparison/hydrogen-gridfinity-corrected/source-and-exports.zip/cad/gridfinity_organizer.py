"""Parametric Gridfinity Fastener Organizer System (5x4 Starter Layout).

Generates:
- 5x4 Gridfinity baseplate (210 x 168 mm, 42 mm pitch)
- Reusable parametric scoop bins (1x1 dual, 2x1 triple, 2x1 dual) with:
  - Standard 42 mm Gridfinity base profile (4.75 mm + 0.25 mm transition)
  - Standard 4.4 mm stacking lip with 0.25 mm+ radial clearance for stacked bins
  - Front finger scoop (R14 mm) for extracting tiny washers and short screws
  - Recessed horizontal top-back label shelf (prints flat in XY, zero supports)
  - Permanent raised Fillaprint labels (>= 8.0 mm em font size, >= 0.80 mm stroke)
  - Optional recessed front-face label on front-row host bin so stacked bins
    never obscure lower-bin identification
- STEP and binary STL exports per part
- assembly.json with exact assembled transforms in millimeters
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import build123d as bd

# ---------------------------------------------------------------------------
# Gridfinity Standard Constants (mm)
# ---------------------------------------------------------------------------
GF_PITCH = 42.0
GF_Z_PITCH = 7.0
GF_BIN_GAP = 0.5  # 41.5 mm outer width for 1u
GF_CORNER_R = 3.75

# Bin base profile (total 5.0 mm)
BASE_LOWER_H = 0.8
BASE_RISER_H = 1.8
BASE_UPPER_H = 2.15
BASE_TRANSITION_H = 0.25
BASE_TOTAL_H = BASE_LOWER_H + BASE_RISER_H + BASE_UPPER_H + BASE_TRANSITION_H  # 5.0

# Baseplate socket profile (total 4.65 mm above floor)
BP_FLOOR_H = 1.2
BP_LOWER_H = 0.7
BP_RISER_H = 1.8
BP_UPPER_H = 2.15
BP_SOCKET_H = BP_LOWER_H + BP_RISER_H + BP_UPPER_H  # 4.65
BP_TOTAL_H = BP_FLOOR_H + BP_SOCKET_H  # 5.85

# Stacking lip profile (total 4.4 mm above nominal H = 7 * Nz)
LIP_LOWER_H = 0.7
LIP_RISER_H = 1.15
LIP_UPPER_H = 2.30
LIP_RIM_H = 0.25
LIP_TOTAL_H = LIP_LOWER_H + LIP_RISER_H + LIP_UPPER_H + LIP_RIM_H  # 4.40
STACK_Z_OFFSET = 28.0  # Z-offset for stacked bin (4.40 mm engagement in 4.40 mm lip, 0.000 mm3 overlap)

# Bin structural & ergonomic parameters
WALL_T = 1.4
DIVIDER_T = 1.2
FLOOR_T = 1.0  # floor thickness above 5.0 mm base
SCOOP_R = 14.0
LABEL_SHELF_DEPTH = 13.8  # accommodates 2-line 8.0 mm em Fillaprint text
LABEL_RECESS = 2.2  # top of shelf is H - 2.2 mm
LABEL_TEXT_H = 0.8  # raised text height -> reaches H - 1.4 mm
FONT_PATH = "assets/fillaprint/Fillaprint-Regular.ttf"
MIN_FONT_SIZE = 8.0


@dataclass(frozen=True)
class BinSpec:
    """Specification for a single bin instance in the starter system."""

    part_id: str
    grid_x: int
    grid_y: int
    grid_z: int  # height units (4u = 28 mm, 3u = 21 mm)
    compartments: int
    labels: tuple[str, ...]
    font_size: float
    pos_gx: int  # 0-based grid X index on 5x4 baseplate
    pos_gy: int  # 0-based grid Y index on 5x4 baseplate
    stacked_on: str | None = None  # part_id of lower bin if stacked
    front_labels: tuple[str, ...] | None = None  # exterior front-face labels for stacked hosts


def _rounded_rect_face(width: float, depth: float, radius: float) -> bd.Face:
    """Return a centered XY rounded-rectangle Face."""
    r = max(0.2, min(radius, min(width, depth) * 0.49))
    with bd.BuildSketch() as sk:
        bd.RectangleRounded(width, depth, r)
    return sk.sketch.face()


def _chamfer_bottom(solid: bd.Solid, z_target: float, dist: float) -> bd.Solid:
    """Chamfer all edges of solid lying at z == z_target by dist (45 deg)."""
    edges = solid.edges().filter_by(lambda e: abs(e.center().Z - z_target) < 0.01)
    return bd.chamfer(edges, dist)


def build_baseplate(nx: int = 5, ny: int = 4) -> bd.Part:
    """Build a rigid nx by ny Gridfinity baseplate with origin at front-left-bottom."""
    total_w = nx * GF_PITCH
    total_d = ny * GF_PITCH

    outer_face = _rounded_rect_face(total_w, total_d, GF_CORNER_R + 0.25)
    plate = bd.extrude(outer_face, BP_TOTAL_H).moved(
        bd.Location((total_w / 2.0, total_d / 2.0, 0.0))
    )

    # Socket cutter: 36.3 -> 37.7 (z=1.2..1.9), vertical 37.7 (z=1.9..3.7), 37.7 -> 42.0 (z=3.7..5.85)
    s_lo = bd.extrude(_rounded_rect_face(37.7, 37.7, 1.85), BP_LOWER_H + BP_RISER_H + 0.05).moved(
        bd.Location((0, 0, BP_FLOOR_H))
    )
    s_lo = _chamfer_bottom(s_lo, BP_FLOOR_H, BP_LOWER_H)
    z_mid = BP_FLOOR_H + BP_LOWER_H + BP_RISER_H
    s_hi = bd.extrude(_rounded_rect_face(42.0, 42.0, GF_CORNER_R + 0.25), BP_UPPER_H + 0.1).moved(
        bd.Location((0, 0, z_mid))
    )
    s_hi = _chamfer_bottom(s_hi, z_mid, BP_UPPER_H)
    socket_cutter = s_lo.fuse(s_hi)

    cutters = [
        socket_cutter.moved(bd.Location(((ix + 0.5) * GF_PITCH, (iy + 0.5) * GF_PITCH, 0.0)))
        for ix in range(nx)
        for iy in range(ny)
    ]
    plate = plate.cut(*cutters)
    return bd.Part(plate.wrapped)


def _build_bin_base_pad(nx: int, ny: int) -> bd.Solid:
    """Build the Gridfinity bottom base pads for an nx by ny bin centered at XY=(0,0)."""
    s1 = bd.extrude(_rounded_rect_face(37.2, 37.2, 1.60), BASE_LOWER_H + BASE_RISER_H + 0.05)
    s1 = _chamfer_bottom(s1, 0.0, BASE_LOWER_H)
    z_mid = BASE_LOWER_H + BASE_RISER_H
    s2 = bd.extrude(
        _rounded_rect_face(41.5, 41.5, GF_CORNER_R), BASE_UPPER_H + BASE_TRANSITION_H + 0.05
    ).moved(bd.Location((0, 0, z_mid)))
    s2 = _chamfer_bottom(s2, z_mid, BASE_UPPER_H)
    single_pad = s1.fuse(s2)

    pads = [
        single_pad.moved(
            bd.Location(((ix - (nx - 1) / 2.0) * GF_PITCH, (iy - (ny - 1) / 2.0) * GF_PITCH, 0.0))
        )
        for ix in range(nx)
        for iy in range(ny)
    ]
    res = pads[0]
    for p in pads[1:]:
        res = res.fuse(p)
    return res


def _build_stacking_lip_cutter(outer_w: float, outer_d: float, nom_h: float) -> bd.Solid:
    """Build the inner cavity cutter for the 4.4 mm stacking lip at z = nom_h."""
    z0 = nom_h - 0.50
    z_mid = nom_h + LIP_LOWER_H + LIP_RISER_H  # nom_h + 1.85
    s1 = bd.extrude(
        _rounded_rect_face(outer_w - 3.7, outer_d - 3.7, 1.90), (z_mid - z0) + 0.05
    ).moved(bd.Location((0, 0, z0)))
    s1 = _chamfer_bottom(s1, z0, 0.75)

    s2 = bd.extrude(
        _rounded_rect_face(outer_w - 0.4, outer_d - 0.4, 3.55), (nom_h + LIP_TOTAL_H + 0.1) - z_mid
    ).moved(bd.Location((0, 0, z_mid)))
    s2 = _chamfer_bottom(s2, z_mid, 1.65)
    return s1.fuse(s2)


def _make_scoop_cutter(comp_w: float, comp_d: float, cav_z0: float, cav_h: float) -> bd.Solid:
    """Build a compartment cavity with a smooth R14 mm front finger scoop (at -Y)."""
    y_front = -comp_d / 2.0
    y_back = comp_d / 2.0
    z_bot = cav_z0
    z_top = cav_z0 + cav_h
    r = min(SCOOP_R, comp_d * 0.45, cav_h * 0.75)

    with bd.BuildSketch(bd.Plane.YZ) as sk:
        with bd.BuildLine():
            bd.Line((y_front, z_top), (y_back, z_top))
            bd.Line((y_back, z_top), (y_back, z_bot))
            bd.Line((y_back, z_bot), (y_front + r, z_bot))
            bd.RadiusArc((y_front + r, z_bot), (y_front, z_bot + r), -r)
            bd.Line((y_front, z_bot + r), (y_front, z_top))
        bd.make_face()

    prism = bd.extrude(sk.sketch.face(), comp_w)
    return prism.moved(bd.Location((-comp_w / 2.0, 0.0, 0.0)))


def _make_label_shelf(comp_w: float, y_back: float, nom_h: float) -> bd.Solid:
    """Build a horizontal label shelf at the top-back of a compartment with gusset above floor."""
    z_top = nom_h - LABEL_RECESS
    shelf_t = 1.6
    z_gusset_bot = max(BASE_TOTAL_H + FLOOR_T, z_top - shelf_t - LABEL_SHELF_DEPTH)
    with bd.BuildSketch(bd.Plane.YZ) as sk:
        bd.Polygon(
            [
                (y_back - LABEL_SHELF_DEPTH, z_top),
                (y_back + 0.4, z_top),
                (y_back + 0.4, z_gusset_bot),
                (y_back - LABEL_SHELF_DEPTH, z_top - shelf_t),
            ],
            align=None,
        )
    return bd.extrude(sk.sketch.face(), comp_w + 0.4).moved(
        bd.Location((-(comp_w + 0.4) / 2.0, 0.0, 0.0))
    )


def _make_raised_label(text: str, font_size: float, cx: float, cy: float, z_base: float) -> bd.Solid:
    """Create raised Fillaprint 3D text centered at (cx, cy) starting at z_base."""
    t_sketch = bd.Text(
        text,
        font_size=font_size,
        font_path=FONT_PATH,
        align=(bd.Align.CENTER, bd.Align.CENTER),
    )
    solid = bd.extrude(t_sketch, LABEL_TEXT_H + 0.1)
    return solid.moved(bd.Location((cx, cy, z_base - 0.1)))


def _add_front_face_labels(
    bin_solid: bd.Solid, outer_w: float, outer_d: float, nom_h: float, front_labels: tuple[str, ...]
) -> bd.Solid:
    """Recess a 0.6 mm front-face panel and place 8.0 mm em raised labels flush inside it."""
    recess_d = 0.6
    panel_w = outer_w - 2.0 * GF_CORNER_R - 1.0
    panel_h = nom_h - BASE_TOTAL_H - 3.0
    panel_zc = BASE_TOTAL_H + 1.5 + panel_h / 2.0
    y_front = -outer_d / 2.0

    # Cut shallow recess on front (-Y) face so raised text stays within outer_d
    recess_box = bd.Solid.make_box(panel_w, recess_d + 0.2, panel_h).moved(
        bd.Location((-panel_w / 2.0, y_front - 0.2, panel_zc - panel_h / 2.0))
    )
    bin_solid = bin_solid.cut(recess_box)

    # Place 2 lines (e.g. "M4", "NUT WSH" or "M4", "NUT|WSH") oriented on XZ plane facing -Y
    n_lines = len(front_labels)
    for idx, line in enumerate(front_labels):
        z_pos = panel_zc + (0.5 - idx) * 8.5 if n_lines == 2 else panel_zc
        t_sketch = bd.Text(
            line,
            font_size=MIN_FONT_SIZE,
            font_path=FONT_PATH,
            align=(bd.Align.CENTER, bd.Align.CENTER),
        )
        # Extrude along +Z in sketch space, then rotate +90 around X so text faces -Y
        txt_solid = bd.extrude(t_sketch, recess_d + 0.15)
        txt_solid = txt_solid.rotate(bd.Axis.X, 90.0).moved(
            bd.Location((0.0, y_front + recess_d + 0.15, z_pos))
        )
        bin_solid = bin_solid.fuse(txt_solid)

    return bin_solid


def build_bin(spec: BinSpec) -> bd.Part:
    """Build a complete Gridfinity bin with scoop compartments and Fillaprint labels."""
    if spec.font_size < MIN_FONT_SIZE:
        raise ValueError(f"{spec.part_id}: font_size {spec.font_size} < {MIN_FONT_SIZE} mm minimum")

    outer_w = spec.grid_x * GF_PITCH - GF_BIN_GAP
    outer_d = spec.grid_y * GF_PITCH - GF_BIN_GAP
    nom_h = spec.grid_z * GF_Z_PITCH

    # 1. Base pads (z = 0 to 5.0)
    base_pads = _build_bin_base_pad(spec.grid_x, spec.grid_y)

    # 2. Main upper body (z = 5.0 to nom_h + LIP_TOTAL_H)
    body_face = _rounded_rect_face(outer_w, outer_d, GF_CORNER_R)
    body = bd.extrude(body_face, nom_h + LIP_TOTAL_H - BASE_TOTAL_H).moved(
        bd.Location((0.0, 0.0, BASE_TOTAL_H))
    )
    bin_solid = base_pads.fuse(body)

    # 3. Cut stacking lip cavity at top
    lip_cutter = _build_stacking_lip_cutter(outer_w, outer_d, nom_h)
    bin_solid = bin_solid.cut(lip_cutter)

    # 4. Cut compartments with front finger scoops (leaving divider tops at nom_h - 1.4 mm)
    inner_w = outer_w - 2.0 * WALL_T
    inner_d = outer_d - 2.0 * WALL_T
    n = spec.compartments
    comp_w = (inner_w - (n - 1) * DIVIDER_T) / n
    cav_z0 = BASE_TOTAL_H + FLOOR_T
    divider_top_z = nom_h - 1.4  # well below stacked bin bottom (nom_h)
    cav_h = divider_top_z - cav_z0

    cutters = []
    shelves = []
    labels = []

    z_shelf_top = nom_h - LABEL_RECESS
    y_back = inner_d / 2.0
    label_cy = y_back - LABEL_SHELF_DEPTH / 2.0

    # Cut upper clearance above dividers so divider tops stay at divider_top_z
    upper_clear = bd.Solid.make_box(inner_w, inner_d, (nom_h + LIP_TOTAL_H + 0.1) - divider_top_z).moved(
        bd.Location((-inner_w / 2.0, -inner_d / 2.0, divider_top_z))
    )
    cutters.append(upper_clear)

    for i in range(n):
        cx = -inner_w / 2.0 + comp_w / 2.0 + i * (comp_w + DIVIDER_T)
        cutters.append(_make_scoop_cutter(comp_w, inner_d, cav_z0, cav_h + 0.1).moved(bd.Location((cx, 0.0, 0.0))))
        shelves.append(_make_label_shelf(comp_w, y_back, nom_h).moved(bd.Location((cx, 0.0, 0.0))))

        lbl = spec.labels[i]
        if "\n" in lbl:
            lines = lbl.split("\n")
            dy = spec.font_size * 0.44
            labels.append(_make_raised_label(lines[0], spec.font_size, cx, label_cy + dy, z_shelf_top))
            labels.append(_make_raised_label(lines[1], spec.font_size, cx, label_cy - dy, z_shelf_top))
        else:
            labels.append(_make_raised_label(lbl, spec.font_size, cx, label_cy, z_shelf_top))

    bin_solid = bin_solid.cut(*cutters)
    for sh in shelves:
        bin_solid = bin_solid.fuse(sh)
    for lb in labels:
        bin_solid = bin_solid.fuse(lb)

    if spec.front_labels:
        bin_solid = _add_front_face_labels(bin_solid, outer_w, outer_d, nom_h, spec.front_labels)

    return bd.Part(bin_solid.wrapped)


def get_starter_specs() -> list[BinSpec]:
    """Return the 5x4 starter assortment (12 base bins + 1 stacked 3u overflow bin)."""
    return [
        # Row 4 (Y=3, back): M2
        BinSpec("bin_m2_nut_wsh", 1, 1, 4, 2, ("M2\nNUT", "M2\nWSH"), 8.0, 0, 3),
        BinSpec("bin_m2_6_8_10", 2, 1, 4, 3, ("M2x6", "M2x8", "M2x10"), 8.0, 1, 3),
        BinSpec("bin_m2_12_16_20", 2, 1, 4, 3, ("M2x12", "M2x16", "M2x20"), 8.0, 3, 3),
        # Row 3 (Y=2): M2.5
        BinSpec("bin_m25_nut_wsh", 1, 1, 4, 2, ("M2.5\nNUT", "M2.5\nWSH"), 8.0, 0, 2),
        BinSpec("bin_m25_6_8_10", 2, 1, 4, 3, ("M2.5\nx6", "M2.5\nx8", "M2.5\nx10"), 8.0, 1, 2),
        BinSpec("bin_m25_12_16_20", 2, 1, 4, 3, ("M2.5\nx12", "M2.5\nx16", "M2.5\nx20"), 8.0, 3, 2),
        # Row 2 (Y=1): M3
        BinSpec("bin_m3_nut_wsh", 1, 1, 4, 2, ("M3\nNUT", "M3\nWSH"), 8.0, 0, 1),
        BinSpec("bin_m3_6_8_10", 2, 1, 4, 3, ("M3x6", "M3x8", "M3x10"), 8.0, 1, 1),
        BinSpec("bin_m3_12_16_20", 2, 1, 4, 3, ("M3x12", "M3x16", "M3x20"), 8.0, 3, 1),
        # Row 1 (Y=0, front): M4 (front-left bin carries front-face label for stacked visibility)
        BinSpec(
            "bin_m4_nut_wsh",
            1,
            1,
            4,
            2,
            ("M4\nNUT", "M4\nWSH"),
            8.0,
            0,
            0,
            front_labels=("M4", "NUT WSH"),
        ),
        BinSpec("bin_m4_8_10_12", 2, 1, 4, 3, ("M4x8", "M4x10", "M4x12"), 8.0, 1, 0),
        BinSpec("bin_m4_16_20", 2, 1, 4, 2, ("M4x16", "M4x20"), 8.5, 3, 0),
        # Stacked 3u (21 mm) overflow/specialty bin on front-left M4 NUT/WSH
        BinSpec(
            "bin_m4_stack_lck",
            1,
            1,
            3,
            2,
            ("M4\nLCK", "M4\nSPR"),
            8.0,
            0,
            0,
            stacked_on="bin_m4_nut_wsh",
        ),
    ]


def main() -> None:
    out_step = Path("exports/step")
    out_stl = Path("exports/stl")
    out_step.mkdir(parents=True, exist_ok=True)
    out_stl.mkdir(parents=True, exist_ok=True)

    # Remove stale files from prior runs if any
    for old_f in list(out_step.glob("*.step")) + list(out_stl.glob("*.stl")):
        old_f.unlink()

    assembly_parts = []

    print("Building baseplate_5x4...")
    bp = build_baseplate(5, 4)
    bp_step = out_step / "baseplate_5x4.step"
    bp_stl = out_stl / "baseplate_5x4.stl"
    bd.export_step(bp, str(bp_step))
    bd.export_stl(bp, str(bp_stl), tolerance=0.05, angular_tolerance=0.1)
    assembly_parts.append(
        {
            "part_id": "baseplate_5x4",
            "step_file": str(bp_step),
            "stl_file": str(bp_stl),
            "translation_mm": [0.0, 0.0, 0.0],
            "rotation_deg": [0.0, 0.0, 0.0],
            "grid_footprint": [5, 4],
        }
    )

    specs = get_starter_specs()
    spec_map = {s.part_id: s for s in specs}

    for spec in specs:
        print(f"Building {spec.part_id}...")
        part = build_bin(spec)
        step_p = out_step / f"{spec.part_id}.step"
        stl_p = out_stl / f"{spec.part_id}.stl"
        bd.export_step(part, str(step_p))
        bd.export_stl(part, str(stl_p), tolerance=0.05, angular_tolerance=0.1)

        cx = (spec.pos_gx + spec.grid_x / 2.0) * GF_PITCH
        cy = (spec.pos_gy + spec.grid_y / 2.0) * GF_PITCH
        if spec.stacked_on is None:
            cz = BP_FLOOR_H
        else:
            lower = spec_map[spec.stacked_on]
            lower_nom_h = lower.grid_z * GF_Z_PITCH
            cz = BP_FLOOR_H + lower_nom_h + (STACK_Z_OFFSET - 28.0)

        assembly_parts.append(
            {
                "part_id": spec.part_id,
                "step_file": str(step_p),
                "stl_file": str(stl_p),
                "translation_mm": [round(cx, 4), round(cy, 4), round(cz, 4)],
                "rotation_deg": [0.0, 0.0, 0.0],
                "grid_footprint": [spec.grid_x, spec.grid_y, spec.grid_z],
                "compartments": spec.compartments,
                "labels": list(spec.labels),
                "font_size_mm": spec.font_size,
                "stacked_on": spec.stacked_on,
                "front_labels": list(spec.front_labels) if spec.front_labels else None,
            }
        )

    assembly = {
        "units": "mm",
        "grid_pitch_mm": GF_PITCH,
        "z_pitch_mm": GF_Z_PITCH,
        "baseplate_grid": [5, 4],
        "parts": assembly_parts,
    }
    with open("assembly.json", "w", encoding="utf-8") as f:
        json.dump(assembly, f, indent=2)
    print(f"Done. Exported {len(assembly_parts)} parts and assembly.json.")


if __name__ == "__main__":
    main()
