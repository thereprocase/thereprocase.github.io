# Gridfinity Fastener Organizer System (5×4 Starter Layout)

A coherent, parametric 42 mm Gridfinity organizer system for hobby machine screws (M2, M2.5, M3, M4 socket-head cap screws), matching plain hex nuts, and flat washers.

## Design Philosophy & Starter Assortment

The system uses a **5 × 4 Gridfinity footprint (210 × 168 mm)** with **one row per thread diameter** (front-to-back: M4, M3, M2.5, M2) and **three reusable bin geometries** (all 4u / 28 mm nominal height, 32.4 mm with stacking lip, plus a 3u / 21 mm stackable overflow bin):

| Row | Thread | Col 1 (`1×1 Dual`) | Cols 2–3 (`2×1 Triple`) | Cols 4–5 (`2×1 Triple` / `2×1 Dual`) |
| :--- | :--- | :--- | :--- | :--- |
| **4 (Back)** | **M2** | `M2 NUT` \| `M2 WSH` | `M2x6` \| `M2x8` \| `M2x10` | `M2x12` \| `M2x16` \| `M2x20` |
| **3** | **M2.5** | `M2.5 NUT` \| `M2.5 WSH` | `M2.5x6` \| `M2.5x8` \| `M2.5x10` | `M2.5x12` \| `M2.5x16` \| `M2.5x20` |
| **2** | **M3** | `M3 NUT` \| `M3 WSH` | `M3x6` \| `M3x8` \| `M3x10` | `M3x12` \| `M3x16` \| `M3x20` |
| **1 (Front)** | **M4** | `M4 NUT` \| `M4 WSH` *(+ front-face `M4` / `NUT WSH`)* | `M4x8` \| `M4x10` \| `M4x12` | `M4x16` \| `M4x20` |
| **Stacked** | **M4+** | `M4 LCK` \| `M4 SPR` (`3u` stacked on `bin_m4_nut_wsh`) | — | — |

- **Capacity**: Each screw compartment holds 20+ socket-head screws (verified up to M4×20 in `2×1 Dual` and M3×20 in `2×1 Triple`); each nut/washer compartment holds 30+ hex nuts or flat washers.
- **Ergonomics**: Every compartment has an **R14 mm front finger scoop** so tiny M2 washers and 6 mm screws slide easily up the ramp under a fingertip.
- **Permanent Fillaprint Labels**: Raised `0.8 mm` text using `Fillaprint-Regular.ttf` at **8.0–8.5 mm em** (at or above FillaPrint's 8 mm em minimum for 0.4 mm lines; ≥ 0.80 mm stroke width) on a recessed horizontal top-back shelf (`13.8 mm` deep, `2.2 mm` below nominal top). Front-row host `bin_m4_nut_wsh` also carries an unobstructed `8.0 mm` em recessed front-face label (`M4` / `NUT WSH`) so its contents remain legible while `bin_m4_stack_lck` is stacked on top.
- **Stacking & Lifting**: Divider tops stop at `nom_h - 1.4 mm` (`26.6 mm`) and the `4.4 mm` stacking lip provides ≥ 0.25 mm radial clearance for a stacked bin seated at `z_offset = 28.0 mm`, yielding zero mesh intersection across 1×1 and 2×1 host placements. Individual bins maintain `0.500 mm` XY clearance to neighbors and seat `4.65 mm` into the baseplate so any bin can be lifted straight out without tipping adjacent bins.
- **Extensibility**: Add another thread size (e.g. M5) by adding a `5×1` row in `get_starter_specs()` and adjusting `(nx, ny)` in `build_baseplate()`.

## Files

- `cad/gridfinity_organizer.py` — Parametric `build123d` source generating all parts and `assembly.json`
- `exports/step/*.step` — STEP B-rep files per part
- `exports/stl/*.stl` — Binary STL files per part
- `assembly.json` — Assembled part transforms in millimeters
- `verify.py` — Mesh, clearance, stacking, label, and capacity verification script

## Printing & Physical Fit Test Notes

- **Recommended Print Settings**: 0.4 mm nozzle, 0.2 mm layer height, 2–3 perimeters, 15% gyroid infill, PLA or PETG, no supports required.
- **Needs Physical Fit Test**:
  - Real-world FDM elephant-foot / XY shrinkage on the `0.25 mm` radial baseplate-to-bin socket clearance and `4.4 mm` stacking lip fit.
  - Visual legibility of the `0.6 mm` recessed front-face `M4 / NUT WSH` label on `bin_m4_nut_wsh` (vertical-wall printing vs flat top-shelf printing).
