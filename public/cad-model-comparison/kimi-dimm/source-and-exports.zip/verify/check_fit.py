"""
Functional verification of the DIMM mailer meshes (runs on the physics venv).

Checks are measured from the exported binary STLs, not from design intent:
  1. Mesh health: watertight, winding, volume vs CAD, bounding boxes.
  2. Assembled pose from assembly.json: no lid/base interpenetration.
  3. Detent: nub tip vs groove floor/walls measured by ray casts (engagement,
     axial play, skirt gap, rim landing).
  4. Pocket fit: worst-case bagged module envelope (138.4 x 47.4 x 10.9 mm)
     must not intersect the base in any extreme pose (end/side play, yaw,
     straight-lift removal sweep, tilted removal).
  5. Gold-contact protection: a contact-strip solid on the module's bottom-edge
     (5 mm tall strips on both faces + the edge face) must stay >= 1.0 mm from
     every rigid surface, in the worst poses.
  6. Finger access: scoop and divider-notch opening depth/width measured.
  7. Labels: deboss depth measured; per-line text width compared with the
     Fillaprint TTF metrics (proves the real font, >= its 9 mm minimum size).

Writes verify/checks.json and verify/checks.md. Exit code 0 = all pass.
"""

import json
import math
import os
import sys

import numpy as np
import trimesh

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE_STL = os.path.join(ROOT, "out", "base.stl")
LID_STL = os.path.join(ROOT, "out", "lid.stl")
ASM_JSON = os.path.join(ROOT, "assembly.json")
FONT = os.path.join(ROOT, "assets", "fillaprint", "Fillaprint-Regular.ttf")

# design constants (mirrors src/mailer_cad.py)
BASE_H, WALL, FLOOR = 14.5, 2.4, 2.0
POCKET_L, POCKET_W, POCKET_D = 140.0, 50.5, 12.5
POCKET_Y = 26.25
NUB_Z, NUB_PROTRUDE, NUB_TIP_H = 2.8, 0.7, 0.8
GROOVE_D, GROOVE_H, GAP, SKIRT_T = 0.85, 2.8, 0.25, 2.0
STICK = (136.0, 45.0, 8.5)
BAG = 1.2
ENV = (STICK[0] + 2 * BAG, STICK[1] + 2 * BAG, STICK[2] + 2 * BAG)  # 138.4x47.4x10.9
STRIP = 5.0  # gold-contact-adjacent strip height on module faces

results = []


def check(name, ok, detail):
    results.append({"check": name, "pass": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL "), name, "-", detail)


def ray_hit(mesh, origin, direction, n=1):
    o = np.array(origin, dtype=float)
    dvec = np.array(direction, dtype=float)
    locs, _, _ = mesh.ray.intersects_location([o], [dvec], multiple_hits=True)
    if len(locs) == 0:
        return None
    d = sorted(float(np.dot(p - o, dvec)) for p in locs)
    return [o + dvec * t for t in d[:n]]


def first_hit(mesh, origin, direction):
    h = ray_hit(mesh, origin, direction, 1)
    return h[0] if h else None


def vol_intersect(a, b):
    try:
        inter = trimesh.boolean.intersection([a, b], engine="manifold")
        return float(inter.volume)
    except Exception as e:  # noqa
        return float("nan")


def main():
    base = trimesh.load(BASE_STL)
    lid = trimesh.load(LID_STL)
    asm = json.load(open(ASM_JSON))
    tz = asm["parts"][1]["translation_mm"][2]
    lid_a = lid.copy()
    lid_a.apply_translation([0, 0, tz])

    # ---- 1. mesh health -------------------------------------------------
    for name, m, cad_vol in (("base", base, 43734), ("lid", lid, 43902)):
        bb = m.bounds
        size = bb[1] - bb[0]
        check(f"{name} watertight+winding", m.is_watertight and m.is_winding_consistent,
              f"watertight={m.is_watertight} winding={m.is_winding_consistent}")
        check(f"{name} volume", abs(m.volume - cad_vol) / cad_vol < 0.03,
              f"mesh={m.volume:.0f} mm^3 cad={cad_vol} mm^3")
        print(f"   {name} bbox size {np.round(size,2)}")

    bb = base.bounds
    check("base outer size", np.allclose(bb[1] - bb[0], [146.4, 107.8, 14.5], atol=0.15),
          f"measured {np.round(bb[1]-bb[0],2)} (X incl. 0.8 mm grip ribs per end)")
    bbl = lid.bounds
    check("lid outer size", np.allclose(bbl[1] - bbl[0], [149.3, 112.3, 10.2], atol=0.15),
          f"measured {np.round(bbl[1]-bbl[0],2)}")

    # ---- 2. assembled pose ----------------------------------------------
    inter = vol_intersect(base, lid_a)
    check("lid/base no interpenetration (assembled)", inter == inter and inter < 1.0,
          f"intersection volume {inter:.3f} mm^3 (touching faces allowed)")

    # ---- 3. detent measured ----------------------------------------------
    nx = 36.2  # nub centre X
    # groove floor: ray along +Y from inside the base wall, through the groove
    p = first_hit(base, (nx, 52.0, BASE_H - NUB_Z), (0, 1, 0))
    groove_floor_y = p[1] if p is not None else float("nan")
    # nub tip: same ray, first lid surface
    p2 = first_hit(lid_a, (nx, 52.0, BASE_H - NUB_Z), (0, 1, 0))
    nub_tip_y = p2[1] if p2 is not None else float("nan")
    base_wall_y = 53.9
    engage = base_wall_y - nub_tip_y
    check("detent engagement (release deflection)", 0.35 <= engage <= 0.55,
          f"nub tip y={nub_tip_y:.2f}, wall face y={base_wall_y}, engagement {engage:.2f} mm (design 0.45)")
    tip_clear = nub_tip_y - groove_floor_y  # tip sits inside the groove, clear of its floor
    check("nub tip clearance in groove", abs(groove_floor_y - (53.9 - GROOVE_D)) < 0.1 and 0.1 <= tip_clear <= 0.6,
          f"groove floor y={groove_floor_y:.2f}, tip-to-floor clearance {tip_clear:.2f} mm")
    # axial play: rays up/down from inside the groove through the nub tip gap
    up = first_hit(base, (nx, 53.3, BASE_H - NUB_Z), (0, 0, 1))
    dn = first_hit(base, (nx, 53.3, BASE_H - NUB_Z), (0, 0, -1))
    if up is not None and dn is not None:
        gh = up[2] - dn[2]
        check("groove axial height", abs(gh - GROOVE_H) < 0.12,
              f"measured {gh:.2f} mm; nub tip {NUB_TIP_H} mm -> play {(gh-NUB_TIP_H)/2:.2f} mm/side")
    else:
        check("groove axial height", False, "groove not found by ray")
    # skirt gap between nubs at x=20 (clear of scoops |x|<13 and nubs at +-36.2)
    hits = ray_hit(base, (20, 45.0, 10.0), (0, 1, 0), 2)
    hits_l = ray_hit(lid_a, (20, 45.0, 10.0), (0, 1, 0), 2)
    if hits and len(hits) == 2 and hits_l and len(hits_l) == 2:
        gap = hits_l[0][1] - hits[1][1]
        skirt = hits_l[1][1] - hits_l[0][1]
        check("skirt-to-base gap", abs(gap - GAP) < 0.12, f"measured {gap:.2f} mm")
        check("skirt thickness", abs(skirt - SKIRT_T) < 0.12, f"measured {skirt:.2f} mm")
    # rim landing: lid ceiling ray up from inside the cavity
    pl = first_hit(lid_a, (60, 45.0, 14.0), (0, 0, 1))
    check("lid ceiling lands on base rim (z=14.5)", pl is not None and abs(pl[2] - BASE_H) < 0.05,
          f"lid ceiling z={pl[2] if pl is not None else 'n/a'}")
    # simple snap-fit strain estimate (documented, physical test still required)
    t, L_span, y = SKIRT_T, 36.0, engage
    strain = 3 * t * y / (2 * L_span ** 2) * 100  # % outer fibre, guided-end bow approx
    check("skirt flex strain estimate", strain < 1.0,
          f"~{strain:.2f}% outer-fibre at {engage:.2f} mm bow over {L_span} mm half-span (PETG ok)")

    # ---- 4. worst-case module envelope poses -----------------------------
    ex, ey, ez = ENV
    env_box = trimesh.creation.box(extents=(ex, ey, ez))

    def pose(dx=0.0, dy=0.0, dz=0.0, yaw=0.0, pitch=0.0, py=None):
        m = env_box.copy()
        if yaw:
            m.apply_transform(trimesh.transformations.rotation_matrix(math.radians(yaw), [0, 0, 1]))
        if pitch:
            m.apply_transform(trimesh.transformations.rotation_matrix(math.radians(pitch), [0, 1, 0]))
        cy = POCKET_Y if py is None else py
        m.apply_translation([dx, cy + dy, FLOOR + ez / 2 + dz])
        return m

    max_dx = (POCKET_L - ex) / 2          # 0.8
    max_dy = (POCKET_W - ey) / 2          # 1.55
    poses = {
        "centred": pose(),
        "max end play +X": pose(dx=max_dx),
        "max side play +Y": pose(dy=max_dy),
        "corner jam (+x,+y)": pose(dx=max_dx, dy=max_dy),
    }
    # max yaw that still fits
    yaw_ok = 0.0
    for a in np.arange(0.5, 5.5, 0.5):
        if vol_intersect(pose(yaw=a), base) < 1e-6:
            yaw_ok = a
        else:
            break
    poses[f"yaw {yaw_ok} deg (max that fits)"] = pose(yaw=yaw_ok, dy=0)
    for name, m in poses.items():
        v = vol_intersect(m, base)
        check(f"envelope pose: {name}", v == v and v < 1e-6,
              f"intersection {v:.4f} mm^3")
    # straight-lift removal sweep
    lift_ok = True
    for dz in (2, 4, 6, 8, 10, 12, 14):
        if vol_intersect(pose(dz=dz), base) > 1e-6:
            lift_ok = False
    check("straight-lift removal sweep (0..14 mm)", lift_ok,
          "no contact while lifting the bagged stick vertically out of the pocket")
    # tilted removal: low-end corner rests at pocket floor end, tilt 18 deg
    m = env_box.copy()
    m.apply_transform(trimesh.transformations.rotation_matrix(math.radians(18), [0, 1, 0]))
    m.apply_translation([-m.bounds[0][0] - (POCKET_L / 2 - max_dx), POCKET_Y, FLOOR - m.bounds[0][2]])
    v = vol_intersect(m, base)
    check("tilted removal (18 deg from floor corner)", v == v and v < 1e-6,
          f"intersection {v:.4f} mm^3")

    # ---- 5. gold-contact strip clearance ---------------------------------
    # module (not bag) at worst allowed pose; strip solid on its contact edge
    def strip_mesh(dy_env, yaw=0.0):
        m = trimesh.creation.box(extents=(STICK[0], STRIP, STICK[2]))
        m.apply_translation([0, STICK[1] / 2 - STRIP / 2, 0])  # at module edge
        mod = trimesh.creation.box(extents=STICK)
        if yaw:
            rot = trimesh.transformations.rotation_matrix(math.radians(yaw), [0, 0, 1])
            m.apply_transform(rot); mod.apply_transform(rot)
        # module sits inside the bagged envelope: envelope pose sets the limits
        m.apply_translation([0, POCKET_Y + dy_env, FLOOR + BAG + STICK[2] / 2])
        return m

    worst = [("side-jam", max_dy, 0.0), (f"yaw {yaw_ok}", 0.0, yaw_ok)]
    for name, dy_env, yaw in worst:
        s = strip_mesh(dy_env, yaw)
        pts, dist, _ = base.nearest.on_surface(s.vertices)
        d = float(dist.min())
        vi = vol_intersect(s, base)
        check(f"contact strip clearance ({name})", d >= 1.0 and vi < 1e-6,
              f"min rigid-to-contact-strip distance {d:.2f} mm (bag film extra)")

    # ---- 6. finger access measured ---------------------------------------
    p = first_hit(base, (0, BASE_Y_approx := 53.9 - WALL / 2, 20.0), (0, 0, -1))
    scoop_bottom = p[2] if p is not None else float("nan")
    check("outer scoop depth from rim", abs((BASE_H - scoop_bottom) - 7.0) < 0.3,
          f"scoop bottom z={scoop_bottom:.2f} -> {BASE_H - scoop_bottom:.1f} mm deep, r=13")
    p = first_hit(base, (0, 0, 20.0), (0, 0, -1))
    notch_bottom = p[2] if p is not None else float("nan")
    check("divider notch depth from rim", abs((BASE_H - notch_bottom) - 6.5) < 0.3,
          f"notch bottom z={notch_bottom:.2f} -> {BASE_H - notch_bottom:.1f} mm deep, 26 wide")
    stick_top = FLOOR + ez
    check("stick edge exposed to fingers",
          (BASE_H - 7.0) < stick_top,
          f"stick top z={stick_top:.1f}, scoop reaches z={BASE_H-7.0:.1f} -> {stick_top-(BASE_H-7.0):.1f} mm grip height (plus bag)")

    # end thumb scallops: at the end skirt (x=73.6), the skirt's lower boundary
    # is the scallop floor (~3.2 mm up) at y=0 but the true bottom edge (~0) at y=30
    d_on = ray_hit(lid, (73.6, 0, 30), (0, 0, -1), 2)
    d_off = ray_hit(lid, (73.6, 30, 30), (0, 0, -1), 2)
    ok = (d_on and len(d_on) == 2 and abs(d_on[1][2] - 3.2) < 0.25
          and d_off and len(d_off) == 2 and d_off[1][2] < 0.8)
    check("end thumb scallops are local (24 mm wide, 3.2 mm deep)", ok,
          f"skirt lower boundary z: centre={d_on[1][2] if d_on and len(d_on)==2 else 'n/a'} "
          f"(notch floor ~3.2), off-centre={d_off[1][2] if d_off and len(d_off)==2 else 'n/a'} (~0)")

    # ---- 7. labels ---------------------------------------------------------
    lid_v = lid.vertices
    mask = (np.abs(lid_v[:, 0]) < 72) & (np.abs(lid_v[:, 1]) < 30) & (lid_v[:, 2] > 9.2)
    zmin = lid_v[mask][:, 2].min() if mask.any() else float("nan")
    check("lid label deboss depth", abs((10.2 - zmin) - 0.7) < 0.15,
          f"measured {10.2 - zmin:.2f} mm (design 0.7)")
    bv = base.vertices
    maskb = (np.abs(bv[:, 0]) < 72) & (np.abs(bv[:, 1]) < 30) & (bv[:, 2] < 1.0)
    zmax = bv[maskb][:, 2].max() if maskb.any() else float("nan")
    check("base label deboss depth", abs(zmax - 0.6) < 0.15,
          f"measured {zmax:.2f} mm (design 0.6)")

    exp = json.load(open(os.path.join(ROOT, "verify", "expected_text.json")))
    all_font_ok = True
    for line in exp["lines"]:
        s, em, y0 = line["text"], line["em_mm"], line["y_center"]
        band = lid_v[(np.abs(lid_v[:, 0]) < 56) & (np.abs(lid_v[:, 1] - y0) < em * 0.45) & (lid_v[:, 2] > 9.3)]
        if not len(band):
            all_font_ok = False
            print("   no deboss geometry found for line:", s)
            continue
        w_meas = band[:, 0].max() - band[:, 0].min()
        w_exp = line["expected_width_mm"]
        ratio = w_meas / w_exp
        ok = 0.85 <= ratio <= 1.18 and em >= 9.0
        all_font_ok &= ok
        print(f"   '{s}': em={em} cap={line['cap_mm']:.1f} mm stroke={line['stroke_mm']:.2f} mm, "
              f"width measured {w_meas:.1f} vs font {w_exp:.1f} (ratio {ratio:.2f})")
    check("Fillaprint label sizes (min em 9 mm honoured, real font)",
          all_font_ok, "cap height = 0.7*em; stroke = em/10 = 2 extrusion widths at em=20*w")

    # ---- summary -----------------------------------------------------------
    n_fail = sum(1 for r in results if not r["pass"])
    out = {
        "units": "mm",
        "assembled_envelope": [149.3, 112.3, 16.7],
        "checks": results,
        "failed": n_fail,
    }
    os.makedirs(os.path.join(ROOT, "verify"), exist_ok=True)
    with open(os.path.join(ROOT, "verify", "checks.json"), "w") as f:
        json.dump(out, f, indent=2)
    with open(os.path.join(ROOT, "verify", "checks.md"), "w") as f:
        f.write("# Measured checks (from exported STLs)\n\n")
        f.write("| check | result | detail |\n|---|---|---|\n")
        for r in results:
            f.write(f"| {r['check']} | {'PASS' if r['pass'] else 'FAIL'} | {r['detail']} |\n")
    print(f"\n{len(results)-n_fail}/{len(results)} checks passed -> verify/checks.json, verify/checks.md")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
