# Measured checks (from exported STLs)

| check | result | detail |
|---|---|---|
| base watertight+winding | PASS | watertight=True winding=True |
| base volume | PASS | mesh=43732 mm^3 cad=43734 mm^3 |
| lid watertight+winding | PASS | watertight=True winding=True |
| lid volume | PASS | mesh=43900 mm^3 cad=43902 mm^3 |
| base outer size | PASS | measured [146.4 107.8  14.5] (X incl. 0.8 mm grip ribs per end) |
| lid outer size | PASS | measured [149.3 112.3  10.2] |
| lid/base no interpenetration (assembled) | PASS | intersection volume 0.000 mm^3 (touching faces allowed) |
| detent engagement (release deflection) | PASS | nub tip y=53.45, wall face y=53.9, engagement 0.45 mm (design 0.45) |
| nub tip clearance in groove | PASS | groove floor y=53.05, tip-to-floor clearance 0.40 mm |
| groove axial height | PASS | measured 2.80 mm; nub tip 0.8 mm -> play 1.00 mm/side |
| skirt-to-base gap | PASS | measured 0.25 mm |
| skirt thickness | PASS | measured 2.00 mm |
| lid ceiling lands on base rim (z=14.5) | PASS | lid ceiling z=14.5 |
| skirt flex strain estimate | PASS | ~0.10% outer-fibre at 0.45 mm bow over 36.0 mm half-span (PETG ok) |
| envelope pose: centred | PASS | intersection 0.0000 mm^3 |
| envelope pose: max end play +X | PASS | intersection 0.0000 mm^3 |
| envelope pose: max side play +Y | PASS | intersection 0.0000 mm^3 |
| envelope pose: corner jam (+x,+y) | PASS | intersection 0.0000 mm^3 |
| envelope pose: yaw 1.0 deg (max that fits) | PASS | intersection 0.0000 mm^3 |
| straight-lift removal sweep (0..14 mm) | PASS | no contact while lifting the bagged stick vertically out of the pocket |
| tilted removal (18 deg from floor corner) | PASS | intersection 0.0000 mm^3 |
| contact strip clearance (side-jam) | PASS | min rigid-to-contact-strip distance 1.20 mm (bag film extra) |
| contact strip clearance (yaw 1.0) | PASS | min rigid-to-contact-strip distance 1.20 mm (bag film extra) |
| outer scoop depth from rim | PASS | scoop bottom z=7.50 -> 7.0 mm deep, r=13 |
| divider notch depth from rim | PASS | notch bottom z=8.00 -> 6.5 mm deep, 26 wide |
| stick edge exposed to fingers | PASS | stick top z=12.9, scoop reaches z=7.5 -> 5.4 mm grip height (plus bag) |
| end thumb scallops are local (24 mm wide, 3.2 mm deep) | PASS | skirt lower boundary z: centre=3.1566446901038425 (notch floor ~3.2), off-centre=0.0 (~0) |
| lid label deboss depth | PASS | measured 0.70 mm (design 0.7) |
| base label deboss depth | PASS | measured 0.60 mm (design 0.6) |
| Fillaprint label sizes (min em 9 mm honoured, real font) | PASS | cap height = 0.7*em; stroke = em/10 = 2 extrusion widths at em=20*w |
