# Research notes (dimensions used for the envelope)

Retrieved 2026-11-03 via the site proxy. Values are manufacturer spec sheets / FAQ unless noted.

## Bare DDR4 UDIMM (JEDEC)
- Length 133.35 mm; standard height 31.25 mm (31.40 max); 288 contacts; VLP 18.75 mm.
  (en.wikipedia.org/wiki/DIMM)
- Kingston datasheet drawings confirm PCB 133.35 x 31.25 mm, tolerance ±0.12
  (kingston.com/datasheets/KF432C16BBK2_16.pdf).

## Common heatspreader modules (height / thickness / length)
| Module | Height mm | Thickness mm | Length mm | Source |
|---|---|---|---|---|
| Kingston Fury Beast DDR4 | 34 | 7.2 | 133.35 | Kingston datasheet KF432C16BBK2/16 |
| Kingston HyperX Fury DDR4 | 34.1 | 7.2 | 133.35 | Kingston datasheet HX432C16FB3K2/16 |
| Corsair Vengeance LPX | 34 | ~7.4 (class typ.) | 133.35 | Corsair/retailer specs ("34 mm low profile") |
| Crucial Ballistix | 39.25 (calipers) | ~7.2 (class typ.) | 133.35 | TechPowerUp review measurement |
| G.Skill Ripjaws V | 42 | — | 133.35 | G.Skill official FAQ height list |
| G.Skill Sniper X | 43 | — | 133.35 | G.Skill FAQ |
| G.Skill Trident Z / Z Neo / Z RGB / Z Royal | 44 | — | 133.35 | G.Skill FAQ |
| Patriot Viper Steel | 44.4 | 7.0 | 135.7 | retailer dims listing (135.7 x 44.4 x 7) |

Excluded as "exotic/tall" (>45 mm): Corsair Vengeance RGB Pro (51),
Dominator Platinum (55), G.Skill Trident Z RGB DC (59, double-capacity),
G.Skill TridentX with fin (54), ADATA Spectrix D41/D60G-class RGB (~46-50).

G.Skill FAQ: https://www.gskill.com/faq/1502180912/DRAM-Memory (retrieved; DDR4 list
31.2 / 40 / 40 / 42 / 43 / 44 / 44 / 44 / 44 / 44 / 59 mm).

## Chosen supported envelope
**L ≤ 136 mm, H ≤ 45 mm, T ≤ 8.5 mm** (heatspreader on), plus a 1.2 mm/face
allowance for a folded static-shielding bag (4x6 in / 102x152 mm class).
Covers everything in the table above and all bare/VLP modules.

## Font
Fillaprint-Regular.ttf (SIL OFL 1.1, see assets/fillaprint/OFL.txt).
Font metadata (nameID 10): "Two-bead FDM font: every stroke is exactly two
extrusion widths (w). ... cap height = 14 x line width; em = 20 x line width."
=> Minimum printable size: em = 20 x line width = 9.0 mm at 0.45 mm line width
(cap height 6.3 mm, stroke 0.9 mm). Labels use em 9 mm (body) and em 12 mm (title).
