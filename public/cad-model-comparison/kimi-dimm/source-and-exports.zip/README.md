# DDR4 DIMM mailer (2 sticks, reusable)

A small two-part FDM-printed box for posting a pair of desktop DDR4 UDIMMs with
ordinary heatspreaders. Each stick goes in its own static-shielding bag, drops
into its own recessed pocket, gets a sheet of foam or folded paper on top, and
the snap lid closes it. The box then goes inside your outer cardboard box.

Assembled size: **149.3 x 112.3 x 16.7 mm** (about the footprint of a small
paperback, 16.7 mm thin). Material usage: base ~43.7 cm^3, lid ~43.9 cm^3
(~110 g PETG total at 100 %; realistically ~55-70 g at normal infill).

## Supported envelope

**Module L <= 136 mm, H <= 45 mm, T <= 8.5 mm, heatspreader on**, in a 4x6 in
(102x152 mm) or similar shielding bag.

Fits (measured/spec, see research/notes.md): Kingston Fury Beast & HyperX Fury
(34 mm), Corsair Vengeance LPX (34), Crucial Ballistix (39.25), G.Skill
Ripjaws V (42), Sniper X (43), Trident Z / Z Neo / Z RGB / Z Royal (44),
Patriot Viper Steel (44.4 x 135.7 long), and all bare or low-profile sticks.

Does NOT fit (deliberately): tall RGB/exotic heatsinks >45 mm (Vengeance RGB
Pro 51, Dominator Platinum 55, Trident Z RGB DC 59, ADATA D41-class), anything
thicker than 8.5 mm or longer than 136 mm. That keeps the box small.

## How it works

**Loading.** Sticks lie flat, faces horizontal, one per pocket. Nothing rigid
touches the gold-contact edge: the contact side of each pocket has >=1.2 mm of
clearance in the worst jammed pose (plus the bag), and both pocket floors have
8 mm wide relief grooves under the strips of the faces adjacent to the contact
edge, so the module rests only on the central 34.5 mm of its heatspreader
faces. Weight and foam pressure go through the heatspreader, never the fingers.

**Lid retention.** The lid is a cap. Four wedge nubs (two per long side, 0.7 mm
proud, 45 deg ramps) snap into grooves in the base wall with 0.45 mm release
deflection and a 0.25 mm skirt gap. The lid ceiling lands directly on the base
rim, so the closed height is fixed and the sticks can't be crushed. No
hardware. Estimated skirt bending strain ~0.1 % — no fatigue issue in PETG.
Measured nub/groove numbers are in verify/checks.json.

**Opening.** Pinch the lid's end scallops (thumb catches the skirt lip) against
the grip ribs on the base ends and pull apart. Arrows on the lid top point at
the lift ends.

**Getting sticks out.** Each pocket has a finger scoop (r13, 7 mm deep) on the
outer wall and a 26 mm notch in the central divider, giving two-finger pinch
access to the bagged stick's long edges with 5.4 mm of grip height; the stick
lifts straight out (verified collision-free), or tilt-and-lift from one end.
The foam sheet goes on top before closing; it is what stops any residual
rattle.

## Printing

- PETG recommended (detent cycles); PLA works for occasional use. 0.2 mm
  layers, 3+ perimeters, no supports, no brim needed.
- Base prints as-is (open pockets up). Lid prints upside-down (top plate on the
  bed, skirt up).
- Labels are debossed (lid top 0.7 mm, base bottom 0.6 mm) in Fillaprint, a
  two-bead FDM font: stroke = 2 line widths, em = 20 x line width. Minimum
  printable size at 0.45 mm line width = em 9 mm; this design uses em 9 mm
  (body, cap height 6.3 mm) and em 12 mm (title, cap 8.4 mm). At 0.6 mm line
  width the body text is still >= its 9 mm em floor (stroke 1.5 beads), but use
  0.4/0.45 mm line width if you want the text crisp.
- Font license: SIL OFL 1.1 (assets/fillaprint/OFL.txt).

## Files

- `src/mailer_cad.py` — parametric source (build123d 0.13); all dimensions at top.
- `out/base.step`, `out/lid.step` — B-rep parts (lid in its local frame, skirt
  bottom z=0). `out/assembly.step` — both parts in assembled pose.
- `out/base.stl`, `out/lid.stl` — binary STLs (0.08 mm linear deflection).
- `assembly.json` — part files + assembled transforms (mm).
- `verify/check_fit.py` — functional verification (trimesh); results in
  `verify/checks.json` / `verify/checks.md` (30/30 pass).
- `research/notes.md` — dimension sources.

Rebuild: `python src/mailer_cad.py`
Verify:  `python verify/check_fit.py`

## What is verified vs what needs a physical test

Verified from the actual meshes (not from design intent): watertight/winding
solids; outer dimensions; lid/base zero interpenetration when assembled;
detent engagement 0.45 mm, nub tip clearance 0.40 mm, skirt gap 0.25 mm; the
worst-case bagged module envelope (138.4 x 47.4 x 10.9 mm) collision-free in
all extreme poses including corner-jam, max yaw (1 deg), straight-lift and
18 deg tilted removal; >=1.2 mm rigid-to-contact-strip clearance in the worst
poses; scoop/notch reach; label deboss depths and per-line widths matching the
Fillaprint TTF metrics within 1 %.

Still needs a physical test (one print):
1. Actual snap/open force of the detent (geometry is to FDM norms, but force
   depends on material/printer). If too loose: raise NUB_PROTRUDE to 0.8; too
   tight: 0.6. Lid has 1.0 mm axial play per side by design (harmless in the
   outer box); reduce GROOVE_H if you want it tighter.
2. Bag reality: I assumed <=1.2 mm/face for a folded 4x6 in bag (very
   generous); confirm your bags, especially if using 5x7 in bags with thick
   folds.
3. Friction feel of pulling a bagged stick (bag film on PETG) — the scoops are
   sized for this, but a ribbon pull-tab can be taped to each bag if wanted.

Known limitations: single-sided VLP/bare sticks rattle more (use a paper wedge
as usual); sticks must be inserted reasonably straight (pockets yaw only ~1
deg); not ESD-safe by itself — the shielding bags provide the ESD protection,
this box is mechanical protection only.
