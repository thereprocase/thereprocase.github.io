"""
Parametric reusable mailer for 2x desktop DDR4 UDIMMs with ordinary heatspreaders.

Workflow it supports: stick -> anti-static shielding bag (4x6 in class) -> recessed
pocket -> sheet of foam/paper on top -> snap lid -> outer cardboard box.

Design decisions (see README.md for sources and rationale):
  * Supported module envelope: L<=136 mm, H<=45 mm, T<=8.5 mm (heatspreader on).
  * Modules lie flat (faces horizontal). Rigid plastic can only touch the bagged
    heatspreader faces / short ends. The gold-contact edge always faces a void:
    >=1 mm clearance to any wall, plus 8 mm wide relief grooves in the pocket
    floor under both contact-adjacent face strips.
  * Lid: full-perimeter cap, retained by 4 wedge detent nubs (2 per long side)
    snapping into grooves in the base wall. No hardware. Open by pinching the
    end scallops of the lid against the grip ribs of the base.
  * Labels: Fillaprint-Regular.ttf, a "two-bead FDM" font (em = 20 x line width,
    stroke = 2 line widths). Minimum printable size for a 0.45 mm line width is
    em 9 mm; all text here uses em >= 9 mm (title em 12 mm), debossed 0.7/0.6 mm.

Run:  python src/mailer_cad.py
Outputs (paths relative to repo root): out/*.step, out/*.stl (binary), assembly.json
Units: millimetres. World frame: XY centred on the box centre, +Z up, base bottom z=0.
"""

import json
import os

from build123d import (
    Align,
    Axis,
    Box,
    BuildSketch,
    Compound,
    Cylinder,
    Locations,
    Plane,
    Polygon,
    Pos,
    Rot,
    Text,
    chamfer,
    export_step,
    export_stl,
    extrude,
    fillet,
    mirror,
)

# ---------------------------------------------------------------- parameters
FONT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "assets", "fillaprint", "Fillaprint-Regular.ttf",
)

# Supported stick envelope (module with ordinary heatspreader)
STICK_L, STICK_H, STICK_T = 136.0, 45.0, 8.5
BAG = 1.2            # allowance per face for the shielding bag (very generous)

# Base / pockets
POCKET_L = 140.0     # X, per pocket (bagged length 136+2.4 -> ~1.6 mm end play)
POCKET_W = 50.5      # Y, per pocket (bagged height 45+2.4 -> eased insertion)
POCKET_D = 12.5      # Z depth (bagged thickness ~11 -> room for 2 mm foam sheet)
WALL = 2.4           # base outer wall
FLOOR = 2.0          # base floor under pockets
DIVIDER = 2.0        # wall between the two pockets
RELIEF_W, RELIEF_D = 8.0, 0.8   # floor relief grooves along both long pocket edges
SCOOP_R, SCOOP_D = 13.0, 7.0    # finger scoop radius / depth from rim (outer walls)
NOTCH_W, NOTCH_D = 26.0, 6.5    # divider finger notch width / depth from rim

BASE_H = FLOOR + POCKET_D                      # 14.5
BASE_X = POCKET_L + 2 * WALL                   # 144.8
BASE_Y = 2 * POCKET_W + DIVIDER + 2 * WALL     # 107.8
R_OUT = 5.0

# Detent (lid retention)
GAP = 0.25           # radial clearance skirt <-> base wall
SKIRT_T = 2.0
SKIRT_H = 8.0        # how far the lid skirt wraps down over the base
PLATE_T = 2.2        # lid top plate
NUB_LEN = 9.0        # along X
NUB_PROTRUDE = 0.7   # how far the nub sticks out from the skirt inner face
NUB_TIP_H = 0.8      # flat tip height (Z)
NUB_RAMP = 0.7       # 45 deg lead/release ramps
NUB_Z = 2.8          # nub centre below the lid ceiling / base rim
GROOVE_D = 0.85      # groove depth into base wall
GROOVE_H = 2.8       # groove height (Z): nub total 2.2 (0.8 tip + 2x0.7 ramps) + 0.3 play/side
GROOVE_L = 9.7       # groove length (X), nub has 0.35 mm play per side

LID_H = SKIRT_H + PLATE_T                      # 10.2
LID_X = BASE_X + 2 * (SKIRT_T + GAP)           # 149.3
LID_Y = BASE_Y + 2 * (SKIRT_T + GAP)           # 112.3
LID_R = R_OUT + SKIRT_T + GAP                  # 7.25
CAV_X = BASE_X + 2 * GAP                       # 145.3
CAV_Y = BASE_Y + 2 * GAP                       # 108.3
CAV_R = R_OUT + GAP                            # 5.25
LID_Z_LIFT = BASE_H - SKIRT_H                  # assembled lid offset = 6.5

# Ergonomics
SCALLOP_R, SCALLOP_D = 14.0, 3.2   # thumb scallop in lid skirt (short ends)
RIB_N, RIB_STEP = 5, 6.0           # grip ribs on base end walls
RIB_W, RIB_PROUD, RIB_H = 1.8, 0.8, 4.7

# Text (Fillaprint: stroke = em/10 = 2 line widths; em >= 9 mm is the minimum
# printable size for a 0.45 mm line width)
EM_TITLE, EM_BODY = 12.0, 9.0
TEXT_LID_D, TEXT_BASE_D = 0.7, 0.6

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "out")


# ---------------------------------------------------------------- base
def make_base():
    part = Pos(0, 0, BASE_H / 2) * Box(BASE_X, BASE_Y, BASE_H)
    part = fillet(part.edges().filter_by(Axis.Z), R_OUT)
    # lead-in chamfer for the lid on the whole top outer rim
    part = chamfer(part.edges().filter_by_position(Axis.Z, BASE_H - 0.01, BASE_H + 0.01), 1.2)
    # first-layer-friendly chamfer on the bottom rim
    part = chamfer(part.edges().filter_by_position(Axis.Z, -0.01, 0.01), 0.6)

    pocket_y = POCKET_W / 2 + DIVIDER / 2  # 26.25
    for s in (+1, -1):
        pocket = Pos(0, s * pocket_y, BASE_H - POCKET_D / 2 + 0.5) * Box(
            POCKET_L, POCKET_W, POCKET_D + 1
        )
        part -= pocket
        # relief grooves: nothing rigid under the 8 mm next to each long edge
        # (that is where the gold-contact-adjacent face strips sit)
        for g in (+1, -1):
            gy = s * pocket_y + g * (POCKET_W / 2 - RELIEF_W / 2)
            part -= Pos(0, gy, FLOOR - RELIEF_D / 2 + 0.001) * Box(
                POCKET_L + 0.2, RELIEF_W, RELIEF_D + 0.002
            )

    # finger scoops in the outer long walls (open into each pocket)
    for s in (+1, -1):
        part -= Pos(0, s * (BASE_Y / 2 - WALL), BASE_H - SCOOP_D + 5) * Cylinder(
            radius=SCOOP_R, height=10
        )

    # divider finger notch (serves both pockets)
    part -= Pos(0, 0, BASE_H - NOTCH_D / 2 + 0.5) * Box(NOTCH_W, DIVIDER + 0.4, NOTCH_D + 1)

    # detent grooves on the outer long walls
    gz = BASE_H - NUB_Z
    for sx in (+1, -1):
        for sy in (+1, -1):
            part -= Pos(
                sx * BASE_X / 4, sy * (BASE_Y / 2 - GROOVE_D / 2 + 0.05), gz
            ) * Box(GROOVE_L, GROOVE_D + 0.1, GROOVE_H)

    # grip ribs on the end walls (below the lid skirt line)
    rib_z0 = 0.8
    for s in (+1, -1):
        for i in range(RIB_N):
            part += Pos(
                s * (BASE_X / 2 + RIB_PROUD / 2),
                (i - (RIB_N - 1) / 2) * RIB_STEP,
                rib_z0 + RIB_H / 2,
            ) * Box(RIB_PROUD, RIB_W, RIB_H)

    # debossed labels on the bottom face (readable when the box is flipped)
    bottom = Plane(origin=(0, 0, 0), x_dir=(1, 0, 0), z_dir=(0, 0, -1))
    with BuildSketch(bottom) as bs:
        with Locations((0, 10)):
            Text("DIMM MAILER R1", font_size=EM_BODY, font_path=FONT_PATH,
                 align=(Align.CENTER, Align.CENTER))
        with Locations((0, -2)):
            Text("2X DDR4 UDIMM - BAGGED", font_size=EM_BODY, font_path=FONT_PATH,
                 align=(Align.CENTER, Align.CENTER))
        with Locations((0, -14)):
            Text("PRINT: PETG OR PLA", font_size=EM_BODY, font_path=FONT_PATH,
                 align=(Align.CENTER, Align.CENTER))
    part -= extrude(bs.sketch, amount=-TEXT_BASE_D)  # -amount -> +Z, into the part
    return part


# ---------------------------------------------------------------- lid
def _nub(skirt_inner_y, x_centre):
    """One wedge detent nub on a long-side skirt inner face (local lid frame)."""
    y0 = skirt_inner_y
    zc = SKIRT_H - NUB_Z  # 5.2 -> world z 11.7 when assembled
    with BuildSketch(Plane(origin=(0, 0, 0), x_dir=(0, 1, 0), z_dir=(1, 0, 0))) as ns:
        Polygon(
            (y0, zc - NUB_TIP_H / 2 - NUB_RAMP),
            (y0, zc + NUB_TIP_H / 2 + NUB_RAMP),
            (y0 - NUB_PROTRUDE, zc + NUB_TIP_H / 2),
            (y0 - NUB_PROTRUDE, zc - NUB_TIP_H / 2),
        )
    nub = extrude(ns.sketch, amount=NUB_LEN)
    nub = Pos(x_centre - NUB_LEN / 2, 0, 0) * nub
    return nub


def make_lid():
    part = Pos(0, 0, LID_H / 2) * Box(LID_X, LID_Y, LID_H)
    part = fillet(part.edges().filter_by(Axis.Z), LID_R)
    part = fillet(part.edges().filter_by_position(Axis.Z, LID_H - 0.01, LID_H + 0.01), 0.8)
    part = chamfer(part.edges().filter_by_position(Axis.Z, -0.01, 0.01), 0.5)

    cavity = Pos(0, 0, SKIRT_H / 2 - 0.05) * Box(CAV_X, CAV_Y, SKIRT_H + 0.1)
    cavity = fillet(cavity.edges().filter_by(Axis.Z), CAV_R)
    part -= cavity

    skirt_inner_y = CAV_Y / 2  # 54.15
    for sx in (+1, -1):
        nub_pos = _nub(skirt_inner_y, sx * BASE_X / 4)
        nub_neg = mirror(nub_pos, Plane.XZ)
        part += nub_pos + nub_neg

    # thumb scallops on the short ends of the skirt (local, 24 mm wide)
    for s in (+1, -1):
        part -= Pos(s * LID_X / 2, 0, -(SCALLOP_R - SCALLOP_D)) * Rot(90, 0, 0) * Cylinder(
            radius=SCALLOP_R, height=24.0
        )

    # debossed labels on the top face + arrows marking the lift ends
    top = Plane(origin=(0, 0, LID_H), x_dir=(1, 0, 0), z_dir=(0, 0, 1))
    with BuildSketch(top) as ts:
        with Locations((0, 18)):
            Text("DIMM MAILER", font_size=EM_TITLE, font_path=FONT_PATH,
                 align=(Align.CENTER, Align.CENTER))
        with Locations((0, 4)):
            Text("2X DDR4 UDIMM - BAGGED", font_size=EM_BODY, font_path=FONT_PATH,
                 align=(Align.CENTER, Align.CENTER))
        with Locations((0, -8)):
            Text("FITS 136 X 45 X 8.5 MM", font_size=EM_BODY, font_path=FONT_PATH,
                 align=(Align.CENTER, Align.CENTER))
        with Locations((0, -20)):
            Text("OPEN: LIFT LID ENDS", font_size=EM_BODY, font_path=FONT_PATH,
                 align=(Align.CENTER, Align.CENTER))
        # arrows pointing at the two lift ends (y=-14 keeps clear of text bands)
        with Locations((63, -14)):
            Polygon((3.2, 0), (-2.2, 3.0), (-2.2, -3.0))
        with Locations((-63, -14)):
            Polygon((-3.2, 0), (2.2, 3.0), (2.2, -3.0))
    part -= extrude(ts.sketch, amount=-TEXT_LID_D)
    return part


# ---------------------------------------------------------------- main
def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    base = make_base()
    lid = make_lid()

    # sanity: text actually got cut (volume reduced) and solids are valid
    assert base.volume > 0 and lid.volume > 0
    assert len(base.solids()) == 1 and len(lid.solids()) == 1

    base_step = os.path.join(OUT_DIR, "base.step")
    lid_step = os.path.join(OUT_DIR, "lid.step")
    export_step(base, base_step)
    export_step(lid, lid_step)
    export_stl(base, os.path.join(OUT_DIR, "base.stl"), tolerance=0.08, angular_tolerance=0.2)
    export_stl(lid, os.path.join(OUT_DIR, "lid.stl"), tolerance=0.08, angular_tolerance=0.2)

    # bonus: both parts in assembled pose, one STEP (compound, no boolean)
    asm = Compound(children=[base, Pos(0, 0, LID_Z_LIFT) * lid])
    export_step(asm, os.path.join(OUT_DIR, "assembly.step"))

    assembly = {
        "units": "mm",
        "frame": "right-handed; XY centred on box centre; +Z up; base bottom face at z=0",
        "parts": [
            {
                "name": "base",
                "step": "out/base.step",
                "stl": "out/base.stl",
                "translation_mm": [0.0, 0.0, 0.0],
                "rotation_euler_xyz_deg": [0.0, 0.0, 0.0],
            },
            {
                "name": "lid",
                "step": "out/lid.step",
                "stl": "out/lid.stl",
                "translation_mm": [0.0, 0.0, LID_Z_LIFT],
                "rotation_euler_xyz_deg": [0.0, 0.0, 0.0],
                "note": "lid local frame: skirt bottom edge z=0, top face z=10.2; "
                        "translation places the ceiling onto the base rim (z=14.5)",
            },
        ],
        "assembled_envelope_mm": [round(LID_X, 2), round(LID_Y, 2), round(LID_Z_LIFT + LID_H, 2)],
    }
    with open(os.path.join(os.path.dirname(OUT_DIR), "assembly.json"), "w") as f:
        json.dump(assembly, f, indent=2)

    # expected label metrics for the verifier (fontTools lives in this venv)
    from fontTools.ttLib import TTFont

    tt = TTFont(FONT_PATH)
    cmap, hmtx = tt.getBestCmap(), tt["hmtx"]
    upm, cap = tt["head"].unitsPerEm, tt["OS/2"].sCapHeight
    lines = [("DIMM MAILER", EM_TITLE, 18.0), ("2X DDR4 UDIMM - BAGGED", EM_BODY, 4.0),
             ("FITS 136 X 45 X 8.5 MM", EM_BODY, -8.0), ("OPEN: LIFT LID ENDS", EM_BODY, -20.0)]
    exp = {
        "cap_height_ratio": cap / upm,
        "lines": [
            {
                "text": s,
                "em_mm": em,
                "y_center": y0,
                "cap_mm": em * cap / upm,
                "stroke_mm": em / 10.0,
                "expected_width_mm": sum(hmtx[cmap[ord(c)]][0] for c in s) / upm * em,
            }
            for s, em, y0 in lines
        ],
    }
    os.makedirs(os.path.join(os.path.dirname(OUT_DIR), "verify"), exist_ok=True)
    with open(os.path.join(os.path.dirname(OUT_DIR), "verify", "expected_text.json"), "w") as f:
        json.dump(exp, f, indent=2)

    print("base volume %.1f mm^3" % base.volume)
    print("lid  volume %.1f mm^3" % lid.volume)
    print("exported to", OUT_DIR)


if __name__ == "__main__":
    main()
