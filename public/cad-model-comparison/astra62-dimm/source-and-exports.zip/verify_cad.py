"""Functional gauges on the re-imported manufacturing STEP files; no printer needed."""
import json
from make_mailer import ROOT, P, FONT, rect, Pos, Text, import_step, section

assy=json.loads((ROOT/'assembly.json').read_text())
tray,lid=[import_step(ROOT/item['step']) for item in assy['parts']]
dz=assy['parts'][1]['transform'][2][3]
lid=Pos(Z=dz)*lid
def vol(a,b):
    i=a.intersect(b)
    if not i:return 0.
    return sum(s.volume for s in i.solids())

def gauge(label,a,b,blocked=False):
    v=vol(a,b); print(f'{label}: {v:.5f} mm³');assert (v>.0001)==blocked,label

gauge('Closed tray / lid overlap',tray,lid)
for label,xyz in [('latched pull',(.8,0,0)),('far stop',(-.6,0,0)),('lift capture',(0,0,1)),('rail shelf',(0,0,-.5))]:
    gauge(label,tray,Pos(*xyz)*lid,True)

# With the lug withdrawn to the rail's nominal width, bound the whole
# moving lid by sweeping its largest guide section along the entire exit.
# Ribs and type are inboard except in the keeper: bound them separately.
a=P.module_length/2+P.end_allowance; b=P.module_height+P.height_allowance+P.divider/2
w=b+P.rail_reach; t=P.lid_thickness;k=P.bevel_start;c=P.slide_play
left=-a+c; end=a+P.wall+152
sweep=section(left,end,[(dz,w),(dz+k,w),(dz+t,w-t+k)])
proud=rect(left,end,-w+t-k,w-t+k,dz+t,dz+t+1)
gauge('Continuous slide, released guide envelope',tray,sweep)
gauge('Continuous slide, raised detail envelope',tray,proud)
retracted=(lid-rect(left-10,end,w,65,dz-.5,dz+k+.01))
assert (retracted-sweep-proud).volume<1e-5

for sign in [-1,1]:
    # 140 x 46 x 12 finished pack, flat on the lands. A vertical
    # prism checks straight-in loading through the entire open tray.
    yy=sorted([sign*(b-1.2),sign*(b-47.2)])
    seat=P.floor+P.relief
    pack=rect(-70,70,*yy,seat,seat+12)
    gauge(f'Bay {sign}: vertical loading path',tray,rect(-70,70,*yy,seat,60))
    gauge(f'Bay {sign}: pack vs closed lid',lid,pack)
    print(f'Bay {sign}: pack to lid distance = {pack.distance_to(lid):.3f} mm')
    # Worst-case contact band for the SHORTEST specified module, fitted
    # spine 2.8 mm inboard of outer wall. Test 2.3 mm below support level.
    edge=b-2.8-34; band=sorted([sign*edge,sign*(edge+8)])
    gauge(f'Bay {sign}: under-contact relief, 34 mm module',tray,rect(-68,68,*band,seat-2.3,seat))

h=Text('H',P.text_em,font='Fillaprint',font_path=FONT).bounding_box().size.Y
assert h>=5.88
print(f'Actual FillaPrint H at smallest em: {h:.3f} mm')
