"""Check binary STL framing, manifold topology, and component count."""
from pathlib import Path
import trimesh
for f in sorted((Path(__file__).resolve().parent/'parts').glob('*.stl')):
    data=f.read_bytes(); n=int.from_bytes(data[80:84],'little');assert len(data)==84+50*n
    m=trimesh.load_mesh(f);assert m.is_volume and len(m.split(only_watertight=False))==1
    print(f'{f.name}: binary, {n} triangles, one closed consistently wound volume; extents {m.extents.round(3)} mm, {m.volume:.2f} mm³')
