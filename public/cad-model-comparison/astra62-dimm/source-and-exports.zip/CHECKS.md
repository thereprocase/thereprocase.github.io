# Export checks — supplied size (mm)

`verify_cad.py` reads the STEP files back and applies the assembly placement. `verify_mesh.py` independently reads the binary STLs. Run them with `/home/repro/venvs/kraken-cad/bin/python` and `/home/repro/venvs/physics/bin/python` respectively.

| Interface or gauge | Result |
|---|---|
| Closed tray vs lid at local-to-assembly Z offsets 0 / +17 | 0 mm³ common volume |
| Pull relaxed lid +0.8 X; push −0.6 X; lift +1 Z; lower −0.5 Z | Interference respectively **0.50547 / 95.46247 / 273.79108 / 126.99286 mm³**. Detects keeper, end stop, capture lips and lower shelves. |
| Released slide | A continuous full-length section bounding the lid with its projecting tooth withdrawn, plus a separate envelope for raised graphics/grip, clears the tray **through the entire withdrawal** (0 mm³). Checks travel space, not elastic deformation. |
| Latch details | 1.70 mm nominal tooth projection beyond guide; 0.32 mm side allowance → **1.38 mm** nominal engagement. 0.45 mm free pull to keeper shoulder. About 34 mm from rounded slot root to shoulder; 3.8 mm lateral slot at paddle gives room for the required inward stroke. Flex force, fatigue and wear unmeasured. |
| Loading and closing | **140 × 46 × 12 mm** block swept vertically straight into either bay: 0 mm³ collision. Loaded blocks on lands clear lid by **0.60 mm** nominal, **0.28 mm** after lid settles onto shelves. Allow for warpage and do not fill space with hard shims. |
| Contact relief | Lands at Z 4.4, floor at Z 2.0. With the spine 2.8 mm inside the wall, even the 34 mm module has a full **8 mm wide** contact band clear of lands: 136 × 8 × 2.3 mm under-edge gauge clears both bays. Taller modules move that band further inboard. At 43 mm height the gold edge is still 3.2 mm from the divider. Requires end packing to preserve alignment. |
| Removal | 30 mm central interruption in divider; two longitudinal sling tails exit at the module ends (4 mm room per end for a centered 136 mm stick before packing). Top-loading gauge can follow the same straight path out. Actual paper handling is untested. |
| Typography | Smallest outlined capital H: **7.000 mm** (10 mm em). Main legend 19.5 mm em. Text projects 0.60 mm above deck. |

Both generated CAD parts passed the single-solid validity check. Each STL has valid binary framing and one closed, consistently wound positive-volume component:

| Local STL | Triangles | Bounding size (mm) | Volume (mm³) |
|---|---:|---|---:|
| tray | 5,544 | 151.60 × 108.00 × 20.95 | 84,109.96 |
| lid | 7,776 | 146.78 × 104.90 × 4.05 | 50,439.37 |

The STEP and STL use the same axes, with +X in the opening direction. Packed gauges and swept sections are virtual checks, not parts to print. Collision volumes demonstrate geometry, not holding strength or shock protection.
