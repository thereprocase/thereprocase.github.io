"""DDR4 two-bay mailer. All design coordinates and parameters in mm."""
from dataclasses import dataclass
from pathlib import Path
import json
from build123d import *

ROOT = Path(__file__).resolve().parent
FONT = ROOT/'assets/fillaprint/Fillaprint-Regular.ttf'
OUT = ROOT/'parts'

@dataclass
class Spec:
    module_length: float = 136
    module_height: float = 43
    module_thickness: float = 9
    end_allowance: float = 4
    height_allowance: float = 6
    packing_depth: float = 3.6
    wall: float = 3.8
    divider: float = 2.4
    floor: float = 2
    relief: float = 2.4
    slide_play: float = .32
    lid_thickness: float = 3.4
    bevel_start: float = 1.1
    rail_reach: float = 1.4
    text_em: float = 10

P=Spec()
def rect(x0,x1,y0,y1,z0,z1,r=0):
    s=RectangleRounded(x1-x0,y1-y0,r) if r else Rectangle(x1-x0,y1-y0)
    return Pos((x0+x1)/2,(y0+y1)/2,z0)*extrude(s,amount=z1-z0)

def section(x0,x1,levels):
    pts=[(-w,z) for z,w in levels]+[(w,z) for z,w in reversed(levels)]
    return Pos(x0,0,0)*extrude(Plane.YZ*Polygon(*pts,align=None),amount=x1-x0,dir=(1,0,0))

def poly(pts,z,h):
    return Pos(0,0,z)*extrude(Polygon(*pts,align=None),amount=h,dir=(0,0,1))

def make(p=P):
    a=p.module_length/2+p.end_allowance; b=p.module_height+p.height_allowance+p.divider/2
    A=a+p.wall; B=b+p.wall; c=p.slide_play
    seat=p.floor+p.relief; deck=seat+p.module_thickness+p.packing_depth
    t=p.lid_thickness; k=p.bevel_start; w=b+p.rail_reach; v=w-(t-k)
    Z=deck+t+.55
    body=rect(-A,A,-B,B,0,Z,4)
    body=chamfer(body.edges().filter_by(Plane.XY),.55)
    body-=rect(-a,a,-b,b,p.floor,Z+1,2)
    # Channels share a 45-degree ceiling. Far end is a blind stop.
    channel=section(-a,A+1,[(deck-c,w+c),(deck+k,w+c),(deck+t,v+c),(Z+1,v+c)])
    body-=channel
    # Only the sloped side lips continue above the entry sill.
    body-=rect(a-.01,A+1,-v-c,v+c,deck-c,Z+1)
    for sign in [-1,1]:
        for side in [-1,1]:
            xx=sorted([side*a*.18,side*(a-3)])
            yy=sorted([sign*(b-28),sign*(b-.7)])
            foot=rect(*xx,*yy,p.floor-.1,seat,3)
            foot=chamfer(foot.edges().group_by(Axis.Z)[-1],.5)
            body+=foot
    for lo,hi in [(-a-1,-15),(15,a+1)]:
        body+=rect(lo,hi,-p.divider/2,p.divider/2,p.floor-.1,deck-1.1,1)
    # Open-top keeper; the square +X shoulder resists withdrawal.
    tooth=A-11; body-=rect(tooth-7,tooth+.45,b-2,B+1,deck-.42,Z+1)
    x0=-a+c; x1=A-.7
    lid=section(x0,x1,[(0,w),(k,w),(t,v)])
    # Round external plan corners and soften loading nose while retaining guide lands.
    lid &= rect(x0,x1,-w,w,-1,t+1,2)
    # Integral in-plane spring. Slot turns inward to form a wide thumb paddle.
    root=tooth-34; y=w-5.5; gap=3.8
    slot=poly([(root,y),(tooth-17,y),(tooth-11,y-6),(A+1,y-6),
               (A+1,y-6-gap),(tooth-11,y-6-gap),(tooth-17,y-gap),(root,y-gap)],-1,t+2)
    slot+=Pos(root,y-gap/2,-1)*Cylinder(gap/2,t+2,align=(Align.CENTER,Align.CENTER,Align.MIN))
    lid-=slot
    lug=poly([(tooth-6,w-.6),(tooth,w+1.7),(tooth,w-.6)],0,k)
    lid+=lug
    for i in range(3):
        lid+=rect(tooth-7,tooth+3,y-4+i*2.5,y-2.8+i*2.5,t-.05,t+.65,.55)
    # Raised lettering, with optical bounds centred rather than typographic origin.
    def mark(txt,size,cx,cy):
        s=Text(txt,size,font='Fillaprint',font_path=FONT)
        bb=s.bounding_box(); return Pos(cx-bb.center().X,cy-bb.center().Y,t-.04)*extrude(s,amount=.64)
    lid+=mark('DDR4',p.text_em*1.95,-a*.48,7)
    lid+=mark('2 x UDIMM',p.text_em,-a*.48,-9)
    lid+=mark('OPEN',p.text_em,a*.48,12)
    lid+=poly([(a*.48-12,3),(a*.48+5,3),(a*.48+5,5),(a*.48+12,1.8),
               (a*.48+5,-1.4),(a*.48+5,.6),(a*.48-12,.6)],t-.04,.64)
    # Chevron points from the grip into the travel space of the spring.
    lid+=poly([(tooth-6,y-4.3),(tooth-3,y-5.7),(tooth,y-4.3)],t-.04,.64)
    return body.clean(),lid.clean(),deck

if __name__=='__main__':
    OUT.mkdir(exist_ok=True)
    tray,lid,z=make(); parts=[]
    for name,part,dz in [('tray',tray,0),('lid',lid,z)]:
        assert part.is_valid and len(part.solids())==1,name
        part.label=name
        export_step(part,OUT/f'{name}.step');export_stl(part,OUT/f'{name}.stl',tolerance=.035,angular_tolerance=.12,ascii_format=False)
        parts.append(dict(name=name,step=f'parts/{name}.step',stl=f'parts/{name}.stl',transform=[[1,0,0,0],[0,1,0,0],[0,0,1,dz],[0,0,0,1]]))
    (ROOT/'assembly.json').write_text(json.dumps(dict(units='mm',state='closed, latch relaxed',convention='row-major matrices multiplying local homogeneous column vectors',parts=parts),indent=2)+'\n')
