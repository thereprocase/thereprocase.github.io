# Two-bay DDR4 mailer

A reusable inner case for **two individually bagged desktop UDIMMs**. The modules lie flat, one on either side of a low center fence. Each heatspreader sits on two broad lands; the contact edge overhangs a recessed floor. Closed size including the thumb grip: **151.6 × 108 × 21.05 mm**. Use a cushioned outer cardboard box. The printed case provides neither static shielding nor a tested impact rating.

### What fits

| Measure before loading | Limit per bay |
|---|---|
| Bare module, including spreader and contacts | **Up to 136 mm long, 34–43 mm high, up to 9 mm thick** |
| Finished bag with folded seams, sling and light padding | **140 × 46 × 12 mm** maximum rectangular pack |

Reference points: Kingston lists the non-RGB [FURY Beast DDR4](https://www.kingston.com/en/memory/gaming/kingston-fury-beast-ddr4-memory) at **133.35 × 34.1 × 7.2 mm**, and the non-RGB [FURY Renegade DDR4](https://www.kingston.com/en/memory/gaming/kingston-fury-renegade-ddr4-memory) at **133.35 × 42.2 × 8.3 mm** (L × H × T). The envelope spans those low and taller heatspreaders with allowance for the bag and a little wrap. The 34 mm lower height limit keeps the underside of the contact band off the lands with the placement below. Check your exact revision, especially flared fins, offset spreaders and bag welds. Tall light bars, DIMMs with fans, and SO-DIMMs are outside the design target.

### Pack, close, reopen

1. Bag each module separately in a shielding bag. In each bay lay a narrow paper strip **lengthwise** along the heatspreader lands, with a lift tail at both short ends. Lower the bag onto it: **gold edge toward the center fence**, heatspreader spine parallel to and about **2.8 mm from the outer bay wall**. The two ends of the strip should lift the spreader together.
2. Fit folded card or thin soft foam at the **spreader ends and spine** so the bag cannot skate along or across the lands. Small folded end shoes can occupy the space beyond the PCB ends and locate the spreader without touching the contact edge. Keep the spine within about 0.5 mm of the specified position. Turn loose seams and sling tails back onto the spreader. Keep all firm padding away from the gold edge. Fold bulky bag tails outside the bay first; if the pack exceeds the gauge, use a better-fitting bag.
3. Feed the plain short end of the lid into the open ends of both rails, lettering up. Slide against the `OPEN` arrow until the ramped tooth springs into the side window. Give the lid a light pull without pressing the grip: the square tooth shoulder should hold. The rails resist lifting and the blind end stops forward travel. The deck should slide freely without dragging a bag. If a stick moves during a gentle tilt, adjust its soft packing before boxing; never force the lid over a high spot.
4. To open, push the **ribbed tab sideways toward the middle of the lid** and slide the lid in the `OPEN` direction. Hold the tab inward until the tooth clears the rim. Slide the lid off, unfold the paper tails, and lift both tails together. The break in the center fence also gives access to a loose bag fold. No tool or prying under the PCB is required.

### Files and fabrication

- `parts/tray.step`, `parts/lid.step`: editable boundary solids. Matching `.stl` files are binary meshes in mm, one of each. Both are already flat-side down; print the tray open-side up and the lid lettering up. `assembly.json` locates those same files in the nominal closed position.
- `make_mailer.py`: parametric build123d source. Edit `Spec` for stock size, packing space, thickness, fit or label scale. Fit checks below describe **the supplied size**; revise the verification gauges when changing its intended payload. Rebuild with `/home/repro/venvs/kraken-cad/bin/python make_mailer.py` here.
- Start with PETG for the repeatedly flexed tongue, a 0.4 mm nozzle, 0.20 mm layers, about 0.42 mm line width and at least three perimeters. Keep seams and first-layer flare off the guide edges. The rail ceilings slope at 45°; the lid spring lies in the layer plane. These are suggested starting settings, not a sliced profile.
- Raised labels use the supplied **FillaPrint** by Repro; font and OFL license are in `assets/fillaprint/`. Smallest em is 10 mm, measured H is 7 mm, nominal stroke 1 mm: above the supplied 5.88 mm cap-height minimum for a 0.42 mm text line. Keep text lines ≤0.50 mm at this scale.

**Before mailing hardware:** test the slide and click empty, cycle the latch, then try representative wrapped dummies. Check that pressing the tab is comfortable, ordinary pulling cannot release it, bags do not snag or shift when inverted, and the contact band remains clear after handling. Confirm cushioning and retention with the actual outer carton and a dummy transit/drop trial. No print, slicing or physical test was performed. See [measured checks](CHECKS.md) for what was verified digitally.
