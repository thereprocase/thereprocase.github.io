# Gridfinity metric fastener bins

The 210 × 168 mm base holds 12 screw bins and eight shallow nut and washer bins on a 42 mm pitch. Each lifts independently. The starter assortment favours short screws for M2 and longer screws for M4.

## Starter layout

Viewed from the 210 mm front edge (Y = 0), the labels read as shown. Screw lengths are measured in millimetres from under the socket head.

| Row | Short screw | Medium screw | Long screw | Plain hex nut | Flat washer |
| --- | --- | --- | --- | --- | --- |
| M4 · back | M4×10 | M4×16 | M4×20 | M4 NUT | M4 WASH |
| M3 | M3×8 | M3×12 | M3×16 | M3 NUT | M3 WASH |
| M2.5 | M2.5×6 | M2.5×10 | M2.5×12 | M2.5 NUT | M2.5 WASH |
| M2 · front | M2×6 | M2×8 | M2×10 | M2 NUT | M2 WASH |

Slide a washer toward the curved front wall to tip it on edge, or roll a short screw up the same scoop. Slip a fingertip under the rear label shelf, pinch from above and lift vertically. Keep the bin level while carrying it. For stacking, settle the contents below the shelf before lowering the next bin into the rim.

## Clear spaces and interfaces

| Dimension, in mm unless stated | Screw bin | Nut or washer bin |
| --- | ---: | ---: |
| Overall part, width × depth × height | 41.5 × 41.5 × 39 | 41.5 × 41.5 × 25 |
| Height added when stacked | 35 (5U) | 21 (3U) |
| Clear opening in front of label, width × depth at centre | 34.6 × 23.8 | 34.6 × 23.8 |
| Flat floor depth along centreline | 21.8 | 18.4 |
| Curved scoop, horizontal run × vertical rise | 12.8 × 27.6 | 12.8 × 13.6 |
| Free volume up to label shelf | 26.17 cm³ | 10.63 cm³ |

The foot measures 35.6 mm square at the sole, 37.2 mm after the first 0.8 mm bevel, then 41.5 mm at Z = 4.75 after a 1.8 mm land and 2.15 mm bevel. Corner radii grow from 0.8 to 3.75 mm around common centres. The base seats the soles on a 1.6 mm floor. Its 5.8 mm overall height leaves a 0.45 mm outside rim at a cell side. Adjacent bins have a 0.50 mm gap, and the tallest assembled point is 40.6 mm above the bench.

The stacking lip has a 4.0 mm rise with a 0.55 mm crest. A flat shoulder supports the next sole at a whole multiple of 7 mm. Side clearance is 0.20 mm at the lip entrance and 0.25 mm on the guide land. Raised lettering finishes 1.6 mm below the supported sole. Interface dimensions follow the Gridfinity drawing, with truncated crests to give the rims finite thickness. [Gridfinity design reference](https://gridfinity.xyz/specification/)

## Capacity, labels and handling checks

The audit placed 20 screws in each screw bin and 30 nuts or washers in each shallow bin using conservative solid envelopes. The M4×20 test includes a 7.22 mm grooved head, an enlarged under-head transition and 0.4 mm of extra shank length. Those 20 envelopes occupy 8.52 cm³. Thirty M4 nuts occupy 4.93 cm³ using cylinders that enclose their corners, and thirty M4 flat washers occupy 1.72 cm³ using solid discs. All placements cleared the bin, the other items and the next stacking plane. Loose-pour counts depend on how the hardware settles. [Screw dimensions](https://www.fasteners.eu/standards/ISO/4762/) · [Nut dimensions](https://www.fasteners.eu/standards/ISO/4032/) · [Washer dimensions](https://www.fasteners.eu/standards/ISO/7089/)

Both bin heights admit a 16 mm spherical fingertip model to within 0.05 mm of the floor. An 8 mm rounded tip passes under the grip, and a 5 × 0.35 mm M2 washer clears the full front scoop and rim. The ink surfaces clear the neighbouring bins along sight lines 30° above the front edge. Permanent raised labels use the supplied FillaPrint outlines, 8.6 mm em, 6.02 mm measured capitals and 0.6 mm relief. The nominal stroke and gap are 0.86 mm, meeting the font minimum for an extrusion line width up to 0.43 mm. [Font sizing notes](assets/fillaprint/PRINTING.md) · [Font license](assets/fillaprint/OFL.txt)

**Physical fit is untested.** Check a bin on a known Gridfinity base, both stack orders for rocking, and a loaded interior bin for grip. Try a single M2 washer on the printed scoop, 20 loose M4×20 screws in the deep bin, and read the labels in drawer light.

## Files and extension

[Part exports](parts/) contain one STEP and one binary STL for each of the 21 parts. [assembly.json](assembly.json) gives file paths, hardware assignments and local-to-world transforms in millimetres. [checks.json](checks.json) records measured results per export, including section gaps and stacked contact. Both part formats use the same local coordinates.

Rebuild the starter layout and rerun the audit from this directory.

```sh
/home/repro/venvs/kraken-cad/bin/python organizer.py
/home/repro/venvs/physics/bin/python verify.py
```

For an additional M3×20 bin, run the following command. It writes a matching pair of part files for an existing socket or another base. To make a different starter arrangement, edit `THREAD_ROWS` in [organizer.py](organizer.py). The `--units` option changes the height in 7 mm steps. Recheck capacity and reach for a changed size or height. The repeatable audit in [verify.py](verify.py) uses the hardware envelopes and packing poses for the supplied assortment.

```sh
/home/repro/venvs/kraken-cad/bin/python organizer.py --single screw --diameter 3 --length 20
```
