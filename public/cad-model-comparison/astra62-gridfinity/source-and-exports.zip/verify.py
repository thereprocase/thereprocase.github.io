"""Audit the delivered STEP and binary STL files. Run with the mesh interpreter."""
import json
import math
import struct
import subprocess
import sys
from itertools import combinations, product
from pathlib import Path

ROOT = Path(__file__).resolve().parent
assembly = json.loads((ROOT / "assembly.json").read_text())
parts = assembly["parts"]

if sys.argv[1:] == ["--step"]:
    from build123d import import_step
    result = {}
    for p in parts:
        shape = import_step(ROOT / p["step"])
        assert shape.is_valid and len(shape.solids()) == 1, p["id"]
        bb = shape.bounding_box()
        result[p["id"]] = dict(volume=shape.volume, bounds=[list(bb.min), list(bb.max)])
    print(json.dumps(result))
    sys.exit()

import manifold3d as md
import numpy as np
import trimesh
from shapely.geometry import LineString, Polygon

M = md.Manifold
TOL_VOLUME = 1e-5
# Screw axes parallel to X. These are measured feasible centres in the common
# YZ section. Three head stations let neighbouring heads pass one another.
SCREW_POSES = [
    (-5.66,10.38,1), (0.77,10.09,2), (7.85,10.09,0), (13.58,10.09,1),
    (-9.50,14.64,2), (-2.23,14.97,0), (4.31,14.60,1), (13.58,15.82,0),
    (-11.67,19.95,0), (-5.98,19.32,1), (-0.34,20.38,2), (5.39,20.23,0),
    (11.07,20.98,1), (-12.94,25.54,1), (-5.84,25.55,0), (0.40,26.07,1),
    (6.13,25.92,2), (-13.54,31.24,0), (-7.81,31.19,1), (-2.07,31.24,2)]
# diameter -> grooved head OD, underhead transition OD, nut AF, nut height,
# plain washer OD and maximum thickness
HARDWARE = {2:(3.98,2.6,4,1.6,5,.35), 2.5:(4.68,3.1,5,2,6,.55),
            3:(5.68,3.6,5.5,2.4,7,.55), 4:(7.22,4.7,7,3.2,9,.9)}


def cylinder(d, h):
    # Circumscribe the true circle so the tessellation encloses the hardware.
    return M.cylinder(h, d / (2 * math.cos(math.pi/64)), circular_segments=64)


def packed(p):
    d = p["diameter"]
    head, transition, af, nut_h, washer_d, washer_h = HARDWARE[d]
    if p["kind"] == "screw":
        h = cylinder(head, d)
        collar = cylinder(transition, 1.2).translate((0, 0, d))
        shank = cylinder(d, p["length"] + .4).translate((0, 0, d))
        item = h + collar + shank
        stations = [(-14.7,90), (-9.12,90), (14.7,-90)]
        return [item.rotate((0,stations[s][1],0)).translate((stations[s][0],y,z))
                for y,z,s in SCREW_POSES]
    if p["kind"] == "nut":
        # Circle encloses every orientation of the solid hexagon.
        item = cylinder(af / math.cos(math.pi/6), nut_h)
        return [item.translate((x,y,8.00 + k*(nut_h+.05))) for k,y,x in
                product(range(4), [-6.29,2.05], [-12.36,-4.12,4.12,12.36])][:30]
    item = cylinder(washer_d, washer_h)
    return [item.translate((x,y,8.35+k*(washer_h+.12))) for k,y,x in
            product(range(5), [-4.8,4.5], [-9.3,0,9.3])]


def union(items):
    return M.batch_boolean(items, md.OpType.Add)


def collision(a,b,tag,limit=TOL_VOLUME):
    value = abs((a ^ b).volume())
    assert value < limit,(tag,value)
    return value


def rounded(value):
    return round(float(value), 5)


def label_bounds(mesh,datum):
    # Restrict section to shelf. The lower ink slice is taken halfway up relief.
    patch = md.CrossSection.square((33.4, 6.8)).translate((-16.7,8.25))
    ink = mesh.slice(datum-2.2+.3) ^ patch
    assert ink.area() > 10
    assert (mesh.slice(datum-2.2+.61) ^ patch).area() < 1e-6
    x1,y1,x2,y2 = ink.bounds()
    assert abs(y2-y1-6.02) < .01
    return list(map(rounded,(x2-x1,y2-y1)))


def test_access(mesh,datum):
    # Sweep a spherical pad vertically. Hull of its end poses is the complete path.
    pad = M.sphere(8, circular_segments=80)
    low = pad.translate((0,-2.2,14.45))
    path = M.batch_hull([low,pad.translate((0,-2.2,datum+13))])
    collision(mesh,path,"16 mm pad to floor")
    grip = M.sphere(4, circular_segments=80)
    z = datum-2.2-2.0-5.35
    path = M.batch_hull([grip.translate((0,y,z)) for y in (-1,5.8)])
    collision(mesh,path,"8 mm pad under shelf")
    # Move the smallest washer tangent to the curved scoop then past the rim.
    # Normal offset gives the flat disc clearance over the curve.
    a,b = 12.8,datum-1-6.4
    washer = cylinder(5,.35)
    poses = []
    for t in np.linspace(math.pi*1.5,math.pi,55):
        y,z = -4.5+a*math.cos(t), datum-1+b*math.sin(t)
        normal = np.array([-math.cos(t)/a,-math.sin(t)/b])
        ny,nz = normal/np.linalg.norm(normal)
        tilt = -math.degrees(math.atan2(ny,nz))
        poses.append(washer.rotate((tilt,0,0)).translate((0,y+ny*.9,z+nz*.9)))
    poses.append(washer.rotate((-90,0,0)).translate((0,-17.3+.9,datum+7)))
    # The convex hull between successive poses encloses linear vertex travels.
    for a,b in zip(poses,poses[1:]):
        collision(mesh,M.batch_hull([a,b]),"washer scoop")
    return dict(pad_diameter=16, pad_bottom_z=6.45, pad_to_floor=.05,
                under_shelf_pad_diameter=8, washer_od=5, washer_thickness=.35,
                washer_sweep_segments=len(poses)-1)


def center_crossing(m,z,x=0,y=0):
    line = LineString([(x+0.0003,y),(x+23,y)])
    endpoints=[]
    for poly in m.slice(z).to_polygons():
        cut=Polygon(poly).boundary.intersection(line)
        for obj in getattr(cut,"geoms",[cut]):
            if not obj.is_empty:
                endpoints.append(obj.x-x)
    return sorted(endpoints)


def main():
    cadpython="/home/repro/venvs/kraken-cad/bin/python"
    steps=json.loads(subprocess.check_output([cadpython,__file__,"--step"],text=True))
    meshes,world,stats={},{},{}
    viewpoints={}
    for p in parts:
        key=p["id"]
        path=ROOT/p["stl"]
        with path.open("rb") as f:
            f.seek(80)
            count=struct.unpack("<I",f.read(4))[0]
        assert path.stat().st_size == 84+50*count
        mesh=trimesh.load_mesh(path)
        assert mesh.is_volume and mesh.is_watertight and mesh.is_winding_consistent
        assert mesh.body_count == 1 and len(mesh.faces)==count,key
        assert np.allclose(mesh.bounds,steps[key]["bounds"],atol=.012)
        delta=abs(mesh.volume-steps[key]["volume"])/steps[key]["volume"]
        assert delta<.0005,(key,delta)
        m=M(md.Mesh(mesh.vertices.astype("float32"),mesh.faces.astype("uint32")))
        assert m.status()==md.Error.NoError
        transform=np.asarray(p["transform"],dtype=float)
        assert np.array_equal(transform[:3,:3],np.eye(3))
        meshes[key],world[key]=m,m.translate(transform[:3,3])
        record=stats[key]=dict(triangles=count,step_valid_solids=1,stl_closed_bodies=1,
            local_bounds_mm=mesh.bounds.round(3).tolist(),step_mm3=rounded(steps[key]["volume"]),
            stl_mm3=rounded(mesh.volume))
        if key=="base":
            continue
        datum=p["height_units"]*7
        record["ink_width_height_mm"]=label_bounds(m,datum)
        centres=mesh.triangles_center
        ink_top=(np.abs(centres[:,2]-(datum-1.6))<1e-4) & (mesh.face_normals[:,2]>.999)
        viewpoints[key]=centres[ink_top]+transform[:3,3]+[0,0,.015]
        assert len(viewpoints[key])>10
        load=packed(p)
        solid=union(load)
        overlap=sum(item.volume() for item in load)-solid.volume()
        assert abs(overlap)<TOL_VOLUME,(key,overlap)
        collision(m,solid,key+" load")
        top=solid.bounding_box()[5]
        assert top<datum,key
        # The entire clipped rectangular column lies within the external body.
        # Subtracting the bin leaves only its internal well and letter recess.
        column=M.cube((34.6,34.6,datum-2.2-6.4)).translate((-17.3,-17.3,6.4))
        cavity=(column-m).volume()
        record.update(count_tested=len(load),hardware_envelope_mm3=rounded(solid.volume()),
                      free_mm3_below_label_top=rounded(cavity),
                      packed_top_to_stack_datum_mm=rounded(datum-top),
                      packed_bin_overlap_mm3=0,packed_pair_overlap_mm3=rounded(abs(overlap)))
        # Float32 STL stores the 1.6 mm base floor 0.000000024 mm above nominal.
        record["seated_overlap_mm3"] = round(collision(
            world["base"],world[key],key+" seating",limit=5e-5),9)
    bins=parts[1:]
    # Sight lines from actual top facets toward a viewer 30 degrees above
    # the front. The segments end above the highest part in the assembly.
    for p in bins:
        group=[world[q["id"]] for q in bins if q["column"]==p["column"]]
        rays=viewpoints[p["id"]]
        for start in rays:
            end=start+[0,-52,30.022]
            assert not any(item.ray_cast(start,end) for item in group),p["id"]
        stats[p["id"]]["unobstructed_ink_top_rays_30deg"]=len(rays)
    gaps=[]
    for a,b in combinations(bins,2):
        d=abs(a["row"]-b["row"])+abs(a["column"]-b["column"])
        if d==1:
            gaps.append(world[a["id"]].min_gap(world[b["id"]],1.0))
        collision(world[a["id"]],world[b["id"]],"neighbours")
    assert abs(min(gaps)-.5)<1e-5
    examples={p["height_units"]:meshes[p["id"]] for p in bins}
    access={}
    stack={}
    for u,lower in examples.items():
        datum=u*7
        access[str(u)]=test_access(lower,datum)
        for v,upper in examples.items():
            seated=upper.translate((0,0,datum))
            collision(lower,seated,"stack")
            at_contact=(seated ^ lower.translate((0,0,.01))).volume()/.01
            assert at_contact>20
            stack[f"{u}u-under-{v}u"]=dict(pitch_mm=datum,
                  overlap_mm3=0,contact_area_from_0p01mm_approach_mm2=rounded(at_contact))
    # Radial clearances at transitions and mid-spans, measured on the STL straight sides.
    foot=examples[5]
    radii={}
    for interface, receiver,origin,z0,levels in [
        ("base",world["base"],(21,21),1.6,[.01,.7,.8,1.7,2.5,2.6,3.5,4.19]),
        ("stack",examples[3],(0,0),21,[.01,.7,.8,1.7,2.5,2.6,3.5,3.85,3.999])]:
        rows=[]
        for z in levels:
            clear=center_crossing(receiver,z0+z,*origin)[0]-center_crossing(foot,z)[0]
            assert .19<clear<.37,(interface,z,clear)
            rows.append([z,rounded(clear)])
        radii[interface]=rows
    result=dict(units="mm",parts=stats,
                assembly=dict(instances=len(world),adjacent_pairs=len(gaps),
                              minimum_neighbour_gap=rounded(min(gaps)),
                              max_seated_overlap_mm3=max(r.get("seated_overlap_mm3",0) for r in stats.values()),
                              any_bin_pair_overlap_mm3=0,stack=stack),
                measured_side_gap_by_height=radii,handling=access)
    (ROOT/"checks.json").write_text(json.dumps(result,indent=2)+"\n")
    print("Verified",len(parts),"STEP/STL pairs, assembly, stacking, access and capacity.")

if __name__=="__main__":
    main()
