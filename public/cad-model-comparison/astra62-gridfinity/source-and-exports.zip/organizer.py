"""Build the starter kit or one new labelled bin. All dimensions are millimetres."""
import argparse
import json
from functools import lru_cache
from pathlib import Path

from build123d import (Edge, Face, Plane, RectangleRounded, Solid, Text, Wire,
                       export_step, export_stl)

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "parts"
FONT = ROOT / "assets/fillaprint/Fillaprint-Regular.ttf"
PITCH, UNIT = 42.0, 7.0
COLS, ROWS = 5, 4
BASE_FLOOR = 1.6
BASE_RIM = 4.20
STACK_RIM = 4.0
FLOOR = 6.4
WELL = 34.6
SCOOP_RUN = 12.8
SHELF_NOSE = 6.5
SHELF_DROP = 2.2
SHELF_EDGE = 2.0
SHELF_Y = 11.65
EM, RELIEF = 8.6, 0.6
THREAD_ROWS = [(2, [6, 8, 10]), (2.5, [6, 10, 12]),
               (3, [8, 12, 16]), (4, [10, 16, 20])]
HEIGHT_UNITS = {"screw": 5, "nut": 3, "washer": 3}
# z above local interface, outside width. Concentric corner centres at +/-17.
FOOT = [(0, 35.6), (0.8, 37.2), (2.6, 37.2), (4.75, 41.5)]


def section(z, width):
    return RectangleRounded(width, width, width / 2 - 17).wire().translate((0, 0, z))


def profile(stations):
    return Solid.make_loft([section(z, w) for z, w in stations], ruled=True)


def socket(datum, height, extra=0.1):
    # Leave a flat rim at the crest. The 45-degree entry stops below the
    # theoretical knife edge. The extra slice carries the cutter through.
    top_width = 37.7 + 2 * (height - 2.5)
    stations = [(0, 36.3), (0.7, 37.7), (2.5, 37.7),
                (height, top_width), (height + extra, top_width)]
    return profile([(datum + z, w) for z, w in stations])


def rounded_prism(width, depth, radius, bottom, height):
    face = RectangleRounded(width, depth, radius).face()
    return Solid.extrude(face, (0, 0, height)).translate((0, 0, bottom))


def cells():
    for row, (diameter, lengths) in enumerate(THREAD_ROWS):
        contents = [("screw", length) for length in lengths] + [("nut", 0), ("washer", 0)]
        for col, (kind, length) in enumerate(contents):
            yield row, col, diameter, kind, length


def center(row, col):
    return ((col + 0.5) * PITCH, (row + 0.5) * PITCH)


def baseplate():
    thick = BASE_FLOOR + BASE_RIM
    body = rounded_prism(COLS * PITCH, ROWS * PITCH, 3.75, 0, thick)
    body = body.translate((COLS * PITCH / 2, ROWS * PITCH / 2, 0))
    die = socket(BASE_FLOOR, BASE_RIM)
    return body.cut(*[die.translate((*center(r, c), 0))
                      for r in range(ROWS) for c in range(COLS)])


def pocket(datum):
    """Void below the stacking seat, including space both under and above the grip."""
    side = WELL / 2
    shoulder_z = datum - 1
    toe = -side + SCOOP_RUN
    plane = Plane(origin=(-22, toe, shoulder_z), x_dir=(0, 1, 0), z_dir=(1, 0, 0))
    arc = Edge.make_ellipse(SCOOP_RUN, shoulder_z - FLOOR, plane, 180, 270)
    # A 45-degree underside gives a fingertip purchase behind the shelf nose.
    top = datum - SHELF_DROP
    under = top - SHELF_EDGE
    back = min(side, SHELF_NOSE + under - FLOOR - 3.0)
    yz = [(toe, FLOOR), (back, FLOOR), (back, under - (back - SHELF_NOSE)),
          (SHELF_NOSE, under), (SHELF_NOSE, top), (side, top),
          (side, datum + 0.03), (-side, datum + 0.03), (-side, shoulder_z)]
    pts = [(-22, y, z) for y, z in yz]
    wire = Wire([arc, *[Edge.make_line(a, b) for a, b in zip(pts, pts[1:])]])
    across = Solid.extrude(Face(wire), (44, 0, 0))
    footprint = rounded_prism(WELL, WELL, 2.2, FLOOR, datum + 1 - FLOOR)
    return across.intersect(footprint)[0]


@lru_cache
def bin_body(units):
    datum = units * UNIT
    if datum - SHELF_DROP - SHELF_EDGE < FLOOR + 8:
        raise ValueError("Bin too shallow for the lifting shelf")
    # Truncate the nominal lip for a 0.55 mm crest and 0.20 mm entry clearance.
    exterior = profile([*FOOT, (datum + STACK_RIM, 41.5)])
    rim_die = socket(datum, STACK_RIM - 0.15, extra=0.25)
    return exterior.cut(pocket(datum), rim_die).clean()


def inscription(diameter, kind, length):
    if kind == "screw":
        return f"M{diameter:g}×{length:g}"
    return f"M{diameter:g} " + {"nut": "NUT", "washer": "WASH"}[kind]


def part_id(diameter, kind, length):
    thread = f"m{diameter:g}".replace(".", "p")
    return f"{thread}-{kind}" + (f"-{length:g}" if kind == "screw" else "")


def labelled_bin(diameter, kind, length, units):
    caption = inscription(diameter, kind, length)
    letters = Text(caption, font_size=EM, font_path=str(FONT))
    bb = letters.bounding_box()
    if bb.size.X > WELL - 1 or bb.size.Y > 8:
        raise ValueError(f"Inscription too large for shelf: {caption}")
    middle = bb.center()
    z = units * UNIT - SHELF_DROP
    glyphs = [Solid.extrude(f, (0, 0, RELIEF + 0.04)).translate(
        (-middle.X, SHELF_Y - middle.Y, z - 0.04)) for f in letters.faces()]
    return bin_body(units).fuse(*glyphs).clean()


def save(shape, name):
    if len(shape.solids()) != 1 or not shape.is_valid:
        raise ValueError(f"Invalid part {name}")
    OUT.mkdir(exist_ok=True)
    files = {ext: f"parts/{name}.{ext}" for ext in ("step", "stl")}
    shape.label = name
    if not export_step(shape, ROOT / files["step"]):
        raise IOError(f"STEP export failed for {name}")
    if not export_stl(shape, ROOT / files["stl"], tolerance=0.007, angular_tolerance=0.055):
        raise IOError(f"STL export failed for {name}")
    print(name, flush=True)
    return files


def placed(name, files, x=0, y=0, z=0, **info):
    return dict(id=name, **files, **info, transform=[
        [1, 0, 0, x], [0, 1, 0, y], [0, 0, 1, z], [0, 0, 0, 1]])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--single", choices=HEIGHT_UNITS)
    parser.add_argument("--diameter", type=float)
    parser.add_argument("--length", type=float, default=0)
    parser.add_argument("--units", type=int)
    args = parser.parse_args()
    if args.single:
        if not args.diameter or args.diameter <= 0 or (args.single == "screw" and args.length <= 0):
            parser.error("Supply positive diameter and screw length")
        units = args.units or HEIGHT_UNITS[args.single]
        name = part_id(args.diameter, args.single, args.length)
        if args.units:
            name += f"-{units}u"
        save(labelled_bin(args.diameter, args.single, args.length, units), name)
        return
    if len(THREAD_ROWS) != ROWS or any(len(ls) + 2 != COLS for _, ls in THREAD_ROWS):
        raise ValueError("The layout and plate dimensions must agree")
    parts = [placed("base", save(baseplate(), "base"))]
    for row, col, d, kind, length in cells():
        units = HEIGHT_UNITS[kind]
        name = part_id(d, kind, length)
        files = save(labelled_bin(d, kind, length, units), name)
        parts.append(placed(name, files, *center(row, col), BASE_FLOOR,
                            label=inscription(d, kind, length), kind=kind, diameter=d,
                            length=length if kind == "screw" else None,
                            height_units=units, row=row, column=col))
    assembly = dict(units="mm", axes="+X right, +Y rear, +Z up; front is Y=0",
                    transform_convention="row-major 4x4, world = matrix @ local column vector",
                    parts=parts)
    (ROOT / "assembly.json").write_text(json.dumps(assembly, indent=2) + "\n")


if __name__ == "__main__":
    main()
