"""
DDR4 pair mailer -- parametric source (build123d).

Two parts:
  base  tray with two vertical slots.  Sticks stand spreader-edge down,
        gold contact edge UP, so nothing in the box can touch the pads.
  lid   sliding plate with stepped edge rails and a pull tab.

Why the lid stays on:
  * each long wall carries a lid track: a tunnel whose floor rises toward
    its mouth (a dovetail undercut).  The lid's edge rails are taller than
    the track mouth is high, so the lid cannot be lifted, tilted or pulled
    sideways out of the tracks.
  * a tooth under each rail seats in a latch pocket at the back of the
    track when the lid reaches the stop.  Opening needs a ~0.2 mm lift
    over the stepped pocket lip - a firm click, then a free slide.
How the sticks come out:
  slide the lid off through the front (deliberately removable for loading)
  and lift the sticks straight up.  With the lid closed the sticks cannot
  leave the box at all.

Units: mm.  Assembly frame: origin at the centre of the base bottom face,
z up, -x = front (pull-tab side), +x = back wall.

Edit PARAMETERS and re-run to regenerate for a different envelope.
"""

import json
import os

from build123d import (
    Axis, Box, Cylinder, Plane, Polygon, Pos, Rectangle, Rot, Text,
    extrude, export_step, export_stl, fillet,
)

HERE = os.path.dirname(os.path.abspath(__file__))
FONT = os.path.join(HERE, "assets", "fillaprint", "Fillaprint-Regular.ttf")
OUT = os.path.join(HERE, "out")

# ------------------------------------------------------------- PARAMETERS
MOD_L_MAX = 134.5   # supported module length (DDR4 UDIMM = 133.35 mm)
MOD_H_MAX = 42.5    # module height, contact edge to spreader edge
MOD_T_MAX = 9.0     # module thickness across the spreaders

BAG_ALLOW = 0.9     # ESD bag film + fold wrinkles, per slot
SLIDE     = 0.7     # extra slot room for the paper wrap and loading
CONTACT_GAP = 1.8   # air between the contact edge and the closed lid

WALL   = 3.4
FLOOR  = 2.6
RIB_W  = 2.6
LID_T  = 2.8
G_D    = 2.2        # track depth into the wall
LIP    = 0.8        # track-floor rise toward the mouth (the undercut)
CLR    = 0.15       # rail/track clearance
RAIL_LIFT = 0.30    # rail top face to track ceiling (lift allowance)
STRIP_WELD = 0.25   # rail overlap into the plate (solid joint)
NECK_IN  = 0.25     # rail inner face inside the plate edge plane
TOOTH_L  = 3.0      # latch tooth length along the lid
TOOTH_H  = 0.15     # latch tooth height (= pocket depth)
TOOTH_HOVER = 0.02  # tooth tip gap above the track floor while sliding
STEP1, STEP2 = 0.10, 0.05   # two-step lead-in on the pocket lip
POCKET_L = 8.0      # latch pocket length
TAB    = 14.0
ENGRAVE = 0.8       # FillaPrint pocket depth (4 layers @ 0.2 mm)

LID_FONT   = 12     # FillaPrint size, lid label (stroke ~1.2 mm)
FLOOR_FONT = 10     # FillaPrint size, floor labels (stroke ~1.0 mm = font min)

# --------------------------------------------------------------- derived
SLOT_W  = MOD_T_MAX + BAG_ALLOW + SLIDE          # 10.6
INT_W   = 2 * SLOT_W + RIB_W                     # 23.8
INT_L   = MOD_L_MAX + 3.5                        # 138.0
INT_H   = MOD_H_MAX + CONTACT_GAP                # 44.3
PLATE_W = INT_W - 2 * CLR                        # 23.5
PLATE_BOT = FLOOR + INT_H                        # 46.9 lid underside
STRIP_TOP = PLATE_BOT + STRIP_WELD               # 47.15
G_CEIL  = STRIP_TOP + RAIL_LIFT                  # 47.45 track ceiling
G_FLOOR = PLATE_BOT - 3.15                       # 43.75 track floor (deep end)
FL_SLOPE = LIP / G_D                             # floor flank slope (dz/dy)
Z_TOP   = FLOOR + INT_H + LID_T + 0.2            # 49.9 wall top
SILL_TOP = min(FLOOR + MOD_H_MAX - 0.6, G_FLOOR + CLR - 0.25)   # 43.5
RIB_TOP = FLOOR + INT_H - 0.4                    # 46.5
L_OUT, W_OUT = INT_L + 2 * WALL, INT_W + 2 * WALL   # 144.8 x 30.6
LID_L   = INT_L + WALL + TAB                     # 155.4
LID_W   = 2 * (INT_W / 2 + G_D - CLR)            # 27.9
LID_REAR = INT_L + WALL - L_OUT / 2              # 69.0  closed lid rear edge
LID_FRONT = LID_REAR - LID_L                     # -86.4
POCKET_X0 = LID_REAR - POCKET_L                  # 61.0  latch lip
TOOTH_X0 = POCKET_X0                             # tooth front face abuts lip
TOOTH_X1 = TOOTH_X0 + TOOTH_L

# ---------------------------------------------------------------- helpers
def box(x0, x1, y0, y1, z0, z1):
    return Pos((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2) * \
        Box(x1 - x0, y1 - y0, z1 - z0)


def prism_yz(pts, x_start, length):
    """Extrude a polygon given in the (y, z) plane along +x.

    The polygon is rewritten counter-clockwise in the sketch plane so the
    extrusion always follows +x regardless of the supplied point order.
    """
    area2 = sum(pts[i][0] * pts[(i + 1) % len(pts)][1]
                - pts[(i + 1) % len(pts)][0] * pts[i][1]
                for i in range(len(pts)))
    if area2 < 0:
        pts = pts[::-1]
    return Pos(x_start, 0, 0) * extrude(Plane.YZ * Polygon(*pts), length)


def text_solid(txt, size, cx, cy, cz, depth=ENGRAVE, dirn=+1, up=+1):
    """Engrave `txt` into a horizontal face at height cz.

    dirn=+1 cuts upward from cz, dirn=-1 cuts downward into the material.
    Reading direction runs +x, glyph tops toward +y.
    """
    sk = Text(txt, font_size=size, font_path=FONT)
    if up < 0:
        sk = Rot(Z=180) * sk
    bb = sk.bounding_box()
    dx = cx - (bb.min.X + bb.max.X) / 2
    dy = cy - (bb.min.Y + bb.max.Y) / 2
    return extrude(Pos(dx, dy, cz) * sk, depth * dirn)


def safe_fillet(part, edges, radius, label):
    try:
        return fillet(edges, radius)
    except Exception as exc:            # cosmetic only -- degrade gracefully
        print(f"  [warn] fillet '{label}' skipped: {exc}")
        return part


def track_floor(y):
    """Track floor height at lateral position y (rises toward the mouth)."""
    return G_FLOOR + FL_SLOPE * (INT_W / 2 + G_D - abs(y))


# ------------------------------------------------------------------- base
def build_base():
    b = extrude(Pos(0, 0, 0) * Rectangle(L_OUT, W_OUT), Z_TOP)
    # cavity, open at the top
    b -= box(-INT_L / 2, INT_L / 2, -INT_W / 2, INT_W / 2, FLOOR, Z_TOP + 1)
    # lower the front wall to sill height
    b -= box(-L_OUT / 2, -INT_L / 2, -W_OUT / 2, W_OUT / 2, SILL_TOP, Z_TOP + 1)
    # centre rib between the two slots
    b += box(-INT_L / 2, INT_L / 2, -RIB_W / 2, RIB_W / 2, FLOOR, RIB_TOP)

    # lid tracks in the top outer corner of each long wall
    for s in (-1, 1):
        y_mouth = s * INT_W / 2              # wall outer face (track mouth)
        y_deep = s * (INT_W / 2 + G_D)       # deepest point
        floor_m = track_floor(y_mouth)
        pts = [(y_mouth, floor_m),           # floor, raised at the mouth
               (y_deep, G_FLOOR),            # floor, low at depth
               (y_deep, G_CEIL),
               (y_mouth, G_CEIL)]
        b -= prism_yz(pts, -L_OUT / 2, L_OUT - WALL)   # open through the front

        # latch pocket: floor profile sunk by TOOTH_H over the back 8 mm
        sunk = [(y_mouth, floor_m - TOOTH_H), (y_deep, G_FLOOR - TOOTH_H),
                (y_deep, G_FLOOR), (y_mouth, floor_m)]
        b -= prism_yz(sunk, POCKET_X0, POCKET_L)
        # two-step lead-in so the tooth can climb out when opening
        for i, depth in ((0, STEP1), (1, STEP2)):
            x0 = POCKET_X0 - (i + 1) * 0.12
            prof = [(y_mouth, floor_m - depth), (y_deep, G_FLOOR - depth),
                    (y_deep, G_FLOOR), (y_mouth, floor_m)]
            b -= prism_yz(prof, x0, 0.122)
    # cosmetic fillets (before label engraving so pockets stay crisp).
    # Kept minimal on purpose: OCC segfaults on the full top-edge loops of
    # this shape, and the outer corner rounds matter most for handling.
    vert = [e for e in b.edges().filter_by(Axis.Z)
            if abs(e.center().X) > L_OUT / 2 - 0.5
            and abs(e.center().Y) > W_OUT / 2 - 0.5]
    b = safe_fillet(b, vert, 4.0, "outer vertical edges")
    b = safe_fillet(b, [e for e in b.edges()
                        if abs(e.center().Z - SILL_TOP) < 0.01
                        and abs(e.center().X + L_OUT / 2) < 0.01],
                    0.6, "sill front edge")
    b = safe_fillet(b, [e for e in b.edges()
                        if abs(e.center().Z - RIB_TOP) < 0.01
                        and abs(abs(e.center().Y) - RIB_W / 2) < 0.01],
                    0.5, "rib top edges")

    # FillaPrint labels in the slot floors (read while loading)
    for cy in (-(INT_W / 2 - SLOT_W / 2), INT_W / 2 - SLOT_W / 2):
        b -= text_solid("CONTACTS UP", FLOOR_FONT, 0, cy, FLOOR, dirn=-1)
    return b


# -------------------------------------------------------------------- lid
def build_lid():
    # central plate
    lid = box(LID_FRONT, LID_REAR, -PLATE_W / 2, PLATE_W / 2,
              PLATE_BOT, PLATE_BOT + LID_T)

    for s in (-1, 1):
        y_neck = s * (PLATE_W / 2 - NECK_IN)      # 11.50 rail inner face
        y_deep = s * (INT_W / 2 + G_D - CLR)      # 13.95 rail deep face
        z_bot_deep = track_floor(y_deep) + CLR    # rail bottom (deep end)
        z_bot_neck = track_floor(y_neck) + CLR    # rail bottom (mouth end)
        pts = [(y_neck, STRIP_TOP),
               (y_deep, STRIP_TOP),
               (y_deep, z_bot_deep),
               (y_neck, z_bot_neck)]
        lid = lid + prism_yz(pts, LID_FRONT, LID_L)

        # latch tooth: thin wedge under the rail, tip on the track floor
        tooth = [(y_neck, track_floor(y_neck)),
                 (y_deep, track_floor(y_deep)),
                 (y_deep, z_bot_deep + 0.2),
                 (y_neck, z_bot_neck + 0.2)]
        lid = lid + prism_yz(tooth, TOOTH_X0, TOOTH_L)

    # cosmetic fillets (before the label so pocket edges stay crisp)
    lid = safe_fillet(lid, lid.edges().group_by(Axis.Z)[-1], 0.8,
                      "lid top edges")

    # FillaPrint label on the top face
    lid -= text_solid("2 × DDR4", LID_FONT, 0, 0, PLATE_BOT + LID_T, dirn=-1)

    # finger dish in the tab underside: half-cylinder clipped flat so it
    # leaves 1.6 mm of plate (never pierces through)
    dish = (Pos(LID_FRONT + 7.0, 0, PLATE_BOT + 1.2)
            * Rot(Y=90) * Cylinder(radius=9.0, height=12.0))
    dish = dish & box(LID_FRONT + 1.0, LID_FRONT + 13.0,
                      -9.5, 9.5, PLATE_BOT - 10, PLATE_BOT + 1.2)
    lid -= dish
    return lid


# ------------------------------------------------------------------ checks
def vol(shape):
    try:
        return shape.volume
    except Exception:
        return 0.0


def report_checks(base, lid):
    print("\n--- exact geometric checks (build123d booleans) ---")
    failures = []

    def check(name, cond, detail=""):
        cond = bool(cond)
        if not cond:
            failures.append(name)
        print(f"  [{'PASS' if cond else 'FAIL'}] {name} {detail}")

    check("base/lid interference when closed = 0",
          vol(base & lid) < 1e-6, f"(vol={vol(base & lid):.1e})")
    # the seated closed pose: lid dropped by the latch depth
    check("base/lid interference when seated (latch dropped) = 0",
          vol(base & (Pos(0, 0, -TOOTH_H) * lid)) < 1e-6,
          f"(vol={vol(base & (Pos(0, 0, -TOOTH_H) * lid)):.1e})")

    worst = None
    t = 1.0
    while t <= LID_L + 2:
        if vol(base & (Pos(-t, 0, 0) * lid)) > 1e-6:
            worst = t
            break
        t += 1.0
    check("lid slides off through the front without collision", worst is None,
          f"(clear over the full {LID_L:.0f} mm travel)"
          if worst is None else f"(first collision at t={worst:.0f} mm)")

    free_lift = 0.0
    d = 0.02
    while d <= 0.6:
        if vol(base & (Pos(0, 0, d) * lid)) > 1e-6:
            break
        free_lift = d
        d += 0.02
    check("lid jams when lifted (cannot escape tracks)", free_lift < 0.6,
          f"(free vertical play {free_lift:.2f} mm, then hard stop)")

    free_ang = 0.0
    pivot = Pos(0, -(INT_W / 2 + G_D - CLR), G_FLOOR)
    for a in range(1, 21):
        moved = (pivot * Rot(X=a) * pivot.inverse()) * lid
        if vol(base & moved) > 1e-6:
            break
        free_ang = a
    check("lid jams when tilted about one rail", free_ang < 20,
          f"(free tilt {free_ang:.0f} deg, then hard stop)")

    free_side = 0.0
    d = 0.2
    while d <= 2.0:
        if vol(base & (Pos(0, d, 0) * lid)) > 1e-6:
            break
        free_side = d
        d += 0.2
    check("lid jams when pushed sideways", free_side < 2.0,
          f"(free lateral play {free_side:.2f} mm)")

    skus = [
        ("Kingston FURY Beast DDR4 (datasheet)", 133.35, 34.0, 7.2),
        ("Corsair Vengeance LPX (official 34 mm)", 133.35, 34.0, 7.2),
        ("G.Skill Ripjaws V (official 42 mm)", 133.7, 42.0, 7.3),
        ("thick-spreaders worst case", 133.35, 42.0, 8.4),
        ("envelope limit (synthetic)", MOD_L_MAX, MOD_H_MAX, MOD_T_MAX),
    ]
    for name, L, H, T in skus:
        for bagged in (False, True):
            bt = T + (0.3 if bagged else 0.0)
            bh = H + (0.3 if bagged else 0.0)
            tag = "in bag" if bagged else "bare"
            bad = None
            for sy in (-(INT_W / 2 - SLOT_W / 2), INT_W / 2 - SLOT_W / 2):
                stick = box(-INT_L / 2 + 2, -INT_L / 2 + 2 + L,
                            sy - bt / 2, sy + bt / 2, FLOOR, FLOOR + bh)
                v1 = vol((base + lid) & stick)
                cz = FLOOR + bh
                guard = box(-INT_L / 2, INT_L / 2, sy - 2.1, sy + 2.1,
                            cz - 0.5, cz + 1.2)
                v2 = vol((base + lid) & guard)
                if v1 > 1e-6 or v2 > 1e-6:
                    bad = (sy, v1, v2)
            check(f"fits & contacts unpressable: {name} [{tag}]",
                  bad is None,
                  "" if bad is None else f"(slot {bad[0]:+.1f}: "
                  f"stick={bad[1]:.1e}, guard={bad[2]:.1e})")

    sy = INT_W / 2 - SLOT_W / 2
    stick = box(-INT_L / 2 + 2, -INT_L / 2 + 2 + 133.35,
                sy - 3.75, sy + 3.75, FLOOR, FLOOR + 34.3)
    clean = all(vol(base & (Pos(0, 0, dz) * stick)) < 1e-6
                for dz in range(5, 65, 5))
    check("stick lifts straight out once the lid is off", clean)

    slab = box(-INT_L / 2, INT_L / 2,
               -PLATE_W / 2 + 0.1, PLATE_W / 2 - 0.1,
               PLATE_BOT + 0.05, PLATE_BOT + 0.15)
    check("closed lid covers the opening", vol(slab - lid) < 1e-6)

    # FillaPrint pockets actually cut (probe the engraved depth)
    probe = box(-20, 20, -SLOT_W / 2, SLOT_W / 2, FLOOR - ENGRAVE + 0.05,
                FLOOR - 0.05)
    got = vol(base & probe)
    full = vol(probe)
    check("floor label pockets engraved", 0 < got < full,
          f"({got:.1f} of {full:.1f} mm3 removed by glyphs)")
    lprobe = box(-16, 16, -8, 8, PLATE_BOT + LID_T - ENGRAVE + 0.05,
                 PLATE_BOT + LID_T - 0.05)
    got = vol(lid & lprobe)
    check("lid label pocket engraved", 0 < got < vol(lprobe),
          f"({got:.1f} mm3 of glyph pockets)")

    print(f"  note: a stick leaning fully against a wall may touch a rail's "
          f"inner face - harmless spreader-face contact, never the contacts")
    return failures


# ---------------------------------------------------------------- exports
def main():
    os.makedirs(OUT, exist_ok=True)
    print("building base ...")
    base = build_base()
    print("building lid ...")
    lid = build_lid()

    failures = report_checks(base, lid)

    print("\n--- export ---")
    export_step(base, f"{OUT}/base.step")
    export_stl(base, f"{OUT}/base.stl")
    export_step(lid, f"{OUT}/lid.step")
    flipped = Rot(X=180) * lid
    bb = flipped.bounding_box()
    lid_print = Pos(-bb.min.X, -bb.min.Y, -bb.min.Z) * flipped
    export_stl(lid_print, f"{OUT}/lid.stl")

    m_asm = (Pos(-bb.min.X, -bb.min.Y, -bb.min.Z) * Rot(X=180)).inverse()
    # the physical closed pose is 0.15 mm lower than the modeled pose: the
    # latch teeth drop into their pockets when the lid reaches the stop
    m_asm = Pos(0, 0, -TOOTH_H) * m_asm
    trsf = m_asm.wrapped.Transformation()
    mat = [[round(trsf.Value(r, c), 6) for c in range(1, 5)] for r in range(1, 4)]
    mat.append([0.0, 0.0, 0.0, 1.0])

    info = {
        "units": "mm",
        "frame": "origin at centre of base bottom face; z up; -x = front "
                 "(lid pull-tab side); +x = back wall",
        "parts": [
            {"name": "base",
             "step": "out/base.step", "stl": "out/base.stl",
             "stl_orientation": "identical to assembled pose (print cavity-up)",
             "transform_print_to_assembled":
                 [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]},
            {"name": "lid",
             "step": "out/lid.step", "stl": "out/lid.stl",
             "stl_orientation": "print orientation: label face down, rails up",
             "transform_print_to_assembled": mat},
        ],
        "assembly_notes": [
            "Slide the lid in from the front (-x) over the sill until its "
            "rear edge meets the back wall; the latch teeth drop into the "
            "pockets with a click.",
            "To open: pull the tab toward the front; the teeth climb the "
            "stepped pocket lips (~0.2 mm lift) and the lid slides free. "
            "Full removal is intended for loading.",
            "Sticks go in contacts-edge UP (see floor labels). The closed "
            "lid leaves a 1.8 mm air gap over the contact edge of the "
            "largest supported module."],
        "supported_envelope_mm": {
            "module_length_max": MOD_L_MAX,
            "module_height_max": MOD_H_MAX,
            "module_thickness_max": MOD_T_MAX,
            "verified_examples": [
                "Corsair Vengeance LPX DDR4  133.35 x 34 x 7.2",
                "Kingston FURY Beast DDR4    133.35 x 34 x 7.2 (datasheet)",
                "G.Skill Ripjaws V DDR4      133.7 x 42 x 7.3",
                "Patriot Viper 4 DDR4        133.3 x 42 x ~7.8"],
            "not_supported": [
                "Tall RGB / liquid-style heatsinks: G.Skill Trident Z RGB "
                "~44.5 mm, Corsair Vengeance RGB Pro 44.45 mm, Dominator "
                "Platinum 56 mm",
                "modules thicker than 9.0 mm or shorter than ~131 mm"]},
        "key_dimensions_mm": {
            "outer_box": [round(L_OUT, 2), round(W_OUT, 2), round(Z_TOP, 2)],
            "slot_width": round(SLOT_W, 2),
            "slot_length": round(INT_L, 2),
            "usable_height": round(INT_H, 2),
            "contact_gap_under_lid": CONTACT_GAP,
            "lid_plate": [round(LID_L, 1), round(LID_W, 1), LID_T],
            "track": {"depth": G_D, "deep_floor": G_FLOOR,
                      "ceiling": round(G_CEIL, 2),
                      "mouth_floor_rise": LIP, "clearance": CLR}},
    }
    with open(f"{OUT}/assembly.json", "w") as f:
        json.dump(info, f, indent=2)
    print(f"  wrote {OUT}/assembly.json")

    print("\n=== summary ===")
    print(f"  outer box : {L_OUT:.1f} x {W_OUT:.1f} x {Z_TOP:.1f} mm")
    print(f"  slots     : 2 x {SLOT_W:.1f} mm wide, {INT_L:.1f} long, "
          f"{INT_H:.1f} usable height")
    print(f"  lid       : {LID_L:.1f} x {LID_W:.1f} mm, {LID_T} plate")
    print(f"  checks    : {'ALL PASS' if not failures else 'FAILURES: ' + ', '.join(failures)}")


if __name__ == "__main__":
    main()
