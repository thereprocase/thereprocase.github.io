# DDR4 Pair Mailer — parametric two-part box

A small, reusable mailer for **two desktop DDR4 UDIMMs with ordinary
heatspreaders**, one per slot, each in its own ESD shielding bag, ready to
drop into a padded outer carton.

**Outer size: 144.8 × 30.6 × 49.9 mm.** Two parts, no hardware, no magnets,
nothing presses on the gold contacts.

## How it works

Sticks stand **vertically, spreader edge down, gold contact edge UP**
(engraved `CONTACTS UP` in each slot floor reminds you at loading time).

- **Contacts can't be touched.** The contact edge faces up into an air gap
  (1.65 mm for the largest supported module, more for smaller ones). The
  stick rests on its spreader edge, so drops load through aluminium, never
  through the pads. Slot walls only touch spreader faces; the PCB and its
  edge plating sit ≥ 1.5 mm proud of them.
- **Why the lid stays on.** Each long wall carries a lid track — a tunnel
  whose floor rises 0.8 mm toward its mouth (a dovetail undercut). The lid's
  edge rails are 3.25 mm tall at their deep section; the track mouth is only
  2.9 mm high, so the lid **cannot be lifted, tilted or pulled sideways
  out**. A tooth under each rail seats in a latch pocket at the back of the
  track when the lid reaches the stop (a felt click); sliding open requires
  a ~0.2 mm lift over the stepped pocket lip, which the rail's 0.3 mm
  vertical play allows.
- **Getting sticks out.** Pull the tab (a finger dish is molded into its
  underside); the lid slides free of the tracks through the front (full
  removal is intended — that's how you load it). With the lid closed the
  sticks are captive; with it off they lift straight up.

Loading: slide the lid off, bag each stick, stand them contacts-up in the
slots (label side up on the floor), tuck a little crumpled paper around the
bags to take the ~1.3 mm slot and ~4.6 mm end slack, slide the lid on until
it clicks.

## Supported envelope (and what doesn't fit)

Per module, before its bag: **length ≤ 134.5 mm, height ≤ 42.5 mm
(contact edge → spreader edge), thickness ≤ 9.0 mm.**

Verified against real products:

| Module | L × H × T (mm) | Source |
|---|---|---|
| Corsair Vengeance LPX DDR4 | 133.35 × 34 × 7.2 | Corsair ("flat height of just 34 mm") |
| Kingston FURY Beast DDR4 | 133.35 × 34 × 7.2 | Kingston datasheet KF432C16BB1/16 (in `research/`) |
| G.Skill Ripjaws V DDR4 | 133.7 × 42 × 7.3 | G.Skill ("42 mm module height") |
| Patriot Viper 4 DDR4 | 133.3 × 42 × ~7.8 | spec listings |

Also covered: TeamGroup T-Force Vulcan Z (~32 mm), most 34–36 mm
heatspreaders, and typical 7.2–8.8 mm thicknesses.

**Not supported (by design, to keep the box compact):** tall RGB /
liquid-style heatsinks — G.Skill Trident Z RGB (~44.5 mm), Corsair
Vengeance RGB Pro (44.45 mm), Dominator Platinum (56 mm) — and anything
thicker than 9.0 mm. If you need a different envelope, edit `PARAMETERS`
in `mailer.py` and re-run; every dimension derives from
`MOD_L_MAX / MOD_H_MAX / MOD_T_MAX`.

## FillaPrint labels

Font: `assets/fillaprint/Fillaprint-Regular.ttf` (SIL OFL 1.1, see
`assets/fillaprint/OFL.txt`).

- Lid top: `2 × DDR4`, font size 12 → glyph band 8.4 mm, **stroke 1.22 mm**.
- Each slot floor: `CONTACTS UP`, font size 10 → glyph band 7.0 mm,
  **stroke 1.02 mm** — this is the font's minimum practical size
  (measured: thinnest glyph stroke ≈ 1.0 mm at size 10, i.e. ≈ 0.10 mm of
  stroke per point of font size). Both labels are at or above it.
- Pockets are 0.8 mm deep (4 layers at 0.2 mm), sized to be filled with a
  contrasting filament inlay in the usual FillaPrint manner.
- Orientation: reading direction runs along the box length with glyph tops
  toward one side — the labels read upright when the pull tab points to
  your left.

## Files

| File | What |
|---|---|
| `mailer.py` | parametric source (build123d) — rebuilds everything, runs the exact-geometry checks |
| `out/base.step`, `out/base.stl` | base, print as-is (cavity up) |
| `out/lid.step`, `out/lid.stl` | lid; STL is in print orientation (label face down), STEP in assembled pose |
| `out/assembly.json` | part files + the actual assembled transform (mm) of each STL |
| `checks.py` | independent mesh-level verification (trimesh, STLs only) |
| `checks_report.txt` | mesh-level check output |
| `research/kingston_bb1.pdf` | source datasheet for the envelope |

The lid STL needs flipping to the assembled pose; `assembly.json` gives the
4×4 transform (it also includes the 0.15 mm "settle" by which the seated
lid sits lower than the modeled pose).

## Printing

- 0.2 mm layers, 3 perimeters, 15 % gyroid infill, PLA or PETG.
- **No supports needed.** The only bridges are the two 2.2 mm-wide track
  roofs in the base and the short label-pocket roofs in the lid.
- Print the base cavity-up exactly as oriented in the STL; print the lid
  label-face-down as oriented in the STL.
- Track clearances are 0.15 mm per side — tuned for a typical 0.4 mm-nozzle
  FDM printer. If the lid binds, sand the rails lightly or regenerate with
  `CLR = 0.2`.

## Verification performed (two independent layers)

`mailer.py` runs exact B-rep boolean checks — all pass:

- base/lid interference = 0, both in the riding and the seated (latch
  dropped) closed poses; lid slides its full 155 mm travel out the front
  with zero collisions;
- lift jam after 0.30 mm, tilt jam immediately, sideways jam immediately
  (the lid cannot escape the tracks);
- five module cases (the three real SKUs above, an 8.4 mm-thick worst case,
  and the synthetic envelope limit), bare and bagged (+0.3 mm): zero
  interference in both slots, and a guard slab around the contact edge is
  clear of both parts — nothing can press the gold contacts;
- sticks lift straight out with the lid removed; the closed lid fully
  covers the opening; both label pockets are actually engraved.

`checks.py` re-verifies from the exported STLs alone (binary STL,
watertight, volumes 78.0 / 11.8 cm³, bounding boxes, ray-interval
assembled-interference over an 11 711-column grid: worst overlap 0.000 mm;
stick and guard clearance re-confirmed; minimum feature thickness scan).
All pass — see `checks_report.txt`.

## What still needs a physical test

1. **Latch feel and retention** (~1 N design target from the 60°-effective
   stepped lip): whether the click is satisfying and whether the lid stays
   shut through transit vibration. `TOOTH_H`, `STEP1/STEP2` and `RAIL_LIFT`
   tune this.
2. **Track friction/slop** at real printer tolerances — the 0.15 mm
   clearances assume a calibrated machine; elephant-foot compensation matters
   on the track mouths.
3. **Drop robustness** of the 1.2 mm outer wall leaf beside the tracks
   (fine in a padded carton; unproven on bare concrete).
4. Bag fold bulk at the slot ends — a thick folded seam may need the bag
   folded flat against the stick's face.
5. Filled-label appearance (inlay adhesion/flushness).

## Regenerating

```sh
python mailer.py    # rebuild + exact checks + export
python checks.py       # mesh-level verification
```
