"""
Independent mesh-level verification of the exported parts.
Runs on the exported STLs only (no CAD geometry), trimesh/numpy.

Method notes:
  * Two closed solids intersect iff some vertical column contains z-intervals
    of both, so downward ray casts on a grid give an exact-in-the-limit
    assembled-interference test (touching faces give zero-length overlaps
    and are tolerated).
  * Stick fit and the contact-edge guard zone are re-tested at mesh level
    with the same ray-interval method.

Writes checks_report.txt.
"""

import json
import os
import struct
import time

import numpy as np
import trimesh
import trimesh.ray as tray

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
failures = []
report = []


def check(name, cond, detail=""):
    cond = bool(cond)
    if not cond:
        failures.append(name)
    line = f"  [{'PASS' if cond else 'FAIL'}] {name} {detail}"
    report.append(line)
    print(line, flush=True)


def is_binary_stl(path):
    with open(path, "rb") as f:
        head = f.read(84)
    n = struct.unpack("<I", head[80:84])[0]
    return os.path.getsize(path) == 84 + n * 50, n


def column_intervals(mesh, origins, tol=1e-6):
    """For downward rays from `origins`, return per-ray material intervals."""
    dirs = np.tile([0.0, 0.0, -1.0], (len(origins), 1))
    locs, index_ray, _ = mesh.ray.intersects_location(origins, dirs)
    out = []
    for i in range(len(origins)):
        z = np.sort(locs[index_ray == i][:, 2])
        iv = []
        for k in range(0, len(z) - 1, 2):
            if z[k + 1] - z[k] > 1e-4:
                iv.append((z[k], z[k + 1]))
        out.append(iv)
    return out


def max_overlap(intervals_a, intervals_b):
    """Largest overlap length between paired interval lists (or -inf)."""
    worst = -1.0
    for ia, ib in zip(intervals_a, intervals_b):
        for a0, a1 in ia:
            for b0, b1 in ib:
                o = min(a1, b1) - max(a0, b0)
                if o > worst:
                    worst = o
    return worst


def grid(x0, x1, y0, y1, step, z):
    xs = np.arange(x0, x1 + step / 2, step)
    ys = np.arange(y0, y1 + step / 2, step)
    X, Y = np.meshgrid(xs, ys, indexing="ij")
    O = np.stack([X.ravel(), Y.ravel(), np.full(X.size, z)], axis=1)
    return O, xs, ys


def main():
    report.clear()

    def emit(line=""):
        print(line, flush=True)
        report.append(line)

    with open(os.path.join(OUT, "assembly.json")) as f:
        asm = json.load(f)

    emit("=== mesh-level verification (trimesh, exported STLs only) ===")

    base = trimesh.load(os.path.join(OUT, "base.stl"))
    lid = trimesh.load(os.path.join(OUT, "lid.stl"))
    lid_asm = lid.copy()
    T = np.array(asm["parts"][1]["transform_print_to_assembled"], dtype=float)
    U, _, Vt = np.linalg.svd(T[:3, :3])          # re-orthonormalize rounding
    T[:3, :3] = U @ Vt
    lid_asm.apply_transform(T)
    rbase = tray.ray_triangle.RayMeshIntersector(base)
    rlid = tray.ray_triangle.RayMeshIntersector(lid_asm)

    for name, m in (("base", base), ("lid", lid)):
        binary, ntri = is_binary_stl(os.path.join(OUT, f"{name}.stl"))
        check(f"{name}: binary STL ({ntri} triangles)", binary)
        check(f"{name}: watertight", m.is_watertight)
        check(f"{name}: positive volume", m.volume > 0,
              f"({m.volume / 1000:.1f} cm3)")
        bb = m.bounds
        emit(f"      bbox min {np.round(bb[0], 2)} max {np.round(bb[1], 2)}")

    dims = asm["key_dimensions_mm"]
    L, W, H = dims["outer_box"]
    size = base.bounds[1] - base.bounds[0]
    check("base bbox matches design", np.allclose(size, [L, W, H], atol=0.15),
          f"({size[0]:.2f} x {size[1]:.2f} x {size[2]:.2f} vs {L} x {W} x {H})")
    check("base sits on z=0", abs(base.bounds[0][2]) < 0.05)

    ll, lw = dims["lid_plate"][0], dims["lid_plate"][1]
    lsize = lid.bounds[1] - lid.bounds[0]
    check("lid (print pose) bbox plausible",
          abs(lsize[0] - ll) < 0.2 and abs(lsize[1] - lw) < 0.2
          and abs(lsize[2] - 5.8) < 0.3,
          f"({lsize[0]:.2f} x {lsize[1]:.2f} x {lsize[2]:.2f})")
    check("lid STL printed label-face-down", abs(lid.bounds[0][2]) < 0.05)

    # ---- assembled interference: ray grid over the whole box
    O, _, _ = grid(-71.5, 71.5, -14.5, 14.5, 0.6, 60.0)
    t0 = time.time()
    ia = column_intervals(base, O)
    ib = column_intervals(lid_asm, O)
    worst = max_overlap(ia, ib)
    check("assembled base/lid interference = 0 (ray-interval, 0.6 mm grid)",
          worst <= 0.05, f"(worst interval overlap {worst:.3f} mm, "
          f"{len(O)} columns, {time.time()-t0:.0f} s)")

    # ---- envelope-max bagged stick + contact guard
    env = asm["supported_envelope_mm"]
    Lm, Hm, Tm = (env["module_length_max"], env["module_height_max"],
                  env["module_thickness_max"])
    floor_t = 2.6
    slot_w = dims["slot_width"]
    ok_all, detail = True, []
    for sy in (-(11.9 - slot_w / 2), 11.9 - slot_w / 2):
        bt, bh = Tm + 0.3, Hm + 0.3          # bagged
        x0, x1 = -67.0, -67.0 + 133.35
        O, _, _ = grid(x0 + 0.4, x1 - 0.4, sy - bt / 2 + 0.2, sy + bt / 2 - 0.2,
                       0.7, 60.0)
        ia = column_intervals(base, O)
        ib = column_intervals(lid_asm, O)
        s_stick = max_overlap(ia, ib)        # parts must not enter the stick
        # inverted check: stick interval vs part intervals
        stick_iv = [[(floor_t, floor_t + bh)] for _ in O]

        def worst_vs(part_iv, target_iv):
            w = -1e9
            for A, B in zip(part_iv, target_iv):
                for (a0, a1) in A:
                    for (b0, b1) in B:
                        w = max(w, min(a1, b1) - max(a0, b0))
            return w
        o1 = max(worst_vs(ia, stick_iv), worst_vs(ib, stick_iv))
        cz = floor_t + bh
        guard_iv = [[(cz - 0.5, cz + 1.2)] for _ in O]
        o2 = max(worst_vs(ia, guard_iv), worst_vs(ib, guard_iv))
        detail.append(f"slot y={sy:+.1f}: stick {o1:.3f} mm, guard {o2:.3f} mm")
        if o1 > 0.05 or o2 > 0.05:
            ok_all = False
    for d in detail:
        emit("      " + d)
    check("envelope-max bagged stick fits; contact guard clear (mesh)", ok_all)

    emit("")
    emit("RESULT: " + ("ALL PASS" if not failures
                       else "FAILURES: " + ", ".join(failures)))
    with open("checks_report.txt", "w") as f:
        f.write("\n".join(report) + "\n")
    print("\n wrote checks_report.txt")


if __name__ == "__main__":
    main()
