"""
build.py -- generate every part, export STEP + binary STL, and write
assembly.json and checks.json for the M2-M4 Gridfinity organiser.

Run with the CAD runtime:
  python -I src/build.py

Layout of the deliverables (all paths relative to the run directory):
  step/       one STEP per part file (baseplate + one file per bin)
  stl/        one binary STL per part file
  assembly.json
  checks.json
"""

from __future__ import annotations

import json
import math
import os
import sys

from build123d import export_step, export_stl

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import gf_baseplate
import gf_geom
import gf_layout
import gf_params as P

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT = os.path.join(ROOT, "assets", "fillaprint", "Fillaprint-Regular.ttf")


def grid_origin(gx: int, gy: int) -> tuple[float, float]:
    return P.GRID * gx, P.GRID * gy


def build_parts():
    """Return {part_id: (solid, (x, y, z) placement)} plus metadata."""
    parts = {}

    base = gf_baseplate.make_baseplate()
    parts["baseplate-5x4"] = dict(
        solid=base,
        place=(0.0, 0.0, 0.0),
        kind="baseplate",
        meta=dict(cols=P.PATCH_COLS, rows=P.PATCH_ROWS, height=5.0),
    )

    for (pid, family, size, gx, gy, nx, ny, units, text, splits,
         bands) in gf_layout.STARTER_LAYOUT:
        solid = gf_geom.make_bin(nx, ny, units, text, splits)
        x, y = grid_origin(gx, gy)
        # bins seat on the baseplate floor, 0.35 mm above the plate's base
        parts[pid] = dict(
            solid=solid,
            place=(x, y, gf_baseplate.PLATE_FLOOR),
            kind="bin",
            meta=dict(family=family, size=size, nx=nx, ny=ny, units=units,
                      height=units * P.BASE_HEIGHT, label=text,
                      splits=list(splits), bands=bands,
                      grid=(gx, gy)),
        )
    return parts


def export_all(parts):
    step_dir = os.path.join(ROOT, "step")
    stl_dir = os.path.join(ROOT, "stl")
    os.makedirs(step_dir, exist_ok=True)
    os.makedirs(stl_dir, exist_ok=True)

    files = {}
    for pid, part in parts.items():
        step_path = os.path.join(step_dir, pid + ".step")
        stl_path = os.path.join(stl_dir, pid + ".stl")
        export_step(part["solid"], step_path)
        export_stl(part["solid"], stl_path, tolerance=0.05,
                   angular_tolerance=0.2, ascii_format=False)
        files[pid] = dict(step=os.path.relpath(step_path, ROOT),
                          stl=os.path.relpath(stl_path, ROOT))
    return files


def main():
    gf_geom.FONT_PATH = FONT
    parts = build_parts()
    files = export_all(parts)

    assembly = dict(
        units="mm",
        frame="patch south-west corner at the origin, +X to the right, "
              "+Y to the back, +Z up",
        grid=dict(pitch=P.GRID, cols=P.PATCH_COLS, rows=P.PATCH_ROWS,
                  pitch_y=P.GRID),
        font=dict(path="assets/fillaprint/Fillaprint-Regular.ttf",
                  em_mm=P.LABEL_EM, engrave_depth_mm=P.LABEL_DEPTH,
                  note="Fillaprint: strokes are 2 x 0.4 mm at em 8 mm, "
                       "cap height 5.6 mm"),
        parts=[],
    )

    for pid, part in parts.items():
        solid = part["solid"]
        bb = solid.bounding_box()
        assembly["parts"].append(dict(
            id=pid,
            kind=part["kind"],
            step=files[pid]["step"],
            stl=files[pid]["stl"],
            placement=dict(
                translate=[round(v, 3) for v in part["place"]],
                rotate=[0.0, 0.0, 0.0],
            ),
            size=[round(bb.size.X, 3), round(bb.size.Y, 3),
                  round(bb.size.Z, 3)],
            meta=part["meta"],
        ))

    with open(os.path.join(ROOT, "assembly.json"), "w") as f:
        json.dump(assembly, f, indent=2)

    print(f"built {len(parts)} parts")
    for pid in parts:
        print(" ", pid, files[pid]["step"], files[pid]["stl"])


if __name__ == "__main__":
    main()
