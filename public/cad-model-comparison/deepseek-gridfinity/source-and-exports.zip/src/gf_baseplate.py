"""
gf_baseplate.py -- the 5 x 4 Gridfinity baseplate.

The plate is 5 x 4 cells of 42 mm, 5 mm tall, with a 0.35 mm floor and a
socket per cell.  Each socket is the bin foot profile grown by 0.15 mm
radially and 0.35 mm in depth: a printed bin drops in with clearance and
seats on the floor at z = 0.35, and the 0.35 mm step between the floor and the
socket rim is the only place the two parts touch.

The sockets are cut per cell rather than as one merged pocket, so a bin can be
lifted out of its own socket without rocking the plate, and a 1 x 1 bin can be
put in any of the 20 cells.  The plate is printed as one piece; it is also
generated at other grid sizes by the same function.
"""

from __future__ import annotations

from build123d import loft

import gf_geom as G
import gf_params as P

SOCKET_CLEAR_R = 0.15   # radial clearance bin foot -> socket wall
SOCKET_CLEAR_Z = 0.35   # extra socket depth over the foot profile
PLATE_FLOOR = SOCKET_CLEAR_Z  # material left under the feet


def plate_socket(cx: float, cy: float):
    """Negative of one bin-foot socket."""
    sections = []
    for foot_z, inset in ((0.0, 2.95), (0.8, 2.15), (2.6, 2.15),
                          (P.PROFILE_H, 0.0)):
        w = P.BASE_TOP - 2 * (inset - SOCKET_CLEAR_R)
        r = P.BASE_R_TOP - (inset - SOCKET_CLEAR_R)
        sections.append(G.rrect(w, w, r, PLATE_FLOOR + foot_z, cx, cy))
    return loft(sections, ruled=True)


def make_baseplate(cols: int = P.PATCH_COLS, rows: int = P.PATCH_ROWS,
                   height: float = 5.0):
    """One-piece baseplate, origin at its south-west corner."""
    w, d = cols * P.GRID, rows * P.GRID
    plate = G.prism(w, d, 4.0, 0.0, height, w / 2, d / 2)

    cutter = None
    for i in range(cols):
        for j in range(rows):
            s = plate_socket(P.GRID * i + P.BASE_TOP / 2,
                             P.GRID * j + P.BASE_TOP / 2)
            cutter = s if cutter is None else cutter + s

    plate -= cutter
    if not plate.is_valid:
        raise RuntimeError("baseplate is not a valid solid")
    return plate
