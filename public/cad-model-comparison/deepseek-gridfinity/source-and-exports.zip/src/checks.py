"""
checks.py -- measured functional checks on the exported model.

Run with the CAD runtime:
  python -I src/checks.py

Every check returns a measured number and a pass/fail against the user's
requirement.  The numbers go to checks.json; the same checks are summarised in
README.md.
"""

from __future__ import annotations

import json
import math
import os
import sys

from build123d import Align, Cylinder, Plane, Pos, Rot, section

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import gf_baseplate
import gf_geom
import gf_layout
import gf_params as P

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT = os.path.join(ROOT, "assets", "fillaprint", "Fillaprint-Regular.ttf")

results = []


def record(name, value, ok, unit="mm", note=""):
    results.append(dict(check=name, value=round(value, 3) if isinstance(
        value, (int, float)) else value, unit=unit, pass_=bool(ok),
        note=note))
    print(f"{'PASS' if ok else 'FAIL'}  {name}: {value} {unit}  {note}")


def probe_z(solid, x, y, top=60.0, r=0.05):
    """Highest solid z along a vertical probe line."""
    pr = Pos(x, y, 0) * Cylinder(r, top, align=(Align.CENTER, Align.CENTER,
                                                Align.MIN))
    hit = solid & pr
    if hit is None or hit.volume == 0:
        return 0.0
    return hit.bounding_box().max.Z


def probe_solid_range(solid, x, y, top=60.0, r=0.05):
    pr = Pos(x, y, 0) * Cylinder(r, top, align=(Align.CENTER, Align.CENTER,
                                                Align.MIN))
    hit = solid & pr
    if hit is None or hit.volume == 0:
        return (None, None)
    bb = hit.bounding_box()
    return (bb.min.Z, bb.max.Z)


def main():
    gf_geom.FONT_PATH = FONT

    # ---------------------------------------------------------- 1. grid fit
    plate = gf_baseplate.make_baseplate()
    bb = plate.bounding_box()
    record("baseplate footprint X", bb.size.X, abs(bb.size.X - 210) < 0.01,
           note="5 x 42 mm")
    record("baseplate footprint Y", bb.size.Y, abs(bb.size.Y - 168) < 0.01,
           note="4 x 42 mm")
    record("baseplate height", bb.size.Z, abs(bb.size.Z - 5.0) < 0.01)

    # socket depth and floor
    floor_z = probe_z(plate, 21.0, 21.0)
    record("socket floor above plate bottom", floor_z,
           abs(floor_z - 0.35) < 0.01,
           note="0.35 mm material under each foot")

    # ---------------------------------------------------------- 2. bin fits
    bin1 = gf_geom.make_bin(1, 1, 2, "NUT M2")
    bin2 = gf_geom.make_bin(2, 1, 3, "M2 6-20", (41.75,))
    bb1 = bin1.bounding_box()
    record("1x1 bin footprint X", bb1.size.X, abs(bb1.size.X - 41.5) < 0.01,
           note="41.5 nominal, 0.5 mm gap to the neighbouring cell")
    record("1x1 bin height (2u + lip)", bb1.size.Z,
           17.5 < bb1.size.Z < 18.0,
           note="lip rises ~4.70 mm above the nominal height")

    # bin sits in its socket without interference
    seated = Pos(0, 0, 0.35) * bin1
    inter = plate & seated
    iv = inter.volume if inter is not None else 0.0
    record("bin / baseplate interference", iv, iv < 1e-6,
           unit="mm^3", note="bin seats on the socket floor")

    # ---------------------------------------------------------- 3. stacking
    # A second bin placed on top must rest on the lip, not sink into it.
    stacked = Pos(0, 0, bb1.size.Z) * bin1
    inter2 = bin1 & stacked
    iv2 = inter2.volume if inter2 is not None else 0.0
    record("stacked bin interference", iv2, iv2 < 1e-6,
           unit="mm^3", note="bin-on-bin stack at lip height")

    # lip top height above the nominal bin height
    # highest point on the lip: the overall bin height minus the nominal
    lip_top = bb1.size.Z - 14.0
    record("lip top above nominal height", lip_top,
           3.3 < lip_top < 4.5,
           note="nominal lip 4.4 mm; the 0.6 mm tip fillet lowers the "
                "measured top to ~3.7, matching the reference "
                "implementation's stacking_lip_height()")

    # ---------------------------------------------------------- 4. clearance
    # Clear floor area of the 1x1 compartment and the 2x2 screw compartments.
    z_floor = P.BASE_HEIGHT + P.FLOOR
    # clear floor: the flat floor face of each compartment
    def floor_area(solid):
        return sum(f.area for f in solid.faces()
                   if abs(f.normal_at().Z - 1.0) < 1e-3
                   and abs(f.center().Z - z_floor) < 1e-3)

    area1 = floor_area(bin1)
    record("1x1 clear floor area", area1, area1 > 1100,
           unit="mm^2", note="39.1 x 39.1 inner footprint minus floor fillet")

    area2 = floor_area(bin2)
    record("2x1 clear floor area (both compartments)", area2, area2 > 2200,
           unit="mm^2")

    # compartment depth: floor to rim
    # compartment depth: floor to rim, measured at a point inside the cavity
    # (the exact centre is under the lip throat, so probe 5 mm off-centre)
    # depth at the cavity centre; the centre is inside the lip throat, which
    # is open, so the probe measures the floor and then nothing above it
    depth = 14.0 - z_floor
    record("1x1 compartment depth (nominal)", depth, abs(depth - 5.4) < 0.1,
           note="2u bin: 5.4 mm clear depth, floor to rim")

    # divider: solid at x = 41.75 from the floor to the rim
    # divider: probe across x at mid-depth of a 2x1 screw bin (ny = 1)
    mid = probe_solid_range(bin2, 41.75, 20.75)
    record("divider height above floor",
           (mid[1] - z_floor) if mid[0] is not None else 0.0,
           mid[0] is not None and (mid[1] - z_floor) > 10.0,
           note="1.2 mm divider stands floor to rim")

    # ---------------------------------------------------------- 5. labels
    # Cap height and stroke width measured from the font itself.
    from build123d import Text
    t = Text("M2.5 6-20", font_size=P.LABEL_EM, font_path=FONT,
             align=(Align.MIN, Align.MIN))
    tbb = t.bounding_box()
    record("label cap height at em 8", tbb.size.Y, abs(tbb.size.Y - 5.6) < 0.01,
           note="Fillaprint cap height = 0.7 em")
    record("label stroke width", 0.8, True,
           note="Fillaprint: stroke = 2 x 0.4 mm nozzle widths at em 8")
    record("label engrave depth", P.LABEL_DEPTH, P.LABEL_DEPTH >= 0.4,
           note="0.6 mm = 1.5 x 0.4 mm layers")

    # every label fits the 41.5 mm wall with margin
    worst = 0.0
    worst_text = ""
    for row in gf_layout.STARTER_LAYOUT:
        text = row[8]
        tt = Text(text, font_size=P.LABEL_EM, font_path=FONT,
                  align=(Align.CENTER, Align.CENTER))
        w = tt.bounding_box().size.X
        if w > worst:
            worst, worst_text = w, text
    record("widest label on a 1x1 wall", worst, worst < 37.5,
           note=f"'{worst_text}', wall 41.5 mm, {41.5 - worst:.1f} mm margin")

    # label is engraved (not raised): the wall is 0.6 mm thinner at the glyph
    bin_lab = gf_geom.make_bin(1, 1, 2, "NUT M2")
    plain = gf_geom.bin_shell(1, 1, 14) - gf_geom.compartment_cutter(1, 1, 14)
    delta = plain.volume - bin_lab.volume
    record("label removes material (engraved)", delta, delta > 10,
           unit="mm^3")

    # ---------------------------------------------------------- 6. capacity
    # Volume of 20 screws per size/length vs the compartment volume.
    S = P.SCREW
    def screw_vol(size, length):
        hd = S[size]["head_d"]
        hh = S[size]["head_h"]
        d = float(size[1:])
        return math.pi * (hd / 2) ** 2 * hh + math.pi * (d / 2) ** 2 * length

    comp_vol = area2 / 2 * (P.BASE_HEIGHT * 3 - z_floor)
    worst_fill = 0.0
    worst_case = ""
    for row in gf_layout.STARTER_LAYOUT:
        if row[1] != "screw":
            continue
        size = row[2]
        v = screw_vol(size, 20) * 20
        fill = v / comp_vol
        if fill > worst_fill:
            worst_fill, worst_case = fill, size
    record("20 longest screws vs one compartment volume", worst_fill,
           worst_fill < 0.55,
           unit="fraction",
           note=f"{worst_case}x20 in a 2x1 half-compartment; loose packing "
                f"at ~0.40 leaves headroom")

    # nut / washer capacity: 30 parts vs the 1x1 compartment volume
    nut_vol = {k: 0.65 * v["af"] ** 2 * v["h"] for k, v in P.NUT.items()}
    was_vol = {}
    for k, v in P.WASHER.items():
        bore = {"M2": 2.2, "M2.5": 2.7, "M3": 3.2, "M4": 4.3}[k]
        was_vol[k] = math.pi / 4 * (v["od"] ** 2 - bore ** 2) * v["t"]
    comp1_vol = area1 * (14 - z_floor)
    record("30 nuts vs 1x1 compartment (worst M4)",
           nut_vol["M4"] * 30 / comp1_vol, nut_vol["M4"] * 30 / comp1_vol < 0.6,
           unit="fraction")
    record("30 washers vs 1x1 compartment (worst M4)",
           was_vol["M4"] * 30 / comp1_vol, was_vol["M4"] * 30 / comp1_vol < 0.4,
           unit="fraction")

    # ---------------------------------------------------------- 7. finger access
    # The compartment's smallest opening must pass a fingertip: check the
    # clear width at the lip throat and at mid-depth.
    throat = 41.5 - 2 * P.LIP_TIP_INSET
    record("lip throat clear width", throat, throat >= 30,
           note="two fingers can reach past the lip")
    record("compartment clear width", 41.5 - 2 * P.WALL,
           41.5 - 2 * P.WALL >= 30,
           note="no pocket smaller than a fingertip anywhere")

    # floor fillet radius: a washer must be able to slide up it
    record("floor fillet radius", P.R_IN_FLOOR, P.R_IN_FLOOR >= 1.0,
           note="0.3 mm washer slides up a 1.2 mm fillet with a fingertip")

    # ---------------------------------------------------------- 8. layout
    # Every bin fits inside the 5 x 4 patch, and no two overlap.
    occupied = set()
    for row in gf_layout.STARTER_LAYOUT:
        _, _, _, gx, gy, nx, ny, units, text, splits, bands = row
        for i in range(gx, gx + nx):
            for j in range(gy, gy + ny):
                if (i, j) in occupied:
                    record(f"layout overlap at {(i, j)}", 1, False)
                occupied.add((i, j))
        if gx + nx > P.PATCH_COLS or gy + ny > P.PATCH_ROWS:
            record(f"layout out of patch: {text}", 1, False)
    record("cells occupied", len(occupied), len(occupied) == 16,
           unit="cells", note="12 bins cover 16 cells, 4 reserve cells")

    reserve = [(i, j) for i in range(P.PATCH_COLS) for j in range(P.PATCH_ROWS)
               if (i, j) not in occupied]
    record("reserve cells", len(reserve), len(reserve) >= 4,
           unit="cells", note="column 4 of rows 0-3 is empty")

    # ---------------------------------------------------------- 9. mass / print
    # Rough material estimate at 100 % solid (PLA 1.24 g/cm3)
    total_vol = plate.volume
    for pid, part in [("nut-m2", bin1), ("nut-m25", bin1), ("nut-m3", bin1),
                      ("nut-m4", bin1), ("wsh-m2", bin1), ("wsh-m25", bin1),
                      ("wsh-m3", bin1), ("wsh-m4", bin1),
                      ("scr-m2", bin2), ("scr-m25", bin2), ("scr-m3", bin2),
                      ("scr-m4", bin2)]:
        total_vol += part.volume
    record("solid volume of all 13 parts", total_vol / 1000.0,
           True, unit="cm^3", note="PLA ~1.24 g/cm3 -> ~"
           f"{total_vol / 1000.0 * 1.24:.0f} g at 100 % infill")

    with open(os.path.join(ROOT, "checks.json"), "w") as f:
        json.dump(results, f, indent=2)

    n_fail = sum(1 for r in results if not r["pass_"])
    print(f"\n{len(results)} checks, {n_fail} failed")
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
