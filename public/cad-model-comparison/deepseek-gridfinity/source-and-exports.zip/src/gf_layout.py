"""
gf_layout.py -- the starter layout on a 5 x 4 patch.

Patch frame: x = column * 42, y = row * 42, z = 0 at the bench.
Column 0 is the left edge, row 0 the front (south) edge.  Bins face south, so
their labels read from the front of the bench.

Starter assortment: four sizes (M2, M2.5, M3, M4) x three families
(nuts, washers, screws) = 12 bins:

  row 0   NUT M2 | NUT M2.5 | NUT M3 | NUT M4 | spare
  row 1   WSH M2 | WSH M2.5 | WSH M3 | WSH M4 | spare
  row 2   M2 (2x1, split) | M2.5 (2x1, split) | spare
  row 3   M3 (2x1, split) | M4 (2x1, split) | spare
  column 4 of rows 0-3: four 1 x 1 cells left open as the extension reserve.

The four reserve cells are the whole extension story: an M5 nut, washer and
screw bin (or a duplicate of whichever size runs out first) drop into the same
baseplate and use the same code with a new size key.

Heights: nuts and washers 2u (14 mm), screws 3u (21 mm), M4 screws 4u (28 mm).
Each compartment is one open compartment -- no little holes -- and every floor
is filleted so a 0.3 mm washer can be slid up the wall with a fingertip.
"""

from __future__ import annotations

import gf_params as P

# id, family, size, grid x, grid y, cells wide, cells deep, height (u),
# label text, x-split positions (local, mm), short/long length labels
STARTER_LAYOUT = [
    # nuts, front row (nearest the bench edge), 1 x 1
    ("nut-m2",  "nut",    "M2",   0, 0, 1, 1, 2, "NUT M2",   (), None),
    ("nut-m25", "nut",    "M2.5", 1, 0, 1, 1, 2, "NUT M2.5", (), None),
    ("nut-m3",  "nut",    "M3",   2, 0, 1, 1, 2, "NUT M3",   (), None),
    ("nut-m4",  "nut",    "M4",   3, 0, 1, 1, 2, "NUT M4",   (), None),
    # washers, second row, 1 x 1
    ("wsh-m2",  "washer", "M2",   0, 1, 1, 1, 2, "WSH M2",   (), None),
    ("wsh-m25", "washer", "M2.5", 1, 1, 1, 1, 2, "WSH M2.5", (), None),
    ("wsh-m3",  "washer", "M3",   2, 1, 1, 1, 2, "WSH M3",   (), None),
    ("wsh-m4",  "washer", "M4",   3, 1, 1, 1, 2, "WSH M4",   (), None),
    # screws, back two rows, 2 x 2 bins split short | long
    ("scr-m2",  "screw",  "M2",   0, 2, 2, 1, 3, "M2 6-20",  (41.75,), (10, 20)),
    ("scr-m25", "screw",  "M2.5", 2, 2, 2, 1, 3, "M2.5 6-20", (41.75,), (10, 20)),
    ("scr-m3",  "screw",  "M3",   0, 3, 2, 1, 3, "M3 6-20",  (41.75,), (10, 20)),
    ("scr-m4",  "screw",  "M4",   2, 3, 2, 1, 4, "M4 6-20",  (41.75,), (10, 20)),
]

# extension reserve: column 4 of rows 0-3 (four 1 x 1 cells, no bins yet)
EXTENSION_CELLS = [(4, 0), (4, 1), (4, 2), (4, 3)]
