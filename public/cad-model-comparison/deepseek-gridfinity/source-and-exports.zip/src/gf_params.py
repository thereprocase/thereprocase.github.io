"""
gf_params.py -- shared parameters for the M2-M4 screw / nut / washer organiser.

Every dimension is in millimetres.  Geometry is authored with +Z up, the bin
sitting on z=0.  Grid coordinates (i, j) are column, row of a 5 x 4 patch;
each cell is 42 mm and the origin of the patch is its south-west corner.

Sources for the Gridfinity interface (checked 2026-11-03):
  https://gridfinity.xyz/specification/            (magnet 6 x 2 mm, M3 screws)
  kennetek/gridfinity-rebuilt-openscad, src/core/standard.scad
      BASE_PROFILE, BASE_TOP_DIMENSIONS, STACKING_LIP, STACKING_LIP_SIZE
The profile numbers below are that reference implementation's reading of the
spec: 41.5 mm top, 0.8 + 1.8 + 2.15 mm stepped 45 deg base flank, 7 mm base,
stacking lip 0.7/2.5/4.4 mm high and 2.6 mm deep, 0.5 mm grid gap.
"""

# ---------------------------------------------------------------- grid
GRID = 42.0                 # nominal cell pitch
BASE_TOP = 41.5             # outer size of one base at its top
BASE_GAP = GRID - BASE_TOP  # 0.5 mm, shared between neighbours
BASE_R_TOP = 3.75           # corner radius of the 41.5 mm square
BASE_HEIGHT = 7.0           # base profile + bridge
PROFILE_STEPS = ((0.8, 0.8), (1.8, 0.8), (2.15, 2.95))  # (dz, outward) at 45 deg
PROFILE_H = 4.75            # 0.8 + 1.8 + 2.15
BRIDGE_H = BASE_HEIGHT - PROFILE_H   # 2.25 mm straight bridge above the profile
BASE_R_BOTTOM = BASE_R_TOP - 2.95    # 0.80 mm

# stacking lip, measured from the outer wall going inward and up
LIP_STEPS = ((0.7, 0.7), (2.5, 0.7), (4.4, 2.6))  # (z above bin top, inset)
LIP_TOP_H = 4.4             # nominal lip height above the bin top
LIP_R = 0.6                 # fillet so the lip tip is not a knife edge
LIP_TIP_INSET = 2.6         # lip tip sits 2.6 mm inside the outer wall

# ---------------------------------------------------------------- bin shell
WALL = 1.2                  # perimeter wall, printable at 0.4 mm nozzle x3
FLOOR = 1.6                 # floor thickness above the bridge
R_OUT = 2.0                 # outer vertical corner radius
R_IN = 1.0                  # compartment corner radius (fits a 0.4 nozzle)
R_IN_FLOOR = 2.0            # floor fillet in the compartment
DIVIDER = 1.2               # wall between two compartments

# label, engraved into the front (south) wall so it never fouls stacking.
# Fillaprint's own metadata: "every stroke is exactly two extrusion widths
# (w); cap height = 14 w; em = 20 w".  At em 8 mm the strokes are 0.8 mm,
# i.e. exactly two 0.4 mm nozzle widths, and the cap height is 5.6 mm.
LABEL_EM = 8.0
LABEL_DEPTH = 0.6           # engraved depth: 1.5 x 0.4 mm layers
LABEL_BAND_Z0 = 12.0        # bottom of the engraved band above the bin foot
LABEL_BAND_H = 12.0         # height of the label panel (cap height + padding)

# ---------------------------------------------------------------- hardware
# ISO 4762 / ISO 4032 / ISO 7089 nominal envelope, plus clearance for a
# printed pocket.  These are used for pocket sizing and for the clearance
# checks, so the numbers are deliberately on the generous side.
SCREW = {
    #        head dia  head h   socket across-flats
    "M2":   dict(head_d=3.8, head_h=2.0, hex_af=1.5),
    "M2.5": dict(head_d=4.5, head_h=2.5, hex_af=2.0),
    "M3":   dict(head_d=5.5, head_h=3.0, hex_af=2.5),
    "M4":   dict(head_d=7.0, head_h=4.0, hex_af=3.0),
}
NUT = {
    #        across flats  height
    "M2":   dict(af=4.0, h=1.6),
    "M2.5": dict(af=5.0, h=2.0),
    "M3":   dict(af=5.5, h=2.4),
    "M4":   dict(af=7.0, h=3.2),
}
WASHER = {
    #        outer dia  thickness
    "M2":   dict(od=4.5, t=0.3),
    "M2.5": dict(od=5.0, t=0.5),
    "M3":   dict(od=7.0, t=0.5),
    "M4":   dict(od=9.0, t=0.8),
}
# Pocket sizing.  Pockets hold parts loose in a single-layer-ish layer, not
# a 20-deep hole: a 20-deep 6 mm hole is unreachable with fingers.  Capacity
# is met with a shallow pocket and a wider footprint, so every pocket stays
# under ~8 mm deep and the fingers can pinch a washer off the floor.
POCKET_CLEAR = 0.6          # radial clearance around each part in its pocket
POCKET_MIN_D = 6.0          # never print a pocket smaller than a fingertip
POCKET_MAX_D = 12.0         # a 12 mm hole is still comfortable to pinch from
POCKET_DEPTH_NUT = 4.0      # nut pocket floor to rim
POCKET_DEPTH_WASHER = 2.4   # washer pocket: shallow tray, easy to slide out
POCKET_DEPTH_SCREW = 7.0    # screw pocket: head sits on the floor
POCKET_CHAMFER = 0.6        # 45 deg entry chamfer at every pocket rim
POCKET_FLOOR_FILLET = 1.0   # floor fillet so a washer can be slid up the side
POCKET_GAP = 1.2            # material between pocket rims
POCKET_EDGE = 2.0           # material between a pocket and the compartment wall

# ---------------------------------------------------------------- layout
PATCH_COLS = 5
PATCH_ROWS = 4

# A "type" is one compartment pattern that repeats across bins.  The starter
# layout uses four types; adding an M5 type later is a new entry in this dict
# plus a new row in STARTER_LAYOUT, with no geometry changes.
BIN_TYPES = {
    # key        nx  ny  height(u)  cell
    "S1": dict(nx=1, ny=1, h=21, cell="screw", screw="M2"),
    "S2": dict(nx=1, ny=1, h=21, cell="screw", screw="M2.5"),
    "S3": dict(nx=1, ny=1, h=21, cell="screw", screw="M3"),
    "S4": dict(nx=1, ny=1, h=21, cell="screw", screw="M4"),
    "N1": dict(nx=1, ny=1, h=14, cell="nut", screw="M2"),
    "N2": dict(nx=1, ny=1, h=14, cell="nut", screw="M2.5"),
    "N3": dict(nx=1, ny=1, h=14, cell="nut", screw="M3"),
    "N4": dict(nx=1, ny=1, h=14, cell="nut", screw="M4"),
    "W1": dict(nx=1, ny=1, h=14, cell="washer", screw="M2"),
    "W2": dict(nx=1, ny=1, h=14, cell="washer", screw="M2.5"),
    "W3": dict(nx=1, ny=1, h=14, cell="washer", screw="M3"),
    "W4": dict(nx=1, ny=1, h=14, cell="washer", screw="M4"),
}


def pocket_round(size_mm):
    """Round a pocket size up to 0.5 mm so the model stays tidy."""
    return float(int(size_mm * 2 + 0.9999) / 2)


def screw_pocket_d(screw):
    """Pocket diameter for a screw stored on its side, head down."""
    return pocket_round(SCREW[screw]["head_d"] + 2 * POCKET_CLEAR)


def nut_pocket_d(screw):
    """Pocket diameter for a hex nut lying flat (circumscribed circle)."""
    af = NUT[screw]["af"]
    return pocket_round(af / 0.8660254 + 2 * POCKET_CLEAR)


def washer_pocket_d(screw):
    """Pocket diameter for a flat washer."""
    return pocket_round(WASHER[screw]["od"] + 2 * POCKET_CLEAR)
