"""
gf_geom.py -- geometry for the M2-M4 organiser.  build123d, millimetres, +Z up.

A bin is built in its own local frame with its south-west grid corner at the
origin, so a bin occupying columns i..i+nx-1 and rows j..j+ny-1 sits at
(42*i, 42*j, 0) in the patch frame.

Construction:
  * base: individual 41.5 mm feet with the spec's stepped 45 deg flank
    (0.8 / 1.8 / 2.15 mm), tied by a 1.2 mm perimeter band from z=4.75 to 7.
  * body: outer wall from z=7 to the nominal height, 1.2 mm thick, floor 1.6.
  * compartment: one open compartment with a 1.2 mm floor fillet, so a
    0.3 mm washer can be slid up the side wall with one finger.
  * stacking lip: ruled loft between rounded rectangles at the four spec
    heights (0.7 / 2.5 / 4.4 mm above the bin top, 2.6 mm deep), tip filleted.
  * label: engraved into the OUTER south wall at em 8 mm, 0.6 mm deep.  On the
    wall it stays legible from the front of the bench, never fouls the stacking
    lip, and never reduces a compartment's clear space.
"""

from __future__ import annotations

import math

from build123d import (
    Align, Box, Face, Plane, Pos, RectangleRounded, Sketch, Solid, Text,
    extrude, fillet, loft,
)

import gf_params as P

FONT_PATH = None  # set by the build script before any label is made


# ------------------------------------------------------------------ helpers
def rrect(w: float, h: float, r: float, z: float = 0.0, cx: float = 0.0,
          cy: float = 0.0) -> Face:
    """A rounded rectangle face on the XY plane at height z."""
    r = max(min(r, w / 2 - 0.05, h / 2 - 0.05), 0.2)
    sk = Sketch() + Pos(cx, cy, z) * RectangleRounded(w, h, r)
    return sk.faces()[0]


def prism(w: float, h: float, r: float, z0: float, z1: float,
          cx: float = 0.0, cy: float = 0.0) -> Solid:
    return extrude(rrect(w, h, r, z0, cx, cy), z1 - z0)


def ring(w: float, h: float, r: float, t: float, z0: float, z1: float,
         cx: float = 0.0, cy: float = 0.0) -> Solid:
    """Rectangular tube: outer rounded rect minus inner offset by t."""
    return prism(w, h, r, z0, z1, cx, cy) - prism(
        w - 2 * t, h - 2 * t, max(r - t, 0.2), z0, z1, cx, cy)


def box(x0, y0, x1, y1, z0, z1) -> Solid:
    return Pos((x0 + x1) / 2, (y0 + y1) / 2, z0) * Box(
        x1 - x0, y1 - y0, z1 - z0,
        align=(Align.CENTER, Align.CENTER, Align.MIN))


# ------------------------------------------------------------------ base
def base_solid(nx: int, ny: int) -> Solid:
    """One Gridfinity base under an nx x ny bin (feet + perimeter bridge)."""
    top_w = nx * P.GRID - P.BASE_GAP
    top_h = ny * P.GRID - P.BASE_GAP

    feet = []
    for i in range(nx):
        for j in range(ny):
            # feet sit centred in the bin's own 41.5 mm footprint, which
            # starts at the bin origin (the 0.5 mm grid gap is at the far side)
            cx = P.GRID * i + P.BASE_TOP / 2
            cy = P.GRID * j + P.BASE_TOP / 2
            sections = [
                rrect(P.BASE_TOP - 2 * off, P.BASE_TOP - 2 * off,
                      P.BASE_R_TOP - off, z, cx, cy)
                for z, off in ((0.0, 2.95), (0.8, 2.15), (2.6, 2.15),
                               (P.PROFILE_H, 0.0))
            ]
            feet.append(loft(sections, ruled=True))

    base = feet[0]
    for f in feet[1:]:
        base = base.fuse(f).clean()
    base = base.fuse(ring(top_w, top_h, P.BASE_R_TOP, P.WALL,
                          P.PROFILE_H, P.BASE_HEIGHT,
                          top_w / 2, top_h / 2)).clean()
    return base


# ------------------------------------------------------------------ shell
def bin_shell(nx: int, ny: int, height: float) -> Solid:
    """Outer body: base, solid wall block, stacking lip.  Compartment uncut."""
    top_w = nx * P.GRID - P.BASE_GAP
    top_h = ny * P.GRID - P.BASE_GAP
    hw, hh = top_w / 2, top_h / 2

    # solid body; the compartment is carved by compartment_cutter() so a
    # divider can be left standing between two compartments
    body = prism(top_w, top_h, P.R_OUT, P.BASE_HEIGHT, height, hw, hh)

    lip_out = loft([
        rrect(top_w - 2 * o, top_h - 2 * o, P.R_OUT - o, height + z, hw, hh)
        for o, z in ((0.0, 0.0), (0.7, 0.7), (0.7, 2.5), (2.6, 4.4))
    ], ruled=True)
    lip_in = loft([
        rrect(top_w - 2 * o, top_h - 2 * o, P.R_OUT - o, height + z, hw, hh)
        for o, z in ((2.6, 4.4), (2.6, 2.5), (P.WALL, 0.0))
    ], ruled=True)
    lip = lip_out - lip_in

    tip = [e for e in lip.edges()
           if abs(e.center().Z - (height + P.LIP_TOP_H)) < 1e-6]
    if tip:
        lip = fillet(tip, P.LIP_R)

    return base_solid(nx, ny).fuse(body).fuse(lip).clean()


# ------------------------------------------------------------------ cavity
def compartment_cutter(nx: int, ny: int, height: float,
                       splits: tuple[float, ...] = ()) -> Solid:
    """The open compartment(s), floor at 8.6, 1.2 mm fillet at the floor.

    splits is a list of x positions (in the bin's local frame) at which a
    1.2 mm divider is left standing.  With no splits the bin is one open
    compartment, which is the default: loose parts stay reachable with
    fingers and a bin can be lifted without tipping its neighbours.
    """
    top_w = nx * P.GRID - P.BASE_GAP
    top_h = ny * P.GRID - P.BASE_GAP
    hw, hh = top_w / 2, top_h / 2
    z_floor = P.BASE_HEIGHT + P.FLOOR
    z_top = height + 1.0

    # Build the cavity as a loft: from the floor outline (inset by the
    # fillet radius) up through a quarter-circle of the floor fillet, then a
    # straight prism to the top.  This keeps the fillet as a smooth swept
    # surface instead of a filleted edge, which meshes cleanly to a
    # watertight STL.
    inner_w = top_w - 2 * P.WALL
    inner_h = top_h - 2 * P.WALL
    rf = P.R_IN_FLOOR

    sections = []
    n = 6
    for k in range(n + 1):
        a = (k / n) * (math.pi / 2)
        # quarter round: at the floor the cavity is inset by rf, widening to
        # the full inner size one fillet radius up
        inset = rf * (1 - math.sin(a))
        sections.append(rrect(inner_w - 2 * inset, inner_h - 2 * inset,
                              P.R_IN + inset,
                              z_floor + rf * (1 - math.cos(a)), hw, hh))
    sections.append(rrect(inner_w, inner_h, P.R_IN, z_top, hw, hh))
    cav = loft(sections, ruled=True)

    for x in splits:
        # the divider stands on the floor; its base is filleted so screws
        # cannot wedge under it
        div = box(x - P.DIVIDER / 2, P.WALL - 0.05,
                  x + P.DIVIDER / 2, top_h - P.WALL + 0.05,
                  z_floor - 0.1, z_top)
        cav -= div
    return cav


# ------------------------------------------------------------------ label
def wall_label(nx: int, ny: int, height: float, text: str,
               em: float = P.LABEL_EM) -> Solid:
    """Cutter for a permanent engraved label on the outer south wall.

    Text reads left-to-right from the front of the bench, cap height centred
    in the wall band between the base and the lip.  The cutter is extruded
    inward so the glyphs sit LABEL_DEPTH below the outer surface.
    """
    top_w = nx * P.GRID - P.BASE_GAP
    z_center = (P.BASE_HEIGHT + height) / 2

    txt = Text(text, font_size=em, font_path=FONT_PATH,
               align=(Align.CENTER, Align.CENTER))
    sk = Plane.XZ * Pos(top_w / 2, z_center, 0) * txt
    # Plane.XZ's normal points at -Y (outward), so extrude inward by -depth
    return extrude(sk, -P.LABEL_DEPTH)


# ------------------------------------------------------------------ build one
def make_bin(nx: int, ny: int, units: int, text: str,
             splits: tuple[float, ...] = ()) -> Solid:
    """Complete bin: shell, compartment(s), engraved label."""
    height = units * P.BASE_HEIGHT
    solid = bin_shell(nx, ny, height)
    solid -= compartment_cutter(nx, ny, height, splits)
    solid -= wall_label(nx, ny, height, text)
    if not solid.is_valid:
        raise RuntimeError(f"bin {text} is not a valid solid")
    return solid
