#!/usr/bin/env python3
"""
Parametric Gridfinity Fastener Organizer System (M2, M2.5, M3, M4 Starter Assortment)
Builds the 5x4 Gridfinity baseplate and 12 modular bins from 3 reusable bin footprints:
  1. 1x1 Dual Hardware Bin (Hex Nuts + Flat Washers with 3D tactile icons + FillaPrint labels)
  2. 2x1 Triple Screw Bin (3 finger-scoop compartments with 2-line FillaPrint labels)
  3. 2x1 Dual Screw Bin (2 wide finger-scoop compartments for longer/bulkier screws)

Uses a stepped stadium height profile:
  - Front 2 rows (M2, M2.5): 3U height (21.0 mm body + 4.4 mm lip = 25.4 mm) for shallow fingertip access to tiny parts
  - Rear 2 rows (M3, M4): 4U height (28.0 mm body + 4.4 mm lip = 32.4 mm) for full bulk capacity of M3/M4x20 screws and M4 nuts

Exports individual STEP and binary STL files per part, plus assembly.json.
"""

import json
import math
import time
from build123d import (
    Align,
    Box,
    BuildLine,
    BuildSketch,
    Circle,
    Line,
    Plane,
    Polygon,
    Pos,
    RectangleRounded,
    RegularPolygon,
    Text,
    ThreePointArc,
    export_step,
    export_stl,
    extrude,
    loft,
    make_face,
)

# ==============================================================================
# Core Gridfinity & Ergonomic Parameters (all dimensions in millimeters)
# ==============================================================================
GRID_PITCH = 42.0
GRID_CLEARANCE = 0.50          # 0.25 mm per side -> 41.5 mm (1U), 83.5 mm (2U)
HEIGHT_UNIT_MM = 7.0
LIP_HEIGHT = 4.40

BASEPLATE_COLS = 5             # 5x4 grid patch = 210.0 x 168.0 mm
BASEPLATE_ROWS = 4
BASEPLATE_HEIGHT = 4.50        # Standard flat-bottom open-frame Gridfinity baseplate height
BIN_SEAT_Z = 0.45              # Assembled Z offset of bin bottom in baseplate socket

WALL_THICKNESS = 1.85          # Flush with inner vertical face of stacking lip (zero front overhang)
FLOOR_Z = 5.80                 # 1.05 mm solid bridge above 4.75 mm foot profile
SHELF_FRONT_Y = 3.70           # 15.20 mm deep horizontal label shelf (Y in [3.70, 18.90])
SCOOP_RADIUS = 11.00           # Front concave finger-scoop ramp radius

FONT_PATH = "assets/fillaprint/Fillaprint-Regular.ttf"
PRIMARY_FONT_SIZE = 9.00       # FillaPrint em=9.00 mm -> cap=6.30 mm, 2-bead stroke=0.90 mm (w=0.45 mm)
SECONDARY_FONT_SIZE = 8.60     # FillaPrint em=8.60 mm -> cap=6.02 mm, 2-bead stroke=0.86 mm (w=0.43 mm)
LABEL_RELIEF = 0.60            # 3 layers at 0.20 mm layer height

# ==============================================================================
# Starter Assortment Definition (4 rows x 5 grid cols = 20 cells)
# Adding a new size later (e.g. M5 or M1.6) requires adding one row tuple here.
# ==============================================================================
STARTER_BINS = [
    # Row 0 (Front Row, Y = -63.0 mm): M2 (3U height = 25.40 mm)
    {
        "id": "bin_m2_nuts_washers",
        "bin_type": "1x1_dual_hw",
        "grid_x": 1,
        "grid_y": 1,
        "height_u": 3,
        "col": 0,
        "row": 0,
        "num_comp": 2,
        "thread": "M2",
        "labels": ["NUT", "WASH"],
        "contents": ["M2 Plain Hex Nuts (ISO 4032, 30+ pcs)", "M2 Flat Washers (ISO 7089, 30+ pcs)"],
    },
    {
        "id": "bin_m2_screws_6_8_10",
        "bin_type": "2x1_triple_screw",
        "grid_x": 2,
        "grid_y": 1,
        "height_u": 3,
        "col": 1,
        "row": 0,
        "num_comp": 3,
        "thread": "M2",
        "labels": ["6mm", "8mm", "10mm"],
        "contents": ["M2x6 SHCS (20+ pcs)", "M2x8 SHCS (20+ pcs)", "M2x10 SHCS (20+ pcs)"],
    },
    {
        "id": "bin_m2_screws_12_16",
        "bin_type": "2x1_dual_screw",
        "grid_x": 2,
        "grid_y": 1,
        "height_u": 3,
        "col": 3,
        "row": 0,
        "num_comp": 2,
        "thread": "M2",
        "labels": ["12mm", "16mm"],
        "contents": ["M2x12 SHCS (20+ pcs)", "M2x16 SHCS (20+ pcs)"],
    },
    # Row 1 (Y = -21.0 mm): M2.5 (3U height = 25.40 mm)
    {
        "id": "bin_m2_5_nuts_washers",
        "bin_type": "1x1_dual_hw",
        "grid_x": 1,
        "grid_y": 1,
        "height_u": 3,
        "col": 0,
        "row": 1,
        "num_comp": 2,
        "thread": "M2.5",
        "labels": ["NUT", "WASH"],
        "contents": ["M2.5 Plain Hex Nuts (ISO 4032, 30+ pcs)", "M2.5 Flat Washers (ISO 7089, 30+ pcs)"],
    },
    {
        "id": "bin_m2_5_screws_6_8_10",
        "bin_type": "2x1_triple_screw",
        "grid_x": 2,
        "grid_y": 1,
        "height_u": 3,
        "col": 1,
        "row": 1,
        "num_comp": 3,
        "thread": "M2.5",
        "labels": ["6mm", "8mm", "10mm"],
        "contents": ["M2.5x6 SHCS (20+ pcs)", "M2.5x8 SHCS (20+ pcs)", "M2.5x10 SHCS (20+ pcs)"],
    },
    {
        "id": "bin_m2_5_screws_12_16",
        "bin_type": "2x1_dual_screw",
        "grid_x": 2,
        "grid_y": 1,
        "height_u": 3,
        "col": 3,
        "row": 1,
        "num_comp": 2,
        "thread": "M2.5",
        "labels": ["12mm", "16mm"],
        "contents": ["M2.5x12 SHCS (20+ pcs)", "M2.5x16 SHCS (20+ pcs)"],
    },
    # Row 2 (Y = +21.0 mm): M3 (4U height = 32.40 mm, all 6 standard lengths + Nuts & Washers)
    {
        "id": "bin_m3_nuts_washers",
        "bin_type": "1x1_dual_hw",
        "grid_x": 1,
        "grid_y": 1,
        "height_u": 4,
        "col": 0,
        "row": 2,
        "num_comp": 2,
        "thread": "M3",
        "labels": ["NUT", "WASH"],
        "contents": ["M3 Plain Hex Nuts (ISO 4032, 30+ pcs)", "M3 Flat Washers (ISO 7089, 30+ pcs)"],
    },
    {
        "id": "bin_m3_screws_6_8_10",
        "bin_type": "2x1_triple_screw",
        "grid_x": 2,
        "grid_y": 1,
        "height_u": 4,
        "col": 1,
        "row": 2,
        "num_comp": 3,
        "thread": "M3",
        "labels": ["6mm", "8mm", "10mm"],
        "contents": ["M3x6 SHCS (20+ pcs)", "M3x8 SHCS (20+ pcs)", "M3x10 SHCS (20+ pcs)"],
    },
    {
        "id": "bin_m3_screws_12_16_20",
        "bin_type": "2x1_triple_screw",
        "grid_x": 2,
        "grid_y": 1,
        "height_u": 4,
        "col": 3,
        "row": 2,
        "num_comp": 3,
        "thread": "M3",
        "labels": ["12mm", "16mm", "20mm"],
        "contents": ["M3x12 SHCS (20+ pcs)", "M3x16 SHCS (20+ pcs)", "M3x20 SHCS (20+ pcs)"],
    },
    # Row 3 (Rear Row, Y = +63.0 mm): M4 (4U height = 32.40 mm)
    {
        "id": "bin_m4_nuts_washers",
        "bin_type": "1x1_dual_hw",
        "grid_x": 1,
        "grid_y": 1,
        "height_u": 4,
        "col": 0,
        "row": 3,
        "num_comp": 2,
        "thread": "M4",
        "labels": ["NUT", "WASH"],
        "contents": ["M4 Plain Hex Nuts (ISO 4032, 30+ pcs)", "M4 Flat Washers (ISO 7089, 30+ pcs)"],
    },
    {
        "id": "bin_m4_screws_8_10_12",
        "bin_type": "2x1_triple_screw",
        "grid_x": 2,
        "grid_y": 1,
        "height_u": 4,
        "col": 1,
        "row": 3,
        "num_comp": 3,
        "thread": "M4",
        "labels": ["8mm", "10mm", "12mm"],
        "contents": ["M4x8 SHCS (20+ pcs)", "M4x10 SHCS (20+ pcs)", "M4x12 SHCS (20+ pcs)"],
    },
    {
        "id": "bin_m4_screws_16_20",
        "bin_type": "2x1_dual_screw",
        "grid_x": 2,
        "grid_y": 1,
        "height_u": 4,
        "col": 3,
        "row": 3,
        "num_comp": 2,
        "thread": "M4",
        "labels": ["16mm", "20mm"],
        "contents": ["M4x16 SHCS (20+ pcs)", "M4x20 SHCS (20+ pcs)"],
    },
]

_BLANK_BIN_CACHE = {}
_TEXT_SOLID_CACHE = {}


def make_baseplate(cols: int = BASEPLATE_COLS, rows: int = BASEPLATE_ROWS):
    """
    Build a standard 42 mm pitch Gridfinity baseplate (cols x rows).
    Outer dimensions: (42*cols) x (42*rows) x 4.50 mm, outer corner radius 4.00 mm.
    Socket profile mates with 35.6 / 37.2 / 41.5 mm Gridfinity feet with >=0.25 mm clearance.
    """
    total_w = GRID_PITCH * cols
    total_d = GRID_PITCH * rows
    plate = extrude(RectangleRounded(total_w, total_d, 4.00), BASEPLATE_HEIGHT)

    # Unit socket cutter at origin (with 0.25 mm/side clearance in vertical section and 0.30 mm/side on upper cone)
    c0 = Pos(0, 0, 0.00) * RectangleRounded(35.50, 35.50, 1.00)
    c1 = Pos(0, 0, 1.10) * RectangleRounded(37.70, 37.70, 2.10)
    c2 = Pos(0, 0, 2.95) * RectangleRounded(37.70, 37.70, 2.10)
    c3 = Pos(0, 0, BASEPLATE_HEIGHT) * RectangleRounded(40.80, 40.80, 3.65)
    unit_cutter = loft([c0, c1]) + extrude(c1, 1.85) + loft([c2, c3])

    cutters = []
    x0 = -0.5 * total_w + 0.5 * GRID_PITCH
    y0 = -0.5 * total_d + 0.5 * GRID_PITCH
    for r in range(rows):
        cy = y0 + r * GRID_PITCH
        for c in range(cols):
            cx = x0 + c * GRID_PITCH
            cutters.append(Pos(cx, cy, 0) * unit_cutter)

    return plate - cutters


def make_foot_cell(cx: float, cy: float):
    """Build one 1x1 Gridfinity foot (0.8 mm @ 45 deg, 1.8 mm vert @ 37.2 mm, 2.15 mm @ 45 deg to 41.5 mm)."""
    s0 = Pos(cx, cy, 0.00) * RectangleRounded(35.60, 35.60, 0.80)
    s1 = Pos(cx, cy, 0.80) * RectangleRounded(37.20, 37.20, 1.60)
    s2 = Pos(cx, cy, 2.60) * RectangleRounded(37.20, 37.20, 1.60)
    s3 = Pos(cx, cy, 4.75) * RectangleRounded(41.50, 41.50, 3.75)
    return loft([s0, s1]) + extrude(s1, 1.80) + loft([s2, s3])


def make_cavity_yz_profile(shelf_top_z: float):
    """
    Build the 2D YZ cross-section of a compartment cavity for a given shelf_top_z:
    - Front wall at Y = -18.90 mm (flush with stacking lip inner face, zero overhang)
    - Front concave finger-scoop ramp of radius R = 11.00 mm tangent to floor at Z = 5.80 mm
    - Flat floor at Z = 5.80 mm
    - Rear 45-degree support-free slope under the horizontal label shelf
    - Horizontal XY label shelf top at Z = shelf_top_z (Y in [+3.70, +18.90], 15.20 mm deep)
    """
    y_arc_center = -18.90 + SCOOP_RADIUS  # -7.90 mm
    z_arc_center = FLOOR_Z + SCOOP_RADIUS  # 16.80 mm
    ym = y_arc_center - SCOOP_RADIUS * math.cos(math.pi / 4.0)
    zm = z_arc_center - SCOOP_RADIUS * math.sin(math.pi / 4.0)

    shelf_underside_front_z = shelf_top_z - 0.90
    dy_shelf = 18.90 - SHELF_FRONT_Y  # 15.20 mm
    z_at_rear_wall = shelf_underside_front_z - dy_shelf

    with BuildSketch(Plane.YZ) as sk:
        with BuildLine():
            Line((-18.90, shelf_top_z + 0.10), (-18.90, z_arc_center))
            ThreePointArc((-18.90, z_arc_center), (ym, zm), (y_arc_center, FLOOR_Z))
            if z_at_rear_wall <= FLOOR_Z:
                # 45-deg slope reaches floor before Y=+18.90 (e.g. 3U bin)
                y_floor_end = SHELF_FRONT_Y + (shelf_underside_front_z - FLOOR_Z)
                Line((y_arc_center, FLOOR_Z), (y_floor_end, FLOOR_Z))
                Line((y_floor_end, FLOOR_Z), (SHELF_FRONT_Y, shelf_underside_front_z))
            else:
                # 45-deg slope meets rear wall at Z = z_at_rear_wall > FLOOR_Z (e.g. 4U bin)
                Line((y_arc_center, FLOOR_Z), (18.90, FLOOR_Z))
                Line((18.90, FLOOR_Z), (18.90, z_at_rear_wall))
                Line((18.90, z_at_rear_wall), (SHELF_FRONT_Y, shelf_underside_front_z))
            Line((SHELF_FRONT_Y, shelf_underside_front_z), (SHELF_FRONT_Y, shelf_top_z + 0.10))
            Line((SHELF_FRONT_Y, shelf_top_z + 0.10), (-18.90, shelf_top_z + 0.10))
        make_face()
    return sk.sketch


def get_blank_bin(grid_x: int, height_u: int, num_comp: int, is_nut_washer: bool):
    """Build or retrieve cached blank bin body for a (grid_x, height_u, num_comp, is_nut_washer) template."""
    key = (grid_x, height_u, num_comp, is_nut_washer)
    if key in _BLANK_BIN_CACHE:
        return _BLANK_BIN_CACHE[key]

    body_h = HEIGHT_UNIT_MM * height_u
    total_h = body_h + LIP_HEIGHT
    shelf_top_z = body_h - 1.40  # 19.60 mm (3U) or 26.60 mm (4U)
    lip_flare_start_z = total_h - 1.00  # 24.40 mm (3U) or 31.40 mm (4U)

    w_outer = GRID_PITCH * grid_x - GRID_CLEARANCE
    d_outer = GRID_PITCH * 1 - GRID_CLEARANCE
    w_inner = w_outer - 2.0 * WALL_THICKNESS  # 37.80 mm (1U) or 79.80 mm (2U)
    d_inner = d_outer - 2.0 * WALL_THICKNESS  # 37.80 mm

    # 1. Outer shell + Gridfinity feet + top outer lead-in chamfer
    feet = None
    for i in range(grid_x):
        cx = -0.5 * GRID_PITCH * (grid_x - 1) + GRID_PITCH * i
        fc = make_foot_cell(cx, 0.0)
        feet = fc if feet is None else (feet + fc)

    body_main = Pos(0, 0, 4.75) * extrude(
        RectangleRounded(w_outer, d_outer, 3.75), total_h - 0.50 - 4.75
    )
    top_s0 = Pos(0, 0, total_h - 0.50) * RectangleRounded(w_outer, d_outer, 3.75)
    top_s1 = Pos(0, 0, total_h) * RectangleRounded(w_outer - 0.70, d_outer - 0.70, 3.40)
    solid = feet + body_main + loft([top_s0, top_s1])

    # 2. Upper cavity above label shelf + 45-deg stacking lip flare
    upper_open = Pos(0, 0, shelf_top_z) * extrude(
        RectangleRounded(w_inner, d_inner, 1.90), lip_flare_start_z - shelf_top_z
    )
    flare_s0 = Pos(0, 0, lip_flare_start_z) * RectangleRounded(w_inner, d_inner, 1.90)
    flare_s1 = Pos(0, 0, total_h) * RectangleRounded(w_outer - 1.70, d_outer - 1.70, 2.90)
    solid = solid - (upper_open + loft([flare_s0, flare_s1]))

    # 3. Compartment cavities below shelf_top_z
    div_thick = 1.60 if (grid_x == 1 and num_comp == 2) else (1.80 if num_comp == 2 else 1.50)
    comp_w = (w_inner - (num_comp - 1) * div_thick) / num_comp
    yz_prof = make_cavity_yz_profile(shelf_top_z)
    inner_env = Pos(0, 0, FLOOR_Z - 0.50) * extrude(
        RectangleRounded(w_inner, d_inner, 1.90), shelf_top_z - FLOOR_Z + 1.00
    )

    cavities = None
    comp_centers_x = []
    x_start = -0.5 * w_inner
    for i in range(num_comp):
        x0 = x_start + i * (comp_w + div_thick)
        xc = x0 + 0.5 * comp_w
        comp_centers_x.append(xc)
        box_cut = Pos(x0, 0, 0) * extrude(yz_prof, comp_w)
        cav = box_cut & inner_env
        cavities = cav if cavities is None else (cavities + cav)
    solid = solid - cavities

    z_sink = shelf_top_z - 0.10
    h_boss = LABEL_RELIEF + 0.10
    structural_features = []

    # Front center-stacking locator rib on 2x1 bins (at X=0 on front inner wall, with 45-deg support base)
    # 2.80 mm wide (X in [-1.40, +1.40]) inside the [-2.25, +2.25] mm inter-foot gap
    if grid_x == 2:
        loc_yz = Plane.YZ * Polygon(
            [
                (-19.00, shelf_top_z),
                (-19.00, lip_flare_start_z),
                (-17.20, lip_flare_start_z),
                (-17.20, shelf_top_z + 1.70),
                (-18.90, shelf_top_z),
            ],
            align=None,
        )
        front_locator = extrude(loc_yz, amount=1.40, both=True)
        structural_features.append(front_locator)

    # Raised visual/tactile divider ribs on the horizontal label shelf
    for i in range(1, num_comp):
        xd = x_start + i * comp_w + (i - 0.5) * div_thick
        if is_nut_washer:
            structural_features.append(Pos(xd, 7.30, z_sink + 0.5 * h_boss) * Box(1.20, 7.20, h_boss))
        else:
            structural_features.append(Pos(xd, 11.30, z_sink + 0.5 * h_boss) * Box(1.20, 15.20, h_boss))

    if is_nut_washer:
        hex_sk = Pos(-13.50, 14.80, z_sink) * (
            RegularPolygon(radius=3.20, side_count=6) - Circle(radius=1.30)
        )
        wsh_sk = Pos(13.50, 14.80, z_sink) * (Circle(radius=3.20) - Circle(radius=1.40))
        structural_features.extend([extrude(hex_sk, h_boss), extrude(wsh_sk, h_boss)])

    solid = solid + structural_features
    _BLANK_BIN_CACHE[key] = (solid, comp_centers_x, shelf_top_z)
    return solid, comp_centers_x, shelf_top_z


def get_text_solid(label: str, font_size: float, h_boss: float):
    """Build or retrieve cached extruded FillaPrint text solid."""
    key = (label, font_size, h_boss)
    if key not in _TEXT_SOLID_CACHE:
        _TEXT_SOLID_CACHE[key] = extrude(
            Text(
                label,
                font_size=font_size,
                font_path=FONT_PATH,
                align=(Align.CENTER, Align.CENTER),
            ),
            h_boss,
        )
    return _TEXT_SOLID_CACHE[key]


def build_bin_solid(spec: dict):
    """Build a complete labeled Gridfinity bin from its specification dictionary."""
    grid_x = spec["grid_x"]
    height_u = spec["height_u"]
    num_comp = spec["num_comp"]
    thread_label = spec["thread"]
    comp_labels = spec["labels"]
    is_nut_washer = spec["bin_type"] == "1x1_dual_hw"

    base_solid, comp_centers_x, shelf_top_z = get_blank_bin(grid_x, height_u, num_comp, is_nut_washer)
    z_sink = shelf_top_z - 0.10
    h_boss = LABEL_RELIEF + 0.10
    labels = []

    if is_nut_washer:
        t_top = Pos(0, 14.80, z_sink) * get_text_solid(thread_label, PRIMARY_FONT_SIZE, h_boss)
        labels.append(t_top)
        for xc, clbl in zip(comp_centers_x, comp_labels):
            t_comp = Pos(xc, 7.60, z_sink) * get_text_solid(clbl, SECONDARY_FONT_SIZE, h_boss)
            labels.append(t_comp)
    else:
        t_thread_proto = get_text_solid(thread_label, PRIMARY_FONT_SIZE, h_boss)
        for xc, clbl in zip(comp_centers_x, comp_labels):
            t1 = Pos(xc, 14.80, z_sink) * t_thread_proto
            t2 = Pos(xc, 7.60, z_sink) * get_text_solid(clbl, PRIMARY_FONT_SIZE, h_boss)
            labels.extend([t1, t2])

    return base_solid + labels


def export_bin(spec: dict):
    """Build and export one bin to STEP and binary STL."""
    t0 = time.time()
    part_id = spec["id"]
    solid = build_bin_solid(spec)
    step_file = f"{part_id}.step"
    stl_file = f"{part_id}.stl"
    export_step(solid, step_file)
    export_stl(solid, stl_file, tolerance=0.02, angular_tolerance=0.1)
    bb = solid.bounding_box()
    return {
        "id": part_id,
        "valid": bool(solid.is_valid),
        "volume_mm3": round(float(solid.volume), 2),
        "bbox_size_mm": [round(bb.size.X, 2), round(bb.size.Y, 2), round(bb.size.Z, 2)],
        "elapsed_s": round(time.time() - t0, 2),
    }


def compute_bin_world_position(spec: dict):
    """Compute the assembled [X, Y, Z] position in millimeters on the 5x4 baseplate."""
    total_w = GRID_PITCH * BASEPLATE_COLS
    total_d = GRID_PITCH * BASEPLATE_ROWS
    col = spec["col"]
    row = spec["row"]
    gx = spec["grid_x"]
    gy = spec["grid_y"]

    x_center = -0.5 * total_w + (col + 0.5 * gx) * GRID_PITCH
    y_center = -0.5 * total_d + (row + 0.5 * gy) * GRID_PITCH
    z_base = BIN_SEAT_Z
    return [round(x_center, 3), round(y_center, 3), round(z_base, 3)]


def make_transform_matrix(tx: float, ty: float, tz: float):
    """Return 4x4 homogeneous translation matrix in millimeters."""
    return [
        [1.0, 0.0, 0.0, tx],
        [0.0, 1.0, 0.0, ty],
        [0.0, 0.0, 1.0, tz],
        [0.0, 0.0, 0.0, 1.0],
    ]


def main():
    t_start = time.time()
    print("Building 5x4 Gridfinity Baseplate (baseplate_5x4)...")
    baseplate = make_baseplate(BASEPLATE_COLS, BASEPLATE_ROWS)
    export_step(baseplate, "baseplate_5x4.step")
    export_stl(baseplate, "baseplate_5x4.stl", tolerance=0.02, angular_tolerance=0.1)
    bp_bb = baseplate.bounding_box()
    print(
        f"  baseplate_5x4: valid={baseplate.is_valid}, "
        f"bbox={[round(bp_bb.size.X, 2), round(bp_bb.size.Y, 2), round(bp_bb.size.Z, 2)]} mm"
    )

    print(f"Building {len(STARTER_BINS)} labeled starter bins (with cached templates & glyphs)...")
    results = []
    for spec in STARTER_BINS:
        r = export_bin(spec)
        results.append(r)
        print(
            f"  {r['id']:24s}: valid={r['valid']}, "
            f"bbox={r['bbox_size_mm']} mm, vol={r['volume_mm3']} mm^3 ({r['elapsed_s']}s)"
        )

    # Build assembly.json
    assembly_parts = [
        {
            "id": "baseplate_5x4",
            "name": "5x4 Gridfinity Baseplate (210 x 168 mm)",
            "role": "baseplate",
            "file": "baseplate_5x4.stl",
            "stl": "baseplate_5x4.stl",
            "step": "baseplate_5x4.step",
            "grid_origin_col_row": [0, 0],
            "grid_span_xy": [BASEPLATE_COLS, BASEPLATE_ROWS],
            "position": [0.0, 0.0, 0.0],
            "translation": [0.0, 0.0, 0.0],
            "rotation": [0.0, 0.0, 0.0],
            "euler_xyz_deg": [0.0, 0.0, 0.0],
            "quaternion_xyzw": [0.0, 0.0, 0.0, 1.0],
            "transform": make_transform_matrix(0.0, 0.0, 0.0),
            "matrix": make_transform_matrix(0.0, 0.0, 0.0),
        }
    ]

    for spec in STARTER_BINS:
        pos = compute_bin_world_position(spec)
        mat = make_transform_matrix(*pos)
        assembly_parts.append(
            {
                "id": spec["id"],
                "name": f"{spec['thread']} ({', '.join(spec['labels'])})",
                "role": "bin",
                "bin_type": spec["bin_type"],
                "height_u": spec["height_u"],
                "thread_family": spec["thread"],
                "compartment_labels": spec["labels"],
                "compartment_contents": spec["contents"],
                "file": f"{spec['id']}.stl",
                "stl": f"{spec['id']}.stl",
                "step": f"{spec['id']}.step",
                "grid_origin_col_row": [spec["col"], spec["row"]],
                "grid_span_xy": [spec["grid_x"], spec["grid_y"]],
                "position": pos,
                "translation": pos,
                "rotation": [0.0, 0.0, 0.0],
                "euler_xyz_deg": [0.0, 0.0, 0.0],
                "quaternion_xyzw": [0.0, 0.0, 0.0, 1.0],
                "transform": mat,
                "matrix": mat,
            }
        )

    max_height_u = max(s["height_u"] for s in STARTER_BINS)
    max_total_z = round(BIN_SEAT_Z + HEIGHT_UNIT_MM * max_height_u + LIP_HEIGHT, 2)

    assembly_data = {
        "name": "Gridfinity Metric Socket-Head Fastener Organizer (M2, M2.5, M3, M4 Starter System)",
        "units": "mm",
        "grid_pitch_mm": GRID_PITCH,
        "height_unit_mm": HEIGHT_UNIT_MM,
        "baseplate_grid": [BASEPLATE_COLS, BASEPLATE_ROWS],
        "overall_footprint_mm": [
            GRID_PITCH * BASEPLATE_COLS,
            GRID_PITCH * BASEPLATE_ROWS,
            max_total_z,
        ],
        "reusable_bin_templates": [
            "1x1_dual_hw (41.5 x 41.5 mm, 3U/4U height, 2 compartments for Hex Nuts & Flat Washers)",
            "2x1_triple_screw (83.5 x 41.5 mm, 3U/4U height, 3 compartments for short/medium SHCS)",
            "2x1_dual_screw (83.5 x 41.5 mm, 3U/4U height, 2 wide compartments for long/bulky SHCS)",
        ],
        "font": {
            "path": FONT_PATH,
            "family": "Fillaprint Regular",
            "primary_em_mm": PRIMARY_FONT_SIZE,
            "primary_cap_height_mm": round(0.70 * PRIMARY_FONT_SIZE, 2),
            "primary_stroke_width_mm": round(0.10 * PRIMARY_FONT_SIZE, 2),
            "secondary_em_mm": SECONDARY_FONT_SIZE,
            "secondary_cap_height_mm": round(0.70 * SECONDARY_FONT_SIZE, 2),
            "secondary_stroke_width_mm": round(0.10 * SECONDARY_FONT_SIZE, 2),
            "relief_height_mm": LABEL_RELIEF,
        },
        "parts": assembly_parts,
    }

    with open("assembly.json", "w", encoding="utf-8") as f:
        json.dump(assembly_data, f, indent=2)

    print(f"All 13 STEP + binary STL parts and assembly.json generated in {time.time() - t_start:.2f}s.")


if __name__ == "__main__":
    main()
