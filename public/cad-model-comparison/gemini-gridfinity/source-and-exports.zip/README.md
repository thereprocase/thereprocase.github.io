# Gridfinity Metric Socket-Head Fastener Organizer System (M2, M2.5, M3, M4)

A parametric Gridfinity hardware storage system for hobby workbenches and drawers, covering **M2, M2.5, M3, and M4** socket-head cap screws (ISO 4762), plain hex nuts (ISO 4032), and flat washers (ISO 7089) in a **5 × 4 Gridfinity footprint (`210.0 × 168.0 mm`)**.

---

## 1. Starter Assortment & 5 × 4 Grid Layout

Rather than cramming 32 tiny, finger-inaccessible wells into a decorative tray, the system uses **four 5-unit rows** (one row per thread family from front to back) built from **three reusable bin footprints** in a **stepped stadium height profile**:
- **Front 2 Rows (`M2` and `M2.5`) — `3U` Height (`21.0 mm` body + `4.4 mm` lip = `25.4 mm` tall)**: Shallow `13.8 mm` cavity depth below the label shelf makes extracting tiny `0.3–0.5 mm` thick washers and `6 mm` screws with a fingertip effortless.
- **Rear 2 Rows (`M3` and `M4`) — `4U` Height (`28.0 mm` body + `4.4 mm` lip = `32.4 mm` tall)**: Stands `7.0 mm` higher behind the front rows for unobstructed stadium-style label visibility while providing the extra volume required for 20 bulky `M3/M4 × 20 mm` screws and 30 `M4` hex nuts.

| Row (Front → Back) | Y Center (`mm`) | Col 0 (`X = -84.0 mm`)<br>`1×1` Dual Hardware Bin | Cols 1–2 (`X = -21.0 mm`)<br>`2×1` Triple Screw Bin | Cols 3–4 (`X = +63.0 mm`)<br>`2×1` Screw Bin (Dual / Triple) |
| :--- | :---: | :--- | :--- | :--- |
| **Row 0: M2** (`3U`) | `-63.0` | `bin_m2_nuts_washers`<br>**M2 `NUT` \| `WASH`** | `bin_m2_screws_6_8_10`<br>**M2 `6mm` \| `8mm` \| `10mm`** | `bin_m2_screws_12_16` *(Dual)*<br>**M2 `12mm` \| `16mm`** |
| **Row 1: M2.5** (`3U`) | `-21.0` | `bin_m2_5_nuts_washers`<br>**M2.5 `NUT` \| `WASH`** | `bin_m2_5_screws_6_8_10`<br>**M2.5 `6mm` \| `8mm` \| `10mm`** | `bin_m2_5_screws_12_16` *(Dual)*<br>**M2.5 `12mm` \| `16mm`** |
| **Row 2: M3** (`4U`) | `+21.0` | `bin_m3_nuts_washers`<br>**M3 `NUT` \| `WASH`** | `bin_m3_screws_6_8_10`<br>**M3 `6mm` \| `8mm` \| `10mm`** | `bin_m3_screws_12_16_20` *(Triple)*<br>**M3 `12mm` \| `16mm` \| `20mm`** |
| **Row 3: M4** (`4U`) | `+63.0` | `bin_m4_nuts_washers`<br>**M4 `NUT` \| `WASH`** | `bin_m4_screws_8_10_12`<br>**M4 `8mm` \| `10mm` \| `12mm`** | `bin_m4_screws_16_20` *(Dual)*<br>**M4 `16mm` \| `20mm`** |

### Why These Sizes Belong Where
- **M2 & M2.5 (`6, 8, 10, 12, 16 mm` + Nuts & Washers)**: Covers PCB standoffs, micro-switches, sensors, and small axial fans. Rarely used `M2×20` and `M2.5×20` are omitted in favor of wide `39.0 mm` dual compartments for `12 mm` and `16 mm` screws.
- **M3 (`6, 8, 10, 12, 16, 20 mm` + Nuts & Washers)**: The universal metric hobby workhorse receives all six standard lengths across two `2×1` Triple bins.
- **M4 (`8, 10, 12, 16, 20 mm` + Nuts & Washers)**: `M4×6` is omitted (a `0.7 mm` pitch `M4` screw at `6 mm` length has barely 1.5 effective threads under the head); `8, 10, 12 mm` handle aluminum extrusion T-nuts and brackets, while bulky `16 mm` and `20 mm` screws sit in wide `39.0 mm` dual compartments.

---

## 2. Reusable Bin Types & Measured Clear Spaces

All compartments run the full front-to-back depth of the bin (`37.80 mm` internal span) with a **`22.60 mm` unobstructed top finger opening** in front of the `15.20 mm` horizontal rear label shelf:

1. **`1×1` Dual Hardware Bin (`1x1_dual_hw`, `41.50 × 41.50 mm`)**:
   - **Clear compartment width**: `18.10 mm` each (Left = Hex Nuts, Right = Flat Washers), separated by a `1.60 mm` divider.
   - **Usable volume below label shelf**: `6.98 cm³` (`3U`) / `11.50 cm³` (`4U`), holding **45–300+ hex nuts** or **90–500+ flat washers** (well above the 30-piece target).
2. **`2×1` Triple Screw Bin (`2x1_triple_screw`, `83.50 × 41.50 mm`)**:
   - **Clear compartment width**: `25.60 mm` each (3 compartments), separated by `1.50 mm` dividers.
   - **Usable volume below label shelf**: `9.87 cm³` (`3U`) / `16.26 cm³` (`4U`), holding **26–120+ socket-head screws** (exceeding the 20-piece target even for `M4×12` and `M3×20`).
3. **`2×1` Dual Screw Bin (`2x1_dual_screw`, `83.50 × 41.50 mm`)**:
   - **Clear compartment width**: `39.00 mm` each (2 wide compartments), separated by a `1.80 mm` divider.
   - **Usable volume below label shelf**: `15.03 cm³` (`3U`) / `24.77 cm³` (`4U`), holding **30–140+ long socket-head screws** (`M4×20` overall length is `24.0 mm`, lying completely flat in any orientation inside the `39.00 × 37.80 mm` compartment).

### Ergonomic & Functional Features
- **Zero-Overhang Front Scoop Wall**: The bin perimeter wall is `1.85 mm` thick—flush with the inner vertical face of the Gridfinity stacking lip (`37.80 mm` inner span)—with an `R = 11.00 mm` concave floor-to-front-wall scoop ramp. Sliding a `0.3 mm` thick `M2` washer up the front wall with an index finger encounters zero inward ledge at the top rim.
- **No Blind Under-Shelf Cave**: The `15.20 mm` horizontal rear label shelf is supported underneath by a continuous `45°` bevel extending down to the floor/rear wall. Fasteners cannot hide in an unreachable dark undercut beneath the label shelf, and the shelf prints cleanly with **zero support material**.

---

## 3. FillaPrint Typography & Nut/Washer Distinction

- **Font Used**: `assets/fillaprint/Fillaprint-Regular.ttf` (SIL Open Font License 1.1).
- **Two-Bead XY Extrusion Sizing**: Per the FillaPrint specification (`cap_height = 14 × w`, `em = 20 × w`, `stroke = 2 × w`), the minimum size for a standard `0.40 mm` nozzle (`w = 0.40–0.42 mm`) is `em = 8.00–8.40 mm` (`cap = 5.60–5.88 mm`).
  - **Primary Labels** (`M2`, `M2.5`, `M3`, `M4` and screw lengths `6mm`–`20mm`): `em = 9.00 mm` (`cap = 6.30 mm`, `stroke = 0.90 mm`, corresponding to `w = 0.45 mm`).
  - **Secondary Hardware Labels** (`NUT`, `WASH`): `em = 8.60 mm` (`cap = 6.02 mm`, `stroke = 0.86 mm`, corresponding to `w = 0.43 mm`).
  - **Horizontal XY Orientation & Relief**: All labels sit flat on the horizontal `Z = 19.60 mm` (`3U`) or `Z = 26.60 mm` (`4U`) shelf, raised `+0.60 mm` (3 layers at `0.20 mm` layer height) so the slicer traces every glyph stroke as exact two-bead XY perimeters and allows a single pause-at-layer filament color swap.
- **Obvious Nut vs. Washer Distinction**: Every `1×1` Hardware Bin pairs the text **`NUT`** (left) and **`WASH`** (right) with a raised **3D Hexagon Nut Icon** (`6.4 mm` across corners) on the left and a raised **3D Circular Washer Ring Icon** (`6.4 mm` OD) on the right, divided by a raised centerline rib.

---

## 4. Gridfinity Interfaces, Handling, Stacking & Extension

- **42 mm Gridfinity Baseplate Compatibility**:
  - `baseplate_5x4` measures `210.00 × 168.00 × 4.50 mm` (`42.00 mm` pitch, `R = 4.00 mm` corners).
  - Bins have outer dimensions of `41.50 × 41.50 mm` (`1×1`) and `83.50 × 41.50 mm` (`2×1`), leaving a `0.50 mm` gap between adjacent bins so any single bin lifts cleanly out of the grid without jostling or spilling its neighbors.
  - Foot profile (`35.60 mm` base, `0.80 mm @ 45°`, `1.80 mm` vertical at `37.20 mm`, `2.15 mm @ 45°` to `41.50 mm`) mates with the baseplate socket with `0.25 mm/side` lateral clearance.
- **Stacking & Project Portability**:
  - All bins sit in a single layer on the `5×4` baseplate during normal bench storage so every label is visible without lifting a bin.
  - When bringing a thread family (e.g., `M3`) to a project, the two `2×1` screw bins stack directly on top of each other, and the `1×1` Nut/Washer bin stacks onto either the left or right cell of any `2×1` bin (positively indexed on all 4 sides by the perimeter stacking lip and the `X = 0` front inter-foot locator rib).
  - Raised FillaPrint labels stop `1.55 mm` below the bottom of a stacked bin's foot (`Z = 20.20 mm` vs. `21.75 mm` on `3U`; `Z = 27.20 mm` vs. `28.75 mm` on `4U`).
- **Extending with Another Size Later**:
  - To add `M5` or `M1.6` later, append one row entry to `STARTER_BINS` in `generate_organizer.py` (using the existing `1x1_dual_hw`, `2x1_triple_screw`, and `2x1_dual_screw` templates) and increment `BASEPLATE_ROWS`.

---

## 5. Limitations & Physical Fit Tests Still Required

1. **First-Layer Elephant's Foot on Foot-to-Socket Fit**: The CAD model provides `0.25 mm/side` lateral clearance between the `37.20 mm` bin foot and `37.70 mm` baseplate socket (`0.15 mm` minimum surface distance on the `45°` mating cone). Print one `1×1` bin (`bin_m2_nuts_washers.stl`) and test-fit it into an existing `42 mm` Gridfinity baseplate and `baseplate_5x4.stl` before batch printing to confirm drop-in release without binding.
2. **Slicer Line Width for Two-Bead FillaPrint Labels**: Slice with a `0.40 mm` nozzle using `0.40–0.44 mm` top-surface extrusion line width (`Classic` or `Arachne` perimeter generator, `0.20 mm` layer height) and verify in slicer preview that each character stroke resolves cleanly as two continuous perimeter beads.
3. **Finger Clearance with Oil/Debris**: The `18.10 × 22.60 mm` top opening on the `1×1` Nut/Washer bin fits a bare adult index fingertip (`~14–16 mm` wide); users wearing thick work gloves may prefer configuring the `NUT`/`WASH` bin as `grid_x = 2` (`39.00 mm` wide compartments) in `generate_organizer.py`.

---

## 6. File Manifest

- `generate_organizer.py` — Parametric `build123d` CAD generator for the baseplate, reusable bin templates, FillaPrint labels, STEP/STL exports, and `assembly.json`.
- `verify_organizer.py` — Automated `trimesh`/`numpy` verification suite generating `checks.json`.
- `assembly.json` — Part manifest and assembled 3D transforms in millimeters.
- `checks.json` — Measured mesh, clearance, stacking, capacity, and typography verification results.
- `baseplate_5x4.step`, `baseplate_5x4.stl` — `5 × 4` Gridfinity baseplate (`210.0 × 168.0 × 4.5 mm`).
- `bin_m2_nuts_washers.{step,stl}`, `bin_m2_screws_6_8_10.{step,stl}`, `bin_m2_screws_12_16.{step,stl}` — Row 0 (`M2`, `3U`).
- `bin_m2_5_nuts_washers.{step,stl}`, `bin_m2_5_screws_6_8_10.{step,stl}`, `bin_m2_5_screws_12_16.{step,stl}` — Row 1 (`M2.5`, `3U`).
- `bin_m3_nuts_washers.{step,stl}`, `bin_m3_screws_6_8_10.{step,stl}`, `bin_m3_screws_12_16_20.{step,stl}` — Row 2 (`M3`, `4U`).
- `bin_m4_nuts_washers.{step,stl}`, `bin_m4_screws_8_10_12.{step,stl}`, `bin_m4_screws_16_20.{step,stl}` — Row 3 (`M4`, `4U`).
