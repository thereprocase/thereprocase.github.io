"""Functional & geometric verification for the Dual DDR4 RAM Mailer."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import trimesh


def is_binary_stl(path: Path) -> bool:
    data = path.read_bytes()
    if len(data) < 84:
        return False
    # ASCII STL starts with "solid " and contains "facet normal" in ASCII
    if data[:6] == b"solid " and b"facet normal" in data[:1024]:
        return False
    tri_count = int.from_bytes(data[80:84], "little")
    expected_size = 84 + tri_count * 50
    return len(data) == expected_size


def main() -> int:
    root = Path(__file__).resolve().parent.parent
    asm_path = root / "assembly.json"
    asm = json.loads(asm_path.read_text())

    meshes: dict[str, trimesh.Trimesh] = {}
    asm_meshes: dict[str, trimesh.Trimesh] = {}

    print("=== 1. STL & Mesh Integrity ===")
    for part in asm["parts"]:
        name = part["name"]
        stl_path = root / part["stl_file"]
        step_path = root / part["step_file"]
        assert stl_path.exists(), f"Missing STL: {stl_path}"
        assert step_path.exists(), f"Missing STEP: {step_path}"
        assert is_binary_stl(stl_path), f"STL is not valid binary STL: {stl_path}"

        m = trimesh.load_mesh(stl_path, force="mesh")
        assert m.is_watertight, f"{name} mesh is not watertight!"
        assert m.is_winding_consistent, f"{name} mesh winding is inconsistent!"
        assert m.volume > 0, f"{name} volume must be positive!"
        meshes[name] = m

        m_asm = m.copy()
        mat = np.array(part["assembled_transform"]["matrix_4x4"], dtype=float)
        m_asm.apply_transform(mat)
        asm_meshes[name] = m_asm

        bb = m.bounds
        ext = m.extents
        print(
            f"  {name}: binary_stl=OK watertight=OK volume={m.volume:.1f} mm^3 "
            f"print_extents=({ext[0]:.2f}, {ext[1]:.2f}, {ext[2]:.2f}) mm "
            f"z_range=({bb[0][2]:.2f}, {bb[1][2]:.2f})"
        )

    base_m = asm_meshes["base"]
    lid_m = asm_meshes["lid"]

    print("\n=== 2. Assembled Envelope & Parting/Latch Clearance ===")
    all_pts = np.vstack([base_m.bounds, lid_m.bounds])
    asm_min = all_pts.min(axis=0)
    asm_max = all_pts.max(axis=0)
    asm_ext = asm_max - asm_min
    print(f"  Assembled outer extents: ({asm_ext[0]:.2f}, {asm_ext[1]:.2f}, {asm_ext[2]:.2f}) mm")

    # Check base vs lid intersection using signed_distance on sampled surface points
    # (positive = inside solid, negative = outside; allow tiny mesh tessellation tolerance <= 0.02 mm)
    lid_pts, _ = trimesh.sample.sample_surface(lid_m, 8000)
    sd_lid_in_base = trimesh.proximity.signed_distance(base_m, lid_pts)
    max_pen_lid_in_base = float(sd_lid_in_base.max())

    base_pts, _ = trimesh.sample.sample_surface(base_m, 8000)
    sd_base_in_lid = trimesh.proximity.signed_distance(lid_m, base_pts)
    max_pen_base_in_lid = float(sd_base_in_lid.max())
    max_pen = max(max_pen_lid_in_base, max_pen_base_in_lid)
    print(f"  Base-Lid max surface penetration (sampled): {max_pen:.4f} mm (must be <= 0.02 mm)")
    assert max_pen <= 0.02, f"Base and lid collide in assembled state: {max_pen:.4f} mm"

    # Check tongue-to-skirt radial clearance at Z=24.5 mm by raycasting along +Y at X=40 mm
    ray_origins = np.array([[40.0, 0.0, 24.5], [40.0, 20.0, 24.5]])
    ray_dirs = np.array([[0.0, 1.0, 0.0], [0.0, -1.0, 0.0]])
    # Base outer tongue face at Z=24.5
    b_locs, _, _ = base_m.ray.intersects_location(ray_origins[:1], ray_dirs[:1])
    # Lid inner skirt face at Z=24.5 (ray from Y=10 outward to +Y)
    l_locs, _, _ = lid_m.ray.intersects_location(np.array([[40.0, 10.0, 24.5]]), np.array([[0.0, 1.0, 0.0]]))
    b_tongue_y = float(b_locs[:, 1].max())
    l_skirt_in_y = float(l_locs[:, 1].min())
    radial_gap = l_skirt_in_y - b_tongue_y
    print(f"  Tongue-to-skirt radial clearance at Z=24.5 mm: {radial_gap:.3f} mm (expected ~0.200 mm)")
    assert 0.15 <= radial_gap <= 0.30, f"Unexpected radial clearance: {radial_gap}"

    print("\n=== 3. DDR4 Module Fit, ESD Clearance & Gold-Contact Relief ===")
    # Pedestal Z and base tongue top Z from actual base mesh
    # Raycast down at X=137/2 - 5 -> X=66.0, Y=6.6 (on pedestal) and X=0, Y=6.6 (in relief channel)
    ped_hits, _, _ = base_m.ray.intersects_location(
        np.array([[66.0, 6.6, 15.0], [0.0, 6.6, 15.0]]),
        np.array([[0.0, 0.0, -1.0], [0.0, 0.0, -1.0]]),
    )
    # Sort hits by Z descending; highest hit < 15.0 is the floor surface
    ped_z = float(max(z for x, y, z in ped_hits if abs(x - 66.0) < 1.0 and z < 15.0))
    rel_z = float(max(z for x, y, z in ped_hits if abs(x) < 1.0 and z < 15.0))
    gold_pin_relief = ped_z - rel_z
    print(f"  Measured pedestal Z: {ped_z:.2f} mm, relief channel Z: {rel_z:.2f} mm -> gold-contact relief gap: {gold_pin_relief:.2f} mm")
    assert gold_pin_relief >= 2.5, f"Gold contact relief too small: {gold_pin_relief}"

    # Base max Z (top of alignment tongue)
    base_top_z = float(base_m.bounds[1][2])

    # Lid inner ceiling Z (raycast up from (0, 6.6, 30.0))
    ceil_hits, _, _ = lid_m.ray.intersects_location(
        np.array([[0.0, 6.6, 30.0]]),
        np.array([[0.0, 0.0, 1.0]]),
    )
    lid_ceil_z = float(ceil_hits[:, 2].min())
    internal_h = lid_ceil_z - ped_z
    print(f"  Measured lid ceiling Z: {lid_ceil_z:.2f} mm -> internal height above pedestal: {internal_h:.2f} mm")

    # Test real-world DDR4 modules + max envelope + excluded tall RGB
    modules = [
        ("JEDEC bare DDR4", 133.35, 4.0, 31.25, True),
        ("Corsair Vengeance LPX", 135.0, 7.0, 33.5, True),
        ("Kingston FURY Beast", 133.35, 7.2, 34.1, True),
        ("Crucial Ballistix", 133.35, 7.2, 39.17, True),
        ("G.Skill Ripjaws V", 133.35, 7.0, 42.0, True),
        ("Max Supported Envelope", 135.5, 8.0, 42.5, True),
        ("Corsair Vengeance RGB Pro (excluded)", 133.35, 7.5, 51.0, False),
    ]

    for label, mod_l, mod_t, mod_h, should_fit in modules:
        # Place two modules centered in each slot (Y = ±6.6 mm), resting on pedestal Z,
        # and verify zero penetration against both base and lid meshes.
        fit_all = True
        for y_c in (-6.6, 6.6):
            mod_box = trimesh.creation.box(extents=[mod_l, mod_t, mod_h])
            mod_box.apply_translation([0.0, y_c, ped_z + mod_h / 2.0])
            pts, _ = trimesh.sample.sample_surface(mod_box, 3000)
            pen_b = float(trimesh.proximity.signed_distance(base_m, pts).max())
            pen_l = float(trimesh.proximity.signed_distance(lid_m, pts).max())
            if max(pen_b, pen_l) > 0.05:
                fit_all = False
                break
        assert fit_all == should_fit, f"Fit mismatch for {label}: got {fit_all}, expected {should_fit}"
        protrusion = (ped_z + mod_h) - base_top_z
        z_clear = internal_h - mod_h
        status = "FITS" if fit_all else "EXCLUDED (expected)"
        print(
            f"  {label:38s}: {status:19s} | "
            f"Z_clear={z_clear:+.2f} mm | open_protrusion={protrusion:+.2f} mm"
        )

    print("\n=== 4. Latch Strain & FillaPrint Label Verification ===")
    # Cantilever latch arm: L = 34.0 - 16.0 = 18.0 mm (root at Z=34, bead at Z=16), t = 1.6 mm, delta = 1.0 mm
    L_arm = 18.0
    t_arm = 1.6
    delta = 1.0
    strain_pct = 100.0 * (3.0 * t_arm * delta) / (2.0 * L_arm ** 2)
    print(f"  Latch cantilever strain (L={L_arm} mm, t={t_arm} mm, delta={delta} mm): {strain_pct:.2f}% (< 1.5% elastic limit)")
    assert strain_pct < 1.5

    # Check debossed text depth on lid top (raycast down near X=-32, Y=0)
    # Sample a grid over the primary label region to verify both Z=total_height and Z=total_height-0.6 exist
    xs = np.linspace(-48, -16, 40)
    ys = np.linspace(-4, 4, 15)
    gx, gy = np.meshgrid(xs, ys)
    origins = np.column_stack([gx.ravel(), gy.ravel(), np.full(gx.size, 60.0)])
    dirs = np.tile([0.0, 0.0, -1.0], (gx.size, 1))
    top_hits, _, _ = lid_m.ray.intersects_location(origins, dirs)
    max_top_z = float(top_hits[:, 2].max())
    # Filter hits on the top surface (within 1.0 mm of max_top_z)
    label_zs = top_hits[:, 2][top_hits[:, 2] > max_top_z - 1.0]
    deboss_depth = max_top_z - float(label_zs.min())
    print(f"  Lid FillaPrint label deboss depth measured: {deboss_depth:.2f} mm (top Z={max_top_z:.2f} mm)")
    assert 0.5 <= deboss_depth <= 0.7

    print("\nALL VERIFICATION CHECKS PASSED.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
