"""Parametric dimensions and envelope specifications for the Dual DDR4 RAM Mailer."""

from dataclasses import dataclass


@dataclass(frozen=True)
class MailerParams:
    # Supported bare/heatsinked DDR4 UDIMM module envelope (mm)
    # Covers JEDEC bare (133.35x31.25x4), Corsair Vengeance LPX (135x33.5x7),
    # Kingston FURY Beast (133.35x34.1x7.2), Crucial Ballistix (133.35x39.17x7.2),
    # and G.Skill Ripjaws V (133.35x42.0x7.0).
    max_module_length: float = 135.5
    max_module_height: float = 42.5
    max_module_thickness: float = 8.0

    # Internal per-slot cavity dimensions (accommodates ESD bag + thin paper/foam)
    slot_length: float = 141.0
    slot_width: float = 10.8
    slot_internal_height: float = 46.6  # From end-pedestal top to lid inner ceiling

    # Gold-contact relief channel on slot floor
    pedestal_length: float = 9.0  # Raised end-support pads at each end of slot
    relief_depth: float = 3.0     # Recessed center channel depth under gold pins

    # Structural wall thicknesses
    outer_wall_t: float = 3.0
    divider_t: float = 2.4
    base_floor_t: float = 2.4     # Thickness under relief channel (5.4 mm at pedestals)
    lid_roof_t: float = 2.5

    # Derived overall outer footprint (mm)
    # outer_X = 141.0 + 2*3.0 = 147.0
    # outer_Y = 2*10.8 + 2.4 + 2*3.0 = 30.0
    outer_corner_chamfer: float = 1.6

    # Split / parting plane & stepped alignment tongue
    base_shoulder_z: float = 22.0   # Outer parting line Z
    tongue_height: float = 5.0      # Base inner alignment tongue above shoulder
    tongue_t: float = 1.4           # Thickness of base alignment tongue
    radial_clearance: float = 0.2   # Fit clearance between lid skirt and base tongue
    axial_clearance: float = 0.2    # Gap above tongue top when lid is seated

    # Lid inner divider rib (keeps bagged modules separated when inverted)
    lid_divider_drop: float = 8.0

    # Compliant side snap-latches (one centered on each long side)
    latch_width: float = 24.0
    latch_slot_width: float = 1.5
    latch_arm_t: float = 1.6
    latch_arm_top_z: float = 34.0     # Top of relief slots in lid skirt
    latch_arm_bottom_z: float = 13.0  # Bottom of finger-lift flare
    latch_bead_z_min: float = 15.5
    latch_bead_z_max: float = 18.5
    latch_bead_depth: float = 1.0     # Inward engagement into base groove
    latch_groove_depth: float = 1.2   # Cutout depth on base outer wall
    latch_flare_out: float = 1.8      # Outward finger-lift lip at bottom of arm

    # FillaPrint debossed labels
    font_path: str = "assets/fillaprint/Fillaprint-Regular.ttf"
    label_depth: float = 0.6
    label_primary_text: str = "2x DDR4"
    label_primary_size: float = 12.0
    label_secondary_text: str = "MAX 135x42.5x8"
    label_secondary_size: float = 8.5
    label_bottom_text: str = "ESD BAG + FOAM"
    label_bottom_size: float = 8.5

    @property
    def outer_length(self) -> float:
        return self.slot_length + 2.0 * self.outer_wall_t

    @property
    def outer_width(self) -> float:
        return 2.0 * self.slot_width + self.divider_t + 2.0 * self.outer_wall_t

    @property
    def pedestal_z(self) -> float:
        return self.base_floor_t + self.relief_depth

    @property
    def lid_inner_ceiling_z(self) -> float:
        return self.pedestal_z + self.slot_internal_height

    @property
    def total_height(self) -> float:
        return self.lid_inner_ceiling_z + self.lid_roof_t

    @property
    def slot_y_centers(self) -> tuple[float, float]:
        offset = (self.divider_t + self.slot_width) / 2.0
        return (-offset, offset)
