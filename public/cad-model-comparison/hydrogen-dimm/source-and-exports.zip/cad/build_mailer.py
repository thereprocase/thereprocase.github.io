"""Parametric build123d CAD generator for the Dual DDR4 RAM Mailer."""

from __future__ import annotations

import json
import math
from pathlib import Path

import build123d as bd

from params import MailerParams


def _chamfered_rect_wire(length: float, width: float, chamfer: float) -> bd.Face:
    """Create a centered 2D rectangle face with 45-deg corner chamfers."""
    sk = bd.Rectangle(length, width)
    if chamfer > 0:
        sk = bd.chamfer(sk.vertices(), chamfer)
    return sk


def _inset_face(face: bd.Face, inset: float) -> bd.Face:
    """Offset a 2D face inward by `inset` mm."""
    return bd.offset(face, -inset)


def build_base(p: MailerParams) -> bd.Part:
    """Build the base tray in assembled coordinates (Z=0 at bottom)."""
    outer_face = _chamfered_rect_wire(p.outer_length, p.outer_width, p.outer_corner_chamfer)
    tongue_inset = p.outer_wall_t - p.tongue_t
    tongue_face = _inset_face(outer_face, tongue_inset)

    # Main outer body up to parting shoulder
    body = bd.extrude(outer_face, p.base_shoulder_z)
    # Bottom edge chamfer for comfortable handling and elephant-foot tolerance
    body = bd.chamfer(body.edges().filter_by(lambda e: abs(e.center().Z) < 1e-4), 0.6)

    # Stepped inner alignment tongue above shoulder
    tongue = bd.Pos(0, 0, p.base_shoulder_z) * bd.extrude(tongue_face, p.tongue_height)
    # Lead-in chamfer on top outer edge of tongue
    tongue = bd.chamfer(
        tongue.edges().filter_by(lambda e: abs(e.center().Z - (p.base_shoulder_z + p.tongue_height)) < 1e-4),
        0.5,
    )
    base = body + tongue

    # Cut the two parallel RAM slots down to pedestal_z
    slot_cut_h = (p.base_shoulder_z + p.tongue_height + 1.0) - p.pedestal_z
    relief_len = p.slot_length - 2.0 * p.pedestal_length
    for y_c in p.slot_y_centers:
        slot_box = bd.Pos(0, y_c, p.pedestal_z) * bd.Box(
            p.slot_length,
            p.slot_width,
            slot_cut_h,
            align=(bd.Align.CENTER, bd.Align.CENTER, bd.Align.MIN),
        )
        base = base - slot_box

        # Gold-contact relief channel recessed below pedestal_z in the center
        relief_box = bd.Pos(0, y_c, p.base_floor_t) * bd.Box(
            relief_len,
            p.slot_width,
            p.relief_depth + 0.5,
            align=(bd.Align.CENTER, bd.Align.CENTER, bd.Align.MIN),
        )
        base = base - relief_box

    # Cut snap-catch grooves on both long outer walls (+Y and -Y)
    groove_w = p.latch_width + 2.0  # 1 mm clearance on each side of latch bead
    z_bot = p.latch_bead_z_min - p.latch_groove_depth - 0.2
    z_top = p.latch_bead_z_max + p.latch_groove_depth + 0.2
    z_mid_bot = p.latch_bead_z_min - 0.2
    z_mid_top = p.latch_bead_z_max + 0.2
    y_out = p.outer_width / 2.0
    y_in = y_out - p.latch_groove_depth

    for sign in (1.0, -1.0):
        # Trapezoidal groove profile in YZ plane extruded along X
        pts = [
            (sign * (y_out + 0.2), z_bot),
            (sign * y_in, z_mid_bot),
            (sign * y_in, z_mid_top),
            (sign * (y_out + 0.2), z_top),
        ]
        if sign < 0:
            pts = list(reversed(pts))
        groove_face = bd.Plane.YZ * bd.Polygon(pts, align=None)
        groove = bd.extrude(groove_face, groove_w / 2.0, both=True)
        base = base - groove

    # Deboss FillaPrint label on bottom face (mirrored in X so readable from below)
    txt = bd.Text(
        p.label_bottom_text,
        font_size=p.label_bottom_size,
        font_path=p.font_path,
        align=(bd.Align.CENTER, bd.Align.CENTER),
    )
    txt_mirrored = bd.mirror(txt, bd.Plane.YZ)
    txt_solid = bd.extrude(txt_mirrored, p.label_depth)
    base = base - txt_solid

    return bd.Part(base.wrapped)


def build_lid(p: MailerParams) -> bd.Part:
    """Build the lid in assembled coordinates (Z=base_shoulder_z to total_height)."""
    outer_face = _chamfered_rect_wire(p.outer_length, p.outer_width, p.outer_corner_chamfer)
    lid_h = p.total_height - p.base_shoulder_z

    # Outer shell
    lid = bd.Pos(0, 0, p.base_shoulder_z) * bd.extrude(outer_face, lid_h)
    lid = bd.chamfer(
        lid.edges().filter_by(lambda e: abs(e.center().Z - p.total_height) < 1e-4),
        0.8,
    )

    # Skirt cavity (tongue clearance zone from base_shoulder_z to tongue_top + axial_clearance)
    skirt_inset = p.outer_wall_t - p.tongue_t - p.radial_clearance
    skirt_cav_face = _inset_face(outer_face, skirt_inset)
    skirt_cav_h = p.tongue_height + p.axial_clearance
    skirt_cav = bd.Pos(0, 0, p.base_shoulder_z - 0.1) * bd.extrude(skirt_cav_face, skirt_cav_h + 0.1)
    lid = lid - skirt_cav

    # Main upper cavity (matches slot footprint)
    upper_cav_face = _inset_face(outer_face, p.outer_wall_t)
    upper_cav_z0 = p.base_shoulder_z + skirt_cav_h
    upper_cav_h = p.lid_inner_ceiling_z - upper_cav_z0
    upper_cav = bd.Pos(0, 0, upper_cav_z0 - 0.1) * bd.extrude(upper_cav_face, upper_cav_h + 0.1)
    lid = lid - upper_cav

    # Inner divider rib hanging from lid ceiling to keep bagged modules separated
    rib_z0 = p.lid_inner_ceiling_z - p.lid_divider_drop
    rib = bd.Pos(0, 0, rib_z0) * bd.Box(
        p.slot_length - 1.0,
        p.divider_t,
        p.lid_divider_drop + 0.2,
        align=(bd.Align.CENTER, bd.Align.CENTER, bd.Align.MIN),
    )
    lid = lid + rib

    # Compliant snap-latch arms on both long sides (+Y and -Y)
    y_out = p.outer_width / 2.0
    y_arm_in = y_out + p.radial_clearance
    y_arm_out = y_arm_in + p.latch_arm_t
    y_bead_in = y_arm_in - p.latch_bead_depth
    y_flare_out = y_arm_out + p.latch_flare_out

    for sign in (1.0, -1.0):
        # Latch arm + inward snap bead + outward finger-lift flare profile in YZ plane
        # Bridges smoothly onto the lid wall at Z = latch_arm_top_z (34.0) down to 22.0,
        # and hangs free from Z = 22.0 down to latch_arm_bottom_z (13.0).
        pts = [
            (sign * (y_out - 0.5), p.latch_arm_top_z),
            (sign * y_arm_out, p.latch_arm_top_z - 2.0),
            (sign * y_arm_out, p.latch_bead_z_min),
            (sign * y_flare_out, p.latch_arm_bottom_z + 1.0),
            (sign * (y_arm_out + 0.4), p.latch_arm_bottom_z),
            (sign * y_arm_in, p.latch_arm_bottom_z),
            (sign * y_arm_in, p.latch_bead_z_min - 1.0),
            (sign * y_bead_in, p.latch_bead_z_min),
            (sign * y_bead_in, p.latch_bead_z_max),
            (sign * y_arm_in, p.latch_bead_z_max + 1.0),
            (sign * y_arm_in, p.latch_arm_top_z - 2.0),
            (sign * (y_out - 0.5), p.latch_arm_top_z - 2.0),
        ]
        if sign < 0:
            pts = list(reversed(pts))
        arm_face = bd.Plane.YZ * bd.Polygon(pts, align=None)
        latch_arm = bd.extrude(arm_face, p.latch_width / 2.0, both=True)
        lid = lid + latch_arm

        # Cut vertical relief slots beside the latch arm AFTER fusing the arm
        for x_sign in (-1.0, 1.0):
            slot_x = x_sign * (p.latch_width / 2.0 + p.latch_slot_width / 2.0)
            relief_slot = bd.Pos(slot_x, sign * (y_out - 1.0), p.base_shoulder_z - 0.1) * bd.Box(
                p.latch_slot_width,
                4.0,
                p.latch_arm_top_z - p.base_shoulder_z + 0.1,
                align=(bd.Align.CENTER, bd.Align.CENTER, bd.Align.MIN),
            )
            lid = lid - relief_slot

    # Deboss FillaPrint labels on top face (Z = total_height)
    txt1 = bd.Text(
        p.label_primary_text,
        font_size=p.label_primary_size,
        font_path=p.font_path,
        align=(bd.Align.CENTER, bd.Align.CENTER),
    )
    txt2 = bd.Text(
        p.label_secondary_text,
        font_size=p.label_secondary_size,
        font_path=p.font_path,
        align=(bd.Align.CENTER, bd.Align.CENTER),
    )
    lbl1 = bd.Pos(-32.0, 0, p.total_height - p.label_depth) * bd.extrude(txt1, p.label_depth + 0.1)
    lbl2 = bd.Pos(24.0, 0, p.total_height - p.label_depth) * bd.extrude(txt2, p.label_depth + 0.1)
    lid = lid - lbl1 - lbl2

    return bd.Part(lid.wrapped)


def export_all(out_dir: Path, p: MailerParams) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    export_dir = out_dir / "exports"
    export_dir.mkdir(parents=True, exist_ok=True)

    base_asm = build_base(p)
    lid_asm = build_lid(p)

    # Print orientation:
    # - Base is already flat on Z=0 (identity transform)
    # - Lid is flipped 180 deg around X and translated by +total_height so its top face rests at Z=0
    base_print = base_asm
    lid_print = bd.Pos(0, 0, p.total_height) * bd.Rot(180, 0, 0) * lid_asm

    # Export STEP and binary STL per part (in print orientation)
    bd.export_step(base_print, str(export_dir / "ddr4_mailer_base.step"))
    bd.export_step(lid_print, str(export_dir / "ddr4_mailer_lid.step"))
    bd.export_stl(base_print, str(export_dir / "ddr4_mailer_base.stl"), ascii_format=False)
    bd.export_stl(lid_print, str(export_dir / "ddr4_mailer_lid.stl"), ascii_format=False)

    # Also export assembled STEP for convenience
    asm_compound = bd.Compound(children=[base_asm, lid_asm])
    bd.export_step(asm_compound, str(export_dir / "ddr4_mailer_assembled.step"))

    # Transform from print orientation back to assembled orientation:
    # For lid: first Rot(180, 0, 0) around X, then Pos(0, 0, total_height)
    # Matrix 4x4 for T(0,0,H) * Rx(180):
    # [1,  0,  0, 0]
    # [0, -1,  0, 0]
    # [0,  0, -1, H]
    # [0,  0,  0, 1]
    assembly = {
        "units": "mm",
        "coordinate_convention": "Z-up; base bottom centered at (0, 0, 0) in assembled frame",
        "supported_envelope_mm": {
            "max_module_length": p.max_module_length,
            "max_module_height": p.max_module_height,
            "max_module_thickness": p.max_module_thickness,
            "examples": [
                "JEDEC bare DDR4 UDIMM (133.35 x 31.25 x ~4.0 mm)",
                "Corsair Vengeance LPX (135.0 x 33.5 x 7.0 mm)",
                "Kingston FURY Beast (133.35 x 34.1 x 7.2 mm)",
                "Crucial Ballistix (133.35 x 39.17 x 7.2 mm)",
                "G.Skill Ripjaws V (133.35 x 42.0 x 7.0 mm)",
            ],
            "excluded_examples": [
                "Corsair Vengeance RGB Pro (~51 mm height)",
                "Corsair Dominator Platinum (~55 mm height)",
                "G.Skill Trident Z / Royal (~44 mm height)",
            ],
        },
        "parts": [
            {
                "name": "base",
                "step_file": "exports/ddr4_mailer_base.step",
                "stl_file": "exports/ddr4_mailer_base.stl",
                "print_orientation": "Bottom face on build plate (Z=0), slots facing up",
                "assembled_transform": {
                    "translation_mm": [0.0, 0.0, 0.0],
                    "rotation_xyz_deg": [0.0, 0.0, 0.0],
                    "matrix_4x4": [
                        [1.0, 0.0, 0.0, 0.0],
                        [0.0, 1.0, 0.0, 0.0],
                        [0.0, 0.0, 1.0, 0.0],
                        [0.0, 0.0, 0.0, 1.0],
                    ],
                },
            },
            {
                "name": "lid",
                "step_file": "exports/ddr4_mailer_lid.step",
                "stl_file": "exports/ddr4_mailer_lid.stl",
                "print_orientation": "Top face (with debossed labels) on build plate (Z=0), skirt facing up",
                "assembled_transform": {
                    "translation_mm": [0.0, 0.0, round(p.total_height, 4)],
                    "rotation_xyz_deg": [180.0, 0.0, 0.0],
                    "matrix_4x4": [
                        [1.0, 0.0, 0.0, 0.0],
                        [0.0, -1.0, 0.0, 0.0],
                        [0.0, 0.0, -1.0, round(p.total_height, 4)],
                        [0.0, 0.0, 0.0, 1.0],
                    ],
                },
            },
        ],
    }

    (out_dir / "assembly.json").write_text(json.dumps(assembly, indent=2) + "\n")
    print(f"Exported base, lid, assembled STEP, and assembly.json to {out_dir}")


if __name__ == "__main__":
    root = Path(__file__).resolve().parent.parent
    export_all(root, MailerParams())
