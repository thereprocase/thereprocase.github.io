# Dual DDR4 RAM Reusable Mailer

Compact, hardware-free, two-part 3D-printed mailer for shipping two desktop DDR4 UDIMM sticks—each in its own ESD shielding bag with light paper or foam padding—inside an outer cardboard shipping box.

## Supported Module Envelope

- **Supported bare/heatsinked module envelope**: up to **135.5 mm (L) × 42.5 mm (H) × 8.0 mm (T)**
- **Per-slot internal cavity**: **141.0 mm (L) × 10.8 mm (W) × 46.6 mm (H)** (allows ~5.5–7.6 mm length, ~2.8–3.6 mm thickness, and ~4.1–15.35 mm top height for folded ESD shielding bags and thin paper/foam shims)

| Module Example | Dimensions (L × H × T, mm) | Status | Top Z Clearance | Open Base Protrusion |
| :--- | :--- | :--- | :--- | :--- |
| JEDEC bare DDR4 UDIMM | 133.35 × 31.25 × 4.0 | Fits | +15.35 mm | +9.65 mm |
| Corsair Vengeance LPX | 135.0 × 33.5 × 7.0 | Fits | +13.10 mm | +11.90 mm |
| Kingston FURY Beast | 133.35 × 34.1 × 7.2 | Fits | +12.50 mm | +12.50 mm |
| Crucial Ballistix | 133.35 × 39.17 × 7.2 | Fits | +7.43 mm | +17.57 mm |
| G.Skill Ripjaws V | 133.35 × 42.0 × 7.0 | Fits | +4.60 mm | +20.40 mm |
| **Max Supported Envelope** | **135.5 × 42.5 × 8.0** | **Fits** | **+4.10 mm** | **+20.90 mm** |
| Corsair Vengeance RGB Pro | 133.35 × 51.0 × 7.5 | Excluded | -4.40 mm | — |

Tall RGB/enthusiast modules (e.g. Corsair Vengeance RGB Pro ~51 mm, Dominator Platinum ~55 mm, G.Skill Trident Z ~44 mm) are intentionally excluded to keep the outer box compact (**147.0 × 37.2 × 54.5 mm** including latch flares; **147.0 × 30.0 × 54.5 mm** main body).

## Key Design Decisions

- **Gold-Contact Protection**: Each slot has **9.0 mm** raised end pedestals (`Z = 5.40 mm`) and a **123.0 mm** central recessed channel (`Z = 2.40 mm`), creating a **3.00 mm** air/padding gap beneath the 288-pin gold edge connector so rigid plastic never presses on the contacts.
- **Lid Retention & Easy Reopening**: A **5.0 mm** stepped perimeter alignment tongue (`0.200 mm` radial clearance) prevents lateral shear, while two centered compliant side snap-latches (`24.0 mm` wide, `1.6 mm` thick, `18.0 mm` cantilever, `1.0 mm` snap bead, `0.74%` max bending strain) click into `45°`-ramped grooves on the base. Pinch/spread the flared finger-lift lips outward to open without tools or hardware.
- **Easy Extraction**: The base tray walls rise `16.6 mm` above the pedestals (`21.6 mm` at the alignment tongue), leaving **9.65–20.90 mm** of every supported stick protruding above the rim when the lid is removed for easy finger-pinch removal. An **8.0 mm** divider rib in the lid ceiling keeps bagged modules separated if inverted in transit.
- **FillaPrint Labels**: Debossed `0.60 mm` deep using `assets/fillaprint/Fillaprint-Regular.ttf`:
  - Lid top: `2x DDR4` (`font_size=12.0`, 8.40 mm cap height) and `MAX 135x42.5x8` (`font_size=8.5`, 5.95 mm cap height)
  - Base bottom: `ESD BAG + FOAM` (`font_size=8.5`, 5.95 mm cap height)

## Files & Printing

- `cad/params.py` — Parametric dimensions and envelope definitions
- `cad/build_mailer.py` — `build123d` CAD generator
- `verify/verify_mailer.py` — Mesh, clearance, fit, strain, and label verification
- `exports/ddr4_mailer_base.step`, `exports/ddr4_mailer_base.stl` — Base (print flat on bottom face, no supports)
- `exports/ddr4_mailer_lid.step`, `exports/ddr4_mailer_lid.stl` — Lid (print upside-down with top face on build plate, no supports)
- `exports/ddr4_mailer_assembled.step` — Combined assembled STEP
- `assembly.json` — Part file paths and 4×4 assembled transforms in millimeters

Recommended material: PETG or PLA, 0.2 mm layer height, 0.4 mm nozzle, 3–4 perimeters, no supports.

## Verification & Physical-Test Limitations

All automated checks in `verify/verify_mailer.py` pass (`base` and `lid` binary STLs watertight, `0.0000 mm` assembled penetration, `0.200 mm` tongue radial clearance, `3.00 mm` pin relief gap, `0.74%` latch strain, `0.60 mm` label deboss).

**Still requires physical print testing**:
1. Snap-latch retention force and finger-release feel on your specific printer/filament (0.200 mm radial and 0.4 mm groove clearances may need slight tuning depending on extrusion flow).
2. Fit with your exact ESD bag fold bulk and paper/foam wrap thickness inside the `10.8 mm × 141.0 mm × 46.6 mm` slot.
3. First-layer bridging/legibility of the `0.60 mm` debossed FillaPrint labels on the lid top face.
