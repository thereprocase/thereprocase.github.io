"""
Parametric CAD model for a compact, rigid 2-module DDR4 UDIMM shipping case.
Designed for same-day printing on a Bambu Lab P1S (no supports required)
and packing inside a standard padded mailer with ESD wrap and tape retention.

Parts generated:
1. case_base: Rigid protective tray with dual module bays, edge-rail support ledges
   (supporting only the component-free 3.0 mm left/right PCB margins and 1.25 mm
   bottom/top margins), anti-crush center divider, finger extraction cutouts,
   interlocking perimeter alignment lip, and outer tape-retention grooves.
2. case_lid: Interlocking protective cover with mating alignment recess, top edge-rail
   hold-downs, center bridge support, and matching outer tape-retention grooves.
3. Closed / packed assembly model (including reference DDR4 UDIMM envelopes) for
   clearance and interference verification.
"""

import json
from pathlib import Path
from build123d import (
    Align,
    Axis,
    Box,
    Compound,
    Part,
    chamfer,
    export_step,
    export_stl,
    fillet,
)


# ---------------------------------------------------------------------------
# Parametric Configuration (all dimensions in mm)
# ---------------------------------------------------------------------------
PARAMS = {
    # JEDEC MO-309 Desktop DDR4 UDIMM nominal & prototype envelope
    "dimm_length_nom": 133.35,
    "dimm_height_nom": 31.25,
    "dimm_pcb_thickness": 1.27,
    # Prototype + ESD bag pocket clearances
    "bay_length": 137.0,          # 133.35 mm + ~1.8 mm clearance per end for ESD bag fold
    "bay_width": 35.0,            # 31.25 mm + ~1.875 mm clearance per side for ESD bag
    "bay_total_depth": 10.0,      # Accommodates dual-sided ICs + ESD bag up to 9.0 mm thick
    # Edge-only retention rail dimensions (keeps IC area completely untouched)
    "end_rail_support": 2.4,      # Contacts only outer ~0.6-2.4 mm of 3.0 mm JEDEC free end zone
    "side_rail_support": 1.2,     # Contacts only outer 1.2 mm of bottom/top edges
    "rail_pocket_height": 4.4,    # Height of the ESD-wrapped PCB edge slot between top/bottom ledges
    "ic_relief_depth_each": 5.0,  # Full pocket depth in base and lid over IC component area
    # Structural enclosure parameters
    "outer_wall": 3.0,            # Rigid perimeter wall against mailer crushing
    "center_divider": 3.0,        # Central rib preventing bending and module-to-module impact
    "floor_ceil_thickness": 2.4,  # Top and bottom armor shell thickness
    # Interlocking alignment lip between base and lid
    "lip_thickness": 1.3,
    "lip_height": 2.2,
    "lip_radial_clearance": 0.20, # 0.20 mm per side slip-fit for FDM printing
    "lip_axial_clearance": 0.30,
    # Ergonomics & Packing Features
    "finger_scoop_length": 26.0,  # Central finger access notch along long sides
    "tape_groove_width": 16.0,    # Recessed channels for 12-15 mm strapping/Kapton/packing tape
    "tape_groove_depth": 0.6,
    "tape_groove_offset_x": 38.0, # Distance from center (+/- X) for dual tape bands
    "corner_radius": 4.0,
    "outer_chamfer": 0.8,
}


def compute_derived_dimensions(p: dict) -> dict:
    """Compute overall enclosure dimensions and key coordinates from parameters."""
    d = dict(p)
    # 2 bays side-by-side along Y
    d["outer_length"] = p["bay_length"] + 2 * p["outer_wall"]  # 137 + 6 = 143.0 mm
    d["outer_width"] = 2 * p["bay_width"] + p["center_divider"] + 2 * p["outer_wall"]  # 70 + 3 + 6 = 79.0 mm
    d["half_height"] = p["floor_ceil_thickness"] + p["ic_relief_depth_each"]  # 2.4 + 5.0 = 7.4 mm
    d["total_closed_height"] = 2 * d["half_height"]  # 14.8 mm (< 15 mm for compact mailers)

    # Y centers of the two bays
    bay_y_offset = (p["center_divider"] + p["bay_width"]) / 2.0  # (3 + 35) / 2 = 19.0 mm
    d["bay_y_centers"] = [-bay_y_offset, bay_y_offset]

    # Ledge depth from split plane (Z = half_height in local part coordinates)
    # Total slot height across base + lid is rail_pocket_height (4.4 mm), so 2.2 mm per half
    d["rail_half_slot"] = p["rail_pocket_height"] / 2.0  # 2.2 mm recess from split plane
    return d


def rounded_box(length: float, width: float, height: float, radius: float, align_z=Align.MIN) -> Part:
    """Create a Z-aligned box with filleted vertical corners."""
    b = Box(length, width, height, align=(Align.CENTER, Align.CENTER, align_z))
    if radius > 0:
        b = fillet(b.edges().filter_by(Axis.Z), radius=radius)
    return b


def build_half_shell(d: dict, is_lid: bool = False) -> Part:
    """
    Build either the case_base (is_lid=False) or case_lid (is_lid=True) in its
    native print-flat orientation (outer flat face at Z=0, split plane at Z=half_height).
    """
    L = d["outer_length"]
    W = d["outer_width"]
    H = d["half_height"]
    wall = d["outer_wall"]
    bay_L = d["bay_length"]
    bay_W = d["bay_width"]
    ic_depth = d["ic_relief_depth_each"]
    slot_depth = d["rail_half_slot"]
    end_sup = d["end_rail_support"]
    side_sup = d["side_rail_support"]

    lip_h = d["lip_height"]
    lip_t = d["lip_thickness"]
    c_rad = d["lip_radial_clearance"]
    c_ax = d["lip_axial_clearance"]

    # 1. Main outer block (Z from 0 to H)
    part = rounded_box(L, W, H, d["corner_radius"], align_z=Align.MIN)
    # Chamfer the bottom exterior perimeter (print bed face Z=0) for clean first layer & easy mailer insertion
    bottom_edges = part.edges().group_by(Axis.Z)[0]
    part = chamfer(bottom_edges, length=d["outer_chamfer"])

    # 2. Interlocking perimeter alignment lip at Z = H
    if not is_lid:
        # Base gets a raised inner perimeter lip extending from Z = H to Z = H + lip_h
        inset = wall - lip_t
        lip_outer = rounded_box(
            L - 2 * inset,
            W - 2 * inset,
            lip_h,
            max(1.0, d["corner_radius"] - inset),
        ).translate((0, 0, H))
        lip_inner = rounded_box(
            L - 2 * wall,
            W - 2 * wall,
            lip_h + 0.2,
            max(0.5, d["corner_radius"] - wall),
        ).translate((0, 0, H - 0.1))
        part = part + (lip_outer - lip_inner)
    else:
        # Lid gets a mating perimeter step recess from Z = H - (lip_h + c_ax) to Z = H
        recess_inset = wall - lip_t - c_rad
        recess_depth = lip_h + c_ax
        recess_box = rounded_box(
            L - 2 * recess_inset,
            W - 2 * recess_inset,
            recess_depth + 0.2,
            max(1.0, d["corner_radius"] - recess_inset),
        ).translate((0, 0, H - recess_depth))
        part = part - recess_box

    # 3. Dual DDR4 Module Bays
    for y_c in d["bay_y_centers"]:
        # 3a. Full-width/length PCB edge-slot pocket (depth = slot_depth from Z=H)
        # Creates the perimeter support shelf at Z = H - slot_depth around all 4 edges of the bay.
        top_cut_z = H - slot_depth
        cut_h_slot = (H + lip_h + 1.0) - top_cut_z
        slot_cut = Box(
            bay_L,
            bay_W,
            cut_h_slot,
            align=(Align.CENTER, Align.CENTER, Align.MIN),
        ).translate((0, y_c, top_cut_z))
        part = part - slot_cut

        # 3b. Deep IC & Component Relief Pocket (depth = ic_depth from Z=H)
        # Inset from the bay walls by end_sup (along X) and side_sup (along Y)
        # so the PCB is supported ONLY by its component-free perimeter edge rails!
        ic_L = bay_L - 2 * end_sup
        ic_W = bay_W - 2 * side_sup
        top_ic_z = H - ic_depth
        cut_h_ic = (H + lip_h + 1.0) - top_ic_z
        ic_cut = rounded_box(ic_L, ic_W, cut_h_ic, radius=1.5).translate((0, y_c, top_ic_z))
        part = part - ic_cut

        # 3c. Finger extraction relief cutouts in the side support ledges at X = 0
        # Allows easy two-finger pinching of the ESD-wrapped module edges at the center without touching ICs
        scoop_cut = rounded_box(
            d["finger_scoop_length"],
            bay_W + 1.2,
            cut_h_ic,
            radius=3.0,
        ).translate((0, y_c, top_ic_z))
        part = part - scoop_cut

        # 4. Exterior Tape-Retention Grooves (two bands at X = +/- tape_groove_offset_x)
    # Shallow recessed tracks on the outer skin (Z=0) and long side walls (Y = +/- W/2)
    # with 45-degree chamfered entry ramps so they print flat on the bed with zero overhang.
    tg_w = d["tape_groove_width"]
    tg_d = d["tape_groove_depth"]
    for x_pos in (-d["tape_groove_offset_x"], d["tape_groove_offset_x"]):
        # Outer bottom/top skin groove (at Z = 0) with 45-deg chamfer on its two top X-edges
        skin_groove = Box(tg_w, W + 2.0, tg_d, align=(Align.CENTER, Align.CENTER, Align.MIN)).translate(
            (x_pos, 0, 0)
        )
        top_y_edges = skin_groove.edges().filter_by(Axis.Y).group_by(Axis.Z)[-1]
        skin_groove = chamfer(top_y_edges, length=tg_d * 0.95)

        # Side wall grooves (at Y = -W/2 and Y = +W/2)
        side_groove_neg = Box(
            tg_w, tg_d, H + 1.0, align=(Align.CENTER, Align.MIN, Align.MIN)
        ).translate((x_pos, -W / 2.0, 0))
        side_groove_pos = Box(
            tg_w, tg_d, H + 1.0, align=(Align.CENTER, Align.MAX, Align.MIN)
        ).translate((x_pos, W / 2.0, 0))
        part = part - skin_groove - side_groove_neg - side_groove_pos

    # 5. Fingernail / coin split slots at the two short ends (X = +/- L/2) at Z = H
    for x_sign in (-1, 1):
        pry_slot = Box(
            1.8, 22.0, 1.6, align=(Align.CENTER, Align.CENTER, Align.MIN)
        ).translate((x_sign * (L / 2.0), 0, H - 0.8))
        part = part - pry_slot

    return part


def build_reference_ddr4_dimm(d: dict) -> Part:
    """
    Build a representative JEDEC DDR4 UDIMM assembly envelope (133.35 x 31.25 mm PCB
    with dual-sided IC packages leaving the 3.0 mm end margins and 2.5 mm top/bottom
    edge margins clear) to verify zero interference in the closed assembly.
    """
    pcb_L = d["dimm_length_nom"]
    pcb_W = d["dimm_height_nom"]
    pcb_T = d["dimm_pcb_thickness"]
    # Dual-sided IC package envelope: 127.35 mm long (leaves 3.0 mm free at each end),
    # 25.0 mm tall (leaves 3.125 mm free at top/bottom edges), total thickness 4.2 mm
    ic_env_L = pcb_L - 6.0
    ic_env_W = pcb_W - 6.25
    ic_total_T = 4.2

    pcb = Box(pcb_L, pcb_W, pcb_T, align=(Align.CENTER, Align.CENTER, Align.CENTER))
    ics = Box(ic_env_L, ic_env_W, ic_total_T, align=(Align.CENTER, Align.CENTER, Align.CENTER))
    return pcb + ics


def main():
    out_dir = Path(__file__).resolve().parent
    d = compute_derived_dimensions(PARAMS)

    # 1. Build printable parts in their print-flat orientation (Z=0 on build plate)
    case_base = build_half_shell(d, is_lid=False)
    case_base.label = "case_base"

    case_lid = build_half_shell(d, is_lid=True)
    case_lid.label = "case_lid"

    # 2. Export individual STEP and binary STL files (print-ready orientation)
    export_step(case_base, str(out_dir / "case_base.step"))
    export_stl(case_base, str(out_dir / "case_base.stl"))

    export_step(case_lid, str(out_dir / "case_lid.step"))
    export_stl(case_lid, str(out_dir / "case_lid.stl"))

    # 3. Construct closed / packed assembly:
    # - case_base sits at origin (Z = 0 to Z = 7.4 mm, lip up to Z = 9.6 mm)
    # - case_lid is rotated 180 deg around X axis and translated to Z = total_closed_height (14.8 mm)
    #   so its parting plane meets case_base at Z = 7.4 mm.
    H_half = d["half_height"]
    H_total = d["total_closed_height"]

    lid_closed = case_lid.rotate(Axis.X, 180).translate((0, 0, H_total))
    lid_closed.label = "case_lid_closed"

    dimm_ref = build_reference_ddr4_dimm(d)
    dimm_1 = dimm_ref.translate((0, d["bay_y_centers"][0], H_half))
    dimm_1.label = "ddr4_udimm_prototype_1"
    dimm_2 = dimm_ref.translate((0, d["bay_y_centers"][1], H_half))
    dimm_2.label = "ddr4_udimm_prototype_2"

    closed_case_compound = Compound(label="ddr4_shipping_case_closed", children=[case_base, lid_closed])
    packed_assembly_compound = Compound(
        label="ddr4_shipping_case_packed_assembly",
        children=[case_base, lid_closed, dimm_1, dimm_2],
    )

    export_step(closed_case_compound, str(out_dir / "assembly_closed.step"))
    export_step(packed_assembly_compound, str(out_dir / "assembly_packed_with_dimms.step"))

    # Save an explicit assembly placement JSON file
    assembly_info = {
        "units": "mm",
        "overall_closed_dimensions_mm": {
            "length_X": d["outer_length"],
            "width_Y": d["outer_width"],
            "height_Z": d["total_closed_height"],
        },
        "bambu_p1s_print_layout": {
            "build_volume_mm": [256, 256, 256],
            "supports_required": False,
            "parts_on_single_plate": [
                {
                    "part": "case_base",
                    "step_file": "case_base.step",
                    "stl_file": "case_base.stl",
                    "print_orientation": "Flat on outer bottom face (Z=0 on bed), cavity facing +Z",
                    "plate_placement_center_xyz_mm": [0.0, -45.0, 0.0],
                    "bounding_box_mm": [d["outer_length"], d["outer_width"], round(d["half_height"] + d["lip_height"], 3)],
                },
                {
                    "part": "case_lid",
                    "step_file": "case_lid.step",
                    "stl_file": "case_lid.stl",
                    "print_orientation": "Flat on outer top face (Z=0 on bed), cavity facing +Z",
                    "plate_placement_center_xyz_mm": [0.0, 45.0, 0.0],
                    "bounding_box_mm": [d["outer_length"], d["outer_width"], d["half_height"]],
                },
            ],
            "combined_plate_footprint_mm": [d["outer_length"], 2 * d["outer_width"] + 11.0],
        },
        "closed_assembly_placement": {
            "parting_plane_z_mm": H_half,
            "components": [
                {
                    "name": "case_base",
                    "source_file": "case_base.step",
                    "rotation_euler_xyz_deg": [0.0, 0.0, 0.0],
                    "translation_xyz_mm": [0.0, 0.0, 0.0],
                },
                {
                    "name": "case_lid",
                    "source_file": "case_lid.step",
                    "rotation_euler_xyz_deg": [180.0, 0.0, 0.0],
                    "translation_xyz_mm": [0.0, 0.0, H_total],
                },
                {
                    "name": "ddr4_udimm_prototype_1 (in ESD sleeve)",
                    "nominal_dimensions_mm": [d["dimm_length_nom"], d["dimm_height_nom"], 4.2],
                    "rotation_euler_xyz_deg": [0.0, 0.0, 0.0],
                    "translation_xyz_mm": [0.0, d["bay_y_centers"][0], H_half],
                },
                {
                    "name": "ddr4_udimm_prototype_2 (in ESD sleeve)",
                    "nominal_dimensions_mm": [d["dimm_length_nom"], d["dimm_height_nom"], 4.2],
                    "rotation_euler_xyz_deg": [0.0, 0.0, 0.0],
                    "translation_xyz_mm": [0.0, d["bay_y_centers"][1], H_half],
                },
            ],
        },
        "design_parameters": d,
    }

    with open(out_dir / "assembly_placement.json", "w", encoding="utf-8") as f:
        json.dump(assembly_info, f, indent=2)

    # Boolean interference check in CAD kernel
    def intersection_volume(a: Part, b: Part) -> float:
        inter = a.intersect(b)
        if inter is None:
            return 0.0
        if isinstance(inter, list):
            return sum(s.volume for s in inter)
        return inter.volume

    inter_vol_base_lid = intersection_volume(case_base, lid_closed)
    inter_vol_dimm1 = intersection_volume(case_base, dimm_1) + intersection_volume(lid_closed, dimm_1)
    inter_vol_dimm2 = intersection_volume(case_base, dimm_2) + intersection_volume(lid_closed, dimm_2)

    print("=== CAD Generation & Kernel Verification Summary ===")
    print(f"case_base volume: {case_base.volume:.2f} mm^3, bbox: {case_base.bounding_box()}")
    print(f"case_lid  volume: {case_lid.volume:.2f} mm^3, bbox: {case_lid.bounding_box()}")
    print(f"Closed assembly overall size: {d['outer_length']} x {d['outer_width']} x {H_total} mm")
    print(f"Interference volume (case_base vs case_lid_closed): {inter_vol_base_lid:.6f} mm^3")
    print(f"Interference volume (case vs DDR4 prototype 1): {inter_vol_dimm1:.6f} mm^3")
    print(f"Interference volume (case vs DDR4 prototype 2): {inter_vol_dimm2:.6f} mm^3")


if __name__ == "__main__":
    main()
