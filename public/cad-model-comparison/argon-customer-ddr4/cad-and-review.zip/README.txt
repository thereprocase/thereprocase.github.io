CAD prototype from a customer-brief design exercise. Read independent-review.json before using the geometry. Fit, bridge behavior, tape retention, and loaded transport require physical validation.
