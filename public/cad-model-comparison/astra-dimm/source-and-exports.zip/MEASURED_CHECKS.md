# Measured checks

All figures below describe the final generated geometry. No physical measurements were made. Millimeters throughout; intersection volumes in mm³. Values below 1e-6 mm³ are treated as zero.

| Check | Result |
|---|---|
| Assembled envelope | 154 × 102 × 20 mm |
| Separate pockets | Each 141 × 45 mm; floor Z=2, supports Z=4 |
| Packed gauges | Two 140 × 44 × 10 mm boxes, both with 0 tray/lid intersection |
| Headroom above packed gauges | 1.35 mm |
| Contact protection | First 8 mm of module height clears tray; 1.5 mm lateral margin to support pads; floor recessed 2 mm below support tops |
| Closed tray/lid intersection | 0 mm³, including re-imported STEP geometry |
| Straight upward packed-module extraction | 40 mm-tall swept volumes: 0 intersection in either pocket, lid removed |
| Rigid lid sliding portion | 0 intersection at offsets 0, −1, −3, −6, −12, −30, −75, −155 mm |
| Released tooth sliding | 0 intersection at the same offsets with 1.5 mm inward release |
| Locked lid pulled −1.1 mm | 0.220 mm³ interference at catch; positive geometric retention |
| Lid lifted directly +1 mm | 378.067 mm³ interference with rails; lift-off is geometrically blocked |
| Lid/channel nominal clearance | 0.30 mm each side; 0.35 mm above and below plate |
| Rail capture overlap | 2.2 mm each side, excluding exposed latch area |
| Latch slot | 1.8 mm wide; 0.3 mm nominal reserve after 1.5 mm release |
| Thumb cap clearance over exposed channel wall | 0.35 mm vertically |
| Text | Supplied Fillaprint, 9 mm em, measured 6.3 mm capitals, nominal 0.9 mm strokes, 0.5 mm engraving |

## Export integrity

| Part | STEP solids / valid | CAD volume mm³ | STL triangles | STL volume mm³ | Mesh |
|---|---|---:|---:|---:|---|
| tray | 1 / yes | 79139.742 | 12000 | 79139.476 | Binary, watertight, consistent winding, one component |
| lid | 1 / yes | 32265.102 | 15960 | 32265.095 | Binary, watertight, consistent winding, one component |

STEP round-trip volume differences are below 0.000001 mm³. STL curved surfaces are tessellated at 0.025 mm tolerance; small volume differences are expected. SHA-256 hashes are in `output/mesh_checks.json`. `assembly.json` locates the lid at Z=15.35 mm; the separate STL and STEP lid remains flat at Z=0 for printing.

## Limits of these checks

The slide tests sample rigid geometry and a translated tooth. They do not simulate elastic deformation, friction, layer adhesion or wear. The 1.5 mm displacement and 32 × 3.2 mm beam give approximately 0.703% idealized surface bending strain using 3tδ/(2L²); stress concentration and anisotropy are not included. Positive CAD interference establishes a catch, not its holding force.

Module/bag gauges are conservative bounding boxes, not scans of products. The supported contact band and loading position require proper padding: loose modules could migrate. Check actual heatspreader contact with the beveled supports, bag folds, sling access, shake/rattle, latch force and cycles, and packaged drop/crush behavior before use. A tray and lid passing these checks are still an untested physical prototype.
