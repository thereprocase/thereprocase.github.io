"""Re-import the delivered STEP parts and verify assembly and removal clearance."""
from pathlib import Path
import json
from build123d import *
R=Path(__file__).resolve().parent
C=json.loads((R/'output/cad_checks.json').read_text());P=C['parameters']
A=json.loads((R/'assembly.json').read_text())
tray=import_step(R/'output/tray.step');lid=import_step(R/'output/lid.step')
def vol(s):return sum(x.volume for x in s.solids()) if s else 0
z=A['parts'][1]['transform'][2][3]
assembled=Pos(0,0,z)*lid
result={'step_reimport':{},'assembly_collision_mm3':vol(tray & assembled),'lift_without_sliding_collision_mm3':vol(tray & (Pos(0,0,z+1)*lid)),'vertical_extraction':[]}
for n,s in [('tray',tray),('lid',lid)]:
 result['step_reimport'][n]={'valid':s.is_valid,'solids':len(s.solids()),'volume_mm3':s.volume,'volume_difference_mm3':s.volume-C['parts'][n]['volume_mm3']}
 assert s.is_valid and len(s.solids())==1
 assert abs(result['step_reimport'][n]['volume_difference_mm3'])<.01
bl=P['module_length']+P['bag_length_allowance'];bw=P['module_height']+P['bag_height_allowance']
for y in [P['side_wall'],P['side_wall']+bw+P['divider']]:
 # Sweep a packed 140 x 44 x 10 gauge straight up through the full opening.
 swept=Pos(P['front_apron']+.5,y+.5,P['floor']+P['support_rise'])*Box(bl-1,bw-1,40,align=(Align.MIN,Align.MIN,Align.MIN))
 v=vol(tray & swept);result['vertical_extraction'].append({'pocket_y_mm':y,'swept_height_mm':40,'collision_mm3':v});assert v<1e-6
assert result['assembly_collision_mm3']<1e-6
assert result['lift_without_sliding_collision_mm3']>0
(R/'output/step_checks.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
