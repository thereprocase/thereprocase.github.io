# Two-DIMM mailer

A reusable, two-part sliding case, **154 × 102 × 20 mm assembled**. Each stick lies flat in a separate pocket. Use it inside a cushioned corrugated shipping box; this printed case is neither an ESD shielding enclosure nor a qualified shipping package.

## What fits

Supported **bare module envelope: up to 135 mm long × 40 mm tall × 8.5 mm thick**, including the heatspreader. Intended for ordinary desktop DDR4 UDIMMs roughly 33–40 mm tall with load-bearing heatspreader faces. This does not imply every module within the bounding box has suitable support geometry.

| Manufacturer example | Length × height × thickness | Assessment |
|---|---|---|
| Kingston FURY Beast KF432C16BB/16 | 133.35 × 34 × 7.2 mm | Within envelope |
| HyperX FURY HX432C16FB3/16 | 133.35 × 34.1 × 7.2 mm | Within envelope |
| Kingston FURY Beast RGB KF432C16BBA/16 | 133.35 × 41.2 × 7.2 mm | Outside supported height; not supported |

These dimensions come from the manufacturers' drawings, not measurements of physical sticks: [Beast](https://www.kingston.com/datasheets/KF432C16BB_16.pdf), [HyperX FURY](https://www.kingston.com/datasheets/HX432C16FB3_16.pdf), [Beast RGB](https://www.kingston.com/datasheets/KF432C16BBA_16.pdf). Copies are in `research/`. The 40 mm limit preserves bag/padding clearance instead of consuming that clearance to fit taller RGB modules. Other models must be measured, including end protrusions.

Each pocket is 141 × 45 mm. **Each closed bag, module and initial padding must fit within 140 × 44 × 10 mm.** Bag seams and folded closures count. Use thin shielding bags with a closure that can meet this envelope; bulky zip sliders are unsuitable. Fold excess over the heatspreader, following the bag manufacturer's closure instructions. Bag fit has not been physically tested.

## Loading and opening

1. With the lid off, lay one approximately 20 × 140 mm paper lifting strip across each pocket, centered along the module's length. Leave two tails accessible. These are disposable lifting aids, not additional printed parts.
2. Close each module in its own ESD shielding bag. Place the gold-contact edge over the floor label **CONTACTS** in each pocket. Both modules face the same direction. Raised pads support the broad heatspreader face; inspect that no pad bears on exposed components. Pads occupy two 25 mm-long regions, 20–45 and 96–121 mm from the pocket's left end, and 12–34 mm from its contact-side wall.
3. Adjust loose nonabrasive paper or ESD-compatible foam at the heatspreader spine and ends to locate the stick and suppress rattle. Keep the contact lane empty. Fold sling tails onto the spreader face. The 10 mm packed stack leaves 1.35 mm to the lid for a light top pad if needed; never force the lid over packing or preload the PCB.
4. Insert the lid at the short end with the exposed thumb tab and slide toward the rear stop. Its ramped tooth should click into the side-wall pocket. Gently pull back to confirm engagement.
5. To open, push the raised tab sideways toward **PUSH** (+Y), about 1.5 mm, and slide the lid in the **SLIDE** arrow direction (−X). Release the tab after about 12 mm of travel, then withdraw the lid completely. Allow about 155 mm of clear space beyond the opening. Lift both sling tails together to remove each bagged stick; grasp the heatspreader through the bag, never the contacts.

## Closure and manufacture

The rails overlap the lid by 2.2 mm on each side and prevent direct lifting. A 32 × 3.2 mm integral in-plane cantilever carries a 1 mm-engagement tooth. A square opening face retains the lid; the opposite ramp deflects it during insertion. The rear wall provides a positive closing stop. There are no loose catches, screws or magnets. Rounded plan corners, perimeter bevels and beveled support pads ease handling.

Prototype in **PETG**, both parts flat as supplied, at 0.20 mm layers with a 0.4 mm nozzle / approximately 0.45 mm line width. Use at least four walls and sufficient solid top/bottom layers; keep the latch solid. These are proposed settings, not a sliced or tested profile. The short rail overhangs need a print-quality check. Remove strings and burrs from rails, slot and bag-contact surfaces. Do not scale the STL to tune fit; change source clearances.

All text uses the supplied **Fillaprint-Regular.ttf**. Its embedded specification gives em = 20 line widths and cap height = 14 line widths. At the chosen 9 mm em, capitals are **6.3 mm high**, with **0.9 mm strokes**, satisfying its two-bead rule at 0.45 mm line width. Labels are engraved 0.5 mm; the font and OFL license are included unchanged.

## Files and validation

- `design.py`: parametric build123d source; edit `Parameters`, regenerate and rerun checks. Support/latch layout assumes the stated class of modules; arbitrary resizing needs renewed engineering review.
- `output/tray.step`, `output/lid.step`: individual solids; matching `.stl` files are binary, in flat print coordinates.
- `output/assembled.step`: assembled geometry. `assembly.json` gives actual file-to-assembly matrices in millimeters: tray identity, lid translated +15.35 mm in Z.
- `MEASURED_CHECKS.md` and `output/*checks.json`: measured geometry and mesh results. `verify_cad.py` and `verify_mesh.py` reproduce independent export checks.

Rebuild from this directory:

```sh
python design.py
python verify_cad.py
python verify_mesh.py
```

**Physical tests still required:** actual module/bag/padding and sling handling; printed rail clearance and warping; thumb force, positive click, unintended opening and repeated latch cycling; bag abrasion; rattle with ordinary and maximum-size modules; and shock/crush/drop behavior inside the intended outer box. The approximately 0.70% idealized latch bending strain is an estimate, not fatigue or force validation. No printing, slicing, physical testing or shipping certification was performed.
