"""Independent binary STL checks using the supplied trimesh runtime."""
from pathlib import Path
import json, struct, hashlib
import trimesh
R=Path(__file__).resolve().parent
report={}
for n in ['tray','lid']:
 p=R/'output'/f'{n}.stl'; raw=p.read_bytes()
 count=struct.unpack('<I',raw[80:84])[0]
 m=trimesh.load_mesh(p,process=True)
 components=m.split(only_watertight=False)
 report[n]={'binary_stl':len(raw)==84+50*count,'triangles':count,'watertight':bool(m.is_watertight),'winding_consistent':bool(m.is_winding_consistent),'connected_components':len(components),'positive_volume':bool(m.volume>0),'volume_mm3':float(m.volume),'bounds_mm':m.bounds.tolist(),'sha256':hashlib.sha256(raw).hexdigest()}
 assert all(report[n][v] for v in ['binary_stl','watertight','winding_consistent','positive_volume'])
 assert len(components)==1
(R/'output'/'mesh_checks.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
