"""Reusable two-DIMM mailer. Millimeters. Run with build123d 0.13.
All exported part coordinates are print coordinates; assembly.json places lid.
"""
from pathlib import Path
import json, math
from dataclasses import dataclass, asdict
from build123d import *

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'output'; OUT.mkdir(exist_ok=True)
FONT = ROOT/'assets/fillaprint/Fillaprint-Regular.ttf'
@dataclass
class Parameters:
    module_length: float = 135
    module_height: float = 40
    module_thickness: float = 8.5
    bag_length_allowance: float = 6
    bag_height_allowance: float = 5
    end_wall: float = 3
    front_apron: float = 10
    side_wall: float = 4.5
    divider: float = 3
    floor: float = 2
    support_rise: float = 2
    cavity_top: float = 15
    groove_bottom: float = 15
    groove_height: float = 2.9
    rail_top: float = 20
    lid_thickness: float = 2.2
    lid_z: float = 15.35
    slide_clearance: float = .3
    font_em: float = 9  # actual cap 6.3; two-bead stroke .9 at line width .45
    label_depth: float = .5
    beam_length: float = 32
    beam_width: float = 3.2
    latch_release: float = 1.5
P=Parameters()
BL=P.module_length+P.bag_length_allowance
BW=P.module_height+P.bag_height_allowance
L=P.front_apron+BL+P.end_wall
W=2*P.side_wall+2*BW+P.divider
YS=[P.side_wall,P.side_wall+BW+P.divider]

def box(x,y,z,dx,dy,dz):
    return Pos(x,y,z)*Box(dx,dy,dz,align=(Align.MIN,Align.MIN,Align.MIN))
def rr(x,y,z,dx,dy,dz,r):
    return Pos(x+dx/2,y+dy/2,z)*extrude(RectangleRounded(dx,dy,r),amount=dz)
labels=[]
def engrave(s,word,x,y,z):
    sk=Text(word,font_size=P.font_em,font_path=str(FONT))
    bb=sk.bounding_box()
    sk=Pos(x-(bb.min.X+bb.max.X)/2,y-(bb.min.Y+bb.max.Y)/2,z-P.label_depth)*sk
    labels.append({'text':word,'cap_height_mm':bb.size.Y,'em_mm':P.font_em,'stroke_mm':.1*P.font_em,'depth_mm':P.label_depth,'center_xy':[x,y]})
    return s-extrude(sk,amount=P.label_depth+.05)

# Full shell; open rectangular pockets with rounded bag-safe inside corners.
tray=rr(0,0,0,L,W,P.rail_top,3)
tray=chamfer(tray.edges().group_by(Axis.Z)[0]+tray.edges().group_by(Axis.Z)[-1],length=.5)
for y in YS:
    tray-=rr(P.front_apron,y,P.floor,BL,BW,P.rail_top,1.5)
# Inner walls terminate below lid; back wall remains a positive slide stop.
tray-=box(-1,4.1,P.cavity_top,L-P.end_wall+1,W-8.2,10)
# Long straight channels capture the lid edges; 0.35 mm each vertical face.
tray-=box(-1,1.6,P.groove_bottom,L-P.end_wall+1,W-3.2,P.groove_height)
# Expose latch to thumb, leaving solid outer channel wall below it.
tray-=box(-1,-1,P.groove_bottom+P.groove_height,34,9,5)
# Detent pocket in left channel wall, 0.5 mm residual outer wall.
tray-=box(4.5,.5,P.groove_bottom,6.5,2,P.groove_height)
for y in YS:
    for x in [P.front_apron+20,P.front_apron+BL-45]:
        pad=rr(x,y+12,P.floor,25,22,P.support_rise,2)
        pad=chamfer(pad.edges().group_by(Axis.Z)[-1],length=.5)
        tray+=pad
    tray=engrave(tray,'CONTACTS',P.front_apron+BL/2,y+5.8,P.floor)
# Shallow center-divider finger access, open when lid removed.
tray-=rr(P.front_apron+BL/2-16,YS[0]+BW-1,7,32,P.divider+2,10,1)

# Lid: flat print face underneath, rounded plan corners, embossed thumb button.
ly=1.6+P.slide_clearance
lid=rr(.5,ly,0,L-P.end_wall-.5,W-2*ly,P.lid_thickness,1)
lid=chamfer(lid.edges().group_by(Axis.Z)[0]+lid.edges().group_by(Axis.Z)[-1],length=.2)
# Cantilever anchored at x=37. Slot defines beam from x=5 to37, y=1.9..5.1.
root=5+P.beam_length
lid-=rr(3.8,ly+P.beam_width, -.1,root-3.8,1.8,P.lid_thickness+.2,.59)
lid-=box(3.8,ly-1,-.1,1.2,P.beam_width+2.2,P.lid_thickness+.2)
# Ramp faces +X for automatic engagement while closing; square -X face retains.
tooth=extrude(Polygon((5.5,.6),(7.2,.6),(10,ly),(10,ly+.4),(5.5,ly+.4),align=None),amount=P.lid_thickness)
lid+=tooth
lid+=rr(6,ly+.3,P.lid_thickness,11,2.4,.7,1)
lid+=rr(5.5,.1,P.lid_thickness+.7,12,5.3,1.6,1)
lid=engrave(lid,'DDR4',L*.55,W*.70,P.lid_thickness)
lid=engrave(lid,'2 X DIMM',L*.55,W*.55,P.lid_thickness)
lid=engrave(lid,'135 X 40 X 8.5',L*.55,W*.85,P.lid_thickness)
lid=engrave(lid,'BAG EACH',L*.55,W*.37,P.lid_thickness)
lid=engrave(lid,'PUSH',18,14,P.lid_thickness)
lid=engrave(lid,'SLIDE',18,27,P.lid_thickness)
# Engraved directional arrows: PUSH +Y; SLIDE -X.
def arrow(points):return Pos(0,0,P.lid_thickness-P.label_depth)*extrude(Polygon(*points,align=None),amount=P.label_depth+.05)
lid-=arrow([(16,5.8),(17,5.8),(17,8),(18,8),(16.5,10),(15,8),(16,8)])
lid-=arrow([(9,33),(12,31.5),(12,32.5),(25,32.5),(25,33.5),(12,33.5),(12,34.5)])

tray.label='Tray';lid.label='Sliding lid'
parts={'tray':tray,'lid':lid}
for name,s in parts.items():
    assert s.is_valid and len(s.solids())==1,(name,'invalid or multiple solids')
    export_step(s,OUT/f'{name}.step')
    export_stl(s,OUT/f'{name}.stl',tolerance=.025,angular_tolerance=.12,ascii_format=False)
assembled_lid=Pos(0,0,P.lid_z)*lid
export_step(Compound(children=[tray,assembled_lid]),OUT/'assembled.step')

def volume(s):return sum(v.volume for v in s.solids()) if s else 0
checks={'parameters':asdict(P),'outer_mm':[L,W,P.rail_top], 'pockets_mm':[BL,BW,P.cavity_top-P.floor], 'labels':labels,'parts':{},'assembled_intersection_mm3':volume(tray & assembled_lid)}
for name,s in parts.items():
    b=s.bounding_box();checks['parts'][name]={'valid':s.is_valid,'solids':len(s.solids()),'volume_mm3':s.volume,'bounds_mm':[[b.min.X,b.min.Y,b.min.Z],[b.max.X,b.max.Y,b.max.Z]]}
# Conservative folded bag+module+padding gauge; rests on supports, never touches lid.
checks['packing_gauges']=[]
for y in YS:
    gauge=box(P.front_apron+.5,y+.5,P.floor+P.support_rise,BL-1,BW-1,10)
    checks['packing_gauges'].append({'dimensions_mm':[BL-1,BW-1,10], 'tray_collision_mm3':volume(tray & gauge),'lid_collision_mm3':volume(assembled_lid & gauge),'lid_headroom_mm':P.lid_z-(P.floor+P.support_rise+10)})
    # Module contact zone: first 8 mm of height, conservative full thickness.
    contact=box(P.front_apron+3,y+2.5,P.floor+P.support_rise,P.module_length,8,P.module_thickness)
    assert volume(tray & contact)<1e-6
checks['contact_lane']={'support_start_from_pocket_edge_mm':12,'module_contact_edge_from_pocket_edge_mm':2.5,'tested_contact_band_mm':8,'support_separation_y_mm':1.5,'floor_recess_mm':P.support_rise}
# Lid rigid sweep without its flexible beam. Beam release modeled separately as
# translation is only a clearance bound, NOT a compliant FEA or force prediction.
beam_region=box(3.8,-1,-1,root-3.8,ly+P.beam_width+1,8)
rigid=lid-beam_region
checks['rigid_slide_sweep_mm3']={str(d):volume(tray & (Pos(d,0,P.lid_z)*rigid)) for d in [0,-1,-3,-6,-12,-30,-75,-155]}
checks['locked_pull_intersection_mm3']=volume(tray & (Pos(-1.1,0,P.lid_z)*lid))
# Tooth at full inward release, slides out through channel without collisions.
checks['released_tooth_sweep_mm3']={str(d):volume(tray & (Pos(d,P.latch_release,P.lid_z)*tooth)) for d in [0,-1,-3,-6,-12,-30,-75,-155]}
checks['latch']={'beam_length_mm':P.beam_length,'beam_width_mm':P.beam_width,'release_mm':P.latch_release,'tooth_engagement_mm':1,'slot_width_mm':1.8,'remaining_slot_at_full_release_mm':.3,'rail_capture_overlap_mm':2.2,'vertical_channel_clearance_each_mm':.35,'estimated_max_bending_strain':1.5*P.beam_width*P.latch_release/P.beam_length**2,'note':'Small-deflection cantilever estimate only; no force, fatigue, or retention certification.'}
assert checks['assembled_intersection_mm3']<1e-6
assert all(g['tray_collision_mm3']<1e-6 and g['lid_collision_mm3']<1e-6 for g in checks['packing_gauges'])
assert max(checks['rigid_slide_sweep_mm3'].values())<1e-6
assert max(checks['released_tooth_sweep_mm3'].values())<1e-6
assert checks['locked_pull_intersection_mm3']>0
(OUT/'cad_checks.json').write_text(json.dumps(checks,indent=2))
assembly={'units':'mm','coordinate_system':'+X closing direction; +Y latch-release direction; +Z up from tray print bed','transform_convention':'4x4 row-major matrices act on column vectors; file coordinates to assembled coordinates','parts':[{'id':n,'step':f'output/{n}.step','stl':f'output/{n}.stl','quantity':1,'transform':[[1,0,0,0],[0,1,0,0],[0,0,1,0 if n=='tray' else P.lid_z],[0,0,0,1]]} for n in parts],'assembly_step':'output/assembled.step','nonprinted_items':['Two individually closed ESD shielding bags','Two loose paper lifting strips, approximately 20 x 140 mm','Light nonabrasive paper or suitable ESD-compatible foam at heatspreaders only','Outer corrugated cardboard shipping box and cushioning']}
(ROOT/'assembly.json').write_text(json.dumps(assembly,indent=2))
print(json.dumps({k:v for k,v in checks.items() if k not in ['labels','parameters']},indent=2))
