from build123d import *
from pathlib import Path
import json, math
OUT=Path('output'); OUT.mkdir(exist_ok=True)
FONT=str(Path('assets/fillaprint/Fillaprint-Regular.ttf').resolve())
PITCH=42.0; OUTER=41.5

def rr(w,r,z):
 return Plane(origin=(0,0,z))*RectangleRounded(w,w,r)
def profile(stations):
 return loft([rr(w,r,z) for z,w,r in stations],ruled=True)
# Standard nominal foot: 0.8 bottom chamfer, 1.8 straight, 2.15 upper chamfer.
foot=profile([(0,35.6,0.8),(0.8,37.2,1.6),(2.6,37.2,1.6),(4.75,41.5,3.75)])
# Matching socket is relieved 0.3 mm diametrically; rim contact is at z=4.15.
socket=profile([(0,35.9,0.95),(0.8,37.5,1.75),(2.6,37.5,1.75),(4.15,40.6,3.3),(4.5,40.6,3.3)])
body=extrude(rr(OUTER,3.75,4.75),amount=24.75)
# Filleted cutter gives a concave scoop around the floor, easing fingertip access.
cutter=extrude(rr(36.7,5.0,6.75),amount=23.5)
bottom=[e for e in cutter.edges() if abs(e.center().Z-6.75)<0.01 and abs(e.bounding_box().max.Z-e.bounding_box().min.Z)<0.01]
cutter=fillet(bottom, radius=4.0)
bin_blank=foot+body-cutter-(Pos(0,0,25)*socket)
print('blank',bin_blank.is_valid,bin_blank.volume,flush=True)

def label(line,z):
 t=Text(line,8,font_path=FONT)
 b=t.bounding_box()
 print('label',line,round(b.size.X,2),round(b.size.Y,2),flush=True)
 if b.size.X>37: raise ValueError('label too wide')
 # local text x/y maps to world x/z, normal toward front (-y)
 pl=Plane(origin=(0,-20.70,z),x_dir=(1,0,0),z_dir=(0,-1,0))
 return extrude(pl*t,amount=0.45)

sizes=['M2','M2.5','M3','M4']
lengths={'M2':[6,10,16], 'M2.5':[6,12,20], 'M3':[8,12,20], 'M4':[8,16,20]}
items=[]
for s in sizes:
 for n in lengths[s]: items.append((s,str(n)+'mm','screw'))
for s in sizes:
 for kind in ['NUT','WASHER']: items.append((s,kind,kind.lower()))
# Build socket tools as one compound to perform a single base cut.
base=extrude(Plane.XY*RectangleRounded(210,168,4),amount=5.1)
tools=[]
for row in range(4):
 for col in range(5):
  x=(col-2)*42; y=(row-1.5)*42
  tools.append(Pos(x,y,0.7)*socket)
base=base.cut(*tools)
print('base',base.is_valid,base.volume,flush=True)
export_step(base,OUT/'base_5x4.step'); export_stl(base,OUT/'base_5x4.stl',tolerance=0.03,angular_tolerance=0.15)
parts=[{'id':'base','step':'base_5x4.step','stl':'base_5x4.stl','translation_mm':[0,0,0],'rotation_deg_xyz':[0,0,0]}]
for i,(s,line,kind) in enumerate(items):
 name=(s+'_'+line).lower().replace('.','p')
 solid=bin_blank+label(s,18.5)+label(line,10.5)
 print('part',name,solid.is_valid,solid.volume,flush=True)
 export_step(solid,OUT/(name+'.step')); export_stl(solid,OUT/(name+'.stl'),tolerance=0.03,angular_tolerance=0.15)
 row=i//5; col=i%5
 parts.append({'id':name,'contents':f'{s} {line} {kind}','step':name+'.step','stl':name+'.stl','translation_mm':[(col-2)*42,(row-1.5)*42,0.8],'rotation_deg_xyz':[0,0,0]})
(OUT/'assembly.json').write_text(json.dumps({'units':'mm','coordinate_system':'base centered in XY; front is -Y; Z up','parts':parts},indent=2)+'\n')
