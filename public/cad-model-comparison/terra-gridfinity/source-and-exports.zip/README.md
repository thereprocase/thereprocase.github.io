# Bench fastener starter set

This set fills a 210 × 168 mm (5 × 4) patch with twenty removable 1 × 1 bins. The single bin design has a rounded floor and a socket for stacking a second bin. Labels are integral, raised 0.4 mm on the front (-Y) face; read them from the front of the drawer. They use the supplied Fillaprint font, 8 mm em / 5.6 mm cap height, its specified minimum for a 0.4 mm line width. Print upright with the base of each part on the bed. A color change for the raised letters is optional; the lettering remains permanent without one. Avoid shrinking the parts or labels.

Each line below is one row of five, viewed from the front (-Y), left to right:

| Row | Contents |
|---|---|
| 1 | M2 × 6, M2 × 10, M2 × 16, M2.5 × 6, M2.5 × 12 screws |
| 2 | M2.5 × 20, M3 × 8, M3 × 12, M3 × 20, M4 × 8 screws |
| 3 | M4 × 16, M4 × 20 screws, M2 nuts, M2 washers, M2.5 nuts |
| 4 | M2.5 washers, M3 nuts, M3 washers, M4 nuts, M4 washers |

Lengths are the screw shank length in mm, measured under the head. `NUT` and `WASHER` are spelled out. Start with about 20 screws or 30 nuts or washers in each bin; leave headroom for fingers and for the foot of a stacked bin. Lift one by its upper walls. Neighboring bins are independent; packing is close, so lift vertically, and keep them below the rim to avoid disturbing loose contents. A second bin nests on the upper rim; it covers the lower contents, and is not a sealed lid. Use stacking for reserve stock rather than the bins accessed most often. The 1 × 1 footprint can be moved to another ordinary Gridfinity base; generate another size by adding an item in `generate.py` and rerunning it. STEP and binary STL names correspond to their labels. `output/assembly.json` gives each part's actual placement; no fasteners are modeled.

The body is 41.5 mm square at 42 mm pitch. The accessible cavity is nominally 36.7 mm square, with 4 mm floor fillets, 28.7 mm flat central floor and approximately 18.25 mm from the flat floor to the start of the stacking socket. The narrow part of the mouth is approximately 36.7 mm; corner radii and the socket make its exact boundary vary with height. The foot has the familiar 35.6 mm lower width, 0.8 mm lower bevel, 1.8 mm straight section, and 2.15 mm upper bevel. Socket dimensions include 0.3 mm nominal diametral relief along the mating profiles. The top rim is thin at its edge (0.45 mm nominal), as it must clear the next foot; treat it gently and test it in your material. The supplied base has a 0.7 mm floor under its socket and no magnet holes. It is one piece and requires a printer with at least 210 × 168 mm usable bed area.

Capacity is an engineering estimate, not a physical fill test: for example, 20 typical M4 × 20 socket screws occupy roughly 8 cm³ of metal, versus roughly 20 cm³ gross cavity space below the socket, allowing for loose packing. Hardware standards and actual screw heads vary. It is not a promise that every oversized or unusually packed part fits. The rounded floor helps retrieve a washer, but fingertip reach depends on the person; tweezers may still help with very small parts.

Test one bin and a small base area first for seating, clearance, stacking, label legibility, rim durability and easy removal on your printer. The labels project 0.40 mm beyond the front wall; the nominal clearance to a neighboring bin is only 0.10 mm, so over-extrusion or elephant foot can cause rubbing. External research was attempted through the specified proxy but the proxy was unreachable. Dimensions are therefore convention-based rather than independently verified against a current official specification, and compatibility with a particular commercial base remains to be tested. The set has not been printed, sliced, or physically tested.

Regenerate in this directory with `python generate.py`. The supplied font and its license are under `assets/fillaprint/`. Exports are in `output/`; `checks.txt` records mesh checks.
