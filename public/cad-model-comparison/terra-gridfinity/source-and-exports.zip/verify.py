from pathlib import Path
import json, trimesh, numpy as np
p=Path('output'); assembly=json.loads((p/'assembly.json').read_text()); rows=[]
assert len(assembly['parts'])==21
for item in assembly['parts']:
 assert (p/item['step']).exists() and (p/item['stl']).exists()
 m=trimesh.load_mesh(p/item['stl'])
 assert m.is_watertight and m.is_winding_consistent and len(m.split())==1, item['id']
 rows.append(f"{item['id']}: watertight=YES components=1 extents_mm="+', '.join(f'{x:.2f}' for x in m.extents)+f' volume_mm3={m.volume:.1f}')
(p/'checks.txt').write_text('Mesh checks (trimesh; all 21 binary STLs):\n'+'\n'.join(rows)+'\n\nDesign dimensions: pitch 42; bin body 41.5; cavity 36.7; central flat 28.7; floor z=6.75; socket starts z=25; rim z=29.5; base 210 x 168 x 5.1; assembled bin origin z=0.8. Raised lettering projects 0.40 toward front; nominal gap to next bin 0.10 mm. Font em 8, caps 5.6 mm.\n')
print('\n'.join(rows))
