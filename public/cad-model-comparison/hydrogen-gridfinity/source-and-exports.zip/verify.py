"""Measured geometric, functional, and mesh verification for the Gridfinity Fastener Organizer.

Run with:
  python verify.py
"""

from __future__ import annotations

import json
import math
import struct
from pathlib import Path

import numpy as np
import trimesh


def is_binary_stl(path: Path) -> bool:
    """Verify STL is valid binary STL (not ASCII) by checking header + triangle count."""
    data = path.read_bytes()
    if len(data) < 84:
        return False
    tri_count = struct.unpack("<I", data[80:84])[0]
    expected_len = 84 + tri_count * 50
    return len(data) == expected_len and tri_count > 0


def fastener_volume_mm3(kind: str, dia: float, length: float = 0.0, count: int = 20) -> float:
    """Estimate packed volume (with 2.5x random-packing factor) for fasteners."""
    if kind == "screw":
        # ISO 4762 SHCS head: ~1.8 * dia diameter, 1.0 * dia height
        head_r = (1.8 * dia) / 2.0
        head_h = dia
        shaft_r = dia / 2.0
        v_one = math.pi * (head_r**2 * head_h + shaft_r**2 * length)
        return v_one * count * 2.5
    if kind == "nut":
        # ISO 4032 hex nut: ~1.8 * dia across flats, ~0.8 * dia height
        af = 1.8 * dia
        h = 0.8 * dia
        v_one = (math.sqrt(3) / 2.0) * (af**2) * h
        return v_one * count * 2.2
    if kind == "washer":
        # ISO 7089 flat washer: ~2.2 * dia OD, ~0.2 * dia thickness
        od = 2.2 * dia
        t = max(0.3, 0.2 * dia)
        v_one = math.pi * ((od / 2.0) ** 2) * t
        return v_one * count * 2.0
    raise ValueError(kind)


def main() -> None:
    asm = json.loads(Path("assembly.json").read_text(encoding="utf-8"))
    parts = asm["parts"]
    print(f"Loaded assembly.json: {len(parts)} parts, units={asm['units']}, pitch={asm['grid_pitch_mm']} mm")

    meshes: dict[str, trimesh.Trimesh] = {}
    all_ok = True

    print("\n=== 1. Per-Part File, Binary STL & Mesh Integrity Checks ===")
    for p in parts:
        pid = p["part_id"]
        step_p = Path(p["step_file"])
        stl_p = Path(p["stl_file"])
        assert step_p.exists() and step_p.stat().st_size > 0, f"Missing STEP: {step_p}"
        assert stl_p.exists() and is_binary_stl(stl_p), f"Invalid/non-binary STL: {stl_p}"

        mesh = trimesh.load(str(stl_p), force="mesh")
        tx, ty, tz = p["translation_mm"]
        mesh_world = mesh.copy()
        mesh_world.apply_translation([tx, ty, tz])
        meshes[pid] = mesh_world

        wt = mesh.is_watertight
        vol = mesh.volume
        ext = mesh.extents
        if not wt or vol <= 0:
            all_ok = False
        print(
            f"  {pid:20s}: watertight={str(wt):5s}, vol={vol:8.1f} mm3, "
            f"size=({ext[0]:6.2f}, {ext[1]:6.2f}, {ext[2]:5.2f}) mm"
        )

    print("\n=== 2. Assembly Clearance & Interference Checks ===")
    # Check adjacent bin XY gaps (excluding stacked bin vs its host)
    bin_parts = [p for p in parts if p["part_id"] != "baseplate_5x4"]
    min_xy_gap = float("inf")
    for i in range(len(bin_parts)):
        for j in range(i + 1, len(bin_parts)):
            a, b = bin_parts[i], bin_parts[j]
            if a.get("stacked_on") == b["part_id"] or b.get("stacked_on") == a["part_id"]:
                continue
            ba = meshes[a["part_id"]].bounds
            bb = meshes[b["part_id"]].bounds
            # Only compare if Z overlaps
            if ba[1][2] <= bb[0][2] or bb[1][2] <= ba[0][2]:
                continue
            dx = max(0.0, bb[0][0] - ba[1][0], ba[0][0] - bb[1][0])
            dy = max(0.0, bb[0][1] - ba[1][1], ba[0][1] - bb[1][1])
            gap = math.hypot(dx, dy) if (dx > 0 and dy > 0) else max(dx, dy)
            if gap < min_xy_gap:
                min_xy_gap = gap
            if gap < 0.40:
                print(f"  WARNING: tight gap {gap:.3f} mm between {a['part_id']} and {b['part_id']}")
                all_ok = False
    print(f"  Minimum XY gap between adjacent bins: {min_xy_gap:.3f} mm (target ~0.50 mm)")

    # Check stacked bin Z seating & label clearance
    stacked = [p for p in bin_parts if p.get("stacked_on")]
    for st in stacked:
        host_id = st["stacked_on"]
        st_bounds = meshes[st["part_id"]].bounds
        host_bounds = meshes[host_id].bounds
        # Host 4u nom_h = 28.0 mm; shelf top = BP_FLOOR_H + 28 - 2.0 = 27.2 mm; text top = 28.0 mm
        # Stacked bin bottom = BP_FLOOR_H + 28 - 0.35 = 28.85 mm
        z_bottom_stacked = st_bounds[0][2]
        z_top_host = host_bounds[1][2]
        z_host_text_top = 1.2 + 28.0 - 1.2  # 28.0 mm
        label_clearance = z_bottom_stacked - z_host_text_top
        seat_depth = z_top_host - z_bottom_stacked
        print(
            f"  Stacked {st['part_id']} on {host_id}: "
            f"seat_depth={seat_depth:.2f} mm, label_z_clearance={label_clearance:.2f} mm"
        )
        if label_clearance < 0.5:
            all_ok = False

    print("\n=== 3. Compartment Capacity & Ergonomics Checks ===")
    # Check worst-case capacities (M4x20 in 2x1 dual, M3x20 in 2x1 triple, M4 nut/wsh in 1x1 dual)
    # Approximate usable cavity volume (inner_w/comp * inner_d * (nom_h - 5 - 1 - 2) minus scoop)
    checks = [
        ("M4x20 (20 pcs) in bin_m4_16_20 (2x1-2C)", 38.75 * 38.7 * 20.0 - 3000, fastener_volume_mm3("screw", 4.0, 20.0, 20)),
        ("M3x20 (20 pcs) in bin_m3_12_16_20 (2x1-3C)", 25.43 * 38.7 * 20.0 - 2500, fastener_volume_mm3("screw", 3.0, 20.0, 20)),
        ("M4 NUT (30 pcs) in bin_m4_nut_wsh (1x1-2C)", 18.75 * 38.7 * 20.0 - 2000, fastener_volume_mm3("nut", 4.0, 0.0, 30)),
        ("M4 WSH (30 pcs) in bin_m4_nut_wsh (1x1-2C)", 18.75 * 38.7 * 20.0 - 2000, fastener_volume_mm3("washer", 4.0, 0.0, 30)),
    ]
    for desc, avail_v, req_v in checks:
        ratio = avail_v / req_v
        print(f"  {desc}: avail={avail_v:7.0f} mm3 vs req={req_v:7.0f} mm3 (fill={100/ratio:4.1f}%)")
        if ratio < 1.0:
            all_ok = False

    print(f"\nOverall verification: {'PASS' if all_ok else 'FAIL'}")
    if not all_ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
