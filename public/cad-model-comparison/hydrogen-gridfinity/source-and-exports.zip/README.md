# Gridfinity Fastener Organizer System (5×4 Starter Layout)

A coherent, parametric 42 mm Gridfinity organizer system for hobby machine screws (M2, M2.5, M3, M4 socket-head cap screws), matching plain hex nuts, and flat washers.

## Design Philosophy & Starter Assortment

The system uses a **5 × 4 Gridfinity footprint (210 × 168 mm)** with **one row per thread diameter** (front-to-back: M4, M3, M2.5, M2) and **only three reusable bin geometries** (all 4u / 28 mm nominal height, 32.4 mm with stacking lip, plus a 3u / 21 mm stackable overflow bin):

| Row | Thread | Col 1 (`1×1 Dual`) | Cols 2–3 (`2×1 Triple`) | Cols 4–5 (`2×1 Triple` / `2×1 Dual`) |
| :--- | :--- | :--- | :--- | :--- |
| **4 (Back)** | **M2** | `M2 NUT` \| `M2 WSH` | `M2x6` \| `M2x8` \| `M2x10` | `M2x12` \| `M2x16` \| `M2x20` |
| **3** | **M2.5** | `M2.5 NUT` \| `M2.5 WSH` | `M2.5x6` \| `M2.5x8` \| `M2.5x10` | `M2.5x12` \| `M2.5x16` \| `M2.5x20` |
| **2** | **M3** | `M3 NUT` \| `M3 WSH` | `M3x6` \| `M3x8` \| `M3x10` | `M3x12` \| `M3x16` \| `M3x20` |
| **1 (Front)** | **M4** | `M4 NUT` \| `M4 WSH` | `M4x8` \| `M4x10` \| `M4x12` | `M4x16` \| `M4x20` |
| **Stacked** | **M3+** | `M3 LCK` \| `M3 SPR` (`3u` stacked on `M3 NUT/WSH`) | — | — |

- **Capacity**: Each screw compartment holds 20+ socket-head screws (verified up to M4×20 in `2×1 Dual` and M3×20 in `2×1 Triple`); each nut/washer compartment holds 30+ hex nuts or flat washers.
- **Ergonomics**: Every compartment has a **R14 mm front finger scoop** so tiny M2 washers and 6 mm screws slide easily up the ramp under a fingertip.
- **Permanent Labels**: Raised **Fillaprint** (`Fillaprint-Regular.ttf`, 4.6–6.5 mm font size, ≥ 0.46 mm stroke width, 0.8 mm relief) on a recessed horizontal top-back shelf (`2.0 mm` below the nominal top). Labels read clearly from a seated bench/drawer angle without picking bins up, print flat in XY without supports, and clear stacked bins by `0.85 mm`.
- **Handling & Lifting**: Each `1×1` and `2×1` bin sits `4.65 mm` deep in the baseplate with `0.50 mm` nominal XY clearance between neighbors, allowing any bin to be lifted straight out and carried to a project without snagging or tipping adjacent bins.
- **Extensibility**: Add another thread size (e.g. M5 or M1.6) by adding a `5×1` row or extending `nx, ny` in `cad/gridfinity_organizer.py`.

## Files

- `cad/gridfinity_organizer.py` — Parametric `build123d` source generating all parts and `assembly.json`
- `exports/step/*.step` — STEP B-rep files per part
- `exports/stl/*.stl` — Binary STL files per part
- `assembly.json` — Assembled part transforms in millimeters
- `verify.py` — Mesh, clearance, stacking, and capacity verification script

## Printing & Physical Fit Test Notes

- **Recommended Print Settings**: 0.4 mm nozzle, 0.2 mm layer height, 2–3 perimeters, 15% gyroid infill, PLA or PETG, no supports required. Optional filament color swap at the label text Z-height (`26.0 mm` on 4u bins) for high-contrast two-tone labels.
- **Needs Physical Fit Test**:
  - Real-world FDM elephant-foot / XY shrinkage on the `0.25 mm` radial baseplate-to-bin socket clearance and `4.4 mm` stacking lip engagement.
  - Visual legibility of the `4.6 mm` two-line `M2.5 NUT / WSH` label on your specific printer/filament contrast.
