from design import *
import hashlib,csv

def main():
 measurements=json.loads((ROOT/'measured_parts.json').read_text())
 assembly=json.loads((ROOT/'assembly.json').read_text())
 report=[]
 for rec in measurements:
  f=OUT/f"{rec['name']}.step"
  shape=import_step(f)
  assert shape.is_valid and len(shape.solids())==1,f
  diff=abs(shape.volume-rec['volume_mm3'])
  assert diff<.01,(f,diff)
  mesh=OUT/f"{rec['name']}.stl"
  report.append(dict(step=str(f.relative_to(ROOT)),step_reimport_valid=True,volume_difference_mm3=diff,step_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),stl_sha256=hashlib.sha256(mesh.read_bytes()).hexdigest()))
 for part in assembly['parts']:
  assert (ROOT/part['step']).exists() and (ROOT/part['stl']).exists(),part
  if part['id']!='base':
   spec=next(s for s in SPECS if s['name']==part['id'])
   assert part['translation_mm']==[spec['col']*42,spec['row']*42,2]
 assert len(assembly['parts'])==len(measurements)==21
 (ROOT/'export_audit.json').write_text(json.dumps(report,indent=2))
 with (ROOT/'parts.csv').open('w') as f:
  writer=csv.writer(f);writer.writerow(['part','quantity','contents','x_mm','y_mm','z_mm','STEP','binary_STL'])
  for part in assembly['parts']:
   writer.writerow([part['id'],1,part.get('contents','baseplate'),*part['translation_mm'],part['step'],part['stl']])
 print('21 STEP round trips valid; volume errors <0.01 mm3; all assembly file references and transforms verified.')
if __name__=='__main__':main()
