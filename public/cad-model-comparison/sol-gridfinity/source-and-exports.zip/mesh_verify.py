from pathlib import Path
import json,struct
import trimesh
root=Path(__file__).resolve().parent
records=[]
for f in sorted((root/'output').glob('*.stl')):
 raw=f.read_bytes();n=struct.unpack('<I',raw[80:84])[0]
 assert len(raw)==84+50*n,(f,'not binary STL')
 mesh=trimesh.load_mesh(f,process=True)
 rec=dict(file=str(f.relative_to(root)),binary_stl=True,triangles=n,watertight=bool(mesh.is_watertight),winding_consistent=bool(mesh.is_winding_consistent),connected_components=len(mesh.split()),bounds_mm=mesh.bounds.tolist(),volume_mm3=float(mesh.volume))
 assert rec['watertight'] and rec['winding_consistent'] and rec['connected_components']==1,rec
 records.append(rec)
print(f'{len(records)} binary STL files; all watertight, consistent, one connected component')
(root/'mesh_checks.json').write_text(json.dumps(records,indent=2))
