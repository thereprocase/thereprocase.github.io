"""Analytical and BREP functional checks. No slicing or rendering."""
from design import *
import itertools
REPORT={}
def vol(shape):
 return sum(s.volume for s in shape.solids()) if shape is not None else 0.0

def overlap(a,b):
 return vol(a & b)
def check(key,value,limit=.001):
 REPORT[key]=value
 assert value<limit,(key,value)
 print(key,value,flush=True)
def cylinder_along(radius,length,center,axis):
 rotation=Rot(90,0,0) if axis=='y' else Rot(0,90,0)
 return Pos(*center)*rotation*Cylinder(radius,length)

def screw(x,y,z,axis='y',reverse=False):
 # Conservative max knurled M4 head envelope, 20mm under-head length.
 h=4.0;L=20.0;dr=7.22/2
 # overall -12..12, head -12..-8, shank -8..12
 head=-10 if not reverse else 10
 shank=2 if not reverse else -2
 if axis=='y':
  return cylinder_along(dr,h,(x,y+head,z),axis)+cylinder_along(2,L,(x,y+shank,z),axis)
 return cylinder_along(dr,h,(x+head,y,z),axis)+cylinder_along(2,L,(x+shank,y,z),axis)

def bbox_touch(a,b):
 a=a.bounding_box();b=b.bounding_box()
 return all(min(getattr(a.max,v),getattr(b.max,v))-max(getattr(a.min,v),getattr(b.min,v))>1e-6 for v in 'XYZ')

def paircheck(parts):
 return sum(overlap(a,b) for a,b in itertools.combinations(parts,2) if bbox_touch(a,b))

def main():
 tall,tm=make_bin(next(s for s in SPECS if s['name']=='bin_M4_x20'))
 small,sm=make_bin(next(s for s in SPECS if s['name']=='bin_M4_wash'))
 base=baseplate()
 for name,shape in [('screw',tall),('small',small)]:
  check(name+'_base_intersection_mm3',overlap(base,Pos(0,0,2)*shape))
  check(name+'_neighbor_intersection_mm3',overlap(shape,Pos(42,0,0)*shape))
  H=42 if name=='screw' else 35
  floor=7.2 if name=='screw' else 10.6
  # Vertical 16mm fingertip reaches flat floor without touching walls/shelf.
  finger=Pos(0,-2,(floor+.02+H+15)/2)*Cylinder(8,H+15-floor-.02)
  check(name+'_vertical_finger_16mm_intersection_mm3',overlap(shape,finger))
  # 12mm tip inserted 7.5mm under rear label shelf; this is a final-position
  # clearance probe, not a full articulated finger/hand motion simulation.
  hook=cylinder_along(6,7.5,(0,12.75,H-10.9),'y')
  check(name+'_shelf_hook_12mm_intersection_mm3',overlap(shape,hook))
 for lowername,lower,H in [('tall',tall,42),('small',small,35)]:
  for uppername,upper in [('tall',tall),('small',small)]:
   check(f'stack_{lowername}_{uppername}_intersection_mm3',overlap(lower,Pos(0,0,H)*upper))
  # Seating must resist a further downward translation, rather than floating.
  intrusion=overlap(lower,Pos(0,0,H-.1)*small)
  REPORT[f'stack_{lowername}_0p1mm_overtravel_intersection_mm3']=intrusion
  assert intrusion>.001
 # Same tapered seat requirement for supplied baseplate.
 intrusion=overlap(base,Pos(0,0,1.9)*small)
 REPORT['base_0p1mm_overtravel_intersection_mm3']=intrusion
 assert intrusion>.001
 screws=[]
 # Two interleaved layers: neighboring shafts/head envelopes have alternating
 # 3.71mm vertical stagger, with the high heads towards the front scoop.
 for layer in range(2):
  for i in range(8):
   screws.append(screw((i-3.5)*4.3,2.5,7.2+3.61+layer*7.42+(i%2)*3.71,reverse=not bool(i%2)))
 # Four unstaggered rear-headed screws nest above the interleaved layers.
 for i in range(4):
  screws.append(screw((i-1.5)*9.0,2.5,27.6,reverse=True))
 check('twenty_M4x20_bin_intersection_mm3',overlap(tall,Compound(children=screws)))
 check('twenty_M4x20_pair_intersection_mm3',paircheck(screws))
 REPORT['twenty_M4x20_packed_top_mm']=max(s.bounding_box().max.Z for s in screws)
 # A narrower 8mm tip gauge fits above this representative full load.
 hook=cylinder_along(4,7.5,(0,12.75,34.1),'y')
 check('twenty_M4x20_shelf_hook_8mm_bin_intersection_mm3',overlap(tall,hook))
 check('twenty_M4x20_shelf_hook_8mm_contents_intersection_mm3',overlap(hook,Compound(children=screws)))
 nuts=[]
 for layer in range(3):
  for y in [-6,2,10]:
   for x in [-12,-4,4,12]:
    if len(nuts)==30:break
    # Full hex envelope: 7mm AF, 3.2mm high. Solid center is conservative.
    nut=Pos(x,y,10.6+layer*3.3)*extrude(Rot(0,0,15)*RegularPolygon(7/math.sqrt(3),6),amount=3.2)
    nuts.append(nut)
 check('thirty_M4_nuts_bin_intersection_mm3',overlap(small,Compound(children=nuts)))
 check('thirty_M4_nuts_pair_intersection_mm3',paircheck(nuts))
 REPORT['thirty_M4_nuts_packed_top_mm']=max(s.bounding_box().max.Z for s in nuts)
 hook_small=cylinder_along(5,7.5,(0,12.75,26.1),'y')
 check('thirty_M4_nuts_hook_10mm_bin_intersection_mm3',overlap(small,hook_small))
 check('thirty_M4_nuts_hook_10mm_contents_intersection_mm3',overlap(hook_small,Compound(children=nuts)))
 washers=[]
 for layer in range(3):
  for y in [-5.9,3.3,12.5]:
   for x in [-13.8,-4.6,4.6,13.8]:
    if len(washers)==30:break
    # Full 9mm OD disk, .8mm thick; no hole gives conservative collisions.
    washers.append(Pos(x,y,10.6+layer*.9+.4)*Cylinder(4.5,.8))
 check('thirty_M4_washers_bin_intersection_mm3',overlap(small,Compound(children=washers)))
 check('thirty_M4_washers_pair_intersection_mm3',paircheck(washers))
 REPORT['thirty_M4_washers_packed_top_mm']=max(s.bounding_box().max.Z for s in washers)
 REPORT['clear_spaces_mm']=dict(bin_outer=41.5,pitch=42,neighbor_gap=.5,inner_width=37.5,mouth_depth_at_shelf=27.75,minimum_rim_throat_width=36.1,minimum_throat_to_shelf_depth=27.05,flat_floor_depth=29.5,scoop_radius=8,shelf_front_y=9,shelf_depth=9.75,shelf_thickness=2,shelf_hook_width=20,screw_hook_height=31.4,small_hook_height=21,screw_floor=7.2,small_floor=10.6,screw_height=45.55,small_height=38.55,receiver_top_wall=1.2,base_top_web=1.2,base_floor=1.8,base_sitting_z=2,stack_pitch_tall=42,stack_pitch_small=35)
 REPORT['font']=dict(file=str(FONT.relative_to(ROOT)),cap_height_mm=tm['cap_height_mm'],em_mm=8.4,stroke_mm=.84,minimum_gap_mm=.84,extrusion_width_design_mm=.42)
 REPORT['limitations']=['Ordered envelope packing establishes geometric capacity, not random-pour behavior.','Finger probes establish rigid final-position clearance; grip motion, human comfort and full-bin stability need physical testing.','No manufacturing tolerance, strength, sliding friction or print bridging simulation.']
 (ROOT/'functional_checks.json').write_text(json.dumps(REPORT,indent=2))
 print('ALL FUNCTIONAL CHECKS PASSED',flush=True)
if __name__=='__main__':main()
