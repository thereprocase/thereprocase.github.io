"""Original parametric Gridfinity bench organizer. Millimeters; build123d 0.13.
Run with python design.py
Use --only NAME for one part; verify.py runs functional checks.
"""
import os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.environ['FONTCONFIG_FILE']=str(ROOT/'fontconfig.xml')
from build123d import *
import json, math, argparse, time
PITCH=42.0
ENVELOPE=41.5
WALL=2.0
INNER=ENVELOPE-2*WALL
LINE_WIDTH=.42
FONT_EM=20*LINE_WIDTH
FONT=ROOT/'assets/fillaprint/Fillaprint-Regular.ttf'
OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
# Three screw lengths per diameter, followed by matching ordinary nuts/washers.
ASSORTMENT=[('M2',[6,10,16]),('M2.5',[6,10,16]),('M3',[8,12,20]),('M4',[8,12,20])]
BASE_NX=5
BASE_NY=len(ASSORTMENT)
BASE_NAME=f'base_{BASE_NX}x{BASE_NY}'
SPECS=[]
for row,(size,lengths) in enumerate(ASSORTMENT):
 for col,L in enumerate(lengths):
  SPECS.append(dict(name=f'bin_{size.replace(".","p")}_x{L}',size=size,kind='screw',length=L,col=col,row=row,H=42.0,floor=7.2,label=f'{size}x{L}'))
 for col,kind in [(3,'NUT'),(4,'WASH')]:
  SPECS.append(dict(name=f'bin_{size.replace(".","p")}_{kind.lower()}',size=size,kind=kind,length=None,col=col,row=row,H=35.0,floor=10.6,label=f'{size} {kind}'))

def rr(w,r,z=0,h=None):
 s=Plane.XY.offset(z)*RectangleRounded(w,w,r)
 return extrude(s,amount=h) if h is not None else s

def profile(sections):
 return loft([rr(w,r,z) for z,w,r in sections],ruled=True)

def male_foot():
 return profile([(0,35.6,.8),(.8,37.2,1.6),(2.6,37.2,1.6),(4.75,41.5,3.75)])

def receiver(seat,top):
 # .25 radial allowance at nominal seat+.25. 45-degree surfaces seat at seat.
 nominal=seat+.25
 levels=[(seat-.2,36.1,1.05),(nominal,36.1,1.05),
         (nominal+.8,37.7,1.85),(nominal+2.6,37.7,1.85)]
 # top is below the full foot shoulder; substantial wall remains at the rim.
 d=top-(nominal+2.6)
 assert d>=0
 levels.append((top+.01,37.7+2*(d+.01),1.85+d+.01))
 return profile(levels)

def baseplate(nx=BASE_NX,ny=BASE_NY):
 shape=Pos((nx-1)*PITCH/2,(ny-1)*PITCH/2,0)*extrude(RectangleRounded(nx*PITCH,ny*PITCH,2),amount=6.4)
 socket=receiver(2,6.5)
 for j in range(ny):
  for i in range(nx):
   shape=shape-(Pos(i*PITCH,j*PITCH,0)*socket)
 return shape

def bowl_blank(H,floor):
 # Slightly inset, shortened receiver lip: accepts ordinary Gridfinity feet,
 # avoids a knife edge and gives an exact H stack pitch on the taper.
 liptop=H+3.55
 outer=rr(ENVELOPE,3.75,4.75,liptop-4.75)+male_foot()
 cavity=profile([(floor,INNER,1.75),(H-2,INNER,1.75),
                 (H-1,36.1,1.05),(H+.25,36.1,1.05)])
 outer=outer-cavity-receiver(H,liptop+.1)
 # Front-only quarter-circle scoop, R8: flat floor starts at y=-10.75.
 R=8.0
 block=Pos(0,-INNER/2+R/2,floor+R/2)*Box(INNER,R,R)
 cyl=Pos(0,-INNER/2+R,floor+R)*Rot(0,90,0)*Cylinder(R,INNER+2)
 scoop=(block-cyl) & rr(INNER,1.75,floor,R)
 outer=outer+scoop
 # Rear shelf: 2mm skin, cap lettering below receiver's seating plane.
 # Side corbels reduce the bridge to 20mm while leaving a central finger hook.
 shelf=Pos(0,(9+INNER/2)/2,H-2.4)*Box(INNER,INNER/2-9,2)
 wings=[]
 for side in [-1,1]:
  # triangular prism in XZ, extruded along rear shelf depth
  pts=[(side*10,H-3.4),(side*INNER/2,H-3.4),(side*INNER/2,H-12.15)]
  face=Plane.XZ*Polygon(*pts,align=None)
  # XZ plane normal -Y
  wing=Pos(0,INNER/2,0)*extrude(face,amount=INNER/2-9,dir=(0,-1,0))
  wings.append(wing)
 return outer+shelf+wings[0]+wings[1]

def label_shape(label,H):
 sketch=Text(label,font_size=FONT_EM,font_path=str(FONT))
 bb=sketch.bounding_box()
 assert abs(bb.size.Y-14*LINE_WIDTH)<.001,(label,bb.size.Y)
 assert bb.size.X<=INNER-2,(label,bb.size.X)
 sketch=Pos(-(bb.min.X+bb.max.X)/2,13.875-(bb.min.Y+bb.max.Y)/2,H-1.4-.05)*sketch
 return extrude(sketch,amount=.65),dict(text=label,width_mm=bb.size.X,cap_height_mm=bb.size.Y,em_mm=FONT_EM,relief_mm=.6)

def make_bin(spec,blank=None):
 blank=blank or bowl_blank(spec['H'],spec['floor'])
 letters,metrics=label_shape(spec['label'],spec['H'])
 return blank+letters,metrics

def record(shape,name,extra=None):
 assert shape.is_valid, f'{name}: invalid BREP'
 assert len(shape.solids())==1,(name,len(shape.solids()))
 export_step(shape,OUT/f'{name}.step')
 export_stl(shape,OUT/f'{name}.stl',tolerance=.025,angular_tolerance=.08,ascii_format=False)
 b=shape.bounding_box()
 rec=dict(name=name,solid_count=len(shape.solids()),brep_valid=shape.is_valid,volume_mm3=shape.volume,
          bounds_mm=[[b.min.X,b.min.Y,b.min.Z],[b.max.X,b.max.Y,b.max.Z]])
 if extra:rec.update(extra)
 print(name,'OK',round(shape.volume),flush=True)
 return rec

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--only');args=parser.parse_args()
 records=[];parts=[]
 if not args.only or args.only==BASE_NAME:
  records.append(record(baseplate(),BASE_NAME))
 parts.append(dict(id='base',step=f'output/{BASE_NAME}.step',stl=f'output/{BASE_NAME}.stl',translation_mm=[0,0,0],rotation_deg_xyz=[0,0,0]))
 blanks={}
 for s in SPECS:
  if not args.only or args.only==s['name']:
   key=(s['H'],s['floor'])
   if key not in blanks:blanks[key]=bowl_blank(*key)
   shape,metrics=make_bin(s,blanks[key])
   records.append(record(shape,s['name'],dict(spec=s,label=metrics)))
  parts.append(dict(id=s['name'],step=f"output/{s['name']}.step",stl=f"output/{s['name']}.stl",translation_mm=[s['col']*PITCH,s['row']*PITCH,2],rotation_deg_xyz=[0,0,0],contents=s['label'],target_count=20 if s['kind']=='screw' else 30))
 if not args.only:
  (ROOT/'assembly.json').write_text(json.dumps(dict(units='mm',coordinate_system='right handed; Z up; front is negative Y; cell (0,0) center at origin',base_size_mm=[BASE_NX*PITCH,BASE_NY*PITCH,6.4],parts=parts),indent=2))
  (ROOT/'measured_parts.json').write_text(json.dumps(records,indent=2))
 else:(OUT/f"{args.only}_checks.json").write_text(json.dumps(records,indent=2))
if __name__=='__main__':main()
