# Bench fastener Gridfinity starter

Includes one 210 × 168 × 6.4 mm baseplate and twenty separate 1×1 bins. Each bin carries one size/type; lifting it never lifts a shared divider or a neighboring compartment. There are two reusable bodies: 6U screw bins (45.55 mm overall) and 5U raised-floor hardware bins (38.55 mm overall). The installed maximum height is 47.55 mm. No magnets or purchased attachment parts are required.

## What goes where

Viewed from above, front is negative Y. Rows run front to back; columns run left to right. All screw lengths are **millimeters under the head**, excluding the socket head.

| Row | Screw, short | Screw, medium | Screw, long | Plain hex nuts | Normal flat washers |
|---|---|---|---|---|---|
| Front, Y=0 | M2×6 | M2×10 | M2×16 | M2 NUT | M2 WASH |
| Y=42 | M2.5×6 | M2.5×10 | M2.5×16 | M2.5 NUT | M2.5 WASH |
| Y=84 | M3×8 | M3×12 | M3×20 | M3 NUT | M3 WASH |
| Back, Y=126 | M4×8 | M4×12 | M4×20 | M4 NUT | M4 WASH |

Assumes ordinary coarse-thread screws/nuts and normal flat washers. Target about 20 screws or 30 nuts/washers in each chosen bin. This samples short, medium and long screws without allocating space to every combination. `M2.5x16` is the permanent screw marking; `NUT` and `WASH` explicitly distinguish the hardware. The same supplied Fillaprint TTF is converted to solid lettering in every export: 8.4 mm em, **5.88 mm measured capitals**, 0.6 mm relief. This meets the author's reference minimum for a **0.42 mm extrusion line width** (0.84 mm nominal strokes and minimum gaps). Do not shrink the labels; a larger line width requires larger lettering. Letter faces can be painted for contrast. Labels read from above with bins seated; stacked bins conceal lower labels.

## Interfaces and handling

The male foot follows the researched Gridfinity profile: 35.6 mm bottom, 0.8 mm outward chamfer, 1.8 mm vertical section, 2.15 mm outward chamfer, 41.5 mm shoulder at Z=4.75; top corner radius 3.75 mm. Cell pitch is 42 mm, leaving 0.5 mm between adjacent bins. Baseplate socket floors are at Z=1.8 and bin bottoms seat at Z=2.0 on the tapers. Nominal radial allowance is 0.25 mm in the vertical socket sections; the 45° surfaces locate the bin as it seats.

The receiving lip is an original **shortened, thick-rim receiver**, not an exact copy of the standard upper lip. It accepts the standard male foot, has a 1.2 mm top wall, and seats another supplied bin at 42 or 35 mm above its bottom. All four tall/shallow stacking combinations were checked. Keep stacks low and stationary; these are open bins, not transport boxes or latched stacks. Cross-brand stacking still needs a fit test.

Each bowl is 37.5 mm wide with 2 mm sidewalls. The narrowest rim throat is 36.1 mm; clear depth from that throat to the rear shelf is 27.05 mm (27.75 mm within the bowl). The floor has a front-only R8 scoop and 29.5 mm maximum flat depth. A 24 mm overall M4×20 screw fits that flat region. Screw floors are at Z=7.2; hardware floors are raised to Z=10.6. Slide the last washer or short screw onto the curved front wall and pinch it there rather than searching a small hole.

Hook a fingertip under the front edge of the label shelf and brace the front rim with your thumb; lift vertically, then cradle the bin for carrying. The shelf has a 20 mm wide central hook space, 9.75 mm depth and a 2 mm skin, supported by side corbels. Empty-bin probes fit a 12 mm tip under the shelf and a 16 mm finger down to the floor. At the verified full M4 screw arrangement, an 8 mm tip gauge fits above the contents; a 10 mm tip gauge clears the 30-nut arrangement. This checks space, not hand comfort: avoid filling the grip space with loose hardware and test the grip loaded before relying on it. Carry upright and do not shake or invert a bin.

## Files, regeneration and extension

- `output/`: one STEP and **binary STL per physical part**: 21 of each, already lettered. All parts use local Z=0 bottoms; the baseplate is centered on its first cell, not at its outside corner.
- `assembly.json`: exact installed translations and rotations in mm; bins at `(42*column, 42*row, 2)`, base at origin.
- `design.py`: editable build123d source; `ASSORTMENT`, `SPECS`, body heights/floors, pitch, wall and font sizing control the design. `baseplate(nx, ny)` also generates larger patches. Keep `male_foot()` unchanged for standard base compatibility.
- `measured_parts.json`, `functional_checks.json`, `mesh_checks.json`: numerical checks; `verify.py` and `mesh_verify.py` reproduce them.

Regenerate from this directory:

```
python design.py
python verify.py
python mesh_verify.py
```

For an omitted screw length, edit an entry in `ASSORTMENT` and regenerate, or copy a generated specification and call `make_bin(spec)` / `record(...)`. For a new diameter, add another row to `ASSORTMENT`: the base height in cells, base filename and assembly metadata extend automatically. The bin body needs no size-specific holes or inserts. Recheck capacity for hardware larger than M4. The OFL font license stays beside the supplied font.

## Verification and physical limits

All 21 parts are valid single BREP solids. All 21 binary STLs are watertight, consistently wound, and have one connected component. Measured base/bin, adjacent-bin and all four stacking intersections are zero within 0.001 mm³. Moving a seated bin down another 0.1 mm creates interference, confirming supported seating rather than a floating placement.

Conservative solid hardware envelopes verify **20 M4×20 screws**, **30 M4 hex nuts** and **30 M4 flat washers**, without bin or pairwise collisions. Screw checks include 7.22 mm maximum head diameter and 4 mm head height; nuts use 7 mm across flats × 3.2 mm; washers use 9 mm OD × 0.8 mm. Smaller chosen fasteners use the same bowls. These are deliberately arranged packing witnesses, not a guarantee that twenty randomly poured long screws leave the grip clear. Keep large screw heads staggered and the upper rear grip area free; the actual arrangement is reproducible in `verify.py`.

**Physical tests remain:** first test one base cell and one bin for taper seating/release on your printer and an ordinary 42 mm base; check foreign-bin stacking; check the 20 mm shelf bridge/corbel region and raised lettering; test finger comfort with the smallest washer and full M4 bin, loose-load capacity, and stability while lifting/carrying. No printing or slicing was performed. Printer shrinkage, tolerances, friction, bridge sag and grip strength are not simulated. Use the supplied 0.42 mm font design width when evaluating lettering. All parts have flat build bottoms; the one-piece base requires a bed that accommodates 210 × 168 mm plus your chosen margin.

## Research

Accessed via the requested proxy; snapshots are in `research/`.

- [Gridfinity Rebuilt standard constants](https://github.com/kennetek/gridfinity-rebuilt-openscad/blob/main/src/core/standard.scad): pitch, male foot dimensions and standard lip profile. Geometry here was authored from dimensions.
- [Fillaprint author sizing guidance](https://github.com/thereprocase/double-bead#choose-a-print-size), cross-checked against the supplied TTF's own name metadata, em and cap-height tables.
- Boltport dimensional tables: [ISO 4762 socket heads](https://boltport.com/standards/iso-4762/), [ISO 4032 nuts](https://boltport.com/standards/iso-4032/), [ISO 7089 washers](https://boltport.com/standards/iso-7089/). These are manufacturer reference tables, not copies of the ISO standards; actual bags may contain other head or washer series.
