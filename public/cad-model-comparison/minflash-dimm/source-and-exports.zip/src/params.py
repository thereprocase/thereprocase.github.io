"""Parameters for the DDR4 DIMM mailer.

All lengths are millimetres.  Every dimension used by the geometry lives
here; `src/geometry.py` only consumes this module.

Coordinate frame of the assembled mailer (origin = outer bottom front-left
corner of the base):

    X  0 .. OUT_L   length of the mailer (module length direction)
    Y  0 .. OUT_W   width of the mailer (module height direction)
    Z  0 .. TOTAL_H height of the mailer, base sits on Z = 0

The base occupies Z = 0 .. RIM_H, the lid slides over it and its top plate
sits on the rim.
"""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FONT_PATH = ROOT / "assets" / "fillaprint" / "Fillaprint-Regular.ttf"
PARTS_DIR = ROOT / "parts"
CHECKS_DIR = ROOT / "checks"

# --------------------------------------------------------------------------
# Supported module envelope
# --------------------------------------------------------------------------
# A desktop DDR4 UDIMM with an ordinary (non-RGB) heat spreader.
#   JEDEC PCB length is 133.35 mm; heat spreaders overhang it slightly.
#   PCB height is 31.25 mm; a spreader adds ~3..13 mm on top of that.
#   PCB is 1.5 mm thick; two spreaders bring the module to 4..8 mm.
MOD_L = 135.0  # max module length over the spreader
MOD_H = 44.0  # max module height (contact edge -> top of spreader)
MOD_T = 8.0  # max module thickness (PCB + both spreaders)

BAG_T = 1.2  # shielding bag film allowance around the module
PAD_T = 2.0  # packing pad allowance (thickness direction)

# Lowest module that the bay still accepts with the contact edge locator.
MOD_H_MIN = 34.0

# --------------------------------------------------------------------------
# Bay
# --------------------------------------------------------------------------
BAY_L = 142.0  # bay interior length (X), between the end walls
BAY_W = 50.0  # bay interior width (Y), between the long walls
BAY_D = 12.0  # bay interior depth (Z), one module + bag + pad + clearance

WALL = 2.0  # outer wall thickness
DIV = 2.4  # divider between the two bays
LID_T = 2.4  # lid top plate thickness
FIT = 0.25  # clearance per side between lid skirt and base wall

# Derived outer sizes of the base
RIM_H = WALL + BAY_D + DIV + BAY_D  # 28.4
OUT_L = BAY_L + 2 * WALL  # 146.0
OUT_W = BAY_W + 2 * WALL  # 54.0
TOTAL_H = RIM_H + LID_T  # 30.8

CAV_X0, CAV_X1 = WALL, WALL + BAY_L  # cavity 2 .. 144
CAV_Y0, CAV_Y1 = WALL, WALL + BAY_W  # cavity 2 .. 52
FLOOR_TOP = WALL  # top of the base floor
BAY0_Z0 = WALL  # lower bay floor top
BAY0_Z1 = BAY0_Z0 + BAY_D  # lower bay ceiling (divider underside) 14
BAY1_Z0 = BAY0_Z1 + DIV  # upper bay floor top (divider top) 16.4
BAY1_Z1 = RIM_H  # upper bay ceiling (lid inner face) 28.4

# --------------------------------------------------------------------------
# Contact protection
# --------------------------------------------------------------------------
# The modules lie flat with the gold contact edge UP, so:
#   * the module is carried by its bottom face, not by the contacts
#   * the contact edge is parked in a relief in the bay ceiling
#   * the exposed PCB bottom edge sits in a trough in the floor
TROUGH_W = 6.0  # floor trough width (Y) under the contact edge
TROUGH_D = 1.0  # floor trough depth
CEIL_RELIEF_W = 6.0  # ceiling relief width (Y) over the contact edge
CEIL_RELIEF_D = 1.2  # ceiling relief depth
LEAD_IN = 2.5  # 45 deg lead-in chamfer at the far wall foot

# --------------------------------------------------------------------------
# Lid: a skirt that slides over the base and locks on two rails
# --------------------------------------------------------------------------
LID_WALL = 2.0  # lid skirt wall thickness
LID_SKIRT = 8.0  # depth of the lid skirt below the rim
LUG_L = 9.0  # rail length (X) on the base wall
LUG_H = 3.0  # rail height (Z) on the base wall
LUG_PROJ = 1.0  # rail projection (Y) off the base wall
LUG_X = 136.0  # X of the rail centre
LUG_Z0 = RIM_H - 5.9  # rail lower edge 22.5
CHANNEL_D = 1.0  # channel depth (Y) in the lid skirt
CHANNEL_H = 3.4  # channel height (Z) in the lid skirt
CHANNEL_LEN = 15.0  # channel length (X) measured from the open end
SLIDE_OUT = 16.0  # lid travel needed to free the rails

# --------------------------------------------------------------------------
# Fillaprint label sizes
# --------------------------------------------------------------------------
# Fillaprint: capital height = 14 x extrusion width w, normal stroke = 2 x w.
# w = 0.42 mm is the line width used for the reference sizes below.
EXTRUSION_W = 0.42
CAP_MIN = 14.0 * EXTRUSION_W  # 5.88 mm, the font's minimum printable size
CAP_SMALL = 2.0 * CAP_MIN  # 11.76 mm -> 4 extrusion beads per stroke
CAP_MED = 1.5 * CAP_MIN  # 8.82 mm -> 3 beads
CAP_TINY = 1.0 * CAP_MIN  # 5.88 mm -> 2 beads
EMBOSS = 0.6  # raised label height
ENGRAVE = 0.6  # engraved label depth

# --------------------------------------------------------------------------
# Optional bay filler (sets the working width of a bay for one module height)
# --------------------------------------------------------------------------
FILLER_T = 6.0  # nominal printed thickness
FILLER_CLEAR = 0.4  # clearance between filler and module
