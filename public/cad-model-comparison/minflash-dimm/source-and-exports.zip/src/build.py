"""Build the mailer, export STEP + binary STL, and write assembly.json.

Run with the CAD runtime:
    python src/build.py
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import params as P
from fillaprint import Fillaprint
from geometry import build_base, build_filler, build_lid

from build123d import Align, Box, Location, Pos, export_step, export_stl

ROOT = P.ROOT
PARTS = P.PARTS_DIR
CHECKS = P.CHECKS_DIR


def module_solid(height=None, length=None, thickness=None):
    """The supported module envelope as a solid, seated in the lower bay.

    The module lies flat with the gold contact edge towards -Y (the near
    wall), resting on the bay floor.
    """
    h = P.MOD_H if height is None else height
    length = P.MOD_L if length is None else length
    t = P.MOD_T if thickness is None else thickness
    return Pos(P.CAV_X0 + (P.BAY_L - length) / 2.0, P.CAV_Y0, P.BAY0_Z0) * Box(
        length, h, t, align=(Align.MIN,) * 3
    )


def gold_solid(height=None, length=None, thickness=None):
    """The exposed gold of the contact edge, in the same seated position."""
    h = P.MOD_H if height is None else height
    length = P.MOD_L if length is None else length
    t = P.MOD_T if thickness is None else thickness
    x0 = P.CAV_X0 + (P.BAY_L - length) / 2.0
    # gold on the module's bottom face near the contact edge
    bottom = Pos(x0, P.CAV_Y0, P.BAY0_Z0) * Box(length, 4.0, 0.4,
                                                  align=(Align.MIN,) * 3)
    # gold on the contact edge itself (PCB thickness band, mid module)
    mid = P.BAY0_Z0 + t / 2.0
    edge = Pos(x0, P.CAV_Y0 - 0.2, mid - 0.75) * Box(
        length, 0.6, 1.5, align=(Align.MIN,) * 3
    )
    # gold on the top face near the contact edge (in the ceiling relief)
    top = Pos(x0, P.CAV_Y0, P.BAY0_Z0 + t - 0.4) * Box(length, 4.0, 0.4,
                                                        align=(Align.MIN,) * 3)
    return bottom + edge + top


def _vol(shape):
    """Total volume of an intersection result (empty list, shape or compound)."""
    if shape is None:
        return 0.0
    if hasattr(shape, "volume"):
        return float(shape.volume)
    return float(sum(s.volume for s in shape))


def main():
    PARTS.mkdir(parents=True, exist_ok=True)
    CHECKS.mkdir(parents=True, exist_ok=True)
    font = Fillaprint(P.FONT_PATH)

    built = {}
    for name, fn in (("mailer_base", lambda: build_base(font)),
                     ("mailer_lid", lambda: build_lid(font)),
                     ("bay_filler", build_filler)):
        t0 = time.time()
        part = fn()
        step = PARTS / f"{name}.step"
        stl = PARTS / f"{name}.stl"
        export_step(part, str(step))
        export_stl(part, str(stl), tolerance=0.05, angular_tolerance=0.2)
        bb = part.bounding_box()
        built[name] = {
            "part": part,
            "step": step.name,
            "stl": stl.name,
            "volume_mm3": round(part.volume, 1),
            "bbox_mm": {
                "min": [round(v, 3) for v in (bb.min.X, bb.min.Y, bb.min.Z)],
                "max": [round(v, 3) for v in (bb.max.X, bb.max.Y, bb.max.Z)],
            },
            "build_s": round(time.time() - t0, 1),
        }
        print(f"{name}: volume {built[name]['volume_mm3']} mm3  "
              f"bbox {built[name]['bbox_mm']['min']} -> {built[name]['bbox_mm']['max']}"
              f"  ({built[name]['build_s']} s)")

    base = built["mailer_base"]["part"]
    lid = built["mailer_lid"]["part"]

    # ------------------------------------------------------------------
    # functional checks
    # ------------------------------------------------------------------
    checks = []

    def check(name, ok, detail):
        checks.append({"check": name, "pass": bool(ok), "detail": detail})
        print(("PASS " if ok else "FAIL ") + name + ": " + detail)

    # 1. the module envelope must not touch the base
    mod = module_solid()
    clash = base.intersect(mod)
    vol = _vol(clash)
    check("module_envelope_fits_lower_bay", vol < 1e-6,
          f"intersection volume {vol:.6f} mm3 (module "
          f"{P.MOD_L} x {P.MOD_H} x {P.MOD_T} mm seated on the bay floor)")

    # 2. the module must not touch the lid either
    clash2 = lid.intersect(mod)
    vol2 = _vol(clash2)
    check("module_envelope_clears_lid", vol2 < 1e-6,
          f"intersection volume {vol2:.6f} mm3")

    # 3. the gold must not touch anything hard
    gold = gold_solid()
    g1 = base.intersect(gold)
    g2 = lid.intersect(gold)
    gv1 = _vol(g1)
    gv2 = _vol(g2)
    check("gold_contacts_are_clear", gv1 < 1e-6 and gv2 < 1e-6,
          f"base {gv1:.6f} mm3, lid {gv2:.6f} mm3 of interference with the "
          f"contact-edge gold")

    # 4. the thickest module that still fits in the bay depth
    max_t = P.BAY_D
    check("bay_depth_covers_module_thickness", P.MOD_T + P.BAG_T <= max_t,
          f"bay depth {max_t} mm, module {P.MOD_T} mm + bag {P.BAG_T} mm "
          f"-> {max_t - P.MOD_T - P.BAG_T:.1f} mm left for packing")

    # 5. bay width vs module height
    check("bay_width_covers_module_height",
          P.MOD_H <= P.BAY_W - P.TROUGH_W,
          f"bay width {P.BAY_W} mm, usable {P.BAY_W - P.TROUGH_W:.1f} mm, "
          f"module {P.MOD_H} mm -> {P.BAY_W - P.TROUGH_W - P.MOD_H:.1f} mm "
          f"of packing gap at the far wall")

    # 6. bay length vs module length
    check("bay_length_covers_module_length", P.MOD_L <= P.BAY_L - 2 * P.LEAD_IN,
          f"bay length {P.BAY_L} mm, module {P.MOD_L} mm -> "
          f"{P.BAY_L - P.MOD_L:.1f} mm of end play")

    # 7. slide lock geometry
    lock_ok = (
        P.CHANNEL_D >= P.LUG_PROJ
        and P.CHANNEL_H >= P.LUG_H
        and P.CHANNEL_LEN >= P.LUG_L
        and P.SLIDE_OUT >= P.CHANNEL_LEN
    )
    check("slide_lock_geometry", lock_ok,
          f"rail {P.LUG_PROJ} mm proud x {P.LUG_H} mm tall in a "
          f"{P.CHANNEL_D} x {P.CHANNEL_H} mm channel {P.CHANNEL_LEN} mm long; "
          f"lid travel {P.SLIDE_OUT} mm frees the rail")

    # 8. lid skirt clearance over the base
    skirt_ok = P.FIT >= 0.2
    check("lid_skirt_clearance", skirt_ok,
          f"{P.FIT} mm per side between base wall and lid skirt")

    # 9. label sizes
    label_specs = [
        ("DIMM MAILER", P.CAP_SMALL, "lid top"),
        ("2 X DDR4 UDIMM", P.CAP_TINY, "lid top"),
        ("MAX 133.35 X 44 X 8 MM", P.CAP_TINY, "lid top"),
        ("OPEN BY LIFTING LID", P.CAP_MED, "base wall"),
        ("MODULE CONTACTS FACE UP", P.CAP_TINY, "base wall"),
        ("SLIDE TO OPEN", P.CAP_TINY, "lid skirt"),
        ("CONTACTS UP", P.CAP_MED, "lid underside"),
        ("A", P.CAP_MED, "bay A floor"),
        ("B", P.CAP_MED, "bay B floor"),
    ]
    label_rows = []
    label_ok = True
    for text, cap, where in label_specs:
        m = font.measure(text, cap, P.EXTRUSION_W)
        ok = (m.cap_height >= P.CAP_MIN - 1e-9
              and m.beads_stroke >= 2.0 - 1e-6
              and m.beads_gap >= 2.0 - 1e-6)
        label_ok = label_ok and ok
        label_rows.append({
            "text": text, "where": where,
            "cap_height_mm": round(m.cap_height, 3),
            "stroke_mm": round(m.stroke, 3),
            "min_gap_mm": round(m.min_gap, 3),
            "beads_per_stroke": round(m.beads_stroke, 2),
            "beads_in_min_gap": round(m.beads_gap, 2),
            "width_mm": round(m.width, 2),
            "pass": ok,
        })
    check("labels_meet_minimum_printable_size", label_ok,
          "all " + str(len(label_rows)) + " labels: capital height >= "
          f"{P.CAP_MIN:.2f} mm (14 x w), stroke >= 2w, clear gap >= 2w, "
          f"w = {P.EXTRUSION_W} mm")

    # 10. the lid label must fit on the lid face
    lid_label_w = max(r["width_mm"] for r in label_rows if r["where"] == "lid top")
    check("lid_label_fits_face", lid_label_w <= P.OUT_L - 10,
          f"widest lid label {lid_label_w:.1f} mm on a {P.OUT_L:.1f} mm face")

    # 11. the assembled envelope
    check("overall_envelope", True,
          f"base {P.OUT_L} x {P.OUT_W} x {P.RIM_H} mm, "
          f"assembled {P.OUT_L + 2.25:.1f} x {P.OUT_W + 4.25:.1f} x "
          f"{P.TOTAL_H:.1f} mm")

    # ------------------------------------------------------------------
    # assembly.json
    # ------------------------------------------------------------------
    assembly = {
        "name": "DIMM MAILER",
        "units": "mm",
        "description": "Reusable two-bay mailer for desktop DDR4 UDIMMs",
        "coordinate_frame": {
            "origin": "outer bottom front-left corner of the base",
            "x": "module length direction",
            "y": "module height direction, contact edge towards -Y",
            "z": "up",
        },
        "parts": [],
        "assembled_size_mm": {
            "x": round(P.OUT_L + 2.25, 2),
            "y": round(P.OUT_W + 4.25, 2),
            "z": round(P.TOTAL_H, 2),
        },
        "checks": checks,
        "labels": label_rows,
    }
    transforms = {
        "mailer_base": {"translation": [0.0, 0.0, 0.0], "rotation_deg": [0, 0, 0]},
        "mailer_lid": {"translation": [0.0, 0.0, 0.0], "rotation_deg": [0, 0, 0]},
        "bay_filler": {"translation": [0.0, 0.0, 0.0], "rotation_deg": [0, 0, 0]},
    }
    for name, info in built.items():
        tr = transforms[name]
        assembly["parts"].append({
            "name": name,
            "step": info["step"],
            "stl": info["stl"],
            "transform": tr,
            "matrix": [
                [1.0, 0.0, 0.0, tr["translation"][0]],
                [0.0, 1.0, 0.0, tr["translation"][1]],
                [0.0, 0.0, 1.0, tr["translation"][2]],
                [0.0, 0.0, 0.0, 1.0],
            ],
            "volume_mm3": info["volume_mm3"],
            "bbox_mm": info["bbox_mm"],
            "note": "modelled in its assembled position; transform is identity",
        })

    (ROOT / "assembly.json").write_text(json.dumps(assembly, indent=2) + "\n")
    (CHECKS / "checks.json").write_text(
        json.dumps({"checks": checks, "labels": label_rows}, indent=2) + "\n")

    n_fail = sum(1 for c in checks if not c["pass"])
    print(f"\n{len(checks) - n_fail}/{len(checks)} checks passed")
    return 1 if n_fail else 0


if __name__ == "__main__":
    sys.exit(main())
