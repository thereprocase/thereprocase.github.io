"""Minimal Fillaprint text engine: TrueType outlines -> build123d solids.

The supplied font (assets/fillaprint/Fillaprint-Regular.ttf) is used as-is;
nothing is installed into a system font directory.  Outlines are read with
fontTools, laid out with the font's own advance widths and kern table, and
converted to build123d faces so labels can be embossed into or engraved out
of the printed parts.

Fillaprint sizing rules (from the font's own name table and README):
    capital height    = 14 * w      (w = extrusion line width)
    normal stroke     =  2 * w
    minimum clear gap =  2 * w
with unitsPerEm = 1000 and sCapHeight = 700, so 1 em = 20 * w.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from fontTools.pens.recordingPen import RecordingPen
from fontTools.ttLib import TTFont

from build123d import Edge, Face, Solid, Vector, Wire, extrude


@dataclass
class TextMetrics:
    """Measured properties of a laid-out text run (millimetres)."""

    text: str
    cap_height: float
    width: float
    advance: float
    stroke: float
    min_gap: float
    beads_stroke: float
    beads_gap: float


class Fillaprint:
    """Lay out and turn Fillaprint strings into extruded solids."""

    def __init__(self, path: Path | str):
        self.path = Path(path)
        self.font = TTFont(str(self.path))
        self.upem = self.font["head"].unitsPerEm
        self.cap_units = self.font["OS/2"].sCapHeight
        self.cmap = self.font.getBestCmap()
        self.metrics = self.font["hmtx"].metrics
        self.glyph_set = self.font.getGlyphSet()
        kern_tables = self.font["kern"].kernTables if "kern" in self.font else []
        self.kern = kern_tables[0].kernTable if kern_tables else {}

    # -- font level helpers -------------------------------------------------
    def _glyph_name(self, ch: str) -> str | None:
        return self.cmap.get(ord(ch))

    def _contours(self, glyph_name: str) -> list[list[tuple[float, float]]]:
        """Return the glyph outline as closed polygons (this font has no curves)."""
        pen = RecordingPen()
        self.glyph_set[glyph_name].draw(pen)
        contours: list[list[tuple[float, float]]] = []
        current: list[tuple[float, float]] = []
        for op, args in pen.value:
            if op == "moveTo":
                current = [(float(args[0][0]), float(args[0][1]))]
                contours.append(current)
            elif op == "lineTo":
                current.append((float(args[0][0]), float(args[0][1])))
            elif op in ("curveTo", "qCurveTo"):
                raise NotImplementedError(
                    f"{self.path.name}: glyph {glyph_name} contains a curve"
                )
            elif op == "closePath":
                current = []
        return contours

    @staticmethod
    def _signed_area(points: list[tuple[float, float]]) -> float:
        area = 0.0
        n = len(points)
        for i in range(n):
            x1, y1 = points[i]
            x2, y2 = points[(i + 1) % n]
            area += x1 * y2 - x2 * y1
        return area / 2.0

    @staticmethod
    def _point_in_polygon(
        pt: tuple[float, float], poly: list[tuple[float, float]]
    ) -> bool:
        x, y = pt
        inside = False
        n = len(poly)
        j = n - 1
        for i in range(n):
            xi, yi = poly[i]
            xj, yj = poly[j]
            if (yi > y) != (yj > y):
                if x < (xj - xi) * (y - yi) / (yj - yi) + xi:
                    inside = not inside
            j = i
        return inside

    # -- layout -------------------------------------------------------------
    def layout(self, text: str) -> tuple[list[tuple[str, float]], float]:
        """Return ([(glyph name, x offset in font units)], total advance)."""
        items: list[tuple[str, float]] = []
        pen_x = 0.0
        prev: str | None = None
        for ch in text:
            name = self._glyph_name(ch)
            if name is None:
                raise KeyError(f"character {ch!r} is not in {self.path.name}")
            if prev is not None:
                pen_x += self.kern.get((prev, name), 0)
            items.append((name, pen_x))
            pen_x += self.metrics[name][0]
            prev = name
        return items, pen_x

    def advance(self, text: str) -> float:
        """Total advance width of `text` in font units (kerning included)."""
        return self.layout(text)[1]

    # -- geometry -----------------------------------------------------------
    def _wire(self, points: list[tuple[float, float]], scale: float, dx: float,
              dy: float = 0.0) -> Wire:
        edges = []
        n = len(points)
        for i in range(n):
            x1, y1 = points[i]
            x2, y2 = points[(i + 1) % n]
            p1 = Vector(dx + x1 * scale, dy + y1 * scale, 0)
            p2 = Vector(dx + x2 * scale, dy + y2 * scale, 0)
            edges.append(Edge.make_line(p1, p2))
        return Wire(edges)

    def glyph_faces(self, glyph_name: str, scale: float, dx: float = 0.0
                    ) -> list[Face]:
        """Build the faces of one glyph.

        TrueType fills with the non-zero rule: outer contours run clockwise
        (negative area here) and counters run counter-clockwise.
        """
        contours = self._contours(glyph_name)
        if not contours:
            return []
        outers = [c for c in contours if self._signed_area(c) < 0]
        holes = [c for c in contours if self._signed_area(c) >= 0]
        faces: list[Face] = []
        for outer in outers:
            inner_wires = []
            for hole in holes:
                if self._point_in_polygon(hole[0], outer):
                    inner_wires.append(self._wire(hole, scale, dx))
            faces.append(Face(self._wire(outer, scale, dx), inner_wires))
        return faces

    def text_faces(self, text: str, cap_height: float) -> list[Face]:
        """Faces for `text`, baseline on y = 0, scaled to the given cap height."""
        scale = cap_height / self.cap_units
        faces: list[Face] = []
        for name, x_off in self.layout(text)[0]:
            faces.extend(self.glyph_faces(name, scale, dx=x_off * scale))
        return faces

    def text_solid(self, text: str, cap_height: float, depth: float) -> Solid:
        """Extrude `text` from z = 0 to z = depth."""
        faces = self.text_faces(text, cap_height)
        if not faces:
            raise ValueError(f"no glyphs produced for {text!r}")
        solid = None
        for face in faces:
            piece = extrude(face, amount=depth)
            solid = piece if solid is None else solid.fuse(piece)
        return solid

    # -- measurement --------------------------------------------------------
    @staticmethod
    def _scan_spans(contours: list[list[tuple[float, float]]], y: float
                    ) -> list[tuple[float, float]]:
        """Filled x-intervals of a contour set on the horizontal line y."""
        events: list[tuple[float, int]] = []
        for contour in contours:
            n = len(contour)
            for i in range(n):
                x1, y1 = contour[i]
                x2, y2 = contour[(i + 1) % n]
                if (y1 <= y < y2) or (y2 <= y < y1):
                    t = (y - y1) / (y2 - y1)
                    events.append((x1 + t * (x2 - x1), 1 if y2 > y1 else -1))
        events.sort()
        spans: list[tuple[float, float]] = []
        winding = 0
        start = 0.0
        for x, direction in events:
            if winding == 0:
                start = x
            winding += direction
            if winding == 0 and x > start:
                spans.append((start, x))
        return spans

    def measure(self, text: str, cap_height: float,
                extrusion_w: float) -> TextMetrics:
        """Measure a laid-out run: cap height, width, stroke width, gap."""
        scale = cap_height / self.cap_units
        items, advance = self.layout(text)
        polygons: list[list[tuple[float, float]]] = []
        xs, ys = [], []
        for name, x_off in items:
            for contour in self._contours(name):
                shifted = [(x_off + x, y) for x, y in contour]
                polygons.append(shifted)
                for x, y in shifted:
                    xs.append(x * scale)
                    ys.append(y * scale)
        width = max(xs) - min(xs) if xs else 0.0
        top = max(ys) if ys else 0.0
        bottom = min(ys) if ys else 0.0

        # stroke width: the horizontal wall of 'O' (outer wall minus counter)
        stem = 0.0
        o_name = self._glyph_name("O")
        if o_name:
            contours = self._contours(o_name)
            if len(contours) >= 2:
                outer = max(contours, key=lambda c: abs(self._signed_area(c)))
                inner = min(contours, key=lambda c: abs(self._signed_area(c)))
                stem = (min(p[0] for p in inner) - min(p[0] for p in outer)) * scale

        # smallest clear gap: scan the filled runs of the laid out text
        gap = float("inf")
        samples = 60
        for k in range(samples + 1):
            y = bottom + (top - bottom) * (k / samples)
            spans = self._scan_spans(polygons, y)
            scaled = [(a * scale, b * scale) for a, b in spans]
            for i in range(1, len(scaled)):
                gap = min(gap, scaled[i][0] - scaled[i - 1][1])
            # gaps between separate glyph runs
            for i in range(1, len(scaled)):
                if scaled[i][0] > scaled[i - 1][1]:
                    gap = min(gap, scaled[i][0] - scaled[i - 1][1])
        if gap == float("inf"):
            gap = 0.0
        return TextMetrics(
            text=text,
            cap_height=top - bottom,
            width=width,
            advance=advance * scale,
            stroke=stem,
            min_gap=gap,
            beads_stroke=stem / extrusion_w,
            beads_gap=gap / extrusion_w,
        )
