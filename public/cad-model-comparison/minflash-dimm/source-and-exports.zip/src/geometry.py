"""Parametric geometry of the DDR4 DIMM mailer.

Parts
-----
mailer_base  : open tray with two module bays, one above the other
mailer_lid   : skirted box that slides over the tray and locks on two rails
bay_filler   : optional spacer that sets the working width of one bay

Coordinate frame (assembled mailer):
    X  0 .. OUT_L   length, the module's long axis
    Y  0 .. OUT_W   width, the module's height axis (contact edge at Y = WALL)
    Z  0 .. TOTAL_H height, the base sits on Z = 0

Modules lie flat with the gold contact edge UP, so the module is carried by
its bottom face and the gold sits in a relief pocket in the bay ceiling.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import params as P
from fillaprint import Fillaprint

from build123d import (
    Align,
    Box,
    Location,
    Plane,
    Polygon,
    Pos,
    Rotation,
    extrude,
)

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _prism_xz(profile, y0, y1):
    """Extrude a 2D profile given in the XZ plane along Y from y0 to y1."""
    sk = Plane.XZ * Polygon(*profile, align=None)
    solid = extrude(sk, amount=-(y1 - y0))
    return solid.moved(Location((0, y0, 0)))


def _prism_yz(profile, x0, x1):
    """Extrude a 2D profile given in the YZ plane along X from x0 to x1."""
    sk = Plane.YZ * Polygon(*profile, align=None)
    solid = extrude(sk, amount=x1 - x0)
    return solid.moved(Location((x0, 0, 0)))


def _text_solid(font: Fillaprint, text, cap, depth):
    """Text extruded along +Z, centred on x = 0, baseline on y = 0."""
    faces = font.text_faces(text, cap)
    if not faces:
        raise ValueError(f"no glyphs for {text!r}")
    solid = None
    for face in faces:
        piece = extrude(face, amount=-depth)  # -amount -> +Z
        solid = piece if solid is None else solid.fuse(piece)
    width = font.measure(text, cap, P.EXTRUSION_W).width
    return solid.moved(Location((-width / 2.0, 0, 0)))


def _label(font, text, cap, depth, mode, origin):
    """Place an extruded text solid.

    mode 'top'     : text lies in XY, extrudes +Z (raised on a top face)
    mode 'under'   : text lies in XY, extrudes -Z (raised on an underside)
    mode 'wall_-y' : text lies in XZ, extrudes -Y (read from -Y outside)
    mode 'wall_+y' : text lies in XZ, extrudes +Y (read from +Y outside)
    """
    solid = _text_solid(font, text, cap, depth)
    if mode == "top":
        pass
    elif mode == "under":
        solid = solid.moved(Rotation(180, 0, 0))
    elif mode == "wall_-y":
        solid = solid.moved(Rotation(90, 0, 0))
    elif mode == "wall_+y":
        solid = solid.moved(Rotation(90, 0, 0)).moved(Rotation(0, 0, 180))
    else:
        raise ValueError(mode)
    return solid.moved(Location(origin))


# ---------------------------------------------------------------------------
# base
# ---------------------------------------------------------------------------


def build_base(font: Fillaprint):
    """Return the base tray solid."""
    body = Box(P.OUT_L, P.OUT_W, P.RIM_H, align=(Align.MIN,) * 3)

    # main cavity
    body = body - Pos(P.CAV_X0, P.CAV_Y0, P.FLOOR_TOP) * Box(
        P.BAY_L, P.BAY_W, P.RIM_H - P.FLOOR_TOP, align=(Align.MIN,) * 3
    )

    # divider between the two bays
    body = body - Pos(P.CAV_X0, P.CAV_Y0, P.BAY0_Z1) * Box(
        P.BAY_L, P.BAY_W, P.DIV, align=(Align.MIN,) * 3
    )

    # ------------------------------------------------------------------
    # per bay features
    # ------------------------------------------------------------------
    for zf, zc in ((P.BAY0_Z0, P.BAY0_Z1), (P.BAY1_Z0, P.BAY1_Z1)):
        # floor trough under the contact edge (keeps the gold clear)
        body = body - Pos(P.CAV_X0, P.CAV_Y0, zf - P.TROUGH_D) * Box(
            P.BAY_L, P.TROUGH_W, P.TROUGH_D, align=(Align.MIN,) * 3
        )

        # 45 deg lead-in at the foot of the far wall
        body = body - _prism_yz(
            [
                (P.CAV_Y1, zf),
                (P.CAV_Y1, zf + P.LEAD_IN),
                (P.CAV_Y1 - P.LEAD_IN, zf),
            ],
            P.CAV_X0,
            P.CAV_X1,
        )

        # 45 deg chamfers on the bay end walls so the module self-centres
        for x_end in (P.CAV_X0, P.CAV_X1):
            s = 1 if x_end == P.CAV_X0 else -1
            profile = [
                (x_end, zf),
                (x_end, zf + P.LEAD_IN),
                (x_end + s * P.LEAD_IN, zf),
            ]
            body = body - _prism_xz(profile, P.CAV_Y0, P.CAV_Y1)

    # ceiling relief over the contact edge of the lower bay (in the divider)
    body = body - Pos(P.CAV_X0, P.CAV_Y0, P.BAY0_Z1 - P.CEIL_RELIEF_D) * Box(
        P.BAY_L, P.CEIL_RELIEF_W, P.CEIL_RELIEF_D, align=(Align.MIN,) * 3
    )

    # ------------------------------------------------------------------
    # slide rails on the outer long walls
    # ------------------------------------------------------------------
    for y_face, sign in ((0.0, -1), (P.OUT_W, 1)):
        if sign < 0:
            lug = Pos(P.LUG_X - P.LUG_L / 2, y_face - P.LUG_PROJ, P.LUG_Z0) * Box(
                P.LUG_L, P.LUG_PROJ, P.LUG_H, align=(Align.MIN,) * 3
            )
        else:
            lug = Pos(P.LUG_X - P.LUG_L / 2, y_face, P.LUG_Z0) * Box(
                P.LUG_L, P.LUG_PROJ, P.LUG_H, align=(Align.MIN,) * 3
            )
        body = body + lug

    # ------------------------------------------------------------------
    # bay letters engraved in the floors
    # ------------------------------------------------------------------
    for letter, zf in (("A", P.BAY0_Z0), ("B", P.BAY1_Z0)):
        body = body - _label(
            font, letter, P.CAP_MED, P.ENGRAVE, "top",
            (P.OUT_L / 2, P.CAV_Y0 + P.TROUGH_W + 2.5, zf - P.ENGRAVE),
        )

    # ------------------------------------------------------------------
    # raised instructions on both outer long walls
    # ------------------------------------------------------------------
    body = body + _label(
        font, "OPEN BY LIFTING LID", P.CAP_MED, P.EMBOSS, "wall_-y",
        (P.OUT_L / 2, 0.0, 6.0),
    )
    body = body + _label(
        font, "MODULE CONTACTS FACE UP", P.CAP_TINY, P.EMBOSS, "wall_-y",
        (P.OUT_L / 2, 0.0, 15.0),
    )
    body = body + _label(
        font, "OPEN BY LIFTING LID", P.CAP_MED, P.EMBOSS, "wall_+y",
        (P.OUT_L / 2, P.OUT_W, 6.0),
    )
    body = body + _label(
        font, "MODULE CONTACTS FACE UP", P.CAP_TINY, P.EMBOSS, "wall_+y",
        (P.OUT_L / 2, P.OUT_W, 15.0),
    )

    return body


# ---------------------------------------------------------------------------
# lid
# ---------------------------------------------------------------------------


def build_lid(font: Fillaprint):
    """Return the lid solid (skirted box, open at +X)."""
    z_rim = P.RIM_H
    x_in0 = -P.FIT  # inner face of the closed (-X) end wall
    x_in1 = P.OUT_L + P.FIT  # open end
    y_in0 = -P.FIT
    y_in1 = P.OUT_W + P.FIT

    x_out0 = x_in0 - P.LID_WALL
    y_out0 = y_in0 - P.LID_WALL
    y_out1 = y_in1 + P.LID_WALL

    # top plate
    lid = Pos(x_out0, y_out0, z_rim) * Box(
        x_in1 - x_out0, y_out1 - y_out0, P.LID_T, align=(Align.MIN,) * 3
    )

    # skirt walls: closed at -X, open at +X
    skirt = Pos(x_out0, y_out0, z_rim - P.LID_SKIRT) * Box(
        x_in1 - x_out0, y_out1 - y_out0, P.LID_SKIRT, align=(Align.MIN,) * 3
    )
    hollow = Pos(x_in0, y_in0, z_rim - P.LID_SKIRT - 1) * Box(
        x_in1 - x_in0, y_in1 - y_in0, P.LID_SKIRT + 2, align=(Align.MIN,) * 3
    )
    lid = lid + (skirt - hollow)

    # slide channels in the skirt, open at the +X end
    ch_z0 = P.LUG_Z0 + (P.LUG_H - P.CHANNEL_H) / 2.0
    ch_x1 = x_in1
    ch_x0 = x_in1 - P.CHANNEL_LEN
    for y_face in (y_in0, y_in1):
        if y_face == y_in0:
            ch = Pos(ch_x0, y_face, ch_z0) * Box(
                ch_x1 - ch_x0, P.CHANNEL_D, P.CHANNEL_H, align=(Align.MIN,) * 3
            )
        else:
            ch = Pos(ch_x0, y_face - P.CHANNEL_D, ch_z0) * Box(
                ch_x1 - ch_x0, P.CHANNEL_D, P.CHANNEL_H, align=(Align.MIN,) * 3
            )
        lid = lid - ch

    # ceiling relief over the contact edge of the upper bay
    lid = lid - Pos(P.CAV_X0, P.CAV_Y0, z_rim) * Box(
        P.BAY_L, P.CEIL_RELIEF_W, P.CEIL_RELIEF_D, align=(Align.MIN,) * 3
    )

    # ------------------------------------------------------------------
    # labels
    # ------------------------------------------------------------------
    # engraved on the outside top face (that face is the bed face when the
    # lid is printed, so engraving prints cleanly)
    for text, cap, y in (
        ("DIMM MAILER", P.CAP_SMALL, 33.0),
        ("2 X DDR4 UDIMM", P.CAP_TINY, 21.0),
        ("MAX 133.35 X 44 X 8 MM", P.CAP_TINY, 12.0),
    ):
        lid = lid - _label(
            font, text, cap, P.ENGRAVE, "top",
            (P.OUT_L / 2, y, z_rim + P.LID_T - P.ENGRAVE),
        )

    # raised on the skirt outer faces, read from outside
    lid = lid + _label(
        font, "SLIDE TO OPEN", P.CAP_TINY, P.EMBOSS, "wall_-y",
        (P.OUT_L / 2, y_out0, z_rim - 6.0),
    )
    lid = lid + _label(
        font, "SLIDE TO OPEN", P.CAP_TINY, P.EMBOSS, "wall_+y",
        (P.OUT_L / 2, y_out1, z_rim - 6.0),
    )

    # raised on the inside face, read when the lid is lifted
    lid = lid + _label(
        font, "CONTACTS UP", P.CAP_MED, P.EMBOSS, "under",
        (P.OUT_L / 2, 16.0, z_rim),
    )

    return lid


# ---------------------------------------------------------------------------
# optional bay filler
# ---------------------------------------------------------------------------


def build_filler():
    """Optional spacer that sets the working width of one bay."""
    w = P.FILLER_T
    length = 130.0
    x0 = P.CAV_X0 + 6.0
    filler = Pos(x0, P.CAV_Y1 - w, P.BAY0_Z0) * Box(
        length, w, P.BAY_D - 1.5, align=(Align.MIN,) * 3
    )
    # chamfer the leading edge so it guides the module in
    filler = filler - _prism_yz(
        [
            (P.CAV_Y1 - w, P.BAY0_Z0),
            (P.CAV_Y1 - w, P.BAY0_Z0 + 3.0),
            (P.CAV_Y1 - w + 3.0, P.BAY0_Z0),
        ],
        x0,
        x0 + length,
    )
    return filler
