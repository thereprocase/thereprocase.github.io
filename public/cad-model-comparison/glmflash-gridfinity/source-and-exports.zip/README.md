# Gridfinity small-hardware organizer

A coherent Gridfinity system for machine screws, nuts and washers:
one 5×4 baseplate (210 × 168 mm nominal), 19 labelled 1×1 bins, and an
empty extension slot. Built from one parametric source
(`src/organizer.py`, build123d); verified by `src/check_assembly.py`.

Geometry follows the official Gridfinity Design Reference v5
(gridfinity.xyz, @willtree8) and Zack Freedman's original system:
42 mm grid, 41.5 mm bin body, dovetail pad/socket interface with
0.25 mm/side fits, 7 mm height units.

## Starter assortment — what belongs where

Rows 1–4 front→back (drawer front = −Y). Columns 1–5 left→right.

| | col 1 | col 2 | col 3 | col 4 | col 5 |
|---|---|---|---|---|---|
| **row 1** (front) | WASHER M2 | WASHER M2.5 | WASHER M3 | M3 x 12 | WASHER M4 |
| **row 2** | NUT M2 | NUT M2.5 | NUT M3 | M3 x 16 | NUT M4 |
| **row 3** | M2 x 6 | M2.5 x 6 | M3 x 8 | M4 x 10 | M4 x 20 |
| **row 4** (back) | M2 x 8 | M2.5 x 10 | M3 x 10 | M4 x 16 | *(empty)* |

Rationale: washers and nuts — the fiddliest parts — live in the most
reachable front rows; screws are grouped by thread left→right, length
increasing front→back; the tallest bin (M4 x 20) sits at the back where
it can rise above its neighbours; every column's heights are
non-increasing toward the front so no label is hidden behind a taller bin.

The assortment covers all six requested lengths (6/8/10/12/16/20) with
a bias toward the most common pairings: M2/M2.5 short (electronics,
cases), the M3 family (3D printing), M4 medium/long (brackets).
Column 5, row 4 is a deliberate **extension slot** — drop in any standard
1×1 bin (or a new bin from this generator) for the next size.

## Bin types — three heights, one design

Only three bin geometries exist; the label is the only other difference:

| type | height units | total height | cavity depth | contents |
|---|---|---|---|---|
| small | 3u | 25.4 mm | 14.45 mm | all washers & nuts, M2/M2.5/M3 screws ≤ 10 mm |
| medium | 4u | 32.4 mm | 21.45 mm | M3 x 12/16, M4 x 10/16 |
| tall | 5u | 39.4 mm | 28.45 mm | M4 x 20 |

Verified capacity per compartment (`checks.json`): ≥ 20 screws standing
head-down (23 for M4, 68 for M2), 30 nuts or 30 washers with pile
heights of 0.5–6.4 mm — everything stays a shallow, finger-reachable
layer or bundle.

## Labels

Engraved 0.5 mm deep with the supplied FilaPrint font
(`assets/fillaprint/Fillaprint-Regular.ttf`, OFL licence beside it):

* **inner face of the back wall** — the primary label; visible from
  above-front while the bin is seated, for every bin in the patch;
* **outer face of the front wall** — second label, readable for the
  front row and when a bin is in hand.

Cap heights 4.3–5.0 mm (well above a 3.5 mm declared minimum); text is
auto-fitted to the flat wall region. Nut/washer wording is spelled out,
not abbreviated.

## Interfaces and actual clear spaces (mm)

| interface | value |
|---|---|
| grid pitch | 42.0 |
| bin outer body | 41.5 × 41.5, corner r 3.75 (0.25/side grid clearance) |
| bin wall / cavity | 1.2 wall → cavity 39.1 × 39.1 (r 1.0) |
| cavity floor | 1.8 above the pad structure |
| male pad | 4.75 tall: 35.6 tip (r 0.8) → 37.2 straight 1.8 → 41.5 top |
| plate | 209.5 × 167.5 × 5.0, through-style sockets 4.9 deep, 0.1 floor |
| plate socket | 36.1 tip → 37.7 straight 1.8 → 42.0 mouth (8.0 corner discs) |
| fit, straight sections | 0.25 per side |
| bin resting height | 0.1 (pad tips rest on socket floors) |
| stacking socket (bin top) | 3.75 deep, bore 37.7 (0.25/side), mouth 40.0 → 0.75 rim ring |
| label band | centre at 7·n − 5.0; engraving leaves 0.7 wall |

## Printing

* Bins print **upside down** (stacking lip down), no supports: all
  flares are 45° or shallower and the cavity floor becomes a top surface.
* Baseplate prints flat as modelled; 0.1 mm socket floors are solid layers.
* Suggested: 0.4 nozzle, 0.2 mm layers, 3 walls, PLA or PETG.
  Engravings need no special settings; slow down on the thin rim if needed.
* The plate alone is 210 × 168 mm — check your printer and drawer.

## Handling

* **Read without lifting:** look into the drawer — each bin's size is
  engraved on its back wall, visible from above-front over the contents.
* **Grab one part:** reach over the rim and pinch; screws stand
  head-down in a loose bundle, washers/nuts form shallow piles.
* **Carry:** lift a bin straight up — contents sit fully below the rim.
* **Stack:** the stacking socket accepts any bin from this system or a
  standard gridfinity bin; stacked height adds H − 4 mm, and the upper
  bin's pad tip stops 0.4 mm above the lower cavity, so contents never
  mix. Stack for transport, not for storage (it hides the label).

## Extending the system

Add one line to `LAYOUT` in `src/organizer.py` (grid cell, height units,
label, part name) and re-run:

    python src/organizer.py
    python src/check_assembly.py

New sizes (e.g. M5, or another M3 length) use the same three bin types;
the empty slot in column 5 is the reserved place in this patch. Larger
expansions: raise `COLS`/`ROWS` for a bigger plate, or print a second
5×4 plate — the bins are fully portable.

## Verification (measured)

`checks.json` records, per part: binary STL + watertight mesh, exact
bounding boxes (bins 41.5 × 41.5, plate 209.5 × 167.5 × 5.0), minimum
inter-bin gap 0.500 mm with zero overlap in the assembled layout,
per-compartment capacity vs the 20/30 targets, and label engraving
(volume delta on every bin, cap ≥ 4.3 mm). All checks pass.

## Physical fit test still required (honest limitations)

The capacities above are geometric bounds, not drop-tests. Check on the
real bench:

1. **Bin↔plate fit** — the 0.25 mm/side straight fit assumes a
   well-tuned printer; if a bin binds, wax the socket or ease it with
   a blade. Never sand the bin pad — it is the stacking interface too.
2. **M4 head diameter** — capacity allows 23 M4 screws at the standard
   7.0 mm head; oversized (7.2+) cheap heads reduce the margin.
3. **M2.5 hardware variant** — sized for ISO 4032 nuts (AF 5.0);
   older DIN 439 low nuts (AF 5.0) also fit, but some "M2.5" junk-nut
   assortments do not match any standard.
4. **Washer OD variants** — sized for DIN 125/ISO 7089 (M2–M4: 5/6/7/9
   OD); oversized flat washers still fit the 39 mm cavity but change the
   pile height.
5. **Stacking with other vendors' bins** — the lip follows the
   reference, but community tolerances vary; test one stack before
   relying on it.
6. **Label legibility** — print one bin first; the 4.3 mm cap on the
   longest label ("WASHER M2.5") is the densest text in the set.
7. **Drawer clearance** — needs 40 mm depth under the tallest bin
   (39.4 mm) plus lifting room, and 210 × 168 mm of patch.

## Files

    src/organizer.py        parametric source (single source of truth)
    src/check_assembly.py   verification (writes checks.json)
    cad/*.step              STEP per part (20)
    stl/*.stl               binary STL per part (20)
    assembly.json           part list + assembled transforms (mm)
    checks.json             measured checks
    build_report.json       build-time measurements (labels, volumes)
    assets/fillaprint/      the supplied font + OFL licence

Assembly convention: origin at the centre of the plate underside, +Z up,
drawer front at −Y; bin positions are the centre of the pad tip at
z = 0.1 (the resting height in the sockets).
