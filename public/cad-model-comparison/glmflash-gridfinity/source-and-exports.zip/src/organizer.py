#!/usr/bin/env python3
"""Gridfinity small-hardware organizer for machine screws, nuts and washers.

Parametric source (build123d). Geometry follows the official Gridfinity
Design Reference v5 (gridfinity.xyz, graphic by @willtree8) and Zack
Freedman's original system:

  * grid pitch 42 mm, height unit 7 mm
  * bin outer 41.5 x 41.5 (0.5 mm total tolerance), corner radius 3.75
  * male dovetail pad (bin bottom), 4.75 tall:
      tip 35.6 (r0.8) -> 0.8 flare -> 37.2 (r1.6) straight 1.8
      -> 2.15 flare -> 41.5 (r3.75) = wall
  * bin total height = 7*nz + 4.4 (stacking lip included)
  * bin-top stacking socket: 3.75 deep, mouth 40.0 -> 0.75 mm rim ring,
    straight bore 37.7 (0.25 mm/side fit to the pad)
  * baseplate: 5.0 mm slab, through-going dovetail sockets per cell:
      tip 36.1 at the underside -> 37.7 straight (1.8) -> 45 deg flare
      2.15 -> mouth 42.0 (r4.0, 8.0 mm corner discs per reference).
    A bin wedges 0.25 mm into the flare; its pad tip sits level with the
    plate underside, visible through the socket hole (original look).
  * radial fits 0.25 mm/side throughout (vector76 battle-tested values)

Fastener reference dims (verified tables):
  ISO 4762 socket head:  head dia / head height
      M2 3.8/2.0  M2.5 4.5/2.5  M3 5.5/3.0  M4 7.0/4.0
  ISO 4032 nuts:  across flats / height
      M2 4.0/1.6  M2.5 5.0/2.0  M3 5.5/2.4  M4 7.0/3.2
  DIN 125 / ISO 7089 washers:  OD / thickness
      M2 5.0/0.3  M2.5 6.0/0.5  M3 7.0/0.5  M4 9.0/0.8

Labels: supplied FilaPrint font, engraved 0.5 mm into
  (a) the inner face of the back wall (readable from above while seated)
  (b) the outer face of the front wall (readable for the front row / in hand)

Outputs: cad/*.step, stl/*.stl (binary), build_report.json, assembly.json
Run from the project root:
  python src/organizer.py
"""

import json
import os

from build123d import (
    Plane, Pos, RectangleRounded, Rot, Text, extrude, loft, mirror,
)

# ---------------------------------------------------------------- spec ----
PITCH = 42.0
Z_PITCH = 7.0
BIN_W = 41.5             # bin outer width/depth
R_OUT = 3.75             # bin/plate outer corner radius
PAD_H = 4.75             # male dovetail pad height
PAD_W_TIP, PAD_R_TIP = 35.6, 0.8
PAD_W_MID, PAD_R_MID = 37.2, 1.6
SOCK_CLEAR = 0.25        # radial fit, per side
LIP_H = 4.4              # stacking lip zone: bin total = 7*nz + LIP_H
LIP_DEPTH = 3.75         # stacking socket depth (vector76 fit)
LIP_MOUTH = 40.0         # socket mouth at the rim (0.75 rim ring)
LIP_MOUTH_R = 2.9
PLATE_H = 5.0
PLATE_SOCK_SECTIONS = [   # z, width, corner radius (z from plate underside);
    # socket ends 0.1 above the underside (reference: 0.25+2.15+1.8+0.7)
    (0.10, 36.1, 1.05),
    (0.90, 37.7, 1.85),
    (2.70, 37.7, 1.85),
    (4.85, 42.0, 4.00),
    (5.00, 42.0, 4.00),
]
BIN_SOCK_SECTIONS = [     # z offsets above 7*nz
    (0.00, 36.1, 1.05),
    (0.80, 37.7, 1.85),
    (2.60, 37.7, 1.85),
    (LIP_DEPTH, LIP_MOUTH, LIP_MOUTH_R),
]
WALL = 1.2
FLOOR_T = 1.8
CAV_R = 1.0               # cavity corner radius (keeps label zone flat)

COLS, ROWS = 5, 4
LABEL_DEPTH = 0.5
LABEL_BAND_DROP = 5.0     # band centre = 7*nz - 5.0
LABEL_MAX_W_INNER = 36.0  # flat region: 2*(19.55 - 1.0 - 0.55)
LABEL_MAX_W_OUTER = 34.0  # flat region: 2*(20.75 - 3.75)
LABEL_MIN_CAP = 3.5       # declared minimum cap height (mm)
LABEL_TARGET_CAP = 5.0
FONT_PATH = os.path.join("assets", "fillaprint", "Fillaprint-Regular.ttf")

# --------------------------------------------- fastener reference table ----
# thread: (head_dia, head_h, nut_af, nut_h, washer_od, washer_t)
FASTENERS = {
    "M2": (3.8, 2.0, 4.0, 1.6, 5.0, 0.3),
    "M2.5": (4.5, 2.5, 5.0, 2.0, 6.0, 0.5),
    "M3": (5.5, 3.0, 5.5, 2.4, 7.0, 0.5),
    "M4": (7.0, 4.0, 7.0, 3.2, 9.0, 0.8),
}

# ------------------------------------------------------------ bin types ----
# Starter assortment: 19 bins in a 5x4 patch.
#   rows 1..4 front->back (front = -Y), columns 1..5 left->right.
#   nz = height in 7 mm units; total height = 7*nz + 4.4.
# Column heights must be non-decreasing front->back so every bin's label
# stays visible over the bins in front of it.
LAYOUT = [
    # (col, row, nz, label, part name)
    (1, 1, 3, "WASHER M2", "bin_washer_m2"),
    (2, 1, 3, "WASHER M2.5", "bin_washer_m25"),
    (3, 1, 3, "WASHER M3", "bin_washer_m3"),
    (4, 1, 4, "M3 x 12", "bin_screw_m3x12"),
    (5, 1, 3, "WASHER M4", "bin_washer_m4"),
    (1, 2, 3, "NUT M2", "bin_nut_m2"),
    (2, 2, 3, "NUT M2.5", "bin_nut_m25"),
    (3, 2, 3, "NUT M3", "bin_nut_m3"),
    (4, 2, 4, "M3 x 16", "bin_screw_m3x16"),
    (5, 2, 3, "NUT M4", "bin_nut_m4"),
    (1, 3, 3, "M2 x 6", "bin_screw_m2x6"),
    (2, 3, 3, "M2.5 x 6", "bin_screw_m25x6"),
    (3, 3, 3, "M3 x 8", "bin_screw_m3x8"),
    (4, 3, 4, "M4 x 10", "bin_screw_m4x10"),
    (5, 3, 5, "M4 x 20", "bin_screw_m4x20"),
    (1, 4, 3, "M2 x 8", "bin_screw_m2x8"),
    (2, 4, 3, "M2.5 x 10", "bin_screw_m25x10"),
    (3, 4, 3, "M3 x 10", "bin_screw_m3x10"),
    (4, 4, 4, "M4 x 16", "bin_screw_m4x16"),
    # (5, 4) intentionally empty: extension slot for a future size
]

EMPTY_SLOT = (5, 4)


def bin_total_h(nz: float) -> float:
    return Z_PITCH * nz + LIP_H


def section(z: float, w: float, r: float):
    return Plane.XY.offset(z) * RectangleRounded(w, w, r)


def pad_male():
    """Male dovetail pad at the bin bottom (z 0 .. 4.75)."""
    return loft([
        section(0.0, PAD_W_TIP, PAD_R_TIP),
        section(0.8, PAD_W_MID, PAD_R_MID),
        section(2.6, PAD_W_MID, PAD_R_MID),
        section(PAD_H, BIN_W, R_OUT),
    ], ruled=True)


def socket_from_sections(sections):
    return loft([section(z, w, r) for (z, w, r) in sections], ruled=True)


def text_prism(label: str, max_w: float, band_center_z: float):
    """Engraving prism: reading surface at local y=0, body extends +Y.

    Readable from the front (-Y side). Auto-fits cap height to max_w.
    Returns (solid, measurement dict).
    """
    em = LABEL_TARGET_CAP / 0.60            # FilaPrint cap ratio 0.60
    sk = Text(label, font_size=em, font_path=FONT_PATH)
    bb = sk.bounding_box()
    width = bb.max.X - bb.min.X
    if width > max_w:
        em *= max_w / width
        sk = Text(label, font_size=em, font_path=FONT_PATH)
        bb = sk.bounding_box()
        width = bb.max.X - bb.min.X
    cap = bb.max.Y                           # baseline at y=0
    if cap < LABEL_MIN_CAP:
        raise ValueError(f"label '{label}' cap {cap:.2f} < {LABEL_MIN_CAP}")
    prism = extrude(sk, amount=LABEL_DEPTH)
    prism = mirror(Rot(90, 0, 0) * prism, about=Plane.XZ)
    prism = Pos(0, 0, band_center_z - cap / 2) * prism
    meas = {"em": em, "cap_mm": cap, "width_mm": width, "depth_mm": LABEL_DEPTH}
    return prism, meas


def make_bin(nz: float, label: str):
    """One 1x1 gridfinity bin with engraved labels; returns (part, info)."""
    h = bin_total_h(nz)
    cav_top = Z_PITCH * nz             # full-width cavity up to the inner lip
    cav_bot = PAD_H + FLOOR_T

    body = pad_male() + extrude(section(PAD_H, BIN_W, R_OUT), amount=h - PAD_H)

    sock = Pos(0, 0, cav_top) * socket_from_sections(
        [(dz, w, r) for (dz, w, r) in BIN_SOCK_SECTIONS])
    cav = extrude(section(cav_bot, BIN_W - 2 * WALL, CAV_R),
                  amount=cav_top - cav_bot)
    part = body - sock - cav

    vol_clean = part.volume

    band_z = Z_PITCH * nz - LABEL_BAND_DROP
    labels = []
    for face_name, face_y, max_w in (
        ("inner_back_wall", BIN_W / 2 - WALL, LABEL_MAX_W_INNER),
        ("outer_front_wall", -(BIN_W / 2), LABEL_MAX_W_OUTER),
    ):
        solid, meas = text_prism(label, max_w, band_z)
        meas["face"] = face_name
        meas["face_y"] = face_y
        solid = Pos(0, face_y, 0) * solid
        part = part - solid
        labels.append(meas)

    info = {
        "label": label,
        "nz": nz,
        "total_height_mm": h,
        "cavity_width_mm": BIN_W - 2 * WALL,
        "cavity_depth_mm": cav_top - cav_bot,
        "label_band_z_mm": [band_z - labels[0]["cap_mm"],
                            band_z + labels[0]["cap_mm"]],
        "labels": labels,
        "volume_mm3_nolabel": vol_clean,
        "volume_mm3": part.volume,
    }
    return part, info


def make_plate():
    """Original-style 5x4 baseplate: 5 mm slab, through dovetail sockets."""
    slab = extrude(
        Plane.XY * RectangleRounded(COLS * PITCH - 0.5, ROWS * PITCH - 0.5, R_OUT),
        amount=PLATE_H,
    )
    for i in range(COLS):
        for j in range(ROWS):
            x = (i - (COLS - 1) / 2) * PITCH
            y = ((ROWS - 1) / 2 - j) * PITCH
            sock = Pos(x, y, 0) * socket_from_sections(PLATE_SOCK_SECTIONS)
            slab = slab - sock
    return slab


def grid_xy(col: int, row: int):
    x = (col - (COLS + 1) / 2) * PITCH
    y = ((ROWS + 1) / 2 - row) * PITCH
    return x, y


def export_part(part, name):
    from build123d import export_step, export_stl
    export_step(part, f"cad/{name}.step")
    export_stl(part, f"stl/{name}.stl")


def main():
    os.makedirs("cad", exist_ok=True)
    os.makedirs("stl", exist_ok=True)

    assembly = {
        "system": "gridfinity",
        "pitch_mm": PITCH,
        "units": "mm",
        "origin": ("centre of the baseplate underside; +Z up; drawer front "
                   "is -Y; part positions refer to each part's own origin "
                   "(bins: centre of the dovetail pad tip)"),
        "parts": [],
        "empty_slots": [],
    }
    report = {"bins": [], "plate": {}}

    plate = make_plate()
    export_part(plate, "baseplate_5x4")
    report["plate"] = {
        "size_mm": [COLS * PITCH - 0.5, ROWS * PITCH - 0.5, PLATE_H],
        "socket_radial_fit_per_side_mm": SOCK_CLEAR,
        "bin_rest_height_mm": 0.1,
        "bin_rest_note": ("pad tip bottoms rest on the 0.1 mm socket floors; "
                          "lateral registration from the 0.25 mm/side "
                          "straight-section fit"),
        "volume_mm3": plate.volume,
    }
    assembly["parts"].append({
        "part": "baseplate_5x4",
        "step": "cad/baseplate_5x4.step",
        "stl": "stl/baseplate_5x4.stl",
        "position": [0.0, 0.0, 0.0],
        "rotation_deg": [0, 0, 0],
        "grid": None,
        "label": "BASEPLATE 5x4",
    })

    for col, row, nz, label, name in LAYOUT:
        part, info = make_bin(nz, label)
        export_part(part, name)
        x, y = grid_xy(col, row)
        info.update({"part": name, "col": col, "row": row, "x_mm": x, "y_mm": y})
        report["bins"].append(info)
        assembly["parts"].append({
            "part": name,
            "step": f"cad/{name}.step",
            "stl": f"stl/{name}.stl",
            "position": [x, y, 0.1],
            "rotation_deg": [0, 0, 0],
            "grid": {"col": col, "row": row},
            "label": label,
        })

    ext_x, ext_y = grid_xy(*EMPTY_SLOT)
    assembly["empty_slots"].append({
        "grid": {"col": EMPTY_SLOT[0], "row": EMPTY_SLOT[1]},
        "position": [ext_x, ext_y, 0.1],
        "note": "extension slot: drop in any standard 1x1 gridfinity bin",
    })

    with open("assembly.json", "w") as f:
        json.dump(assembly, f, indent=2)
    with open("build_report.json", "w") as f:
        json.dump(report, f, indent=2)
    print("built", len(LAYOUT) + 1, "parts")


if __name__ == "__main__":
    main()
