#!/usr/bin/env python3
"""Measured checks for the gridfinity hardware organizer.

Verifies function against the requested use:
  * every STL is a binary, watertight mesh
  * bin footprints are true 41.5 x 41.5 gridfinity (fits a 42 mm base)
  * the assembled 5x4 layout has no interference
  * every compartment provably holds its target contents
  * labels are engraved (volume delta) with >= 3.5 mm cap height

Run: python src/check_assembly.py
"""

import json
import math
import os

import numpy as np
import trimesh

PITCH = 42.0
BIN_W = 41.5
CAV_W = BIN_W - 2.4          # 39.1
COLS, ROWS = 5, 4
SOCK_CLEAR = 0.25
LIP_MOUTH = 40.0
PAD_H = 4.75
FLOOR_T = 1.8

FASTENERS = {   # head_dia, head_h, nut_af, nut_h, washer_od, washer_t
    "M2": (3.8, 2.0, 4.0, 1.6, 5.0, 0.3),
    "M2.5": (4.5, 2.5, 5.0, 2.0, 6.0, 0.5),
    "M3": (5.5, 3.0, 5.5, 2.4, 7.0, 0.5),
    "M4": (7.0, 4.0, 7.0, 3.2, 9.0, 0.8),
}


def is_binary_stl(path):
    size = os.path.getsize(path)
    if size < 84 or (size - 84) % 50 != 0:
        return False, None
    with open(path, "rb") as f:
        head = f.read(5)
    if head == b"solid":
        return False, None
    return True, (size - 84) // 50


def hex_pack_count(dia, box=CAV_W):
    """Hex-packed circles of diameter `dia` in a `box` square (bound)."""
    nx = int((box - dia) // dia) + 1
    row_h = dia * math.sqrt(3) / 2
    ny = int((box - dia) // row_h) + 1
    full = (ny + 1) // 2
    offset = ny // 2
    return full * nx + offset * (nx - 1)


def capacity(label, nz):
    depth = 7.0 * nz - (PAD_H + FLOOR_T)
    words = label.split()
    if words[0] == "WASHER":
        thread = words[1]
        od = FASTENERS[thread][4]
        t = FASTENERS[thread][5]
        per_layer = hex_pack_count(od + 1.0)
        layers = math.ceil(30 / per_layer)
        pile = layers * t * 1.6        # 1.6: loose scatter factor
        return {"content": "30 washers " + thread, "per_layer": per_layer,
                "pile_mm": round(pile, 1), "depth_mm": round(depth, 2),
                "ok": bool(pile <= depth)}
    if words[0] == "NUT":
        thread = words[1]
        af = FASTENERS[thread][2]
        nut_h = FASTENERS[thread][3]
        per_layer = hex_pack_count(af + 1.0)
        layers = math.ceil(30 / per_layer)
        pile = layers * nut_h
        return {"content": "30 nuts " + thread, "per_layer": per_layer,
                "pile_mm": round(pile, 1), "depth_mm": round(depth, 2),
                "ok": bool(pile <= depth)}
    thread = words[0]
    length = float(words[2])
    head_dia = FASTENERS[thread][0]
    head_h = FASTENERS[thread][1]
    count = hex_pack_count(head_dia + 0.8)
    stack = head_h + length
    return {"content": "20 screws %s x %g" % (thread, length),
            "screws_fit_standing": count, "stack_mm": stack,
            "depth_mm": round(depth, 2),
            "ok": bool(count >= 20 and stack <= depth)}


def main():
    assembly = json.load(open("assembly.json"))
    build = json.load(open("build_report.json"))
    checks = {"stl": {}, "assembly": {}, "interface": {}, "capacity": []}

    meshes = {}
    for part in assembly["parts"]:
        name = part["part"]
        binary, n_tri = is_binary_stl(part["stl"])
        m = trimesh.load(part["stl"], force="mesh")
        meshes[name] = m
        bb = m.bounds
        checks["stl"][name] = {
            "binary_stl": bool(binary),
            "triangles": n_tri,
            "watertight": bool(m.is_watertight),
            "volume_mm3": round(float(m.volume), 1),
            "bbox_mm": [round(float(v), 2) for v in (bb[1] - bb[0])],
        }

    plate_bb = meshes["baseplate_5x4"].bounds
    plate_size = [round(float(v), 2) for v in (plate_bb[1] - plate_bb[0])]
    checks["assembly"]["plate_size_mm"] = plate_size
    checks["assembly"]["plate_is_5x4_grid"] = bool(
        abs(plate_size[0] - (COLS * PITCH - 0.5)) < 0.05
        and abs(plate_size[1] - (ROWS * PITCH - 0.5)) < 0.05)

    bin_boxes = []
    footprints = {}
    for part in assembly["parts"]:
        if part["grid"] is None:
            continue
        m = meshes[part["part"]]
        pos = np.array(part["position"])
        b = m.bounds + pos
        bin_boxes.append((part["part"], b))
        foot = b[1] - b[0]
        footprints[part["part"]] = {
            "x_mm": round(float(foot[0]), 3),
            "y_mm": round(float(foot[1]), 3),
            "z_bottom_mm": round(float(b[0][2]), 3),
            "z_top_mm": round(float(b[1][2]), 3),
        }
    checks["assembly"]["bin_footprints"] = footprints

    min_gap = 1e9
    overlap = False
    n = len(bin_boxes)
    for i in range(n):
        for j in range(i + 1, n):
            a = bin_boxes[i][1]
            b = bin_boxes[j][1]
            gap_x = max(a[0][0] - b[1][0], b[0][0] - a[1][0])
            gap_y = max(a[0][1] - b[1][1], b[0][1] - a[1][1])
            gap = max(gap_x, gap_y)
            if gap < -0.01:
                overlap = True
            min_gap = min(min_gap, gap)
    checks["assembly"]["min_gap_between_bins_mm"] = round(float(min_gap), 3)
    checks["assembly"]["any_bin_overlap"] = bool(overlap)

    checks["interface"] = {
        "plate_socket_radial_fit_mm_per_side": SOCK_CLEAR,
        "bin_wedge_depth_in_plate_mm": 0.25,
        "stack_socket_mouth_mm": LIP_MOUTH,
        "stack_rim_ring_mm": round((BIN_W - LIP_MOUTH) / 2, 3),
        "stack_straight_bore_mm": 37.7,
        "pad_straight_mm": 37.2,
        "stack_fit_mm_per_side": 0.25,
    }

    for b in build["bins"]:
        entry = capacity(b["label"], b["nz"])
        entry["part"] = b["part"]
        checks["capacity"].append(entry)

    cap_ok = all(e["ok"] for e in checks["capacity"])
    caps = [lab["cap_mm"] for b in build["bins"] for lab in b["labels"]]
    cut_ok = all(b["volume_mm3_nolabel"] > b["volume_mm3"]
                 for b in build["bins"])
    checks["labels"] = {
        "cap_min_mm": round(min(caps), 2),
        "cap_max_mm": round(max(caps), 2),
        "engraved_on_every_bin": bool(cut_ok),
    }

    checks["all_passed"] = bool(cap_ok and not overlap and min_gap >= 0.4
                                and cut_ok and min(caps) >= 3.5)
    with open("checks.json", "w") as f:
        json.dump(checks, f, indent=2)

    print("all_passed:", checks["all_passed"])
    print("plate:", plate_size)
    print("min gap between bins: %.3f mm (design 0.5)" % min_gap)
    for e in checks["capacity"]:
        tag = "OK  " if e["ok"] else "FAIL"
        if "screws_fit_standing" in e:
            print(tag, e["part"], ":", e["screws_fit_standing"],
                  "screws standing (need 20), stack",
                  e["stack_mm"], "<= depth", e["depth_mm"])
        else:
            print(tag, e["part"], ":", e["content"], ", pile",
                  e["pile_mm"], "<= depth", e["depth_mm"])
    bad = []
    for name, e in checks["stl"].items():
        if not (e["binary_stl"] and e["watertight"]):
            bad.append(name)
    print("binary+watertight failures:", bad or "none")
    print("label cap heights: %.2f..%.2f mm, engraved: %s"
          % (min(caps), max(caps), cut_ok))


if __name__ == "__main__":
    main()
