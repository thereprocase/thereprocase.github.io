# Gridfinity fastener organizer (M2 / M2.5 / M3 / M4 starter set)

Parametric Gridfinity organizer for socket-head screws, hex nuts and flat
washers on a hobby bench: a 5x4 open-frame baseplate plus 18 labelled 1x1
bins. Original geometry, built with build123d; labels are debossed with the
supplied FillaPrint font (no stickers, no AI images).

## Starter layout (what belongs where)

One row per size, front row = M2. `S` = screw bin, `N` = nut bin, `W` = washer
bin, `D` = divided bin (two compartments), `.` = spare cell for extension.

| cell (col,row) | content | bin | height |
|---|---|---|---|
| (0,0) (1,0) | 20x M2x6, M2x10 socket-head screws (ISO 4762) | S | 2u (18.4 mm) |
| (2,0) (3,0) | 30x M2 hex nuts / flat washers (ISO 4032 / 7089) | N / W | 2u |
| (4,0) | **spare** (extension point, e.g. M2x8) | - | - |
| (0,1) (1,1) | 20x M2.5x6, M2.5x10 screws | S | 2u |
| (2,1) (3,1) | 30x M2.5 nuts / washers | N / W | 2u |
| (4,1) | **spare** (extension point, e.g. M2.5x12) | - | - |
| (0,2)..(3,2) | 20x M3x6, x10, x16, x20 screws | S | 2u |
| (4,2) | 30x M3 nuts (left) + 30x M3 washers (right) | D | 2u |
| (0,3)..(2,3) | 20x M4x10, x16, x20 screws | S | 3u (25.4 mm) |
| (3,3) (4,3) | 30x M4 nuts / washers | N / W | 2u |

Rationale: M3 gets the most lengths (the bench workhorse), M2/M2.5 get the two
most common lengths, M4 gets three. M4 screw bins are 3u because 20 long M4
screws need the volume (measured fill 52%); everything else is 2u so small
parts stay near the top and easy to pinch. Worst-case fill is 52% of the
compartment volume, so a bin can be lifted and carried without spilling.

## Bin family (few reusable types)

All bins share one parametric body (`src/gf_bin.py`): standard Gridfinity base
profile, standard stacking lip, 1.2 mm walls, interior floor at 5.75 mm with a
45 deg chamfer all around (no sharp internal corners; parts slide out, one
washer can be scooped with a fingertip), 4x magnet pockets (6.5 mm dia x 2.4 mm
for 6x2 magnets) with concentric 3.2 mm M3 screw holes, and a debossed front
label. Variants are parameters:

* **S** single compartment, `height_u` 2 or 3
* **N / W** same as S, only the label differs (hexagon = nut, ring = washer)
* **D** adds a 1.2 mm divider -> two 18.95 mm compartments; the divider top
  stops 1.0 mm below the body top so a stacked bin's base clears it
  (measured 0.55 mm worst-case clearance)

## Interfaces and clear spaces (as designed)

* Grid: 42 mm pitch, bin footprint 41.5 mm (0.5 mm per-cell clearance).
* Base profile per spec: 35.6 / 37.2 / 37.2 / 41.5 mm wide at z = 0 / 0.8 /
  2.6 / 4.75 mm (45 deg chamfers), corner radii R0.8 / R1.6 / R3.75.
* Height: total = 7*u + 4.4 mm (2u = 18.4, 3u = 25.4), lip 4.4 mm.
* Stacking lip funnel: spec profile + 0.10 mm extra radial clearance;
  registers a stacked bin's base at its top edge with measured 0.07 mm median
  clearance and no interference. Stacks with standard Gridfinity bins both
  ways (my base is exact spec; my throat is 36.5 mm >= 35.6 mm standard foot).
* Baseplate: 210 x 168 x 4.75 mm open frame; cell openings are the bin base
  profile + 0.25 mm radial clearance, R4 outer corners. Bins' bottom faces
  rest on the drawer surface through the open frame; lifted alone, a bin hangs
  on its chamfers protruding ~0.25 mm below the frame (standard behaviour).
* Clear interior: 39.1 mm wide, floor at 5.75 mm, usable depth 8.25 mm (2u) /
  15.25 mm (3u); lip throat 36.5 mm.

## Labels

* FillaPrint-Regular (supplied, SIL OFL 1.1 - license in `assets/fillaprint/`),
  debossed 0.6 mm: permanent and paint-fillable. Every bin carries the same
  marking **twice**:
  * **Front face** (outer, vertical): cap 6.5 mm - visible on the front row
    and whenever a bin is pulled forward or carried to a project.
  * **Inner back wall** (top of the wall, facing up-front): cap 6.0 mm on 2u
    bins / 6.5 mm on 3u bins - visible over the row in front when looking
    into the grid from above-front (verified by ray test at 45 deg elevation
    for every bin), so rear rows read without lifting anything.
* FillaPrint strokes are exactly cap/7 (font docs: "cap height = 14 x line
  width"), so 6.5 / 6.0 mm caps give 0.93 / 0.86 mm strokes = exactly two
  0.46 / 0.43 mm extrusion beads - at/above the font's designed minimum.
  Print with line width <= 0.45 mm (any 0.4 mm nozzle profile).
* Screw bins read e.g. `M3x10` (x = U+00D7). Nuts carry a hexagon ring,
  washers a circle ring, next to the size (`M2.5`); the divided bin shows
  hexagon + size + ring on the front (left symbol = left compartment) and
  symbol + size per half on the back wall. Symbols are debossed with
  1.4 mm grooves.

## Handling

* One washer / short screw: compartments are shallow (8.25 mm) with a
  chamfered floor edge; press the part against a wall and slide it up, or tilt
  the bin and pinch. In the divided bin, work one compartment at a time with
  one finger.
* Lifting a bin: bins seat by their base profile; lift straight up. Neighbours
  are untouched (0.5 mm gaps, no inter-bin features). Fill is <= 52%, walls
  are full height, nothing spills.
* Stacking: all bins stack (same-height rows stack best). Labels are a
  in-base feature and are covered when stacked - stacking is for transport and
  spare bins, not for reading.
* Magnets: press 6x2 mm magnets into the four bottom pockets of each bin
  (glue if loose); bins then grip a steel drawer through the open frame.
  Alternatively M3 screws through the concentric 3.2 mm holes.

## Extending with another size

Everything is table-driven in `src/assortment.py`: add e.g.
`screw("M2", 8, 2, (4, 0))` for the spare cell, or new sizes (M5: add its
head/nut/washer dimensions to the dicts at the top). Re-run
`python build.py`. The bin generator takes
height, label and divider parameters, so new compartment text is a one-line
change. Current generator makes 1x1 bins only (see Limitations).

## Measured checks (from exported STLs, `out/checks.json`, 53 checks, all pass)

* Base profile stations: 35.7 / 37.2 / 37.2 / 41.4 mm measured at
  z = 0.05 / 0.9 / 2.5 / 4.7 mm (spec: 35.6 / 37.2 / 37.2 / 41.4 there).
* Every part: watertight single solid, binary STL (84 + 50*n bytes), bounding
  box within 0.05 mm of nominal.
* Interior: clear width 39.1 mm, floor z = 5.75 mm, lip throat 36.6 mm.
* Magnet pocket floor at 2.4 mm, M3 screw hole through to 4.75 mm.
* Bin seated in baseplate cell: min clearance 0.15 mm (at the pulled-in top
  ridge), 0.18 mm median perpendicular clearance on the 45 deg seat chamfers
  (= 0.25 mm radial), 0 interfering sample points (1068 pts).
* Stacking 2u-on-2u: registers at the lip top edge (designed contact),
  median clearance 0.07 mm elsewhere, 0 interfering points; boolean
  intersection volume at the 13.65 mm stack offset: **0.0 mm3** - both
  ordinary-bin-on-ordinary-bin and ordinary-bin-on-the-divided-M3-bin
  (an earlier revision intersected here through the divider top).
* Divider top at 13.0 mm: 0.65 mm clearance to a stacked foot (nominal),
  0.55 mm at maximum lip drop.
* Labels: glyph grooves measured 0.6 mm deep on the front face and on the
  inner back wall; stroke 0.93 mm (front) / 0.86 mm (rear) = two 0.46/0.43 mm
  beads (font minimum respected).
* Rear-label visibility: sightlines from every rear-row bin's back-wall label
  toward the viewer at 45 deg elevation clear the bin in front - 13/13 bins,
  10/10 sample rays each. (Base seating, neighbour clearance and withdrawal
  re-verified unchanged.)
* Capacity vs real fastener dimensions (ISO 4762/4032/7089, packing factor
  0.6): worst fill 52% (M3x20, M4x20); all <= 52%.

## What still needs a physical fit test

1. **Printer tolerances on the base/lip interface.** The stack registers with
   designed surface contact at the lip top edge; if your printer runs tight or
   loose, adjust `LIP_CLEAR` in `src/gf_common.py` (+/- 0.05..0.1) and the
   baseplate's `OPEN_CLEAR` in `src/gf_baseplate.py` likewise. Test with one
   bin + a 2x2 plate section before printing all 19 parts.
2. **Real hardware variance.** Capacities use ISO/DIN nominal dimensions;
   vendor heads, nut heights and washers vary. 52% worst fill leaves margin,
   but verify your actual M4x20 screws pour comfortably.
3. **Magnet fit.** Pockets are 6.5 mm dia x 2.4 mm for nominal 6x2 mm magnets;
   magnet tolerance varies by vendor - glue if loose, ream if tight.
4. **Label legibility** depends on filament contrast; debossed grooves can be
   paint-filled (acrylic marker, wipe the face) for high contrast.
5. **Baseplate flatness**: a 210 x 168 mm open frame can warp on some
   printers/materials; print flat with good bed adhesion (brim if needed).

## Printing notes

No supports anywhere: all overhangs are <= 45 deg, the two horizontal hole
ceilings (magnet 6.5 mm, screw 3.2 mm dia) bridge. 0.4 mm nozzle, line width
<= 0.46 mm (labels), 3-4 perimeters, 15-25% infill. PLA or PETG.

## Limitations (honest)

* Generator makes 1x1 bins only; multi-unit bins would need the multi-cell
  base bridging added to `gf_bin.py`.
* The stacking lip top is the spec's exact registration edge (effectively a
  knife edge in CAD; prints as ~0.3 mm). Chosen for correct stacking; the
  gridfinity-rebuilt project rounds it 0.6 mm instead.
* Label visibility: the back-wall labels read from above-front (verified at
  45 deg elevation). At exactly 0 deg elevation (eye level) a rear row's
  markings are physically hidden by the 18.4 mm tall row in front - no dense
  42 mm grid of equal-height bins can avoid that; only the front row reads at
  0 deg. Read the grid from above, or pull a bin forward to use its front
  label.
* In the fullest 2u bins (fill > ~50%, e.g. M3x20 completely full) the top of
  the contents can touch the bottom edge of the back-wall label; the marking
  is still identifiable, and the front label is the backup.
* Labels are hidden while bins are stacked; stacking is for transport/spares.
* Bin bottoms protrude ~0.25 mm below the baseplate frame if the plate is
  lifted with bins hanging (standard open-frame behaviour; irrelevant on a
  drawer surface).
* Capacity numbers are volumetric estimates with a 0.6 packing factor, not a
  physical pour test.

## Files

* `src/gf_common.py` - Gridfinity spec constants + loft helper
* `src/gf_bin.py` - parametric bin (height, label, divider)
* `src/gf_baseplate.py` - parametric baseplate
* `src/assortment.py` - starter assortment + layout table (edit to extend)
* `build.py` - builds everything into `out/` (+ `assembly.json`)
* `checks.py` - measured verification (trimesh), writes `out/checks.json`
* `out/stl/*.stl` (binary), `out/step/*.step`, `out/assembly.step`,
  `assembly.json`

## Licenses

FillaPrint font: SIL Open Font License 1.1 (see `assets/fillaprint/OFL.txt`).
Gridfinity is CC BY-NC-SA by Zack Freedman; design reference v5 by willtree8.
This parametric implementation is original geometry; license your remixes
accordingly.
