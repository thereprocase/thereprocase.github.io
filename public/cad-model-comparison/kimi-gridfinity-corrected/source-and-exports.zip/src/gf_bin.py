"""Parametric Gridfinity fastener bin.

One reusable bin body, parameterised by:
  height_u     height in gridfinity units (2 or 3 in this assortment)
  front_label  label items for the outer front face
  rear_labels  [(items, x_centre)] debossed into the inner back wall, visible
               over the row in front when looking from above-front
  divider      if True, split the interior into two left/right compartments

Label items: ("text", "M3x10") | ("hex",) hexagon ring = hex nut |
             ("ring",) circle ring = washer

Labels are debossed 0.6 mm using the FillaPrint font. FillaPrint strokes are
exactly cap/7 (font docs: "cap height = 14 x line width"), so:
  cap 6.5 mm -> 0.93 mm strokes = two 0.46 mm beads (front labels)
  cap 6.0 mm -> 0.86 mm strokes = two 0.43 mm beads (rear labels of 2u bins)
Both are at/above the font's designed minimum for the corresponding line width.
"""
from build123d import (
    Mode, BuildPart, BuildSketch, Plane, Locations, Axis,
    Box, Cylinder, Text, Circle, RegularPolygon, RectangleRounded, extrude, Align,
)
from fontTools.ttLib import TTFont

from gf_common import (
    BIN_W, R_TOP, WALL, UNIT_H, LIP_H, BASE_H, BASE_PROFILE, FLOOR_Z,
    MAGNET_D, MAGNET_DEPTH, MAGNET_XY, SCREW_D,
    lip_funnel, cavity_profile, sectioned_loft,
)

BASE_H_TOP = BASE_H  # screw hole stops here (1.0 mm below cavity floor)

FRONT_CAP_MM = 6.5        # front label cap height (two 0.46 mm beads)
REAR_CAP_MM = {2: 6.0, 3: 6.5}   # rear label cap height per bin height
LABEL_DEPTH = 0.6
FRONT_LABEL_Z = 9.4       # front label centre height
LABEL_GAP = 2.0           # gap between symbol and text
SYMBOL_R = 3.6            # symbol outer radius (scaled with cap/6.5)
SYMBOL_RING = 1.4         # symbol groove width
REAR_TOP_MARGIN = 0.15    # rear label top edge below body top

# Divider top must stay clear of a stacked bin's base: a stacked bin's foot
# bottom registers at body_top - 0.35 (worst case body_top - 0.45 with the
# extra lip clearance), so the divider ends 1.0 mm below body top.
DIVIDER_TOP_DROP = 1.0

_font_cache = {}

def _text_width_mm(s, cap_mm, font_path):
    if font_path not in _font_cache:
        f = TTFont(font_path)
        _font_cache[font_path] = (f["hmtx"], f.getBestCmap())
    hmtx, cmap = _font_cache[font_path]
    units = sum(hmtx[cmap[ord(c)]][0] for c in s)
    return units / 700.0 * cap_mm      # cap height = 700 units


def _layout(label, font_path, cap_mm):
    """Return [(kind, payload, x_centre)] for the label, centred on x=0."""
    widths = []
    for item in label:
        if item[0] == "text":
            widths.append(_text_width_mm(item[1], cap_mm, font_path))
        else:
            widths.append(2 * SYMBOL_R * cap_mm / 6.5)
    total = sum(widths) + LABEL_GAP * (len(label) - 1)
    out, x = [], -total / 2
    for item, w in zip(label, widths):
        out.append((item[0], item[1] if len(item) > 1 else None, x + w / 2))
        x += w + LABEL_GAP
    return out


def _sketch_label(plane, groups, cap_mm, font_path):
    """Draw label groups on `plane`. groups: [(items, x_offset)]. Returns the sketch."""
    with BuildSketch(plane) as sk:
        for items, x_off in groups:
            for kind, payload, xc in _layout(items, font_path, cap_mm):
                with Locations((x_off + xc, 0)):
                    if kind == "text":
                        Text(payload, font_size=cap_mm / 0.7,
                             font_path=font_path,
                             align=(Align.CENTER, Align.CENTER))
                    elif kind == "hex":
                        r = SYMBOL_R * cap_mm / 6.5
                        RegularPolygon(r, 6)
                        RegularPolygon(r - SYMBOL_RING, 6, mode=Mode.SUBTRACT)
                    elif kind == "ring":
                        r = SYMBOL_R * cap_mm / 6.5
                        Circle(r)
                        Circle(r - SYMBOL_RING, mode=Mode.SUBTRACT)
    return sk.sketch


def make_bin(height_u=2, front_label=None, rear_labels=None, divider=False,
             font_path="assets/fillaprint/Fillaprint-Regular.ttf"):
    body_top = UNIT_H * height_u
    top = body_top + LIP_H
    inner = BIN_W - 2 * WALL
    inner_face = BIN_W / 2 - WALL          # 19.55

    with BuildPart() as bp:
        # ---- base profile + body block (solid) ----
        sectioned_loft(BASE_PROFILE)                                  # base
        with BuildSketch(Plane.XY.offset(BASE_PROFILE[-1][2])):
            RectangleRounded(BIN_W, BIN_W, R_TOP)
        extrude(amount=top - BASE_PROFILE[-1][2])                     # body + lip block

        # ---- interior cavity with 45 deg floor chamfer ----
        sectioned_loft(cavity_profile(body_top), mode=Mode.SUBTRACT)

        # ---- stacking-lip funnel ----
        sectioned_loft(lip_funnel(body_top), mode=Mode.SUBTRACT)

        # ---- divider (optional; top below the stacking throat) ----
        if divider:
            div_top = body_top - DIVIDER_TOP_DROP
            with Locations((0, 0, FLOOR_Z - 0.1)):
                Box(1.2, inner + 0.4, div_top - FLOOR_Z + 0.1,
                    align=(Align.CENTER, Align.CENTER, Align.MIN))

        # ---- magnet pockets + M3 screw holes ----
        for sx in (-1, 1):
            for sy in (-1, 1):
                with Locations((sx * MAGNET_XY, sy * MAGNET_XY, -0.05)):
                    Cylinder(MAGNET_D / 2, MAGNET_DEPTH + 0.05,
                             align=(Align.CENTER, Align.CENTER, Align.MIN), mode=Mode.SUBTRACT)
                    Cylinder(SCREW_D / 2, BASE_H_TOP + 0.05,
                             align=(Align.CENTER, Align.CENTER, Align.MIN), mode=Mode.SUBTRACT)

        # ---- debossed front label (outer front face) ----
        if front_label:
            plane = Plane(origin=(0, -BIN_W / 2 - 0.2, FRONT_LABEL_Z),
                          x_dir=(1, 0, 0), z_dir=(0, -1, 0))
            sk = _sketch_label(plane, [(front_label, 0.0)], FRONT_CAP_MM, font_path)
            extrude(sk, amount=-(0.2 + LABEL_DEPTH), mode=Mode.SUBTRACT)

        # ---- debossed rear label (inner back wall, top of wall) ----
        if rear_labels:
            cap = REAR_CAP_MM[height_u]
            zc = body_top - REAR_TOP_MARGIN - cap / 2
            plane = Plane(origin=(0, inner_face - 0.2, zc),
                          x_dir=(1, 0, 0), z_dir=(0, -1, 0))
            sk = _sketch_label(plane, rear_labels, cap, font_path)
            extrude(sk, amount=-(0.2 + LABEL_DEPTH), mode=Mode.SUBTRACT)

    part = bp.part
    assert len(part.solids()) == 1, "bin is not a single solid"
    part.label = f"bin_{height_u}u"
    return part


def rear_center_z(height_u):
    """Z centre of the rear label band (used by checks)."""
    return UNIT_H * height_u - REAR_TOP_MARGIN - REAR_CAP_MM[height_u] / 2


if __name__ == "__main__":
    p = make_bin(2, front_label=[("text", "M3×10")], rear_labels=[([("text", "M3×10")], 0.0)])
    print("volume:", round(p.volume, 1), "bbox:", p.bounding_box().size)
