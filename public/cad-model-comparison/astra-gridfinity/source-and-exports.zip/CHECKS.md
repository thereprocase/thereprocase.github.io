# Measured checks

All exact Boolean interference tests passed at a 0.00001 mm³ threshold. Tests load the exported STEP files.

| Representative | Clear volume below stack seat | Ordered count |
|---|---:|---:|
| M3_20mm | 31.47 cm³ | 20 |
| M4_20mm | 41.29 cm³ | 20 |
| M4_NUT | 23.39 cm³ | 30 |
| M4_WASH | 23.38 cm³ | 30 |

Clear volumes subtract the scoop, shelf, walls and stacking transition. They are not rectangular usable boxes. A 20 mm screw is checked with its head added: 23 mm total for M3 and 24 mm for M4.

Capacity witnesses use M3 heads Ø5.5 × 3 mm with Ø3 × 20 mm shafts; M4 heads Ø7 × 4 mm with Ø4 × 20 mm shafts. Nut envelopes are solid Ø8.2 × 3.3 mm cylinders (enclosing a plain M4 hex nut); washer envelopes are solid Ø9.2 × 0.9 mm discs. Holes and socket recesses are omitted conservatively. Each witness has zero item-to-bin and item-to-item overlap. Smaller selected hardware fits within the corresponding largest envelope when head-aligned. This does not establish random packing, fastener tolerances, or finger access when filled.

Base seating, vertical withdrawal at 0.2 / 1 / 3 / 5 mm, and stacking were checked on the representative labeled bins. Adjacent-bin bounding boxes are separated by 0.5 mm. Labels cannot bridge that gap. All share identical feet.

Foot stations (z, width, corner radius): (0,35.6,0.8), (0.8,37.2,1.6), (2.6,37.2,1.6), (4.75,41.5,3.75). Sockets offset that profile by 0.25 mm per side. Base socket starts at z=2 and ends at z=6.4, leaving 0.7 mm webs. Bin feet seat on the solid base floor.

Stacking sockets begin at the nominal height and end 3.8 mm above it, leaving a 0.7 mm top wall and a 0.95 mm gap below the upper bin body. A 34.8 mm throat gives 0.4 mm nominal bearing per side beneath the 35.6 mm foot. The internal transition is supported at 45°. Physical cross-compatibility and bearing strength remain untested.

All 21 STLs: binary encoding, watertight, consistently wound, positive volume and one connected component. Maximum STEP/STL volume discrepancy: 0.0068%. All source CAD exports are valid single solids.

Font dimensions are measured per label in assembly.json. Mesh tessellation: 0.025 mm linear and 0.08 rad angular tolerance. Exact checks do not model FDM tolerances.
