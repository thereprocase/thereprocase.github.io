"""Conservative cylinder-envelope packing witnesses, in mm, not a pouring simulation."""
import math,json
from pathlib import Path

def inside(x,y,z,h,R):
 if abs(x)>18.6 or abs(y)>18.6 or z<7.05 or z>h-2.4: return False
 if y< -18.75+R and z<7+R and (y-(-18.75+R))**2+(z-(7+R))**2>(R-.05)**2:return False
 if y>=4.45 and z>=h-1.05-y:return False
 # conservative rounded-cavity corner
 if abs(x)>17 and abs(y)>17 and (abs(x)-17)**2+(abs(y)-17)**2>1.6**2:return False
 return True

def screws(h,hd,sd,headlen,length):
 R=19;rad=hd/2+.1; pitch=(hd+sd)/2+.3
 best=[]
 for a in range(15):
  for b in range(15):
   pts=[]
   for j in range(10):
    for k in range(10):
     y=-18.5+rad+a*.4+j*pitch;z=7.1+rad+b*.4+k*pitch
     if all(inside(0,y+rad*math.cos(t*math.pi/30),z+rad*math.sin(t*math.pi/30),h,R) for t in range(60)):
      pts.append({'xyz':[0,y,z],'reverse':bool((j+k)%2)})
   if len(pts)>len(best):best=pts
   if len(best)>=20:return {'height':h,'head_diameter':hd,'shaft_diameter':sd,'head_length':headlen,'shaft_length':length,'positions':best[:20], 'count':20,'grid_pitch':pitch}
 raise ValueError(('insufficient screw count',h,len(best)))

def discs(d,t):
 rad=d/2;h=28;R=12;best=[]
 for a in range(9):
  for b in range(9):
   pts=[]
   for i in range(4):
    for j in range(5):
     for k in range(15):
      x=-1.5*(d+.2)+i*(d+.2);y=-18.5+rad+a*.4+j*(d+.2);z=7.1+b*.2+k*(t+.15)
      if all(inside(x+rad*math.cos(q*math.pi/16),y+rad*math.sin(q*math.pi/16),zz,h,R) for q in range(32) for zz in [z,z+t]):
       pts.append({'xyz':[x,y,z]})
   if len(pts)>len(best):best=pts
   if len(best)>=30:return {'height':28,'diameter':d,'thickness':t,'positions':best[:30],'count':30}
 raise ValueError(('insufficient discs',d,t,len(best)))

if __name__=='__main__':
 data={'M3_20mm':screws(35,5.5,3,3,20),'M4_20mm':screws(42,7,4,4,20),'M4_NUT':discs(8.2,3.3),'M4_WASH':discs(9.2,.9)}
 Path('output/capacity_witnesses.json').write_text(json.dumps(data,indent=2)); print({k:v['count'] for k,v in data.items()})
