# Research record

Retrieved 2026-11-03, only through the requested HTTP proxy.

- [Gridfinity community specification](https://gridfinity.xyz/specification/), including its [dimensioned v5 drawing](https://gridfinity.xyz/assets/img/spec_draft_willtree8.jpg). Saved as `gridfinity.html` and `spec.jpg`. Drawing credited to willtree8, based on Zack Freedman's Gridfinity. It labels itself draft/WIP. Used for 42 mm pitch, 41.5 mm bin width, 7 mm vertical units, foot widths and 0.8 / 1.8 / 2.15 mm height transitions. Original CAD was constructed from dimensions, not imported geometry.
- [Gridfinity Extended constants](https://github.com/ostat/gridfinity_extended_openscad/blob/main/modules/gridfinity_constants.scad), saved as `constants.scad`, cross-checks foot transitions and shows the reduced 3.8 mm lip-height convention. This design uses an explicitly dimensioned matching foot socket with its top trimmed to 3.8 mm; it does not claim to reproduce every standard lip detail.
- Supplied `Fillaprint-Regular.ttf`: inspected with fontTools. Units per em 1000; cap height 700. Embedded name ID 10 says: “Two-bead FDM font: every stroke is exactly two extrusion widths (w). Fusion text Height = 14 x line width (cap height); em = 20 x line width.” Thus 0.4 mm line width requires 8 mm em and 5.6 mm cap height. The font is supplied with OFL.txt.

Attempts to retrieve fastener supplier dimension tables from Accu, Bolt Depot, Fastenal and Fastenerdata returned challenge pages or missing pages. Those responses were not used as dimensional evidence. The fastener dimensions in CHECKS.md are explicit design envelopes, not claims that every supplier's hardware was verified. Check actual hardware, especially oversized washers and nonstandard socket heads.
