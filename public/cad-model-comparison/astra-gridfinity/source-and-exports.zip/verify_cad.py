from design import *
from itertools import combinations
A=json.loads((ROOT/'assembly.json').read_text())
report={'method':'Exact OCCT Boolean interference on exported STEP; cylinder-envelope capacity witnesses; dimensions in mm','interfaces':{},'bins':{},'capacity':{}}
reps={n:import_step(OUT/f'{n}.step') for n in ['M3_20mm','M4_20mm','M4_NUT','M4_WASH']}
basepart=import_step(OUT/'base_5x4.step')
def vol(s): return sum(x.volume for x in s.solids()) if s else 0.
def assertclear(a,b):
 v=vol(a&b);assert v<1e-5,v;return v
for name,b in reps.items():
 h=next(p['stack_pitch_mm'] for p in A['parts'] if p['id']==name)
 full=extrude(rr(37.5,1.75,7),amount=h-7)
 void=full-b
 r={'usable_void_below_stack_seat_mm3':vol(void),'floor_z':7,'stack_seat_z':h,'label_top_z':h-3.4,'overall_height':b.bounding_box().size.Z,'inner_width':37.5,'upper_throat_width':34.8,'front_access_depth':21.9,'main_wall':2.,'rim_min_wall':.7}
 r['base_interference_mm3']=assertclear(Pos(0,0,2)*b,basepart)
 r['vertical_withdrawal_max_interference_mm3']=max(assertclear(Pos(0,0,2+dz)*b,basepart) for dz in [.2,1,3,5])
 r['stack_interference_mm3']=assertclear(b,Pos(0,0,h)*reps['M4_20mm'])
 # Fingers are geometric gauges, not a human-factors test.
 r['finger_entry_16mm_diameter_interference']=assertclear(b,Pos(0,-5,h-5)*Cylinder(8,14,align=(Align.CENTER,Align.CENTER,Align.MIN)))
 r['fingertip_12mm_at_floor_interference']=assertclear(b,Pos(0,0,13.2)*Sphere(6))
 report['bins'][name]=r;print(name,r,flush=True)
C=json.loads((OUT/'capacity_witnesses.json').read_text())
for name,d in C.items():
 items=[]
 for p in d['positions']:
  if 'head_diameter' in d:
   le=d['shaft_length'];hl=d['head_length']; start=-(le+hl)/2
   head=Pos(start+hl/2,0,0)*Cylinder(d['head_diameter']/2,hl,rotation=(0,90,0))
   shaft=Pos(start+hl+le/2,0,0)*Cylinder(d['shaft_diameter']/2,le,rotation=(0,90,0))
   item=head+shaft
   if p['reverse']:item=Rot(0,0,180)*item
  else:item=Cylinder(d['diameter']/2,d['thickness'],align=(Align.CENTER,Align.CENTER,Align.MIN))
  items.append(Pos(*p['xyz'])*item)
 # Pairwise bounding boxes prune nonoverlapping fixtures; exact tests for the remainder.
 pairmax=0
 for a,b in combinations(items,2):
  aa=a.bounding_box();bb=b.bounding_box()
  if all(tuple(aa.min)[i]<tuple(bb.max)[i] and tuple(bb.min)[i]<tuple(aa.max)[i] for i in range(3)):pairmax=max(pairmax,assertclear(a,b))
 cv=assertclear(reps[name],Compound(children=items))
 report['capacity'][name]={'verified_count':len(items),'bin_interference_mm3':cv,'item_pair_interference_mm3':pairmax,'envelope':'Solid cylindrical nut/washer envelopes; socket head plus solid shaft for screws. Ordered placement demonstrates capacity, not random-pour packing.'}
 print('capacity',name,flush=True)
report['interfaces']={'pitch':42,'bin_outer_width':41.5,'neighbor_gap':.5,'foot_stations_z_width_radius':[[0,35.6,.8],[.8,37.2,1.6],[2.6,37.2,1.6],[4.75,41.5,3.75]],'socket_radial_clearance':.25,'base_floor':2,'base_top':6.4,'base_top_web':.7,'stack_lip_height_above_seat':3.8,'bin_body_gap_when_stacked':.95,'label_clearance_below_upper_foot':3.4}
(OUT/'measured_checks.json').write_text(json.dumps(report,indent=2))
print('CAD CHECKS PASSED',flush=True)
