"""Original parametric Gridfinity hardware bins. Run with build123d 0.13.
Coordinates: foot bottom z=0; front=-Y; label reads from front.
"""
from build123d import *
from pathlib import Path
import json, math
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'; OUT.mkdir(exist_ok=True)
FONT=ROOT/'assets/fillaprint/Fillaprint-Regular.ttf'
PITCH=42.; OUTER=41.5; INNER=37.5; FLOOR=7.; CLEARANCE=.25
LINE_WIDTH=.4; FONT_EM=20*LINE_WIDTH; LABEL_RELIEF=.6
BASE_FLOOR=2.; BASE_TOP=6.4
SCREW_UNITS={'M2':5,'M2.5':5,'M3':5,'M4':6}
SIZES=[('M2',[6,8,12]),('M2.5',[6,10,16]),('M3',[8,12,20]),('M4',[10,16,20])]

def rr(w,r,z): return Plane.XY.offset(z)*RectangleRounded(w,w,r)
def profile(stations): return loft([rr(w,r,z) for z,w,r in stations],ruled=True)
def foot(): return profile([(0,35.6,.8),(.8,37.2,1.6),(2.6,37.2,1.6),(4.75,41.5,3.75)])
def socket(z=0,top=4.4):
    c=CLEARANCE
    return profile([(z,35.6+2*c,.8+c),(z+.8,37.2+2*c,1.6+c),(z+2.6,37.2+2*c,1.6+c),(z+top,37.2+2*c+2*(top-2.6),1.6+c+top-2.6)])
def block(x,y,z,cx=0,cy=0,bottom=0):
    return Pos(cx,cy,bottom)*Box(x,y,z,align=(Align.CENTER,Align.CENTER,Align.MIN))
def wedge_shelf(h):
    # 45-degree supported shelf, ending at y=4.5. top 4 mm below seat.
    top=h-4; rear=18.75; front=4.5
    wire=Wire.make_polygon([(-18.75,rear,top-15.75),(-18.75,front,top-1.5),(-18.75,front,top),(-18.75,rear,top)],close=True)
    return extrude(Face(wire),amount=37.5,dir=(1,0,0))
def blank(units):
    h=7*units; radius=12 if units<=4 else 19
    outer=extrude(rr(OUTER,3.75,4.75),amount=h+3.8-4.75)
    cavity=extrude(rr(INNER,1.75,FLOOR),amount=h-2.35-FLOOR)
    cavity+=profile([(h-2.35,37.5,1.75),(h-1,34.8,.4),(h,34.8,.4)])
    cavity+=socket(h,3.8)
    b=foot()+outer-cavity
    # Quarter-circle scoop: cylinder removes the concave surface from a solid block.
    rampbox=block(INNER,radius,radius,cy=-18.75+radius/2,bottom=FLOOR)
    cyl=Pos(0,-18.75+radius,FLOOR+radius)*Cylinder(radius,40,rotation=(0,90,0))
    ramp=(rampbox-cyl)&extrude(rr(INNER,1.75,FLOOR),amount=radius)
    b=b+ramp+(wedge_shelf(h)&outer)
    return b

def labeled(units,diam,kind):
    b=blank(units); metrics=[]
    for line,y in [(diam,14.9),(kind,8.1)]:
        txt=Text(line,font_size=FONT_EM,font_path=str(FONT),align=(Align.CENTER,Align.CENTER))
        bb=txt.bounding_box(); assert bb.size.X<33 and bb.size.Y<=5.61,(line,bb)
        txt=Pos(0,y,7*units-4-.02)*extrude(txt,amount=LABEL_RELIEF+.02)
        b+=txt
        metrics.append({'text':line,'width_mm':bb.size.X,'height_mm':bb.size.Y,'em_mm':FONT_EM})
    return b,metrics

def base(nx=5,ny=None):
    ny=len(SIZES) if ny is None else ny
    b=block(nx*PITCH,ny*PITCH,BASE_TOP,cx=(nx-1)*PITCH/2,cy=(ny-1)*PITCH/2)
    for row in range(ny):
        for col in range(nx): b-=Pos(col*PITCH,row*PITCH,0)*socket(BASE_FLOOR,BASE_TOP-BASE_FLOOR+.001)
    return b

def save(name,part):
    assert part.is_valid and len(part.solids())==1,(name,'invalid',len(part.solids()))
    export_step(part,OUT/f'{name}.step')
    export_stl(part,OUT/f'{name}.stl',tolerance=.025,angular_tolerance=.08,ascii_format=False)
    bb=part.bounding_box()
    return {'id':name,'step':f'output/{name}.step','stl':f'output/{name}.stl','volume_mm3':part.volume,'bounds_mm':{'min':list(bb.min),'max':list(bb.max)},'solids':len(part.solids()),'valid':part.is_valid}

def main():
    parts=[]; instances=[]; checks={}
    base_id=f'base_5x{len(SIZES)}'
    p=base(); parts.append(save(base_id,p)); instances.append({'part':base_id,'translation_mm':[0,0,0],'rotation_xyz_deg':[0,0,0]});print('base saved',flush=True)
    for row,(diam,lengths) in enumerate(SIZES):
        for col,kind in enumerate([f'{n}mm' for n in lengths]+['NUT','WASH']):
            units=SCREW_UNITS.get(diam,6) if col<3 else 4
            name=f'{diam.replace(".","p")}_{kind}'
            b,labels=labeled(units,diam,kind)
            record=save(name,b);record.update({'type':f'screw_{units}U' if col<3 else 'small_4U','labels':labels,'contents':f'{diam} {kind}','target_count':20 if col<3 else 40,'stack_pitch_mm':7*units})
            parts.append(record); instances.append({'part':name,'translation_mm':[42*col,42*row,BASE_FLOOR],'rotation_xyz_deg':[0,0,0]})
            print(name,'saved',flush=True)
    for inst in instances:
        x,y,z=inst['translation_mm']
        inst['transform_4x4']=[[1,0,0,x],[0,1,0,y],[0,0,1,z],[0,0,0,1]]
    data={'units':'mm','coordinate_system':'+Z up, front=-Y, rows from front M2/M2.5/M3/M4; origins at first cell center and base underside','parts':parts,'instances':instances,'stacking':'A bin above a lower bin is translated by lower_bin_units*7 in Z; starter assembly is unstacked.'}
    (ROOT/'assembly.json').write_text(json.dumps(data,indent=2))
if __name__=='__main__': main()
