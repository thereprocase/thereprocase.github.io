# Gridfinity bench hardware starter

Twenty removable bins on one **210 × 168 × 6.4 mm base**. Each cell is 42 mm pitch; each bin is 41.5 mm wide. The assembled maximum height is **47.8 mm**. All dimensions are millimeters.

## What goes where

Rows run front to back; columns run left to right. Screw labels show thread diameter on the first line and under-head length, including `mm`, on the second. `NUT` means plain hex nut; `WASH` means ordinary flat washer, not a large/fender washer.

| Row | Screw 1 | Screw 2 | Screw 3 | Nuts | Washers |
|---|---|---|---|---|---|
| M2 | 6 mm | 8 mm | 12 mm | M2 | M2 |
| M2.5 | 6 mm | 10 mm | 16 mm | M2.5 | M2.5 |
| M3 | 8 mm | 12 mm | 20 mm | M3 | M3 |
| M4 | 10 mm | 16 mm | 20 mm | M4 | M4 |

This provides short, medium and longer screws for each diameter without allocating every permutation. Target: **20 screws or 30 nuts/washers per bin**. Keep different lengths separate.

Two body styles share one interface: the screw scoop uses 5U for M2–M3 and 6U for M4; the shallow hardware scoop uses 4U. Overall heights are 38.8, 45.8 and 31.8 mm respectively. A unit is 7 mm of stacking pitch.

## Handling

Read the permanent raised labels from above/front. They use the supplied Fillaprint TTF directly: **8 mm em, 5.6 mm capitals, 0.8 mm nominal strokes, 0.6 mm relief**, matching the font's two-bead minimum at 0.4 mm extrusion width. No font substitution or compressed text. Labels are integral solids; contrasting paint on the raised faces would improve contrast but is not included.

The 37.5 mm-wide cavity has a broad curved front scoop (12 mm radius for hardware, 19 mm for screws). Roll or slide a small part onto the curve to pinch it; the retaining front wall means this is not a pour-out chute. The upper opening is 34.8 mm wide, with **21.9 mm clear front-to-label depth**. A 16 mm finger-entry gauge and 12 mm fingertip gauge near the floor clear the modeled walls. These are geometric checks, not ergonomic proof for every hand.

Hook a fingertip beneath the front edge of the rear label shelf and stabilize the bin with your thumb on its rim; lift straight up. The shelf stays inside the footprint. Neighbors have 0.5 mm separation and no interlocking handles or magnets to disturb them. Keep bins upright; they are open containers, not spillproof transport boxes. A full bin's grip strength needs physical testing.

For reserve stock, stack one bin directly over another. The receiving seat is 28, 35 or 42 mm above the lower bin's foot. All three heights share the socket. Labels stay 3.4 mm below the next foot. Stacking hides the lower contents and label, so the starter layout is deliberately unstacked. Unstack before taking parts out. No lids or magnets are included.

## Files and regeneration

- `design.py`: complete build123d source; `SIZES`, `SCREW_UNITS`, `CLEARANCE`, font and geometry parameters are near the top.
- `output/`: one STEP and binary STL for each of the 20 labeled bins and the base.
- `assembly.json`: file inventory, measured solid properties, and actual assembled transforms. Matrices act on column vectors; local bin origin is the foot center at z=0. Base origin is below the first cell; bins sit at z=2.
- `capacity.py`, `verify_cad.py`, `verify_mesh.py`: reproducible functional and export checks; reports and packing coordinates are in `output/`.
- `assets/fillaprint/`: original font and its OFL license.

Run from this directory:

```sh
python design.py
python capacity.py
python verify_cad.py
python verify_mesh.py
```

Add a diameter row to `SIZES` and choose its screw height in `SCREW_UNITS`; regeneration extends the base by one 42 mm row. Alternatively reuse a cell or make a separate base with `base(nx, ny)`. Recheck capacities for new hardware. The verification scripts cover this starter assortment, not arbitrary parameter choices. A larger extrusion width requires larger text and a renewed shelf-fit check.

## Before relying on a printed set

No physical fabrication, slicing or load testing was performed. Test one bin against your ordinary base and this base against a known Gridfinity bin; check elephant-foot and shrinkage effects before making twenty. Check stacking stability, the 0.7 mm rim, raised label readability, a single thin washer pickup, and lifting twenty loaded M4 screws. The 45° shelf support and curved scoop are modeled without separate support parts, but print behavior remains untested. Capacity checks prove ordered fit, not a guaranteed loose-pour fill count. Hardware dimensions must match the envelopes in `CHECKS.md`.
