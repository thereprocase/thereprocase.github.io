import json,struct
from pathlib import Path
import trimesh
root=Path(__file__).resolve().parent
a=json.loads((root/'assembly.json').read_text());out=[]
for p in a['parts']:
 path=root/p['stl'];m=trimesh.load_mesh(path);raw=path.read_bytes();faces=struct.unpack('<I',raw[80:84])[0]
 assert len(raw)==84+50*faces
 assert m.is_watertight and m.is_winding_consistent and m.volume>0,p['id']
 assert len(m.split())==1,p['id']
 err=abs(m.volume-p['volume_mm3'])/p['volume_mm3'];assert err<.002,(p['id'],err)
 out.append({'part':p['id'],'binary':True,'triangles':faces,'watertight':m.is_watertight,'connected_components':1,'positive_volume':True,'relative_step_mesh_volume_error':err,'bounds_mm':m.bounds.tolist()})
(root/'output/mesh_checks.json').write_text(json.dumps(out,indent=2));print('PASS',len(out),'binary watertight single-component STLs')
